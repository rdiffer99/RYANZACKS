# FlyFF.sln

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\FlyFF.sln`
Chemin relatif: `FlyFF.sln`
Nom du fichier: `FlyFF.sln`
Extension originale: `.sln`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 18
VisualStudioVersion = 18.9.12120.119 stable
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "AccountServer", "AccountServer\AccountServer.vcxproj", "{FF113D29-9F20-4D4D-BF94-26F0C67CB78D}"
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "CacheServer", "CacheServer\CacheServer.vcxproj", "{11F05019-EF07-4A5B-B143-7B569374E837}"
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "Certifier", "Certifier\Certifier.vcxproj", "{BEEB1DDB-9C3C-43E4-831F-3ECAE53092A1}"
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "CoreServer", "CoreServer\CoreServer.vcxproj", "{E441E1BD-55F2-4649-A7D0-020CA5327C0C}"
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "DatabaseServer", "DatabaseServer\DatabaseServer.vcxproj", "{701A20E7-5272-467E-B8F3-656DB21959D9}"
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "LoginServer", "LoginServer\LoginServer.vcxproj", "{073CA223-A87D-4CC7-AFBF-8A4D022CA502}"
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "Neuz", "Neuz\Neuz.vcxproj", "{5B8B5D21-B3B4-4141-9233-C9A235C46E13}"
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "WorldServer", "WorldServer\WorldServer.vcxproj", "{D048E8BF-104D-480C-B029-2CE86D064841}"
EndProject
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "WorldDialog", "WORLDDIALOG\WorldDialog.vcxproj", "{8F3C6B25-95BE-4669-A67C-C27354DB0F54}"
EndProject
Project("{2150E333-8FDC-42A3-9474-1A3956D46DE8}") = "CustomCommon", "CustomCommon", "{87BE18AA-9A20-48DD-84D9-07C645E052FD}"
	ProjectSection(SolutionItems) = preProject
		_Common\CustomCommon.h = _Common\CustomCommon.h
	EndProjectSection
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Release|Win32 = Release|Win32
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{FF113D29-9F20-4D4D-BF94-26F0C67CB78D}.Release|Win32.ActiveCfg = Release|Win32
		{FF113D29-9F20-4D4D-BF94-26F0C67CB78D}.Release|Win32.Build.0 = Release|Win32
		{11F05019-EF07-4A5B-B143-7B569374E837}.Release|Win32.ActiveCfg = Release|Win32
		{11F05019-EF07-4A5B-B143-7B569374E837}.Release|Win32.Build.0 = Release|Win32
		{BEEB1DDB-9C3C-43E4-831F-3ECAE53092A1}.Release|Win32.ActiveCfg = Release|Win32
		{BEEB1DDB-9C3C-43E4-831F-3ECAE53092A1}.Release|Win32.Build.0 = Release|Win32
		{E441E1BD-55F2-4649-A7D0-020CA5327C0C}.Release|Win32.ActiveCfg = Release|Win32
		{E441E1BD-55F2-4649-A7D0-020CA5327C0C}.Release|Win32.Build.0 = Release|Win32
		{701A20E7-5272-467E-B8F3-656DB21959D9}.Release|Win32.ActiveCfg = Release|Win32
		{701A20E7-5272-467E-B8F3-656DB21959D9}.Release|Win32.Build.0 = Release|Win32
		{073CA223-A87D-4CC7-AFBF-8A4D022CA502}.Release|Win32.ActiveCfg = Release|Win32
		{073CA223-A87D-4CC7-AFBF-8A4D022CA502}.Release|Win32.Build.0 = Release|Win32
		{5B8B5D21-B3B4-4141-9233-C9A235C46E13}.Release|Win32.ActiveCfg = Release|Win32
		{5B8B5D21-B3B4-4141-9233-C9A235C46E13}.Release|Win32.Build.0 = Release|Win32
		{5B8B5D21-B3B4-4141-9233-C9A235C46E13}.Release|Win32.Deploy.0 = Release|Win32
		{D048E8BF-104D-480C-B029-2CE86D064841}.Release|Win32.ActiveCfg = Release|Win32
		{D048E8BF-104D-480C-B029-2CE86D064841}.Release|Win32.Build.0 = Release|Win32
		{8F3C6B25-95BE-4669-A67C-C27354DB0F54}.Release|Win32.ActiveCfg = Release|Win32
		{8F3C6B25-95BE-4669-A67C-C27354DB0F54}.Release|Win32.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {73CC256F-585D-4ED2-B335-7350EC3CB430}
	EndGlobalSection
EndGlobal
```
