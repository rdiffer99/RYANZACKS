# connection.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DiscordSDK\src\connection.h`
Chemin relatif: `DiscordSDK\src\connection.h`
Nom du fichier: `connection.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#pragma once

// This is to wrap the platform specific kinds of connect/read/write.

#include <stdint.h>
#include <stdlib.h>

// not really connectiony, but need per-platform
int GetProcessId();

struct BaseConnection {
    static BaseConnection* Create();
    static void Destroy(BaseConnection*&);
    bool isOpen{false};
    bool Open();
    bool Close();
    bool Write(const void* data, size_t length);
    bool Read(void* data, size_t length);
};
```
