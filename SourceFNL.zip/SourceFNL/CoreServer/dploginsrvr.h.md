# dploginsrvr.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CoreServer\dploginsrvr.h`
Chemin relatif: `CoreServer\dploginsrvr.h`
Nom du fichier: `dploginsrvr.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __DPLOGINSRVR_H__
#define __DPLOGINSRVR_H__

#pragma once

#include "DPMng.h"

#undef	theClass
#define theClass	CDPLoginSrvr
#undef	theParameters
#define theParameters	CAr & ar

class CDPLoginSrvr : public CDPMng
{
public:
	CDPLoginSrvr();
	virtual	~CDPLoginSrvr();

	virtual void	SysMessageHandler( LPDPMSG_GENERIC lpMsg, DWORD dwMsgSize, DPID idFrom );
	virtual void	UserMessageHandler( LPDPMSG_GENERIC lpMsg, DWORD dwMsgSize, DPID idFrom );

	void	SendQueryRemovePlayer( const CHAR* lpszAccount );
//	Handlers
	USES_PFNENTRIES;

	void	OnAddConnection( DPID dpid );
	void	OnRemoveConnection( DPID dpid );

	void	OnQueryTickCount( CAr & ar );
	void	OnPreJoin( CAr & ar );
	void	OnLeave( CAr & ar );
};

#endif	// __DPLOGINSRVR_H__
```
