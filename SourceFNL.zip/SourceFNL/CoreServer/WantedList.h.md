# WantedList.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CoreServer\WantedList.h`
Chemin relatif: `CoreServer\WantedList.h`
Nom du fichier: `WantedList.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __WANTEDLIST__H
#define __WANTEDLIST__H

#include "misc.h"		// WANTED_ENTRY
#include "ar.h"


#endif // __WANTEDLIST__H
```
