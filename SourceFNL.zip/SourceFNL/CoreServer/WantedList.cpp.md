# WantedList.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CoreServer\WantedList.cpp`
Chemin relatif: `CoreServer\WantedList.cpp`
Nom du fichier: `WantedList.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "WantedList.h"
#include <algorithm>
#include "dpdatabaseclient.h"

extern	CDPDatabaseClient	g_dpDatabaseClient;

```
