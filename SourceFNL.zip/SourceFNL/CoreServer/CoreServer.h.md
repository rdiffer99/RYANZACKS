# CoreServer.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CoreServer\CoreServer.h`
Chemin relatif: `CoreServer\CoreServer.h`
Nom du fichier: `CoreServer.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp

#if !defined(AFX_CORESERVER_H__EF414209_2F99_495F_989A_6A2BD65EB5B9__INCLUDED_)
#define AFX_CORESERVER_H__EF414209_2F99_495F_989A_6A2BD65EB5B9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_CORESERVER_H__EF414209_2F99_495F_989A_6A2BD65EB5B9__INCLUDED_)
```
