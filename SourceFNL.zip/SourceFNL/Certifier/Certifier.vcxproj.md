# Certifier.vcxproj

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\Certifier\Certifier.vcxproj`
Chemin relatif: `Certifier\Certifier.vcxproj`
Nom du fichier: `Certifier.vcxproj`
Extension originale: `.vcxproj`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup Label="ProjectConfigurations">
    <ProjectConfiguration Include="Debug|Win32">
      <Configuration>Debug</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Release|Win32">
      <Configuration>Release</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
  </ItemGroup>
  <PropertyGroup Label="Globals">
    <VCProjectVersion>16.0</VCProjectVersion>
    <ProjectGuid>{BEEB1DDB-9C3C-43E4-831F-3ECAE53092A1}</ProjectGuid>
    <WindowsTargetPlatformVersion>10.0</WindowsTargetPlatformVersion>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.Default.props" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>true</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <CharacterSet>MultiByte</CharacterSet>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>false</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <WholeProgramOptimization>true</WholeProgramOptimization>
    <CharacterSet>MultiByte</CharacterSet>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.props" />
  <ImportGroup Label="ExtensionSettings">
  </ImportGroup>
  <ImportGroup Label="Shared">
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <PropertyGroup Label="UserMacros" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <LinkIncremental>true</LinkIncremental>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <LinkIncremental>false</LinkIncremental>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
  </PropertyGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <ClCompile>
      <AdditionalIncludeDirectories>..\DX_SDK;..\..\resource;..\_network;..\_Network\Net\Include;..\_Network\Misc\Include;.;..\_Network\Mcl\Include;..\_DirectX;..\_Common;..\_database;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;_DEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level3</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreadedDebug</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>odbc32.lib;odbccp32.lib;ws2_32.lib;d3dx9.lib;winmm.lib</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\Lib;..\_Network\Mcl\Lib\Release</AdditionalLibraryDirectories>
      <GenerateDebugInformation>true</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <ClCompile>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <AdditionalIncludeDirectories>..\DX_SDK;..\..\resource;..\_network;..\_Network\Net\Include;..\_Network\Misc\Include;.;..\_Network\Mcl\Include;..\_DirectX;..\_Common;..\_database;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;NDEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <FunctionLevelLinking>true</FunctionLevelLinking>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level1</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreaded</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>odbc32.lib;odbccp32.lib;ws2_32.lib;d3dx9.lib;winmm.lib</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\Lib;..\_Network\Mcl\Lib\Release</AdditionalLibraryDirectories>
      <GenerateDebugInformation>DebugFull</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
      <EnableCOMDATFolding>
      </EnableCOMDATFolding>
      <OptimizeReferences>
      </OptimizeReferences>
      <LinkTimeCodeGeneration />
      <LinkTimeCodeGenerationObjectFile />
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemGroup>
    <ClCompile Include="AccountMgr.cpp">
    </ClCompile>
    <ClCompile Include="certifier.cpp">
    </ClCompile>
    <ClCompile Include="DBManager.cpp">
    </ClCompile>
    <ClCompile Include="dpaccountclient.cpp">
    </ClCompile>
    <ClCompile Include="DPCertifier.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">Create</PrecompiledHeader>
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">Create</PrecompiledHeader>
    </ClCompile>
    <ClCompile Include="user.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
    </ClCompile>
    <ClCompile Include="..\_Network\Net\Src\crc.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\DoS.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\dos2.cpp">
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\mytrace.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\file.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\Rijndael.cpp" />
    <ClCompile Include="..\_Common\timer.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\vutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\scanner.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\des.c">
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
      </PrecompiledHeader>
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
      </PrecompiledHeader>
    </ClCompile>
	<ClCompile Include="..\_database\Query.cpp">
	</ClCompile>
<ClCompile Include="..\_Common\ZckSpdLog.cpp">
  <PrecompiledHeader>NotUsing</PrecompiledHeader>
  <AdditionalIncludeDirectories>..\ThirdParty\spdlog\include;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
  <AdditionalOptions>/EHsc /utf-8 /Zc:__cplusplus %(AdditionalOptions)</AdditionalOptions>
</ClCompile>
	</ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="certifier.rc" />
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="AccountMgr.h" />
    <ClInclude Include="certifier.h" />
    <ClInclude Include="DBManager.h" />
    <ClInclude Include="dpaccountclient.h" />
    <ClInclude Include="DPCertifier.h" />
    <ClInclude Include="..\_Common\memtrace.h" />
    <ClInclude Include="resource.h" />
    <ClInclude Include="StdAfx.h" />
    <ClInclude Include="user.h" />
    <ClInclude Include="VersionCommon.h" />
    <ClInclude Include="..\_network\cmnhdr.h" />
    <ClInclude Include="..\_network\MsgHdr.h" />
    <ClInclude Include="..\_network\mcl\include\cmcl.h" />
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h" />
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h" />
    <ClInclude Include="..\_network\net\include\buffer.h" />
    <ClInclude Include="..\_network\net\include\clientsock.h" />
    <ClInclude Include="..\_network\net\include\clientsocke.h" />
    <ClInclude Include="..\_Network\Net\Include\crc.h" />
    <ClInclude Include="..\_network\net\include\dpmng.h" />
    <ClInclude Include="..\_network\net\include\dpsock.h" />
    <ClInclude Include="..\_network\net\include\serversock.h" />
    <ClInclude Include="..\_network\net\include\serversocke.h" />
    <ClInclude Include="..\_network\net\include\sock.h" />
    <ClInclude Include="..\_network\misc\include\ar.h" />
    <ClInclude Include="..\_network\misc\include\DoS.h" />
    <ClInclude Include="..\_network\misc\include\dos2.h" />
    <ClInclude Include="..\_network\misc\include\heapmng.h" />
    <ClInclude Include="..\_network\misc\include\mempool.h" />
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H" />
    <ClInclude Include="..\_network\misc\include\Misc.h" />
    <ClInclude Include="..\_network\misc\include\mymap.h" />
    <ClInclude Include="..\_network\misc\include\mytrace.h" />
    <ClInclude Include="..\_common\data.h" />
    <ClInclude Include="..\_common\debug.h" />
    <ClInclude Include="..\_Common\DefineCommon.h" />
    <ClInclude Include="..\_Common\file.h" />
    <ClInclude Include="..\_Common\Rijndael.h" />
    <ClInclude Include="..\_Common\timer.h" />
    <ClInclude Include="..\_common\vutil.h" />
    <ClInclude Include="..\_common\xutil.h" />
    <ClInclude Include="..\_DirectX\dxutil.h" />
    <ClInclude Include="..\_Common\scanner.h" />
    <ClInclude Include="..\_Database\des.h" />
    <ClInclude Include="..\_database\Query.h" />
	<ClInclude Include="..\_Common\ZckSpdLog.h" />
  </ItemGroup>
  <ItemGroup>
    <Image Include="certifier.ico" />
    <Image Include="small.ico" />
  </ItemGroup>
  <ItemGroup>
    <None Include="Certifier.ini" />
  </ItemGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.targets" />
  <ImportGroup Label="ExtensionTargets">
  </ImportGroup>
</Project>
```
