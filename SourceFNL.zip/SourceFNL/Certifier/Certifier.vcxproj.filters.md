# Certifier.vcxproj.filters

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\Certifier\Certifier.vcxproj.filters`
Chemin relatif: `Certifier\Certifier.vcxproj.filters`
Nom du fichier: `Certifier.vcxproj.filters`
Extension originale: `.filters`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup>
    <Filter Include="Source Files">
      <UniqueIdentifier>{85c28766-5234-4858-8012-b1676ea9b4bd}</UniqueIdentifier>
      <Extensions>cpp;c;cxx;rc;def;r;odl;idl;hpj;bat</Extensions>
    </Filter>
    <Filter Include="Header Files">
      <UniqueIdentifier>{90e74333-f743-45b7-aa03-b5ca57e5ac6e}</UniqueIdentifier>
      <Extensions>h;hpp;hxx;hm;inl</Extensions>
    </Filter>
    <Filter Include="Resource Files">
      <UniqueIdentifier>{ffa9a75a-0f1b-4b44-9574-f126a3a1bf00}</UniqueIdentifier>
      <Extensions>ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe</Extensions>
    </Filter>
    <Filter Include="Network Files">
      <UniqueIdentifier>{e40257e9-215c-4ca0-8b5a-726901018cb4}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Mcl">
      <UniqueIdentifier>{597db8ec-f1a8-4911-9fab-1cc9d7083803}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Net">
      <UniqueIdentifier>{5413a825-1b67-414b-b042-49ca7fb3c22f}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Misc">
      <UniqueIdentifier>{69a0d3bf-ed50-4ec7-b419-09ecd3c219b1}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files">
      <UniqueIdentifier>{375712d2-8ec6-45db-bfb5-3fff0f9cf50d}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files\DX">
      <UniqueIdentifier>{2b6fc40b-8e48-4936-9613-01a25d1a2e60}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files\Script">
      <UniqueIdentifier>{63d9f7c6-2dfb-4fa8-acf5-8a9ec832e3d6}</UniqueIdentifier>
    </Filter>
    <Filter Include="ODBC Files">
      <UniqueIdentifier>{c57151ff-4baa-4210-a0b4-746cdf7e2cbc}</UniqueIdentifier>
    </Filter>
  </ItemGroup>
  <ItemGroup>
    <ClCompile Include="AccountMgr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="certifier.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DBManager.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="dpaccountclient.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPCertifier.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="user.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Net\Src\crc.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\DoS.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\dos2.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\mytrace.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
      <Filter>Neuz Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\file.cpp">
      <Filter>Neuz Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Rijndael.cpp">
      <Filter>Neuz Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\timer.cpp">
      <Filter>Neuz Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\vutil.cpp">
      <Filter>Neuz Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
      <Filter>Neuz Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
      <Filter>Neuz Common Files\DX</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\scanner.cpp">
      <Filter>Neuz Common Files\Script</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\des.c">
      <Filter>ODBC Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_database\Query.cpp">
      <Filter>ODBC Files</Filter>
    </ClCompile>
  </ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="certifier.rc">
      <Filter>Source Files</Filter>
    </ResourceCompile>
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="AccountMgr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="certifier.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DBManager.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="dpaccountclient.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPCertifier.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\memtrace.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="resource.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="StdAfx.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="user.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="VersionCommon.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\cmnhdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\MsgHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmcl.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\buffer.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_Network\Net\Include\crc.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpmng.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\sock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ar.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\DoS.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\dos2.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\heapmng.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mempool.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\Misc.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mymap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mytrace.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\data.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\debug.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\DefineCommon.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\file.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Rijndael.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\timer.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\vutil.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\xutil.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_DirectX\dxutil.h">
      <Filter>Neuz Common Files\DX</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\scanner.h">
      <Filter>Neuz Common Files\Script</Filter>
    </ClInclude>
    <ClInclude Include="..\_Database\des.h">
      <Filter>ODBC Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_database\Query.h">
      <Filter>ODBC Files</Filter>
    </ClInclude>
  </ItemGroup>
  <ItemGroup>
    <Image Include="certifier.ico">
      <Filter>Resource Files</Filter>
    </Image>
    <Image Include="small.ico">
      <Filter>Resource Files</Filter>
    </Image>
  </ItemGroup>
  <ItemGroup>
    <None Include="Certifier.ini">
      <Filter>Resource Files</Filter>
    </None>
  </ItemGroup>
</Project>
```
