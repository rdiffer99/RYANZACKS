# pngexifinfo.bat

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngexif\pngexifinfo.bat`
Chemin relatif: `lpng1658\contrib\pngexif\pngexifinfo.bat`
Nom du fichier: `pngexifinfo.bat`
Extension originale: `.bat`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```bat
@echo off
@setlocal enableextensions

python.exe -BES %~dp0.\pngexifinfo.py %*
```
