# README.md

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngexif\README.md`
Chemin relatif: `lpng1658\contrib\pngexif\README.md`
Nom du fichier: `README.md`
Extension originale: `.md`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```markdown
pngexifinfo
===========

Show the EXIF information embedded in a PNG file.


Sample usage
------------

Show the EXIF info inside a PNG file:

    pngexifinfo /path/to/file.png

Show the EXIF info inside a raw `.exif` file, using base 16 for the EXIF tags:

    pngexifinfo --hex /path/to/file.exif

Show the help text:

    pngexifinfo --help
```
