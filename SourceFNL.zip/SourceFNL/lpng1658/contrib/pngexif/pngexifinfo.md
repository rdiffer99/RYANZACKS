# pngexifinfo

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngexif\pngexifinfo`
Chemin relatif: `lpng1658\contrib\pngexif\pngexifinfo`
Nom du fichier: `pngexifinfo`
Extension originale: `(aucune)`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
#!/bin/sh
set -eu

my_python="$(command -v python3 || command -v python)" || {
    echo >&2 "error: program not found: Python interpreter"
    exit 127
}
my_python_flags="-BES"

exec "$my_python" "$my_python_flags" "$(dirname "$0")/pngexifinfo.py" "$@"
```
