# README

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngminim\decoder\README`
Chemin relatif: `lpng1658\contrib\pngminim\decoder\README`
Nom du fichier: `README`
Extension originale: `(aucune)`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
This demonstrates the use of PNG_USER_CONFIG, pngusr.h and pngusr.dfa

The makefile builds a minimal read-only decoder with embedded libpng
and zlib.

Specify the location of the zlib source (1.2.1 or later) as ZLIBSRC
on the make command line.

If you prefer to use the shared libraries, go to contrib/pngminus
and build the png2pnm application there.
```
