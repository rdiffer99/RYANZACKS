# pngusr.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngminim\encoder\pngusr.h`
Chemin relatif: `lpng1658\contrib\pngminim\encoder\pngusr.h`
Nom du fichier: `pngusr.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
/* minwrpngconf.h: headers to make a minimal png-write-only library
 *
 * Copyright (c) 2007, 2010-2013 Glenn Randers-Pehrson
 *
 * This code is released under the libpng license.
 * For conditions of distribution and use, see the disclaimer
 * and license in png.h
 *
 * Derived from pngcrush.h, Copyright 1998-2007, Glenn Randers-Pehrson
 */

#ifndef MINWRPNGCONF_H
#define MINWRPNGCONF_H

/* To include pngusr.h set -DPNG_USER_CONFIG in CPPFLAGS */

/* List options to turn off features of the build that do not
 * affect the API (so are not recorded in pnglibconf.h)
 */

#define PNG_ALIGN_TYPE PNG_ALIGN_NONE

#endif /* MINWRPNGCONF_H */
```
