# README

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngminim\encoder\README`
Chemin relatif: `lpng1658\contrib\pngminim\encoder\README`
Nom du fichier: `README`
Extension originale: `(aucune)`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
This demonstrates the use of PNG_USER_CONFIG and pngusr.h

The makefile builds a minimal write-only encoder with embedded libpng
and zlib.

Specify the location of the zlib source (1.2.1 or later) as ZLIBSRC
on the make command line.

If you prefer to use the shared libraries, go to contrib/pngminus
and build the pnm2png application there.
```
