# verify-windows.yml

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\.github\workflows\verify-windows.yml`
Chemin relatif: `lpng1658\.github\workflows\verify-windows.yml`
Nom du fichier: `verify-windows.yml`
Extension originale: `.yml`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```yaml
name: Verifying libpng on Windows

on:
  push:
    branches:
      - libpng16
      - libpng18
  pull_request:
    branches:
      - libpng16
      - libpng18

jobs:
  verify-windows:
    runs-on: windows-latest
    timeout-minutes: 10
    steps:
      - name: Set up vcpkg cache
        uses: actions/cache@v4
        with:
          path: C:/vcpkg/installed
          key: ${{ runner.os }}-vcpkg-${{ hashFiles('vcpkg.json', '**/vcpkg.json') }}
          restore-keys: ${{ runner.os }}-vcpkg-
      - name: Install dependencies
        run: |
          vcpkg install zlib:x64-windows
          vcpkg integrate install
      - name: Check out the code
        uses: actions/checkout@v4
      - name: Run the CMake verification script
        run: bash ./ci/ci_verify_cmake.sh
        env:
          CI_CMAKE_GENERATOR: Visual Studio 17 2022
          CI_CMAKE_GENERATOR_PLATFORM: x64
          CI_CMAKE_TOOLCHAIN_FILE: C:/vcpkg/scripts/buildsystems/vcpkg.cmake
          CI_CMAKE_BUILD_FLAGS: -j2
          CI_CTEST_FLAGS: -j2
```
