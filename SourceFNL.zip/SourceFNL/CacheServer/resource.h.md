# resource.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CacheServer\resource.h`
Chemin relatif: `CacheServer\resource.h`
Nom du fichier: `resource.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CacheServer.rc

#define IDC_MYICON                      2
#define IDS_LANG                        2
#define IDS_SUBLANG                     3
#define IDS_CODEPAGE                    4
#define IDS_2ND_PASSWORD                5
#define IDD_CACHESERVER_DIALOG          102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_CACHESERVER                 107
#define IDI_SMALL                       108
#define IDC_CACHESERVER                 109
#define IDR_MAINFRAME                   128
#define IDC_STATIC                      -1

// Next default values for new objects

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
```
