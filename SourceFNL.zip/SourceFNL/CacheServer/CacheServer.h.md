# CacheServer.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CacheServer\CacheServer.h`
Chemin relatif: `CacheServer\CacheServer.h`
Nom du fichier: `CacheServer.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp

#if !defined(AFX_CACHESERVER_H__3D7B41FB_7518_428A_BBFC_4FF9776328B2__INCLUDED_)
#define AFX_CACHESERVER_H__3D7B41FB_7518_428A_BBFC_4FF9776328B2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_CACHESERVER_H__3D7B41FB_7518_428A_BBFC_4FF9776328B2__INCLUDED_)
```
