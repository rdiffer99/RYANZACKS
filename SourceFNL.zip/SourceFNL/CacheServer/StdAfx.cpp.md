# StdAfx.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CacheServer\StdAfx.cpp`
Chemin relatif: `CacheServer\StdAfx.cpp`
Nom du fichier: `StdAfx.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// stdafx.cpp : source file that includes just the standard includes
//	CacheServer.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file

```
