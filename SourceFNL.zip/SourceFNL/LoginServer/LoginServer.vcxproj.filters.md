# LoginServer.vcxproj.filters

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\LoginServer\LoginServer.vcxproj.filters`
Chemin relatif: `LoginServer\LoginServer.vcxproj.filters`
Nom du fichier: `LoginServer.vcxproj.filters`
Extension originale: `.filters`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup>
    <Filter Include="Source Files">
      <UniqueIdentifier>{dd53e4e4-0b2b-4d28-a026-f52488ce02ac}</UniqueIdentifier>
      <Extensions>cpp;c;cxx;rc;def;r;odl;idl;hpj;bat</Extensions>
    </Filter>
    <Filter Include="Header Files">
      <UniqueIdentifier>{70d54463-c3bb-4341-9b6a-c3372cac58b1}</UniqueIdentifier>
      <Extensions>h;hpp;hxx;hm;inl</Extensions>
    </Filter>
    <Filter Include="Resource Files">
      <UniqueIdentifier>{4d9a0f8a-cbe2-46a1-b8a5-15125a80b3bc}</UniqueIdentifier>
      <Extensions>ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe</Extensions>
    </Filter>
    <Filter Include="Network Files">
      <UniqueIdentifier>{e64aaaa0-9dbf-4030-b13f-624fca34b636}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Misc">
      <UniqueIdentifier>{a22529d2-8c3d-4e63-83e1-d9432db4e19d}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Mcl">
      <UniqueIdentifier>{c04eb304-64b4-4b2b-85c1-15e997de16bf}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Net">
      <UniqueIdentifier>{65f98fe8-c303-417b-ace7-367fcb23e351}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files">
      <UniqueIdentifier>{25e5f20c-829f-4277-8631-79bcb486984d}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\DirectX Files">
      <UniqueIdentifier>{25b73741-6ea1-404c-a408-f015478f2092}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\Common Files">
      <UniqueIdentifier>{157005dc-960c-431c-916e-84d3a3d8ce0c}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\Common Files\Script">
      <UniqueIdentifier>{96f67994-d77d-4bbd-851d-5482afd84131}</UniqueIdentifier>
    </Filter>
  </ItemGroup>
  <ItemGroup>
    <ClCompile Include="DPCoreClient.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPDatabaseClient.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPLoginSrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="LoginProtect.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="LoginServer.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="User.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\dos2.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\MyTrace.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Net\Src\crc.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
      <Filter>Neuz Files\DirectX Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\file.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\timer.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\vUtil.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\scanner.cpp">
      <Filter>Neuz Files\Common Files\Script</Filter>
    </ClCompile>
  </ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="LoginServer.rc">
      <Filter>Source Files</Filter>
    </ResourceCompile>
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="DPCoreClient.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPDatabaseClient.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPLoginSrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="LoginProtect.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="LoginServer.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\memtrace.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="resource.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="StdAfx.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="User.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="VersionCommon.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\CmnHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\ggsrv.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\MsgHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ar.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\dos2.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\heapmng.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mempool.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\memspy.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MyMap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MyTrace.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ObjMap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\tickcount.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmcl.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\buffer.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\crc.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpmng.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\sock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\DefineCommon.h">
      <Filter>Neuz Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_DirectX\dxutil.h">
      <Filter>Neuz Files\DirectX Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\data.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\debug.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\file.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\timer.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\vUtil.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\xutil.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\scanner.h">
      <Filter>Neuz Files\Common Files\Script</Filter>
    </ClInclude>
  </ItemGroup>
  <ItemGroup>
    <Image Include="LoginServer.ico">
      <Filter>Resource Files</Filter>
    </Image>
    <Image Include="small.ico">
      <Filter>Resource Files</Filter>
    </Image>
  </ItemGroup>
  <ItemGroup>
    <None Include="LoginServer.ini">
      <Filter>Resource Files</Filter>
    </None>
  </ItemGroup>
</Project>
```
