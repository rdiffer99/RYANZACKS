# LoginServer.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\LoginServer\LoginServer.h`
Chemin relatif: `LoginServer\LoginServer.h`
Nom du fichier: `LoginServer.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp

#if !defined(AFX_LOGINSERVER_H__387E4F73_ADC7_45DE_820C_3724E882F2AC__INCLUDED_)
#define AFX_LOGINSERVER_H__387E4F73_ADC7_45DE_820C_3724E882F2AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_LOGINSERVER_H__387E4F73_ADC7_45DE_820C_3724E882F2AC__INCLUDED_)
```
