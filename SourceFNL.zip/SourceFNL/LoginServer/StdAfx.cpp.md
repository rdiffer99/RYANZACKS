# StdAfx.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\LoginServer\StdAfx.cpp`
Chemin relatif: `LoginServer\StdAfx.cpp`
Nom du fichier: `StdAfx.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// stdafx.cpp : source file that includes just the standard includes
//	LoginServer.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

char	g_lpCoreAddr[16];
char	g_lpDBAddr[16];
char    g_szMSG_VER[256] = "20040706";
BOOL	g_bNProtectAuth = FALSE;

CTickCount	g_TickCount;
```
