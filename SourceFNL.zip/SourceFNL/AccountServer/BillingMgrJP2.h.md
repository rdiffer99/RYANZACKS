# BillingMgrJP2.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgrJP2.h`
Chemin relatif: `AccountServer\BillingMgrJP2.h`
Nom du fichier: `BillingMgrJP2.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __BILLINGMGRJP2_H__
#define	__BILLINGMGRJP2_H__


#endif	// __BILLINGMGR_H__
```
