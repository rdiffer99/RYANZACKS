# BillingMgr.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgr.cpp`
Chemin relatif: `AccountServer\BillingMgr.cpp`
Nom du fichier: `BillingMgr.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
```
