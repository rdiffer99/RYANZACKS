# globalgiftbox.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\globalgiftbox.cpp`
Chemin relatif: `AccountServer\globalgiftbox.cpp`
Nom du fichier: `globalgiftbox.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "globalgiftbox.h"
#include "dpmng.h"
#include "msghdr.h"
```
