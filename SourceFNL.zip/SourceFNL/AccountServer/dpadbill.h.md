# dpadbill.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\dpadbill.h`
Chemin relatif: `AccountServer\dpadbill.h`
Nom du fichier: `dpadbill.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __DPADBILL_H__
#define	__DPADBILL_H__

#endif	// __DPADBILL_H__
```
