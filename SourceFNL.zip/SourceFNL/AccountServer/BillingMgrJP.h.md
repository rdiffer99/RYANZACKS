# BillingMgrJP.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgrJP.h`
Chemin relatif: `AccountServer\BillingMgrJP.h`
Nom du fichier: `BillingMgrJP.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __BILLINGMGRJP_H__
#define	__BILLINGMGRJP_H__

#endif	// __BILLINGMGR_H__
```
