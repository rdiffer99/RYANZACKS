# BillingMgr.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgr.h`
Chemin relatif: `AccountServer\BillingMgr.h`
Nom du fichier: `BillingMgr.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __BILLINGMGR_H__
#define	__BILLINGMGR_H__

#endif	// __BILLINGMGR_H__
```
