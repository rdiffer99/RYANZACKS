# StdAfx.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\StdAfx.h`
Chemin relatif: `AccountServer\StdAfx.h`
Nom du fichier: `StdAfx.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#pragma once

#define WIN32_LEAN_AND_MEAN
#define POINTER_64 __ptr64
#define _USE_32BIT_TIME_T
#define __ACCOUNT
#define _WIN32_WINNT 0x0A00 // Windows 10

#include <afxwin.h>

#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <mmsystem.h>
#include <dplay.h>
#include <d3dx9tex.h>

#pragma warning(disable:4786)
#include <vector>
#include <list>
#include <string>
#include <map>
#include <unordered_map>
#include <array>
#include <queue>
#include <set>
#include <unordered_set>
#include <chrono>
#include <random>
using namespace std;

#include "VersionCommon.h"
#include "CustomCommon.h"
#include "memtrace.h"

#include "DefineCommon.h"
#include "cmnhdr.h"

#include <afxdisp.h>

#include "dxutil.h"
#include "vutil.h"
#include "data.h"
#include "file.h"
#include "d3dfont.h"
#include "scanner.h"
#include "timer.h"
#include "debug.h"
#include "xutil.h"

const UINT	IDT_SENDPLAYERCOUNT	= 0;
const UINT	IDT_RECONNECT		= 1;
const UINT  IDT_KEEPALIVE		= 2;
const UINT  IDT_KICKOUT			= 3;
const UINT  IDT_PREVENT_EXCESS	= 4;
const UINT	IDT_BUYING_INFO		= 5;
const UINT  IDT_RELOAD_PROJECT	= 6;
const UINT  IDT_TIME_CHECKADDR	= 7;


extern char		DSN_NAME_LOG[];
extern char		DB_ADMIN_ID_LOG[];

extern char		DSN_NAME_LOGIN[];
extern char		DB_ADMIN_ID_LOGIN[];

```
