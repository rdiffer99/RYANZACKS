# BillingMgrJP2.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgrJP2.cpp`
Chemin relatif: `AccountServer\BillingMgrJP2.cpp`
Nom du fichier: `BillingMgrJP2.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
```
