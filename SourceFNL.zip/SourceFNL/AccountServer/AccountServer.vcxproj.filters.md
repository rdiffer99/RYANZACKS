# AccountServer.vcxproj.filters

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\AccountServer.vcxproj.filters`
Chemin relatif: `AccountServer\AccountServer.vcxproj.filters`
Nom du fichier: `AccountServer.vcxproj.filters`
Extension originale: `.filters`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup>
    <Filter Include="Source Files">
      <UniqueIdentifier>{db5f4d30-c58c-4b88-ba40-c15f4572a6af}</UniqueIdentifier>
      <Extensions>cpp;c;cxx;rc;def;r;odl;idl;hpj;bat</Extensions>
    </Filter>
    <Filter Include="Header Files">
      <UniqueIdentifier>{4174f21b-45a1-4917-a707-69b34627993f}</UniqueIdentifier>
      <Extensions>h;hpp;hxx;hm;inl</Extensions>
    </Filter>
    <Filter Include="Resource Files">
      <UniqueIdentifier>{97fffd72-ef25-4c24-8c21-a2e30c4fcc5d}</UniqueIdentifier>
      <Extensions>ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe</Extensions>
    </Filter>
    <Filter Include="Network Files">
      <UniqueIdentifier>{53fbf0dc-1cb3-4978-b8b6-fcbcefdbfda5}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Mcl">
      <UniqueIdentifier>{a9ca1acb-b72b-4e94-970c-a47a4e5c9ff5}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Misc">
      <UniqueIdentifier>{6be2ff8e-0d32-40d3-9945-413c45ff4ef0}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Net">
      <UniqueIdentifier>{c7e857d4-5bd1-4e86-b287-bcce7d2ceef7}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files">
      <UniqueIdentifier>{dce80b9a-cfac-4576-bbcf-7da68e65d64e}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\DX">
      <UniqueIdentifier>{75a137a1-c556-4870-8cba-3a0420787aab}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\Cmn">
      <UniqueIdentifier>{b3fcc2fa-53b6-4fa4-b234-b75a6615e89f}</UniqueIdentifier>
    </Filter>
    <Filter Include="ODBC Files">
      <UniqueIdentifier>{4cbe0267-5c3c-4972-8a29-42606a319b5f}</UniqueIdentifier>
    </Filter>
    <Filter Include="Billing">
      <UniqueIdentifier>{284cfa34-e12b-4c0b-b903-e5091e821dba}</UniqueIdentifier>
    </Filter>
  </ItemGroup>
  <ItemGroup>
    <ClCompile Include="account.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="AccountServer.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DBManager.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="dpdbsrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="dpsrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="dpwldsrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="globalgiftbox.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\mytrace.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net2\src\buffer.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net2\src\crc.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net2\src\sock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_directx\dxutil.cpp">
      <Filter>Neuz Files\DX</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
      <Filter>Neuz Files\Cmn</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\file.cpp">
      <Filter>Neuz Files\Cmn</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
      <Filter>Neuz Files\Cmn</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\scanner.cpp">
      <Filter>Neuz Files\Cmn</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\timer.cpp">
      <Filter>Neuz Files\Cmn</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\vutil.cpp">
      <Filter>Neuz Files\Cmn</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
      <Filter>Neuz Files\Cmn</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\des.c">
      <Filter>ODBC Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\Query.cpp">
      <Filter>ODBC Files</Filter>
    </ClCompile>
    <ClCompile Include="BillingMgr.cpp">
      <Filter>Billing</Filter>
    </ClCompile>
    <ClCompile Include="BillingMgrJP.cpp">
      <Filter>Billing</Filter>
    </ClCompile>
    <ClCompile Include="BillingMgrJP2.cpp">
      <Filter>Billing</Filter>
    </ClCompile>
    <ClCompile Include="BillingMgrTH.cpp">
      <Filter>Billing</Filter>
    </ClCompile>
    <ClCompile Include="BillingMgrTW.cpp">
      <Filter>Billing</Filter>
    </ClCompile>
    <ClCompile Include="dpadbill.cpp">
      <Filter>Billing</Filter>
    </ClCompile>
    <ClCompile Include="dpBilling.cpp">
      <Filter>Billing</Filter>
    </ClCompile>
    <ClCompile Include="dpBillingTH.cpp">
      <Filter>Billing</Filter>
    </ClCompile>
  </ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="AccountServer.rc">
      <Filter>Source Files</Filter>
    </ResourceCompile>
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="account.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="AccountServer.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DBManager.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="dpdbsrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="dpsrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="dpwldsrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="globalgiftbox.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="resource.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="StdAfx.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="VersionCommon.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\cmnhdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\msghdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmcl.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ar.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\heapmng.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mempooler.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\misc.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mymap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mytrace.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\buffer.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\clientsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\clientsocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\crc.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\dpmng.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\dpsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\serversock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\serversocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net2\include\sock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\DefineCommon.h">
      <Filter>Neuz Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_directx\dxutil.h">
      <Filter>Neuz Files\DX</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\buyinginfo.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\data.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\debug.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\file.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\memtrace.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\scanner.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\timer.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\vutil.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\xutil.h">
      <Filter>Neuz Files\Cmn</Filter>
    </ClInclude>
    <ClInclude Include="..\_Database\des.h">
      <Filter>ODBC Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Database\Query.h">
      <Filter>ODBC Files</Filter>
    </ClInclude>
    <ClInclude Include="BillingMgr.h">
      <Filter>Billing</Filter>
    </ClInclude>
    <ClInclude Include="BillingMgrJP.h">
      <Filter>Billing</Filter>
    </ClInclude>
    <ClInclude Include="BillingMgrJP2.h">
      <Filter>Billing</Filter>
    </ClInclude>
    <ClInclude Include="BillingMgrTH.h">
      <Filter>Billing</Filter>
    </ClInclude>
    <ClInclude Include="BillingMgrTW.h">
      <Filter>Billing</Filter>
    </ClInclude>
    <ClInclude Include="dpadbill.h">
      <Filter>Billing</Filter>
    </ClInclude>
    <ClInclude Include="dpBilling.h">
      <Filter>Billing</Filter>
    </ClInclude>
    <ClInclude Include="dpBillingTH.h">
      <Filter>Billing</Filter>
    </ClInclude>
  </ItemGroup>
  <ItemGroup>
    <Image Include="AccountServer.ico">
      <Filter>Resource Files</Filter>
    </Image>
    <Image Include="small.ico">
      <Filter>Resource Files</Filter>
    </Image>
  </ItemGroup>
  <ItemGroup>
    <None Include="AccountServer.ini">
      <Filter>Resource Files</Filter>
    </None>
  </ItemGroup>
</Project>
```
