# BillingMgrTW.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgrTW.h`
Chemin relatif: `AccountServer\BillingMgrTW.h`
Nom du fichier: `BillingMgrTW.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __BILLINGMGRTW_H__
#define	__BILLINGMGRTW_H__


#endif	// __BILLINGMGRTW_H__
```
