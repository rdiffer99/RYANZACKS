# dpadbill.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\dpadbill.cpp`
Chemin relatif: `AccountServer\dpadbill.cpp`
Nom du fichier: `dpadbill.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "dpdbsrvr.h"
```
