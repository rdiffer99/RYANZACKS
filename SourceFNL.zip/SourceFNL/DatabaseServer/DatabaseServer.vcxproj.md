# DatabaseServer.vcxproj

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\DatabaseServer.vcxproj`
Chemin relatif: `DatabaseServer\DatabaseServer.vcxproj`
Nom du fichier: `DatabaseServer.vcxproj`
Extension originale: `.vcxproj`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup Label="ProjectConfigurations">
    <ProjectConfiguration Include="Debug|Win32">
      <Configuration>Debug</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Release|Win32">
      <Configuration>Release</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
  </ItemGroup>
  <PropertyGroup Label="Globals">
    <ProjectGuid>{701A20E7-5272-467E-B8F3-656DB21959D9}</ProjectGuid>
    <WindowsTargetPlatformVersion>10.0</WindowsTargetPlatformVersion>
    <VCProjectVersion>16.0</VCProjectVersion>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.Default.props" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>true</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <CharacterSet>MultiByte</CharacterSet>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>false</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <WholeProgramOptimization>true</WholeProgramOptimization>
    <CharacterSet>MultiByte</CharacterSet>
    <EnableASAN>false</EnableASAN>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.props" />
  <ImportGroup Label="ExtensionSettings">
  </ImportGroup>
  <ImportGroup Label="Shared">
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <PropertyGroup Label="UserMacros" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <LinkIncremental>true</LinkIncremental>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <LinkIncremental>false</LinkIncremental>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
  </PropertyGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <ClCompile>
      <AdditionalIncludeDirectories>..\DX_SDK;.;..\_Network\Net\Include;..\_Network\Misc\Include;..\_Network\Mcl\Include;..\_network;..\_DirectX;..\_Common;..\..\resource;..\_database;..\_Interface;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;_DEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level3</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreadedDebug</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>ws2_32.lib;winmm.lib;odbc32.lib;odbccp32.lib</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\_Network\Mcl\Lib\Debug</AdditionalLibraryDirectories>
      <GenerateDebugInformation>true</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
      <IgnoreSpecificDefaultLibraries>msvcrt.lib</IgnoreSpecificDefaultLibraries>
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <ClCompile>
      <AdditionalIncludeDirectories>..\DX_SDK;.;..\_Network\Net\Include;..\_Network\Misc\Include;..\_Network\Mcl\Include;..\_network;..\_DirectX;..\_Common;..\..\resource;..\_database;..\_Interface;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;NDEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <FunctionLevelLinking>true</FunctionLevelLinking>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level1</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreaded</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
      <Optimization>MaxSpeed</Optimization>
      <WholeProgramOptimization>true</WholeProgramOptimization>
    </ClCompile>
    <Link>
      <AdditionalDependencies>ws2_32.lib;winmm.lib;odbc32.lib;odbccp32.lib</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\_Network\Mcl\Lib\Release</AdditionalLibraryDirectories>
      <GenerateDebugInformation>DebugFull</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
      <EnableCOMDATFolding>
      </EnableCOMDATFolding>
      <OptimizeReferences>
      </OptimizeReferences>
      <IgnoreSpecificDefaultLibraries>msvcrt.lib</IgnoreSpecificDefaultLibraries>
      <LinkTimeCodeGeneration />
      <LinkTimeCodeGenerationObjectFile />
      <StackReserveSize>
      </StackReserveSize>
      <LargeAddressAware>true</LargeAddressAware>
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemGroup>
    <ClCompile Include="..\WorldServer\MiniDumper.cpp" />
    <ClCompile Include="..\_Common\Buyback.cpp" />
    <ClCompile Include="..\_Common\FlyFFShop.cpp" />
    <ClCompile Include="..\_Common\MonsterAlbum.cpp" />
    <ClCompile Include="..\_Common\PlayerStatue.cpp" />
    <ClCompile Include="..\_Common\RecordBook.cpp" />
    <ClCompile Include="..\_Common\SeasonPass.cpp" />
    <ClCompile Include="..\_Common\StarterItems.cpp" />
    <ClCompile Include="..\_Common\Switches.cpp" />
    <ClCompile Include="..\_Common\Wardrobe.cpp" />
    <ClCompile Include="..\_Common\ZckAchievement.cpp" />
    <ClCompile Include="..\_Common\ZckClassementDonjon.cpp" />
    <ClCompile Include="..\_Database\AccountCacheMgr.cpp">
    </ClCompile>
    <ClCompile Include="AccountTimeLimitDBCtrl.cpp">
    </ClCompile>
    <ClCompile Include="CampusDBCtrl.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\Continent.cpp">
    </ClCompile>
    <ClCompile Include="couplehelper.cpp">
    </ClCompile>
    <ClCompile Include="DatabaseServer.cpp">
    </ClCompile>
    <ClCompile Include="dbcontroller.cpp">
    </ClCompile>
    <ClCompile Include="dpaccountclient.cpp">
    </ClCompile>
    <ClCompile Include="DPCoreSrvr.cpp">
    </ClCompile>
    <ClCompile Include="DPLoginSrvr.cpp">
    </ClCompile>
    <ClCompile Include="dptrans.cpp">
    </ClCompile>
    <ClCompile Include="GuildHouseDBCtrl.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\Housing.cpp">
    </ClCompile>
    <ClCompile Include="HousingDBCtrl.cpp">
    </ClCompile>
    <ClCompile Include="lordskillexecutable.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\pocket.cpp">
    </ClCompile>
    <ClCompile Include="Project.cpp">
    </ClCompile>
    <ClCompile Include="QuizDBCtrl.cpp">
    </ClCompile>
    <ClCompile Include="RainbowRaceDBCtrl.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\rtmessenger.cpp">
    </ClCompile>
    <ClCompile Include="SecretRoomDBMng.cpp">
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">Create</PrecompiledHeader>
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">Create</PrecompiledHeader>
    </ClCompile>
    <ClCompile Include="..\_Common\Tax.cpp">
    </ClCompile>
    <ClCompile Include="tlord.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\vutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\MyTrace.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\objects\Obj.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\langman.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\path.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\xutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\buff.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\Campus.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\couple.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\EventLua.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\file.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\FunnyCoin.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\guild.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\GuildCombat1to1.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\GuildHouse.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\guildquest.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\guildwar.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\honor.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\lord.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\lordskill.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\LuaBase.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\messenger.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\piercing.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\playerdata.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\post.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\ProjectCmn.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\Quiz.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\serialnumber.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\SkillInfluence.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\spevent.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\timer.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\scanner.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\script.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\ObjSerialize.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\ObjSerializeOpt.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\pet.cpp">
    </ClCompile>
    <ClCompile Include="..\_Interface\UserTaskBar.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\DBBackEndSystem.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\DBConvert.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\DBConvertNew.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\DbItemUpdate.cpp">
    </ClCompile>
    <ClCompile Include="..\_database\DbManager.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\DbManagerFun.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\DbManagerJoin.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\DbManagerLog.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\DbManagerSave.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\des.c">
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
      </PrecompiledHeader>
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
      </PrecompiledHeader>
    </ClCompile>
	<ClCompile Include="..\_database\Query.cpp">
	</ClCompile>
<ClCompile Include="..\_Common\ZckSpdLog.cpp">
  <PrecompiledHeader>NotUsing</PrecompiledHeader>
  <AdditionalIncludeDirectories>..\ThirdParty\spdlog\include;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
  <AdditionalOptions>/EHsc /utf-8 /Zc:__cplusplus %(AdditionalOptions)</AdditionalOptions>
</ClCompile>
	</ItemGroup>
  <ItemGroup>
    <ClInclude Include="..\WorldServer\MiniDumper.h" />
    <ClInclude Include="..\_Common\Buyback.h" />
    <ClInclude Include="..\_Common\FlyFFShop.h" />
    <ClInclude Include="..\_Common\MonsterAlbum.h" />
    <ClInclude Include="..\_Common\PlayerStatue.h" />
    <ClInclude Include="..\_Common\RecordBook.h" />
    <ClInclude Include="..\_Common\RecordParameters.h" />
    <ClInclude Include="..\_Common\SeasonPass.h" />
    <ClInclude Include="..\_Common\StarterItems.h" />
    <ClInclude Include="..\_Common\Switches.h" />
    <ClInclude Include="..\_Common\Wardrobe.h" />
    <ClInclude Include="..\_Common\ZckAchievement.h" />
    <ClInclude Include="..\_Common\ZckClassementDonjon.h" />
    <ClInclude Include="..\_Common\ZckPrestige.h" />
    <ClInclude Include="..\_Common\ZckAura.h" />
    <ClInclude Include="..\_Common\ZckArmeReborn.h" />
    <ClInclude Include="..\_Common\ZckPetGlow.h" />
    <ClInclude Include="..\_Common\ZckTrails.h" />
    <ClInclude Include="..\_Common\ZckElementRgb.h" />
    <ClInclude Include="..\_Database\AccountCacheMgr.h" />
    <ClInclude Include="AccountTimeLimitDBCtrl.h" />
    <ClInclude Include="CampusDBCtrl.h" />
    <ClInclude Include="couplehelper.h" />
    <ClInclude Include="DatabaseServer.h" />
    <ClInclude Include="dbcontroller.h" />
    <ClInclude Include="DefineConMode.h" />
    <ClInclude Include="dpaccountclient.h" />
    <ClInclude Include="DPCoreSrvr.h" />
    <ClInclude Include="DPLoginSrvr.h" />
    <ClInclude Include="dptrans.h" />
    <ClInclude Include="GuildHouseDBCtrl.h" />
    <ClInclude Include="..\_Common\Housing.h" />
    <ClInclude Include="HousingDBCtrl.h" />
    <ClInclude Include="lordskillexecutable.h" />
    <ClInclude Include="..\_Common\memtrace.h" />
    <ClInclude Include="..\_Common\pocket.h" />
    <ClInclude Include="project.h" />
    <ClInclude Include="QuizDBCtrl.h" />
    <ClInclude Include="RainbowRaceDBCtrl.h" />
    <ClInclude Include="..\_Common\rtmessenger.h" />
    <ClInclude Include="SecretRoomDBMng.h" />
    <ClInclude Include="StdAfx.h" />
    <ClInclude Include="tlord.h" />
    <ClInclude Include="VersionCommon.h" />
    <ClInclude Include="resource.h" />
    <ClInclude Include="..\_network\CmnHdr.h" />
    <ClInclude Include="..\_network\MsgHdr.h" />
    <ClInclude Include="..\_network\misc\include\ar.h" />
    <ClInclude Include="..\_network\misc\include\heapmng.h" />
    <ClInclude Include="..\_network\misc\include\mempool.h" />
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H" />
    <ClInclude Include="..\_network\misc\include\memspy.h" />
    <ClInclude Include="..\_network\misc\include\Misc.h" />
    <ClInclude Include="..\_network\misc\include\MyMap.h" />
    <ClInclude Include="..\_network\misc\include\MyTrace.h" />
    <ClInclude Include="..\_network\mcl\include\cmcl.h" />
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h" />
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h" />
    <ClInclude Include="..\_network\net\include\buffer.h" />
    <ClInclude Include="..\_network\net\include\clientsock.h" />
    <ClInclude Include="..\_network\net\include\clientsocke.h" />
    <ClInclude Include="..\_network\net\include\dpmng.h" />
    <ClInclude Include="..\_network\net\include\dpsock.h" />
    <ClInclude Include="..\_network\net\include\serversock.h" />
    <ClInclude Include="..\_network\net\include\serversocke.h" />
    <ClInclude Include="..\_network\net\include\sock.h" />
    <ClInclude Include="..\_network\objects\Obj.h" />
    <ClInclude Include="..\_Common\DefineCommon.h" />
    <ClInclude Include="..\_Common\langman.h" />
    <ClInclude Include="..\_Common\patch.h" />
    <ClInclude Include="..\_Common\xutil.h" />
    <ClInclude Include="..\_DirectX\dxutil.h" />
    <ClInclude Include="..\_Common\authorization.h" />
    <ClInclude Include="..\_Common\buff.h" />
    <ClInclude Include="..\_common\buyinginfo.h" />
    <ClInclude Include="..\_Common\Campus.h" />
    <ClInclude Include="..\_Common\data.h" />
    <ClInclude Include="..\_common\debug.h" />
    <ClInclude Include="..\_Common\EventLua.h" />
    <ClInclude Include="..\_Common\file.h" />
    <ClInclude Include="..\_Common\FunnyCoin.h" />
    <ClInclude Include="..\_common\guild.h" />
    <ClInclude Include="..\_Common\GuildCombat1to1.h" />
    <ClInclude Include="..\_Common\GuildHouse.h" />
    <ClInclude Include="..\_common\guildquest.h" />
    <ClInclude Include="..\_common\guildwar.h" />
    <ClInclude Include="..\_Common\lord.h" />
    <ClInclude Include="..\_Common\lordskill.h" />
    <ClInclude Include="..\_Common\LuaBase.h" />
    <ClInclude Include="..\_Common\messenger.h" />
    <ClInclude Include="..\_common\party.h" />
    <ClInclude Include="..\_common\path.h" />
    <ClInclude Include="..\_Common\Piercing.h" />
    <ClInclude Include="..\_Common\playerdata.h" />
    <ClInclude Include="..\_Common\post.h" />
    <ClInclude Include="..\_Common\ProjectCmn.h" />
    <ClInclude Include="..\_Common\Quiz.h" />
    <ClInclude Include="..\_Common\serialnumber.h" />
    <ClInclude Include="..\_Common\SkillInfluence.h" />
    <ClInclude Include="..\_Common\spevent.h" />
    <ClInclude Include="..\_Common\timer.h" />
    <ClInclude Include="..\_Common\scanner.h" />
    <ClInclude Include="..\_Common\script.h" />
    <ClInclude Include="..\_Common\pet.h" />
    <ClInclude Include="..\_Interface\UserTaskBar.h" />
    <ClInclude Include="..\_database\DbManager.h" />
    <ClInclude Include="..\_Database\des.h" />
    <ClInclude Include="..\_database\Query.h" />
	<ClInclude Include="..\_Common\ZckSpdLog.h" />
  </ItemGroup>
  <ItemGroup>
    <Image Include="DatabaseServer.ico" />
    <Image Include="small.ico" />
  </ItemGroup>
  <ItemGroup>
    <None Include="databaseserver.ini" />
  </ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="DatabaseServer.rc" />
  </ItemGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.targets" />
  <ImportGroup Label="ExtensionTargets">
  </ImportGroup>
</Project>
```
