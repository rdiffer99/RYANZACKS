# lordskillexecutable.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\lordskillexecutable.h`
Chemin relatif: `DatabaseServer\lordskillexecutable.h`
Nom du fichier: `lordskillexecutable.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __LORD_SKILL_EXECUTABLE_H__
#define	__LORD_SKILL_EXECUTABLE_H__

#include "lordskill.h"

class CLordSkillComponentODBC
	: public CLordSkillComponentExecutable
{
public:
	CLordSkillComponentODBC();
	virtual ~CLordSkillComponentODBC();
public:
	virtual	void	Execute( u_long idPlayer, u_long idTarget, VOID* pParam );
};

#endif	// __LORD_SKILL_EXECUTABLE_H__
```
