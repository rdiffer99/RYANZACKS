# DatabaseServer.rc

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\DatabaseServer.rc`
Chemin relatif: `DatabaseServer\DatabaseServer.rc`
Nom du fichier: `DatabaseServer.rc`
Extension originale: `.rc`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// Microsoft Visual C++ generated resource script.
//
#include "resource.h"

#define APSTUDIO_READONLY_SYMBOLS
/////////////////////////////////////////////////////////////////////////////
//
// Generated from the TEXTINCLUDE 2 resource.
//
#define APSTUDIO_HIDDEN_SYMBOLS
#include "windows.h"
#undef APSTUDIO_HIDDEN_SYMBOLS
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
#undef APSTUDIO_READONLY_SYMBOLS

/////////////////////////////////////////////////////////////////////////////
// English (U.S.) resources

#if !defined(AFX_RESOURCE_DLL) || defined(AFX_TARG_ENU)
#ifdef _WIN32
LANGUAGE LANG_ENGLISH, SUBLANG_ENGLISH_US
#pragma code_page(1252)
#endif //_WIN32

/////////////////////////////////////////////////////////////////////////////
//
// Icon
//

// Icon with lowest ID value placed first to ensure application icon
// remains consistent on all systems.
IDI_DATABASESERVER      ICON                    "DatabaseServer.ICO"
IDI_SMALL               ICON                    "SMALL.ICO"

#ifdef APSTUDIO_INVOKED
/////////////////////////////////////////////////////////////////////////////
//
// TEXTINCLUDE
//

2 TEXTINCLUDE 
BEGIN
    "#define APSTUDIO_HIDDEN_SYMBOLS\r\n"
    "#include ""windows.h""\r\n"
    "#undef APSTUDIO_HIDDEN_SYMBOLS\r\n"
    "#include ""resource.h""\r\n"
    "\0"
END

3 TEXTINCLUDE 
BEGIN
    "\r\n"
    "\0"
END

1 TEXTINCLUDE 
BEGIN
    "resource.h\0"
END

#endif    // APSTUDIO_INVOKED


/////////////////////////////////////////////////////////////////////////////
//
// Menu
//

IDC_DATABASESERVER MENU 
BEGIN
    POPUP "Event"
    BEGIN
        MENUITEM "LuaEvent -> Apply Now",       IDM_EVENTLUA_APPLYNOW
    END
    POPUP "Reload"
    BEGIN
        MENUITEM "FlyFF Shop -> Reload Now", IDM_LOAD_CSHOP
    END
END


/////////////////////////////////////////////////////////////////////////////
//
// Version
//

VS_VERSION_INFO VERSIONINFO
 FILEVERSION 1,0,0,1
 PRODUCTVERSION 1,0,0,1
 FILEFLAGSMASK 0x3fL
#ifdef _DEBUG
 FILEFLAGS 0x1L
#else
 FILEFLAGS 0x0L
#endif
 FILEOS 0x40004L
 FILETYPE 0x1L
 FILESUBTYPE 0x0L
BEGIN
    BLOCK "StringFileInfo"
    BEGIN
        BLOCK "041204b0"
        BEGIN
            VALUE "CompanyName", "AEONSOFT"
            VALUE "FileDescription", "DatabaseServer"
            VALUE "FileVersion", "1, 0, 0, 1"
            VALUE "InternalName", "DatabaseServer"
            VALUE "LegalCopyright", "Copyright �� 2003"
            VALUE "OriginalFilename", "DatabaseServer.exe"
            VALUE "ProductName", "AEONSOFT DatabaseServer"
            VALUE "ProductVersion", "1, 0, 0, 1"
        END
    END
    BLOCK "VarFileInfo"
    BEGIN
        VALUE "Translation", 0x412, 1200
    END
END


/////////////////////////////////////////////////////////////////////////////
//
// Dialog
//

IDD_VERIFYPLAYER DIALOGEX 0, 0, 188, 34
STYLE DS_SETFONT | WS_POPUP | WS_BORDER
FONT 10, "SquireD", 0, 0, 0x1
BEGIN
    CONTROL         "Progress1",IDC_PROGRESS1,"msctls_progress32",0x1,7,7,
                    174,9,WS_EX_CLIENTEDGE | WS_EX_STATICEDGE
    CONTROL         "",IDC_STATIC,"Static",SS_LEFTNOWORDWRAP | 
                    SS_CENTERIMAGE | WS_GROUP,123,17,58,9,WS_EX_RIGHT
    CONTROL         "",IDC_STATIC1,"Static",SS_LEFTNOWORDWRAP | 
                    SS_CENTERIMAGE | WS_GROUP,65,17,53,9,WS_EX_RIGHT
    CONTROL         "",IDC_STATIC2,"Static",SS_LEFTNOWORDWRAP | 
                    SS_CENTERIMAGE | WS_GROUP,7,17,55,9,WS_EX_RIGHT
END

IDD_DIALOG_CONVERT DIALOG  0, 0, 301, 186
STYLE DS_SETFONT | WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME
CAPTION "Convert"
FONT 10, "Fixedsys"
BEGIN
    LTEXT           "Time : ",IDC_STATIC,1,1,33,11
    LTEXT           "",IDC_STATIC_TIME,37,0,33,11
    CONTROL         "Progress1",IDC_PROGRESS,"msctls_progress32",WS_BORDER | 
                    0x1,74,1,165,8
    LTEXT           "",IDC_STATIC_TOTAL,241,1,60,8
    CONTROL         "",IDC_DATAGRID4,"{CDE57A43-8B86-11D0-B3C6-00A0C90AEA82}",
                    WS_TABSTOP,0,12,301,174
END


/////////////////////////////////////////////////////////////////////////////
//
// DESIGNINFO
//

#ifdef APSTUDIO_INVOKED
GUIDELINES DESIGNINFO 
BEGIN
    IDD_VERIFYPLAYER, DIALOG
    BEGIN
        LEFTMARGIN, 7
        RIGHTMARGIN, 181
        TOPMARGIN, 7
        BOTTOMMARGIN, 26
    END
END
#endif    // APSTUDIO_INVOKED


/////////////////////////////////////////////////////////////////////////////
//
// Dialog Info
//

IDD_DIALOG_CONVERT DLGINIT
BEGIN
    IDC_DATAGRID4, 0x37a, 506, 0
0x0024, 0x0000, 0x0043, 0x0044, 0x0045, 0x0035, 0x0037, 0x0041, 0x0035, 
0x0035, 0x002d, 0x0038, 0x0042, 0x0038, 0x0036, 0x002d, 0x0031, 0x0031, 
0x0044, 0x0030, 0x002d, 0x0062, 0x0033, 0x0043, 0x0036, 0x002d, 0x0030, 
0x0030, 0x0041, 0x0030, 0x0043, 0x0039, 0x0030, 0x0041, 0x0045, 0x0041, 
0x0038, 0x0032, 0x0012, 0x0000, 0x0001, 0x0000, 0x000a, 0x0000, 0x002a, 
0x0000, 0x0000, 0x4321, 0x1234, 0x0008, 0x0000, 0x3e38, 0x0000, 0x23f8, 
0x0000, 0xe860, 0x5ad5, 0x0000, 0x0006, 0x0001, 0x0000, 0x0002, 0x0000, 
0x0005, 0x8000, 0x0008, 0x8000, 0x0000, 0x3f80, 0x0000, 0x4170, 0x0000, 
0x0000, 0x0101, 0x0002, 0x0001, 0x0101, 0x0101, 0x0100, 0x0000, 0x0000, 
0x5203, 0x0be3, 0x8f91, 0x11ce, 0xe39d, 0xaa00, 0x4b00, 0x51b8, 0x8101, 
0x0000, 0x0190, 0xd4c0, 0x0001, 0x4608, 0x7869, 0x6465, 0x7973, 0x0373, 
0xe352, 0x910b, 0xce8f, 0x9d11, 0x00e3, 0x00aa, 0xb84b, 0x0151, 0x0081, 
0x9000, 0xc001, 0x01d4, 0x0800, 0x6946, 0x6578, 0x7364, 0x7379, 0x0000, 
0x0000, 0x0012, 0x0000, 0x0044, 0x0061, 0x0074, 0x0061, 0x0047, 0x0072, 
0x0069, 0x0064, 0x0034, 0x0006, 0x0000, 0x0004, 0x0000, 0x0000, 0x0000, 
0x0001, 0x0000, 0x0001, 0x0000, 0x0001, 0x0000, 0x0000, 0x0000, 0x0001, 
0x0000, 0x0001, 0x0000, 0x0001, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 
0x5690, 0x6d83, 0x900b, 0x11d0, 0x8494, 0xa000, 0x11c9, 0xed10, 0x3850, 
0x6b26, 0x0002, 0x0006, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 
0x0000, 0x0000, 0x0000, 0x0000, 0xb84b, 0x0151, 0x0081, 0x9000, 0xc001, 
0x01d4, 0x0412, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 
0x5690, 0x6d83, 0x900b, 0x11d0, 0x8494, 0xa000, 0x11c9, 0xed10, 0x3850, 
0x6b26, 0x0002, 0x0006, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 
0x0000, 0x0000, 0x0000, 0x0000, 0xb84b, 0x0151, 0x0081, 0x9000, 0xc001, 
0x01d4, 0x0412, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0002, 0x0000, 
0x0001, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0001, 0x0000, 0x0000, 
0x0000, 0x0000, 0x42ac, 0x0000, 0x0000, 0x0002, 0x0000, 0x0001, 0x0000, 
0x0000, 0x0000, 0x0000, 0x0000, 0x0001, 0x0000, 0x0000, 0x0000, 0x0000, 
0x42ac, 
    0
END


/////////////////////////////////////////////////////////////////////////////
//
// String Table
//

STRINGTABLE 
BEGIN
    IDS_APP_TITLE           "Trans Server"
    IDC_DATABASESERVER      "DATABASESERVER"
END

STRINGTABLE 
BEGIN
    IDS_LANG                "1"
    IDS_SUBLANG             "0"
    IDS_CODEPAGE            "0"
    IDS_2ND_PASSWORD        "0"
END

#endif    // English (U.S.) resources
/////////////////////////////////////////////////////////////////////////////



#ifndef APSTUDIO_INVOKED
/////////////////////////////////////////////////////////////////////////////
//
// Generated from the TEXTINCLUDE 3 resource.
//


/////////////////////////////////////////////////////////////////////////////
#endif    // not APSTUDIO_INVOKED

```
