# QuizDBCtrl.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\QuizDBCtrl.h`
Chemin relatif: `DatabaseServer\QuizDBCtrl.h`
Nom du fichier: `QuizDBCtrl.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// QuizDBCtrl.h: interface for the CQuizDBCtrl class.

////////////////////////////////////////////////////////////////

#if !defined(AFX_QUIZDBCTRL_H__4019A7AB_9F66_46B7_9116_D45D7338A3D8__INCLUDED_)
#define AFX_QUIZDBCTRL_H__4019A7AB_9F66_46B7_9116_D45D7338A3D8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#endif // !defined(AFX_QUIZDBCTRL_H__4019A7AB_9F66_46B7_9116_D45D7338A3D8__INCLUDED_)
```
