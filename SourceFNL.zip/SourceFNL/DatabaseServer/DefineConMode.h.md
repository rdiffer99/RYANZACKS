# DefineConMode.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\DefineConMode.h`
Chemin relatif: `DatabaseServer\DefineConMode.h`
Nom du fichier: `DefineConMode.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#define CONVER_ITEM_START	(DWORD)0x00000001
#define SAVE_TEXT			(DWORD)0x00000002
#define REMOVE_ITEM_ALL		(DWORD)0x00000004
#define REMOVE_ITEM_ALL_PAY	(DWORD)0x00000008
#define PIERCING_CONFIRM	(DWORD)0x00000010

```
