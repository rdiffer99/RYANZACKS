/*
    02_PREPARATION.sql
    Cree CHARACTER_CASH_TBL et lui donne une ligne a zero par personnage.

    ATTENTION, contradiction assumee et signalee :
    le cahier des charges dit "ne creer aucune table dans les bases FlyFF".
    CHARACTER_CASH_TBL est pourtant la fondation du chantier __ZCK_SHOP :
    les etapes 4, 5 et 6, declarees intouchables, la referencent. Sans elle,
    le serveur lit une table inexistante. Elle est donc creee ici, dans
    CHARACTER_01_DBF, parce que le WorldServer ne connait pas REBORN_WEB_DBF.
    Aucune table FlyFF existante n'est modifiee.

    Style : pas de cle primaire, pas de CHECK, ON [PRIMARY], valeurs par
    defaut par ALTER TABLE, index a la maniere de CHARACTER_ID1.

    Rejouable : la table n'est creee que si absente, les lignes ne sont
    inserees que si absentes. Une deuxieme execution ne remet AUCUN solde
    a zero.
*/
USE [CHARACTER_01_DBF]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET NOCOUNT ON
GO

IF OBJECT_ID(N'dbo.CHARACTER_CASH_TBL', N'U') IS NULL
CREATE TABLE [dbo].[CHARACTER_CASH_TBL](
	[m_idPlayer] [char](7) NULL,
	[serverindex] [char](2) NOT NULL,
	[cash] [int] NOT NULL,
	[votepoint] [int] NOT NULL
) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.default_constraints WHERE name = N'DF_CHARACTER_CASH_TBL_cash')
ALTER TABLE [dbo].[CHARACTER_CASH_TBL] ADD  CONSTRAINT [DF_CHARACTER_CASH_TBL_cash]  DEFAULT ((0)) FOR [cash]
GO

IF NOT EXISTS (SELECT * FROM sys.default_constraints WHERE name = N'DF_CHARACTER_CASH_TBL_votepoint')
ALTER TABLE [dbo].[CHARACTER_CASH_TBL] ADD  CONSTRAINT [DF_CHARACTER_CASH_TBL_votepoint]  DEFAULT ((0)) FOR [votepoint]
GO

/* Index calque sur CHARACTER_ID1 : meme couple de colonnes, meme forme.
   UNIQUE parce qu'un personnage n'a qu'une ligne de solde. */
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N'CHARACTER_CASH_ID1' AND object_id = OBJECT_ID(N'dbo.CHARACTER_CASH_TBL'))
CREATE UNIQUE CLUSTERED INDEX [CHARACTER_CASH_ID1] ON [dbo].[CHARACTER_CASH_TBL]
(
	[m_idPlayer] DESC,
	[serverindex] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

/* Une ligne a zero par personnage existant. Meme base des deux cotes,
   donc aucun risque de classement : pas de COLLATE ici. */
INSERT INTO dbo.CHARACTER_CASH_TBL (m_idPlayer, serverindex, cash, votepoint)
SELECT A.m_idPlayer, A.serverindex, 0, 0
FROM dbo.CHARACTER_TBL A
WHERE A.m_idPlayer IS NOT NULL
  AND NOT EXISTS (
	SELECT * FROM dbo.CHARACTER_CASH_TBL B
	WHERE B.m_idPlayer = A.m_idPlayer AND B.serverindex = A.serverindex
  )

SELECT @@ROWCOUNT AS lignes_ajoutees
GO

SELECT
	COUNT(*)					AS lignes_totales,
	SUM(ISNULL(cash, 0))		AS total_cash,
	SUM(ISNULL(votepoint, 0))	AS total_votepoint
FROM dbo.CHARACTER_CASH_TBL
GO