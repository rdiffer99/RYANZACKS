USE [CHARACTER_01_DBF]
GO

/****** Object:  Table [dbo].[ZCK_CRAFT_TBL]    Script Date: 10/10/2026 12:41:05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ZCK_CRAFT_TBL](
	[serverindex] [char](2) NOT NULL,
	[m_idPlayer] [varchar](7) NOT NULL,
	[m_nZckCraftExp] [int] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


USE [CHARACTER_01_DBF]
GO

/****** Object:  Index [ZCK_CRAFT_ID1]    Script Date: 10/10/2026 12:41:13 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [ZCK_CRAFT_ID1] ON [dbo].[ZCK_CRAFT_TBL]
(
	[m_idPlayer] ASC,
	[serverindex] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 75) ON [PRIMARY]
GO


USE [CHARACTER_01_DBF]
GO

/****** Object:  Index [ZCK_CRAFT_TBL_ID1]    Script Date: 10/10/2026 12:41:25 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [ZCK_CRAFT_TBL_ID1] ON [dbo].[ZCK_CRAFT_TBL]
(
	[m_idPlayer] DESC,
	[serverindex] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


USE [CHARACTER_01_DBF]
GO

/****** Object:  Index [IDX_ZCK_CRAFT_TBL_m_idPlayer]    Script Date: 10/10/2026 12:41:33 AM ******/
CREATE UNIQUE CLUSTERED INDEX [IDX_ZCK_CRAFT_TBL_m_idPlayer] ON [dbo].[ZCK_CRAFT_TBL]
(
	[m_idPlayer] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


USE [CHARACTER_01_DBF]
GO

/****** Object:  StoredProcedure [dbo].[SAVE_ZCK_CRAFT]    Script Date: 10/10/2026 12:41:52 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SAVE_ZCK_CRAFT]
	@im_idPlayer varchar(7),
	@iserverindex char(2),
	@im_nZckCraftExp int = 0
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS(SELECT * FROM ZCK_CRAFT_TBL WHERE m_idPlayer = @im_idPlayer AND serverindex = @iserverindex)
		UPDATE ZCK_CRAFT_TBL SET m_nZckCraftExp = @im_nZckCraftExp
							 WHERE
								  m_idPlayer = @im_idPlayer
							 AND  serverindex = @iserverindex
	ELSE
		INSERT ZCK_CRAFT_TBL (m_idPlayer,     serverindex,    m_nZckCraftExp)
					VALUES	  (@im_idPlayer, @iserverindex, @im_nZckCraftExp)
END

GO


