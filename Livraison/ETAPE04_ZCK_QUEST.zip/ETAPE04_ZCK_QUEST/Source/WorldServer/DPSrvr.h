#ifndef __DPSRVR_H__
#define __DPSRVR_H__

#pragma once

#include "DPMng.h"
#include "MsgHdr.h"
#include "Snapshot.h"

#ifdef __FL_EQUALIZED_MODE
#include "User.h"
#endif

#undef	theClass
#define theClass	CDPSrvr
#undef theParameters
#define theParameters	CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize

class CDPSrvr : public CDPMng
{
public:
	// Constructions
	CDPSrvr();
	virtual	~CDPSrvr();

	// Operations
	virtual	void SysMessageHandler(LPDPMSG_GENERIC lpMsg, DWORD dwMsgSize, DPID idFrom);
	virtual void UserMessageHandler(LPDPMSG_GENERIC lpMsg, DWORD dwMsgSize, DPID idFrom);

	USES_PFNENTRIES;

	// Handlers
	void	OnAddConnection(DPID dpid);
	void	OnRemoveConnection(DPID dpid);
	void	OnAddUser(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnRemoveUser(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnChat(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#ifdef __ZCK_FENETRE_CHAT_MJ
	void	OnZckFenetreChatMj(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif // __ZCK_FENETRE_CHAT_MJ
	void	OnMoveItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnDropItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnDropGold(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnTrade(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnConfirmTrade(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnConfirmTradeCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnTradePut(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnTradePull(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnTradePutGold(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnTradeClearGold(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnTradeCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnTradeOk(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnTradelastConfrim(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPVendorOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPVendorClose(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRegisterPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnUnregisterPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnBuyPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnEnchant(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSmeltSafety(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRemoveAttribute(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnCreateSfxObj(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPiercing(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPiercingRemove(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void	OnItemTransy(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnCommercialElem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRepairItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnScriptDialogReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnOpenShopWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnCloseShopWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnBuyItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnBuyChipItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSellItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnOpenBankWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnOpenGuildBankWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnCloseGuildBankWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPutItemGuildBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGetItemGuildBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGuildBankMoveItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnCloseBankWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnBankToBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPutItemBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGetItemBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPutGoldBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize);
	void	OnGetGoldBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize);
	void	OnMoveBankItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnChangeBankPass(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnConfirmBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRevival(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRevivalLodestar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPlayerBehavior(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPlayerSetDestObj(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnCorrReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSkillTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnAddAppletTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRemoveAppletTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnAddItemTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRemoveItemTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPartyRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnAddFriendNameReqest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPartyRequestCancle(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPartySkillUse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnAddFriendReqest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnAddFriendCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGetFriendName(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRemoveQuest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryPlayerData(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryPlayerData2(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

#ifdef __JEFF_11
	void	OnQuePetResurrection(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif	// __JEFF_11
#ifdef __JEFF_11_4
	void	OnArenaEnter(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnArenaExit(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif	// __JEFF_11_4
	void	OnGuildInvite(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnIgnoreGuildInvite(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnEndSkillQueue(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void	OnDoUseItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void	OnDoUseItemTarget(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRemoveItemLevelDown(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnBlessednessCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void	OnMeleeAttack(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnMeleeAttack2(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnMagicAttack(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRangeAttack(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnUseSkill(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnUseObject(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSfxID(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSfxHit(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSfxClear(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSnapshot(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSetTarget(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	//	void	OnDoCollect( CAr & ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize );
	void	OnTeleSkill(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPlayerPos(CAr& ar, CUser* pUser);
	void	OnPlayerDestPos(CAr& ar, CUser* pUser);
	void	OnModifyMode(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnExpUp(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSetHair(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnBlock(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGuildLogo(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGuildContribution(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGuildNotice(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnEnterChattingRoom(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnChatting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnOpenChattingRoom(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnCloseChattingRoom(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void	OnSetNaviPoint(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnResurrectionOK(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnResurrectionCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnChangeMode(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnStateMode(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQuerySetPlayerName(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQuerySetGuildName(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnDoEscape(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnCheering(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryEquip(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryEquipSetting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnFoucusObj(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnReturnScroll(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnChangeFace(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryPostMail(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryRemoveMail(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryGetMailItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryGetMailGold(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryReadMail(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryMailBox(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGCApp(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGCCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGCRequestStatus(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGCSelectPlayer(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGCSelectMap(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGCJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGCTele(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnGCPlayerPoint(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSummonFriend(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSummonFriendConfirm(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSummonFriendCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSummonParty(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnSummonPartyConfirm(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void	OnRemoveInvenItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnRandomScroll(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void	OnCreateMonster(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void	OnCreateAngel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnAngleBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

#ifdef __EVE_MINIGAME
	void OnKawibawiboStart(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnKawibawiboGetItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif // __EVE_MINIGAME


	void OnUltimateMakeItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnUltimateMakeGem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnUltimateTransWeapon(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnUltimateSetGem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnUltimateRemoveGem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnUltimateEnchantWeapon(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

#ifdef __TRADESYS
	void OnExchange(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif // __TRADESYS

#if __VER >= 9	// __PET_0410
	void	OnPetRelease(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnUsePetFeed(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnMakePetFeed(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPetTamerMistake(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPetTamerMiracle(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnFeedPocketInactive(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif	// __PET_0410

#if __VER >= 11 // __SYS_COLLECTING
	void	OnQueryStartCollecting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnQueryStopCollecting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif	// __SYS_COLLECTING

#if __VER >= 9 // __CSC_VER9_2
	void OnModifyStatus(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif //__CSC_VER9_2

#if __VER >= 11
	void OnQueryGuildBankLogList(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif
#if __VER >= 13
	void OnHonorListReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnHonorChangeReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif
#ifdef __NPC_BUFF
	void OnNPCBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif // __NPC_BUFF

	void OnSecretRoomTenderOpenWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnSecretRoomLineUpOpenWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnSecretRoomTender(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnSecretRoomTenderCancelReturn(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnSecretRoomLineUpMember(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnSecretRoomEntrance(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnSecretRoomTeleportToNPC(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void OnSecretRoomTenderView(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

#ifndef __FL_GUILD_FINDER
	BOOL IsInviteAbleGuild(CUser* pUser);
#else
	BOOL IsInviteAbleGuild(u_long idGuild, CUser* pUser);
#endif

	void OnSetTaxRate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

	void OnTeleportToHeavenTower(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

public:
	void	QueryDestroyPlayer(DPID dpidCache, DPID dpidUser, DWORD dwAuthKey, u_long idPlayer);
#ifndef __FL_FIX_USELESS_LOGS
	void	PutCreateItemLog(CUser* pUser, CItemElem* pItemElem, const char* szAction, const char* recv);
#endif
	void	OnLogItem(LogItemInfo& info, CItemElem* pItemElem = NULL, int nItemCount = 0);
	void	InviteParty(u_long uLeaderid, u_long uMemberid, BOOL bTroup);
	void	InviteCompany(CUser* pUser, OBJID objid);
	void	UpdateGuildBank(CGuild* p_GuildBank, int p_Mode, BYTE cbUpdate = 0, u_long idPlayer = 0, CItemElem* pItemElem = NULL, DWORD dwPenya = 0, short nItemCount = 0);
	BOOL	ClosePVendor(CUser* pUser, OBJID objidVendor);
	BOOL	IsPiercingSize(CUser* pUser, CItemElem* pItemElem0, CItemElem* pItemElem1, CItemElem* pItemElem2, int& nError);

	BOOL	DoUseItemTarget_GenRandomOption(CUser* pUser, CItemElem* pTarget, int nKind,
		int nOk, int nMismatchKind, int nHasOption,
		const char* szOperation, const char* szReceive);
	BOOL	DoUseItemTarget_InitializeRandomOption(CUser* pUser, CItemElem* pTarget, int nKind,
		int nOk, int nError,
		const char* szOperation, const char* szRecv);
	BOOL	DoUseItemTarget_ItemLevelDown(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget);

#if __VER >= 12 // __LORD
public:
	void	PutItemLog(CUser* pUser, const char* szAction, const char* szContext, CItemElem* pItem, int nNum = 0);
	void	PutPenyaLog(CUser* pUser, const char* szAction, const char* szContext, int nCost);
private:
	void	OnElectionAddDeposit(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnElectionSetPledge(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnElectionIncVote(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnLEventCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnLordSkillUse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif	// __LORD
#if __VER >= 12 // __PET_0519
	void	OnPickupPetAwakeningCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif	// __PET_0519

#ifdef __PET_1024
	void	OnClearPetName(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif	// __PET_1024

	void	OnHousingSetupFurniture(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnHousingSetVisitAllow(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnHousingVisitRoom(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnHousingVisitableList(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnHousingGoOut(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnReqQuestNPCPos(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnPropose(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnRefuse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnCouple(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnDecouple(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#ifdef __MAP_SECURITY
	void	OnMapKey(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __MAP_SECURITY
	void	OnRemoveVis(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnSwapVis(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnBuyGuildHouse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnGuildHousePacket(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnGuildHouseEnter(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnGuildHouseGoOut(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnTeleporterReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnCheckedQuest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnItemSelectAwakeningValue(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);

#ifdef __FL_DUNGEON_TREASURE
	void	OnDungeonTreasureSelect(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_CONSUMABLES_STORAGE
	void	OnMoveItemToChest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnMoveItemInsideChest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnMoveAllItemsToChest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif
#ifdef __FL_BOXES_V2
	void	OnBulkBoxOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif
	BOOL    UnbindScroll(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget);
#ifdef __FL_FAST_ELEMENT
	void	OnChangeAttributeNew(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize);
#endif
	void	OnHideCoat(CAr&, DPID, DPID, LPBYTE, u_long);
#ifdef __FL_SHOP_SEARCH
	void	OnRequestShopSearch(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize);
	void	OnTeleportToShop(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize);
#endif
#ifdef __FL_PET_FILTER
	void	OnPetLootOption(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnPetFilterException(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
#endif
#ifdef __FL_EQUALIZED_MODE
	void OnSelectTmpClass(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
public:
	vector<TEMPORAL_PRESETS> m_vecTemporalConfig;
private:
#endif
	void	OnConfirmPartyRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnConfirmFriendRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);
	void	OnConfirmGuildRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize);

#ifdef __FL_FFA
	void	OnRequestFFA(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnRequestFFARegister(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnRequestFFAJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif

#ifdef __FL_DAILY_REWARDS
	void	OnCollectDailyGift(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif

#ifdef __WIKI_ITEMS_V2
	void	OnWikiCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif

#ifdef __FL_TELEPORT
	void	OnTeleportRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __JOB_CHANGE
	void	OnSendJobChange(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_RECYCLE
	void	OnRecycle(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_PARTY_FINDER
	void	OnPartyFinderRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnPartyFinderJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_VENDORS
	void	OnVendorAction(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif

#ifdef __FL_CASH_SHOP
	void	OnGetCShopBalance(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnBuyCShopItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_NEW_BOXES
	void	OnNewBoxOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
	void	OnUseTransy(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#ifdef __FL_PENYA_CONVERTER
	void	OnConvertPenya(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_SWITCH_EQ
	void	OnSwitchAdd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnSwitchDelete(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnSwitchUse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_GUILD_FINDER
	void	OnGuildFinderRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnGuildFinderJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnGuildFinderAddon(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_PACKED_ITEMS
	void	OnPackageOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnPackageAdd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnPackageRestore(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_WHEEL_OF_FORTUNE
	void	OnWofRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnWofStart(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnWofFinish(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_RECORD_BOOK
	void	OnRecordBook(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_MONSTER_ALBUM
	void	OnMABossCardSlotRestore(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_ACHIEVEMENT
	void	OnZckAchievementClaim(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_QUEST
	void	OnZckQuest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_QUEST
#ifdef __ZCK_CLASSEMENT
	void	OnZckClassement(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_PRESTIGE
	void	OnZckPrestigeRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_SYSTEME_EVEIL
    void OnZckSystemeEveil(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
    void OnZckAwakeAffinity(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_MINIJEU_PVP
	void OnZckPvPMinigameCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckPvPMinigameCommand(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckPvPMinigameChat(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckPvPMinigameGetList(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_ANARCHY
	void OnZckAnarchy(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_ANARCHY
#ifdef __ZCK_INVASION
	void OnZckInvasion(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_INVASION
#ifdef __ZCK_BADGE
	void OnZckBadge(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_BADGE
#ifdef __ZCK_AURA_SYSTEM
	void OnZckAura(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_AURA_SYSTEM
#ifdef __ZCK_PET_GLOW
	void OnZckPetGlow(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_PET_GLOW
#ifdef __ZCK_TRAILS
	void OnZckTrails(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_TRAILS
#ifdef __ZCK_ELEMENT_RGB
	// Element RGB : main, couleur demandee + Pierre d'element RGB (PACKETTYPE_ZCK_ELEMENT_RGB).
	void OnZckElementRgb(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_ELEMENT_RGB
#ifdef __ZCK_VOIR_INVENTAIRE_JOUEURS
	// Voir l'inventaire d'un joueur (MJ) : nom du joueur vise et onglet (PACKETTYPE_ZCK_VOIR_INVENTAIRE).
	void OnZckVoirInventaire(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_VOIR_INVENTAIRE_JOUEURS
#ifdef __ZCK_CHANGE_DST_NIVEAU
	// Changement de la caracteristique du niveau d'arme : objid, serie, choix (PACKETTYPE_ZCK_CHANGE_DST_NIVEAU).
	void OnZckChangeDstNiveau(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_CHANGE_DST_NIVEAU
#ifdef __ZCK_MOUNTURE_VOLANTE
	void OnZckMontureVolante(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_MOUNTURE_VOLANTE
#ifdef __ZCK_IA_FARM
	// Auto Farm IA hors ligne : reglages + armement du client (PACKETTYPE_ZCK_IA_FARM).
	void OnZckIaFarm(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
	// Buffs mondiaux : action + index + empreinte du .inc (PACKETTYPE_ZCK_MONDIAL_BUFF).
	void OnZckMondialBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
	// Buffs Perin : action + quantite + empreinte du .inc (PACKETTYPE_ZCK_PERIN_BUFF).
	void OnZckPerinBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_PERIN_BUFF
#ifdef __ZCK_AMELIORATION_TICKET
	// Carte des joueurs d'un canal : objid du ticket, monde, canal (PACKETTYPE_ZCK_TICKET_CARTE).
	void OnZckTicketCarte(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_AMELIORATION_TICKET
#ifdef __ZCK_LISTE_JOUEURS
	void OnPlayerListRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnPlayerListUpdateMods(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_LISTE_JOUEURS
#ifdef __ZCK_COMBAT_MC
	void OnZckCombatMCRegisterWindow(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckCombatMCRegisterMemberWindow(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckCombatMCRegister(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckCombatMCRegisterMember(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckCombatMCUnregisterMember(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_COMBAT_MC
#ifdef __ZCK_TOUR_INFINI
	void OnZckTourInfiniEnter(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckTourInfiniLeave(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnZckTourInfiniRanking(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_TOUR_INFINI
#ifdef __ZCK_COLOSSEUM
	void OnZckColosseum(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_COLOSSEUM
#ifdef __FL_TDM
	void	OnRequestTDM(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnRequestTDMRegister(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnRequestTDMJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_BUYBACK
	void	OnBuyback(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnBuybackRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_WIKI_HONORS
	void	OnRequestHonors(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_SEASON_PASS
	void	OnSeasonPassUnlock(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void	OnSeasonPassClaim(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_WARDROBE
	void OnWardrobePresetCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnWardrobePresetDelete(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnWardrobePresetUse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnWardrobeItemActivate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnWardrobeItemDeactivate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void OnWardrobeItemUnlock(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_ITEM_RUNE
	BOOL    DoUseItemTarget_FashRuneAdd(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget);
	BOOL    DoUseItemTarget_FashRuneRemove(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget, bool bRestore);
#endif
#ifdef __FL_QUICK_SELL
	void OnQuickSell(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	void DoSellItem(CUser* pUser, CMover* pVendor, vector<DWORD>& refVecItemObjID, int nItemNum = 0, int nType = TYPE_INVENTORY);
#endif
#ifdef __SIZED_SNAPSHOTS_V2
	void OnSnapshotReport(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_WORLDBOSS
	void OnWorldBossTeleport(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
	void OnExpUpStop(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#ifdef __ZCK_CRAFT_LOAD_TEX
	// Artisanat : demande nommant une recette (PACKETTYPE_ZCK_CRAFT), jugee en entier ici.
	void OnZckCraft(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#else
#line 552 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#ifdef __ZCK_BURNOUT
	void OnZckBurnout(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_BURNOUT
#ifdef __FL_AUTO_STAT
	void OnAutoStat(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __FL_PLAYER_STATUE
	void OnPlayerStatueBuffReceive(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_UPGRADE
	void OnUpgrade(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_RARE
	void OnZckRare(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_ARME_REBORN
	void OnZckArmeReborn(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif // __ZCK_ARME_REBORN
#ifdef __ZCK_DIFFICULTY
	void OnDungeonDifficulty(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#endif
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	// Retrait d'un buff de competence demande par le joueur (PACKETTYPE_ZCK_RETIRER_BUFF).
	void OnZckRetirerBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
#else
#line 573 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __ZCK_LINK
	// Lien d'objet dans le chat (DPSrvr.cpp, apres OnChat ; code commun dans FuncTextCmd.h).
	// Clic sur un lien : identifiant de lien seul (PACKETTYPE_ZCK_LIEN_DEMANDE).
	void	OnZckLienDemande(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long);
	// Codes du message pszChat de pUser (OnChat, avant ParsingCommand) : #j valides
	// reecrits en #k, tout autre code retire. TRUE si le message contenait un code.
	BOOL	ZckLienReecrire(CUser* pUser, TCHAR* pszChat);
public:
	// Range une copie (lien de ce WorldServer ou relaye par le CoreServer, appele par
	// CDPCoreClient::OnZckLienCopie) ; FALSE si elle est invalide ou deja connue.
	BOOL	ZckLienRanger(DWORD dwHaut, DWORD dwBas, const BYTE* pOctets, int nTaille);
private:
#define ZCK_LIEN_DUREE				900000		// une copie est servie 15 minutes
#define ZCK_LIEN_STOCK_MAX			20000		// copies gardees au plus ...
#define ZCK_LIEN_STOCK_OCTETS		(16 * 1024 * 1024)	// ... et octets au plus ; les plus anciennes partent d'abord
	struct ZCK_LIEN_STOCK
	{
		DWORD			dwHeure;		// GetTickCount() a l'arrivee de la copie
		vector<BYTE>	aOctets;		// CItemElem::Serialize, 1 a ZCK_LIEN_COPIE_MAX octets
	};
	map<unsigned __int64, ZCK_LIEN_STOCK>	m_mapZckLien;			// identifiant de lien -> copie
	deque<unsigned __int64>					m_dqZckLien;			// identifiants, du plus ancien au plus recent
	size_t									m_nZckLienOctets = 0;	// octets de toutes les copies gardees
	DWORD									m_dwZckLienSeconde = 0;	// seconde du dernier identifiant cree
	DWORD									m_dwZckLienCompteur = 0;	// identifiants deja crees dans cette seconde
	BOOL	ZckLienCreer(CUser* pUser, const struct ZCK_LIEN* pDemande, TCHAR* pszCode);
	void	ZckLienPurger();
#else
#line 574
#endif // __ZCK_LINK
private:
	DPID	m_dpidCache;
};


#endif // __DPSRVR_H__