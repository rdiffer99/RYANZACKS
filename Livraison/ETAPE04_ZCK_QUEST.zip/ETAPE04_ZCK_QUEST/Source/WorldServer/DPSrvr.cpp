#include "stdafx.h"
#ifdef __ZCK_SPD_LOG
#include "ZckSpdLog.h"
#endif // __ZCK_SPD_LOG
#include "defineText.h"
#include "defineItem.h"
#include "defineSkill.h"
#include "dpcoreclient.h"
#include "dpdatabaseclient.h"
#include "dpsrvr.h"
#include "definesound.h"
#include "defineObj.h"
#include "user.h"
#include "worldmng.h"
#include "misc.h"
#include "lang.h"
#include "npchecker.h"
#include "guild.h"
#include "..\_Common\Ship.h"
#include "Party.h"
#include "Chatting.h"
#include "post.h"
#include "..\_Network\ErrorCode.h"
#include "definequest.h"
#include "Exchange.h"
#ifdef __ZCK_LINK
#include "FuncTextCmd.h"
#else
#line 25
#endif // __ZCK_LINK
#ifdef __ZCK_DIFFICULTY
#include "InstanceDungeonBase.h"
#endif
#ifdef __ZCK_CLASSEMENT
#include "ZckClassementDonjon.h"
#endif
#ifdef __ZCK_MINIJEU_PVP
#include "..\_Common\ZckPvPMinigames.h"
#endif
#ifdef __ZCK_COMBAT_MC
#include "ZckCombatMC.h"
#endif // __ZCK_COMBAT_MC
#ifdef __ZCK_TOUR_INFINI
#include "ZckTourInfini.h"
#endif // __ZCK_TOUR_INFINI
#ifdef __ZCK_COLOSSEUM
#include "ZckColosseum.h"
#endif // __ZCK_COLOSSEUM
#ifdef __FL_TELEPORT
#include "Teleporter.h"
#endif
#ifdef __ZCK_CRAFT_LOAD_TEX
#include "ZckCraftLoadTexTraitement.h"
#else
#line 51 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX

#ifdef __FL_CASH_SHOP
#include "FlyFFShop.h"
#endif

#if __VER >= 12 // __PET_0519
#include "pet.h"
#endif	// __PET_0519

#if __VER >= 12 // __LORD
#include "slord.h"
#include "lordskillexecutable.h"
#endif	// __LORD

#if __VER >= 11 // __SYS_IDENTIFY
#include "randomoption.h"
#endif	// __SYS_IDENTIFY

#if __VER >= 11 // __SYS_PLAYER_DATA
#include "playerdata.h"
#endif	// __SYS_PLAYER_DATA

#if __VER >= 12 // __ITEMCREATEMON_S0602
#include "CreateMonster.h"
#endif // __ITEMCREATEMON_S0602

#if __VER >= 13
#include "honor.h"
#endif

#if __VER >= 12 // __SECRET_ROOM
#include "SecretRoom.h"
#endif // __SECRET_ROOM

#if __VER >= 12 // __TAX
#include "Tax.h"
#endif // __TAX

#if __VER >= 12 // __EXT_PIERCING
#include "ItemUpgrade.h"
#endif // __EXT_PIERCING

#include "tools.h"

#if __VER >= 13 // __COUPLE_1117
#include "couplehelper.h"
#endif	// __COUPLE_1117

#if __VER >= 15 // __GUILD_HOUSE 
#include "GuildHouse.h"
#endif // __GUILD_HOUSE

#ifdef __FL_FFA
#include "FFAManager.h"
#endif
#ifdef __FL_TDM
#include "TDMManager.h"
#endif

#ifdef __FL_WHEEL_OF_FORTUNE
#include "WheelOfFortune.h"
#endif

#ifdef __FL_RECORD_BOOK
#include "RecordBook.h"
#endif

#ifdef __FL_WORLDBOSS
#include "WorldBoss.h"
#endif

#ifdef __ZCK_FENETRE_CHAT_MJ
#include "ZckFenetreChatMj.h"
#endif // __ZCK_FENETRE_CHAT_MJ

#ifdef __ZCK_ANARCHY
#include "ZckAnarchy.h"
#include "ZckAnarchyRank.h"
#endif // __ZCK_ANARCHY

#ifdef __ZCK_BUFF_CLASSE
#include "ZckBuffClasse.h"
#endif // __ZCK_BUFF_CLASSE

#ifdef __ZCK_BUFF_GROUPE
#include "ZckBuffGroupe.h"
#endif // __ZCK_BUFF_GROUPE

#ifdef __ZCK_IA_FARM
#include "ZckIaFarmServeur.h"
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
#include "ZckMondialBuff.h"
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
#include "ZckPerinBuff.h"
#endif // __ZCK_PERIN_BUFF
#ifdef __ZCK_AMELIORATION_TICKET
#include "ticket.h"
#endif // __ZCK_AMELIORATION_TICKET
#ifdef __ZCK_VOIR_INVENTAIRE_JOUEURS
#include "ZckVoirInventaire.h"
#endif // __ZCK_VOIR_INVENTAIRE_JOUEURS
#ifdef __ZCK_CHANGE_DST_NIVEAU
#include "ZckChangeDstNiveau.h"
#endif // __ZCK_CHANGE_DST_NIVEAU

#define	MAX_RANGE_ASYNC			1024
#define	MAX_RANGE_NPC_MENU		1024

extern	CGuildMng			g_GuildMng;
extern	CPartyMng			g_PartyMng;
extern	CUserMng			g_UserMng;
extern	CDPDatabaseClient	g_dpDBClient;
extern	CDPCoreClient		g_DPCoreClient;
extern	CWorldMng			g_WorldMng;
extern	CChattingMng		g_ChattingMng;
extern	CGuildCombat		g_GuildCombatMng;

CDPSrvr		g_DPSrvr;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
// Actions economiques interdites au staff (portage recode de Titanium __BLOCK_STAFF_ACTIONS) : echange,
// banque, banque de guilde, envoi de courrier, boutique personnelle (et vendeur), contribution et
// invitation de guilde, deliaison d'objet. Staff : tout grade de staff de __ZCK_AUTH (IsAuthHigher(AUTH_GUIDE) :
// Guide, Animateur, Moderateur, Maitre du jeu, Developpeur, Mappeur ; sans __ZCK_AUTH, AUTH_GAMEMASTER et
// plus), sauf le Developpeur (AUTH_ADMINISTRATOR), comme l'administrateur chez Titanium.
static BOOL ZckStaffBloque(CMover* pMover)
{
	if (!IsValidObj(pMover) || !pMover->IsPlayer())
		return FALSE;
	if (pMover->m_dwAuthorization == AUTH_ADMINISTRATOR)
		return FALSE;
#ifdef __ZCK_AUTH
	return pMover->IsAuthHigher(AUTH_GUIDE) ? TRUE : FALSE;
#else
	return pMover->IsAuthHigher(AUTH_GAMEMASTER) ? TRUE : FALSE;
#endif // __ZCK_AUTH
}

// TRUE si pUser fait partie du staff bloque : l'action est refusee et il en est prevenu.
static BOOL ZckRefusStaff(CUser* pUser, LPCTSTR szAction)
{
	if (!ZckStaffBloque(pUser))
		return FALSE;
	CString str;
	str.Format("Action interdite au staff : %s.", szAction);
	pUser->AddText(str, 0xffff0000);
	return TRUE;
}

// Echange : refuse si l'un des deux fait partie du staff bloque ; c'est pUser, qui agit, qui est prevenu
// (Titanium prevenait l'autre joueur, et castait un BOOL en CUser*).
static BOOL ZckRefusStaffEchange(CUser* pUser, CMover* pTrader)
{
	if (ZckRefusStaff(pUser, "\351change"))
		return TRUE;
	if (!ZckStaffBloque(pTrader))
		return FALSE;
	pUser->AddText("\311change impossible : ce personnage fait partie du staff.", 0xffff0000);
	return TRUE;
}

// Retrait d'un buff de competence par le joueur (portage recode de Titanium __REMOVE_SKILL_BUFF) : seulement
// un buff de competence present sur lui, et benefique (nEvildoing >= 1), sauf avec les droits
// d'administration (IsAuthHigher(AUTH_ADMINISTRATOR)). L'identifiant est borne avant toute lecture des
// proprietes : un paquet court donne 0 (CAr), refuse ; rien d'autre n'est lu du client.
void CDPSrvr::OnZckRetirerBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	DWORD dwSkill = 0;
	ar >> dwSkill;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
	if (dwSkill == 0 || dwSkill > 0xFFFF || dwSkill >= (DWORD)prj.m_aPropSkill.GetSize())
		return;
	ItemProp* pSkillProp = prj.GetSkillProp((int)dwSkill);
	if (pSkillProp == NULL)
		return;
	if (pSkillProp->nEvildoing < 1 && !pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
		return;
	if (!pUser->HasBuff(BUFF_SKILL, (WORD)dwSkill))
		return;
	pUser->RemoveBuff(BUFF_SKILL, (WORD)dwSkill);
}

#else
#line 171 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF


#ifdef __ZCK_CRAFT_LOAD_TEX
// Artisanat (portage recode de Titanium __AEGON_CRAFTING_SYSTEM) : le paquet est lu en
// entier (contrat de _Common/ZckCraftLoadTex.h), puis tout est juge par ZckCraftTraiter
// (WorldServer/ZckCraftLoadTexTraitement.h) : forme, sequence, delai, etat du joueur,
// recette, ingredients, place. Le client ne designe jamais un objet.
void CDPSrvr::OnZckCraft(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	ZCK_CRAFT_DEMANDE d;
	ZckCraftLireDemande(ar, d);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	BOOL bModeEgalise = FALSE;
#ifdef __FL_EQUALIZED_MODE
	bModeEgalise = pUser->bTmpMode;
#endif // __FL_EQUALIZED_MODE
	BOOL bStaffBloque = FALSE;
#if defined(__ZCK_CUSTOM_UI_CORRECTIF)
	bStaffBloque = ZckStaffBloque(pUser);
#endif // ZckStaffBloque (__ZCK_CUSTOM_UI_CORRECTIF)
	ZckCraftTraiter(this, pUser, d, bModeEgalise, bStaffBloque);
}

#else
#line 242 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
BOOL CanAdd(DWORD dwGold, int nPlus)
{
	if (nPlus <= 0)
		return FALSE;

	__int64 n64Gold = (__int64)dwGold;
	if (n64Gold < 0 || (n64Gold + (__int64)nPlus) < 0 || (n64Gold + (__int64)nPlus) > INT_MAX)
		return FALSE;

	return TRUE;
}

CDPSrvr::CDPSrvr()
{
	BEGIN_MSG;

	ON_MSG(PACKETTYPE_JOIN, &CDPSrvr::OnAddUser);
	ON_MSG(PACKETTYPE_LEAVE, &CDPSrvr::OnRemoveUser);
	ON_MSG(PACKETTYPE_CORR_REQ, &CDPSrvr::OnCorrReq);
	ON_MSG(PACKETTYPE_SCRIPTDLG, &CDPSrvr::OnScriptDialogReq);
	ON_MSG(PACKETTYPE_TRADEPUT, &CDPSrvr::OnTradePut);
	ON_MSG(PACKETTYPE_TRADEPULL, &CDPSrvr::OnTradePull);
	ON_MSG(PACKETTYPE_TRADEPUTGOLD, &CDPSrvr::OnTradePutGold);
	ON_MSG(PACKETTYPE_SFX_ID, &CDPSrvr::OnSfxID);
	ON_MSG(PACKETTYPE_SFX_CLEAR, &CDPSrvr::OnSfxClear);
	ON_MSG(PACKETTYPE_CHAT, &CDPSrvr::OnChat);
	ON_MSG(PACKETTYPE_MOVEITEM, &CDPSrvr::OnMoveItem);
	ON_MSG(PACKETTYPE_SNAPSHOT, &CDPSrvr::OnSnapshot);
	ON_MSG(PACKETTYPE_MODIFYMODE, &CDPSrvr::OnModifyMode);
	ON_MSG(PACKETTYPE_REVIVAL, &CDPSrvr::OnRevival);
	ON_MSG(PACKETTYPE_REVIVAL_TO_LODESTAR, &CDPSrvr::OnRevivalLodestar);
	ON_MSG(PACKETTYPE_OPENSHOPWND, &CDPSrvr::OnOpenShopWnd);
	ON_MSG(PACKETTYPE_CLOSESHOPWND, &CDPSrvr::OnCloseShopWnd);
	ON_MSG(PACKETTYPE_SEND_TO_SERVER_EXP, &CDPSrvr::OnExpUp);
	ON_MSG(PACKETTYPE_OPENBANKWND, &CDPSrvr::OnOpenBankWnd);
	ON_MSG(PACKETTYPE_GUILD_BANK_WND, &CDPSrvr::OnOpenGuildBankWnd);
	ON_MSG(PACKETTYPE_PUTITEMGUILDBANK, &CDPSrvr::OnPutItemGuildBank);
	ON_MSG(PACKETTYPE_GETITEMGUILDBANK, &CDPSrvr::OnGetItemGuildBank);
	ON_MSG(PACKETTYPE_GUILD_BANK_WND_CLOSE, &CDPSrvr::OnCloseGuildBankWnd);
	ON_MSG(PACKETTYPE_GUILD_BANK_MOVEITEM, &CDPSrvr::OnGuildBankMoveItem);
	ON_MSG(PACKETTYPE_CLOSEBANKWND, &CDPSrvr::OnCloseBankWnd);
	ON_MSG(PACKETTYPE_PUTITEMBACK, &CDPSrvr::OnPutItemBank);
	ON_MSG(PACKETTYPE_PUTBACKTOBANK, &CDPSrvr::OnBankToBank);
	ON_MSG(PACKETTYPE_GETITEMBACK, &CDPSrvr::OnGetItemBank);
	ON_MSG(PACKETTYPE_PUTGOLDBACK, &CDPSrvr::OnPutGoldBank);
	ON_MSG(PACKETTYPE_GETGOLDBACK, &CDPSrvr::OnGetGoldBank);
	ON_MSG(PACKETTYPE_MOVEBANKITEM, &CDPSrvr::OnMoveBankItem);
	ON_MSG(PACKETTYPE_CHANGEBANKPASS, &CDPSrvr::OnChangeBankPass);
	ON_MSG(PACKETTYPE_CONFIRMBANK, &CDPSrvr::OnConfirmBank);

	ON_MSG(PACKETTYPE_PLAYERBEHAVIOR, &CDPSrvr::OnPlayerBehavior);
	ON_MSG(PACKETTYPE_PLAYERSETDESTOBJ, &CDPSrvr::OnPlayerSetDestObj);

	ON_MSG(PACKETTYPE_TRADE, &CDPSrvr::OnTrade);
	ON_MSG(PACKETTYPE_CONFIRMTRADE, &CDPSrvr::OnConfirmTrade);
	ON_MSG(PACKETTYPE_CONFIRMTRADECANCEL, &CDPSrvr::OnConfirmTradeCancel);
	ON_MSG(PACKETTYPE_TRADECANCEL, &CDPSrvr::OnTradeCancel);
	ON_MSG(PACKETTYPE_DOUSEITEM, &CDPSrvr::OnDoUseItem);

	ON_MSG(PACKETTYPE_DO_USE_ITEM_TARGET, &CDPSrvr::OnDoUseItemTarget);
	ON_MSG(PACKETTYPE_REMOVE_ITEM_LEVEL_DOWN, &CDPSrvr::OnRemoveItemLevelDown);
	ON_MSG(PACKETTYPE_BLESSEDNESS_CANCEL, &CDPSrvr::OnBlessednessCancel);

#ifdef __PET_1024
	ON_MSG(PACKETTYPE_CLEAR_PET_NAME, &CDPSrvr::OnClearPetName);
#endif	// __PET_1024

#ifdef __JEFF_11
	ON_MSG(PACKETTYPE_QUE_PETRESURRECTION, &CDPSrvr::OnQuePetResurrection);
#endif	// __JEFF_11

#ifdef __JEFF_11_4
	ON_MSG(PACKETTYPE_ARENA_ENTER, &CDPSrvr::OnArenaEnter);
	ON_MSG(PACKETTYPE_ARENA_EXIT, &CDPSrvr::OnArenaExit);
#endif	// __JEFF_11_4

	ON_MSG(PACKETTYPE_TRADECONFIRM, &CDPSrvr::OnTradelastConfrim);
	ON_MSG(PACKETTYPE_DROPITEM, &CDPSrvr::OnDropItem);
	ON_MSG(PACKETTYPE_DROPGOLD, &CDPSrvr::OnDropGold);
	ON_MSG(PACKETTYPE_BUYITEM, &CDPSrvr::OnBuyItem);
	ON_MSG(PACKETTYPE_BUYCHIPITEM, &CDPSrvr::OnBuyChipItem);
	ON_MSG(PACKETTYPE_SELLITEM, &CDPSrvr::OnSellItem);
	ON_MSG(PACKETTYPE_TRADEOK, &CDPSrvr::OnTradeOk);

	ON_MSG(PACKETTYPE_MELEE_ATTACK, &CDPSrvr::OnMeleeAttack);
	ON_MSG(PACKETTYPE_MELEE_ATTACK2, &CDPSrvr::OnMeleeAttack2);
	ON_MSG(PACKETTYPE_MAGIC_ATTACK, &CDPSrvr::OnMagicAttack);
	ON_MSG(PACKETTYPE_RANGE_ATTACK, &CDPSrvr::OnRangeAttack);

	ON_MSG(PACKETTYPE_SFX_HIT, &CDPSrvr::OnSfxHit);
	ON_MSG(PACKETTYPE_USESKILL, &CDPSrvr::OnUseSkill);
	ON_MSG(PACKETTYPE_USEOBJECT, &CDPSrvr::OnUseObject);
	ON_MSG(PACKETTYPE_SETTARGET, &CDPSrvr::OnSetTarget);
	ON_MSG(PACKETTYPE_TELESKILL, &CDPSrvr::OnTeleSkill);
	ON_MSG(PACKETTYPE_SKILLTASKBAR, &CDPSrvr::OnSkillTaskBar);
	ON_MSG(PACKETTYPE_ADDAPPLETTASKBAR, &CDPSrvr::OnAddAppletTaskBar);
	ON_MSG(PACKETTYPE_REMOVEAPPLETTASKBAR, &CDPSrvr::OnRemoveAppletTaskBar);
	ON_MSG(PACKETTYPE_ADDITEMTASKBAR, &CDPSrvr::OnAddItemTaskBar);
	ON_MSG(PACKETTYPE_REMOVEITEMTASKBAR, &CDPSrvr::OnRemoveItemTaskBar);
	ON_MSG(PACKETTYPE_MEMBERREQUEST, &CDPSrvr::OnPartyRequest);
	ON_MSG(PACKETTYPE_MEMBERREQUESTCANCLE, &CDPSrvr::OnPartyRequestCancle);
	ON_MSG(PACKETTYPE_PARTYSKILLUSE, &CDPSrvr::OnPartySkillUse);
	ON_MSG(PACKETTYPE_ADDFRIENDREQEST, &CDPSrvr::OnAddFriendReqest);
	ON_MSG(PACKETTYPE_ADDFRIENDNAMEREQEST, &CDPSrvr::OnAddFriendNameReqest);
	ON_MSG(PACKETTYPE_ADDFRIENDCANCEL, &CDPSrvr::OnAddFriendCancel);

	ON_MSG(PACKETTYPE_QUERY_PLAYER_DATA, &CDPSrvr::OnQueryPlayerData);
	ON_MSG(PACKETTYPE_QUERY_PLAYER_DATA2, &CDPSrvr::OnQueryPlayerData2);
	ON_MSG(PACKETTYPE_GUILD_INVITE, &CDPSrvr::OnGuildInvite);
	ON_MSG(PACKETTYPE_IGNORE_GUILD_INVITE, &CDPSrvr::OnIgnoreGuildInvite);
	ON_MSG(PACKETTYPE_NW_GUILDLOGO, &CDPSrvr::OnGuildLogo);
	ON_MSG(PACKETTYPE_NW_GUILDCONTRIBUTION, &CDPSrvr::OnGuildContribution);
	ON_MSG(PACKETTYPE_NW_GUILDNOTICE, &CDPSrvr::OnGuildNotice);
	ON_MSG(PACKETTYPE_PVENDOR_OPEN, &CDPSrvr::OnPVendorOpen);
	ON_MSG(PACKETTYPE_PVENDOR_CLOSE, &CDPSrvr::OnPVendorClose);
	ON_MSG(PACKETTYPE_REGISTER_PVENDOR_ITEM, &CDPSrvr::OnRegisterPVendorItem);
	ON_MSG(PACKETTYPE_UNREGISTER_PVENDOR_ITEM, &CDPSrvr::OnUnregisterPVendorItem);
	ON_MSG(PACKETTYPE_QUERY_PVENDOR_ITEM, &CDPSrvr::OnQueryPVendorItem);
	ON_MSG(PACKETTYPE_BUY_PVENDOR_ITEM, &CDPSrvr::OnBuyPVendorItem);
	ON_MSG(PACKETTYPE_SET_HAIR, &CDPSrvr::OnSetHair);
	ON_MSG(PACKETTYPE_BLOCK, &CDPSrvr::OnBlock);

	ON_MSG(PACKETTYPE_ENCHANT, &CDPSrvr::OnEnchant);
	ON_MSG(PACKETTYPE_SMELT_SAFETY, &CDPSrvr::OnSmeltSafety);
	ON_MSG(PACKETTYPE_REMVOE_ATTRIBUTE, &CDPSrvr::OnRemoveAttribute);
	ON_MSG(PACKETTYPE_RANDOMSCROLL, &CDPSrvr::OnRandomScroll);
	ON_MSG(PACHETTYPE_ITEMTRANSY, &CDPSrvr::OnItemTransy);
	ON_MSG(PACKETTYPE_PIERCING, &CDPSrvr::OnPiercing);
	ON_MSG(PACKETTYPE_PIERCINGREMOVE, &CDPSrvr::OnPiercingRemove);
	ON_MSG(PACKETTYPE_ENTERCHTTING, &CDPSrvr::OnEnterChattingRoom);
	ON_MSG(PACKETTYPE_CHATTING, &CDPSrvr::OnChatting);
	ON_MSG(PACKETTYPE_OPENCHATTINGROOM, &CDPSrvr::OnOpenChattingRoom);
	ON_MSG(PACKETTYPE_CLOSECHATTINGROOM, &CDPSrvr::OnCloseChattingRoom);

	ON_MSG(PACKETTYPE_SETNAVIPOINT, &CDPSrvr::OnSetNaviPoint);
	ON_MSG(PACKETTYPE_DO_ESCAPE, &CDPSrvr::OnDoEscape);
	ON_MSG(PACKETTYPE_RETURNSCROLL, &CDPSrvr::OnReturnScroll);
	ON_MSG(PACKETTYPE_ENDSKILLQUEUE, &CDPSrvr::OnEndSkillQueue);
	ON_MSG(PACKETTYPE_FOCUSOBJ, &CDPSrvr::OnFoucusObj);

	ON_MSG(PACKETTYPE_REMOVEQUEST, &CDPSrvr::OnRemoveQuest);

	ON_MSG(PACKETTYPE_RESURRECTION_OK, &CDPSrvr::OnResurrectionOK);
	ON_MSG(PACKETTYPE_RESURRECTION_CANCEL, &CDPSrvr::OnResurrectionCancel);
	ON_MSG(PACKETTYPE_MODE, &CDPSrvr::OnChangeMode);

	ON_MSG(PACKETTYPE_STATEMODE, &CDPSrvr::OnStateMode);
	ON_MSG(PACKETTYPE_QUERYSETPLAYERNAME, &CDPSrvr::OnQuerySetPlayerName);
	ON_MSG(PACKETTYPE_QUERYSETGUILDNAME, &CDPSrvr::OnQuerySetGuildName);
	ON_MSG(PACKETTYPE_CHEERING, &CDPSrvr::OnCheering);
	ON_MSG(PACKETTYPE_QUERYEQUIP, &CDPSrvr::OnQueryEquip);
	ON_MSG(PACKETTYPE_QUERYEQUIPSETTING, &CDPSrvr::OnQueryEquipSetting);
	ON_MSG(PACKETTYPE_QUERYPOSTMAIL, &CDPSrvr::OnQueryPostMail);
	ON_MSG(PACKETTYPE_QUERYREMOVEMAIL, &CDPSrvr::OnQueryRemoveMail);
	ON_MSG(PACKETTYPE_QUERYGETMAILITEM, &CDPSrvr::OnQueryGetMailItem);
	ON_MSG(PACKETTYPE_QUERYGETMAILGOLD, &CDPSrvr::OnQueryGetMailGold);
	ON_MSG(PACKETTYPE_READMAIL, &CDPSrvr::OnQueryReadMail);
	ON_MSG(PACKETTYPE_QUERYMAILBOX, &CDPSrvr::OnQueryMailBox);
	ON_MSG(PACKETTYPE_CHANGEFACE, &CDPSrvr::OnChangeFace);

	ON_MSG(PACKETTYPE_CREATEMONSTER, &CDPSrvr::OnCreateMonster);

	ON_MSG(PACKETTYPE_IN_GUILDCOMBAT, &CDPSrvr::OnGCApp);
	ON_MSG(PACKETTYPE_OUT_GUILDCOMBAT, &CDPSrvr::OnGCCancel);
	ON_MSG(PACKETTYPE_REQUEST_STATUS, &CDPSrvr::OnGCRequestStatus);
	ON_MSG(PACKETTYPE_SELECTPLAYER_GUILDCOMBAT, &CDPSrvr::OnGCSelectPlayer);
	ON_MSG(PACKETTYPE_SELECTMAP_GUILDCOMBAT, &CDPSrvr::OnGCSelectMap);
	ON_MSG(PACKETTYPE_JOIN_GUILDCOMBAT, &CDPSrvr::OnGCJoin);
	ON_MSG(PACKETTYPE_TELE_GUILDCOMBAT, &CDPSrvr::OnGCTele);
	ON_MSG(PACKETTYPE_PLAYERPOINT_GUILDCOMBAT, &CDPSrvr::OnGCPlayerPoint);
	ON_MSG(PACKETTYPE_SUMMON_FRIEND, &CDPSrvr::OnSummonFriend);
	ON_MSG(PACKETTYPE_SUMMON_FRIEND_CONFIRM, &CDPSrvr::OnSummonFriendConfirm);
	ON_MSG(PACKETTYPE_SUMMON_FRIEND_CANCEL, &CDPSrvr::OnSummonFriendCancel);
	ON_MSG(PACKETTYPE_SUMMON_PARTY, &CDPSrvr::OnSummonParty);
	ON_MSG(PACKETTYPE_SUMMON_PARTY_CONFIRM, &CDPSrvr::OnSummonPartyConfirm);

	ON_MSG(PACKETTYPE_REMOVEINVENITEM, &CDPSrvr::OnRemoveInvenItem);

	ON_MSG(PACKETTYPE_CREATEANGEL, &CDPSrvr::OnCreateAngel);
	ON_MSG(PACKETTYPE_ANGELBUFF, &CDPSrvr::OnAngleBuff);

#ifdef __EVE_MINIGAME
	ON_MSG(PACKETTYPE_KAWIBAWIBO_START, &CDPSrvr::OnKawibawiboStart);
	ON_MSG(PACKETTYPE_KAWIBAWIBO_GETITEM, &CDPSrvr::OnKawibawiboGetItem);
#endif // __EVE_MINIGAME

	ON_MSG(PACKETTYPE_ULTIMATE_MAKEITEM, &CDPSrvr::OnUltimateMakeItem);
	ON_MSG(PACKETTYPE_ULTIMATE_MAKEGEM, &CDPSrvr::OnUltimateMakeGem);
	ON_MSG(PACKETTYPE_ULTIMATE_TRANSWEAPON, &CDPSrvr::OnUltimateTransWeapon);
	ON_MSG(PACKETTYPE_ULTIMATE_SETGEM, &CDPSrvr::OnUltimateSetGem);
	ON_MSG(PACKETTYPE_ULTIMATE_REMOVEGEM, &CDPSrvr::OnUltimateRemoveGem);
	ON_MSG(PACKETTYPE_ULTIMATE_ENCHANTWEAPON, &CDPSrvr::OnUltimateEnchantWeapon);

#ifdef __TRADESYS
	ON_MSG(PACKETTYPE_EXCHANGE, &CDPSrvr::OnExchange);
#endif // __TRADESYS

	ON_MSG(PACKETTYPE_PET_RELEASE, &CDPSrvr::OnPetRelease);
	ON_MSG(PACKETTYPE_USE_PET_FEED, &CDPSrvr::OnUsePetFeed);
	ON_MSG(PACKETTYPE_MAKE_PET_FEED, &CDPSrvr::OnMakePetFeed);
	ON_MSG(PACKETTYPE_PET_TAMER_MISTAKE, &CDPSrvr::OnPetTamerMistake);
	ON_MSG(PACKETTYPE_PET_TAMER_MIRACLE, &CDPSrvr::OnPetTamerMiracle);
	ON_MSG(PACKETTYPE_FEED_POCKET_INACTIVE, &CDPSrvr::OnFeedPocketInactive);

	ON_MSG(PACKETTYPE_MODIFY_STATUS, &CDPSrvr::OnModifyStatus);

	ON_MSG(PACKETTYPE_GUILDLOG_VIEW, &CDPSrvr::OnQueryGuildBankLogList);

	ON_MSG(PACKETTYPE_HONOR_LIST_REQ, &CDPSrvr::OnHonorListReq);
	ON_MSG(PACKETTYPE_HONOR_CHANGE_REQ, &CDPSrvr::OnHonorChangeReq);

	ON_MSG(PACKETTYPE_QUERY_START_COLLECTING, &CDPSrvr::OnQueryStartCollecting);
	ON_MSG(PACKETTYPE_QUERY_STOP_COLLECTING, &CDPSrvr::OnQueryStopCollecting);

#ifdef __NPC_BUFF
	ON_MSG(PACKETTYPE_NPC_BUFF, &CDPSrvr::OnNPCBuff);
#endif // __NPC_BUFF

	ON_MSG(PACKETTYPE_SECRETROOM_TENDEROPENWND, &CDPSrvr::OnSecretRoomTenderOpenWnd);
	ON_MSG(PACKETTYPE_SECRETROOM_TENDER, &CDPSrvr::OnSecretRoomTender);
	ON_MSG(PACKETTYPE_SECRETROOM_TENDERCANCELRETURN, &CDPSrvr::OnSecretRoomTenderCancelReturn);
	ON_MSG(PACKETTYPE_SECRETROOM_LINEUPOPENWND, &CDPSrvr::OnSecretRoomLineUpOpenWnd);
	ON_MSG(PACKETTYPE_SECRETROOM_LINEUPMEMBER, &CDPSrvr::OnSecretRoomLineUpMember);
	ON_MSG(PACKETTYPE_SECRETROOM_ENTRANCE, &CDPSrvr::OnSecretRoomEntrance);
	ON_MSG(PACKETTYPE_SECRETROOM_TELEPORTTONPC, &CDPSrvr::OnSecretRoomTeleportToNPC);
	ON_MSG(PACKETTYPE_SECRETROOM_TENDERVIEW, &CDPSrvr::OnSecretRoomTenderView);

	ON_MSG(PACKETTYPE_ELECTION_ADD_DEPOSIT, &CDPSrvr::OnElectionAddDeposit);
	ON_MSG(PACKETTYPE_ELECTION_SET_PLEDGE, &CDPSrvr::OnElectionSetPledge);
	ON_MSG(PACKETTYPE_ELECTION_INC_VOTE, &CDPSrvr::OnElectionIncVote);
	ON_MSG(PACKETTYPE_L_EVENT_CREATE, &CDPSrvr::OnLEventCreate);
	ON_MSG(PACKETTYPE_LORD_SKILL_USE, &CDPSrvr::OnLordSkillUse);


	ON_MSG(PACKETTYPE_TAX_SET_TAXRATE, &CDPSrvr::OnSetTaxRate);

	ON_MSG(PACKETTYPE_HEAVENTOWER_TELEPORT, &CDPSrvr::OnTeleportToHeavenTower);

	ON_MSG(PACKETTYPE_PICKUP_PET_AWAKENING_CANCEL, &CDPSrvr::OnPickupPetAwakeningCancel);

	ON_MSG(PACKETTYPE_HOUSING_SETUPFURNITURE, &CDPSrvr::OnHousingSetupFurniture);
	ON_MSG(PACKETTYPE_HOUSING_SETVISITALLOW, &CDPSrvr::OnHousingSetVisitAllow);
	ON_MSG(PACKETTYPE_HOUSING_VISITROOM, &CDPSrvr::OnHousingVisitRoom);
	ON_MSG(PACKETTYPE_HOUSING_REQVISITABLELIST, &CDPSrvr::OnHousingVisitableList);
	ON_MSG(PACKETTYPE_HOUSING_GOOUT, &CDPSrvr::OnHousingGoOut);

	ON_MSG(PACKETTYPE_QUESTHELPER_REQNPCPOS, &CDPSrvr::OnReqQuestNPCPos);

	ON_MSG(PACKETTYPE_PROPOSE, &CDPSrvr::OnPropose);
	ON_MSG(PACKETTYPE_REFUSE, &CDPSrvr::OnRefuse);
	ON_MSG(PACKETTYPE_COUPLE, &CDPSrvr::OnCouple);
	ON_MSG(PACKETTYPE_DECOUPLE, &CDPSrvr::OnDecouple);

#ifdef __MAP_SECURITY
	ON_MSG(PACKETTYPE_MAP_KEY, &CDPSrvr::OnMapKey);
#endif // __MAP_SECURITY

	ON_MSG(PACKETTYPE_VISPET_REMOVEVIS, &CDPSrvr::OnRemoveVis);
	ON_MSG(PACKETTYPE_VISPET_SWAPVIS, &CDPSrvr::OnSwapVis);

	ON_MSG(PACKETTYPE_GUILDHOUSE_BUY, &CDPSrvr::OnBuyGuildHouse);
	ON_MSG(PACKETTYPE_GUILDHOUSE_PACKET, &CDPSrvr::OnGuildHousePacket);
	ON_MSG(PACKETTYPE_GUILDHOUSE_ENTER, &CDPSrvr::OnGuildHouseEnter);
	ON_MSG(PACKETTYPE_GUILDHOUSE_GOOUT, &CDPSrvr::OnGuildHouseGoOut);

	ON_MSG(PACKETTYPE_TELEPORTER, &CDPSrvr::OnTeleporterReq);

	ON_MSG(PACKETTYPE_QUEST_CHECK, &CDPSrvr::OnCheckedQuest);

	ON_MSG(PACKETTYPE_ITEM_SELECT_AWAKENING_VALUE, &CDPSrvr::OnItemSelectAwakeningValue);


#ifdef __FL_DUNGEON_TREASURE
	ON_MSG(PACKETTYPE_DUNGEON_TREASURE_SELECT, &CDPSrvr::OnDungeonTreasureSelect);
#endif

#ifdef __FL_CONSUMABLES_STORAGE
	ON_MSG(PACKETTYPE_MOVE_ITEM_CHEST, &CDPSrvr::OnMoveItemToChest);
	ON_MSG(PACKETTYPE_MOVE_ITEM_INSIDECHEST, &CDPSrvr::OnMoveItemInsideChest);
	ON_MSG(PACKETTYPE_MOVE_ALL_ITEMS_CHEST, &CDPSrvr::OnMoveAllItemsToChest);
#endif

#ifdef __FL_BOXES_V2
	ON_MSG(PACKETTYPE_BULKBOXOPENING, &CDPSrvr::OnBulkBoxOpen);
#endif

#ifdef __FL_FAST_ELEMENT
	ON_MSG(PACKETTYPE_SELECT_ELEMENT, &CDPSrvr::OnChangeAttributeNew);
#endif

	ON_MSG(PACKETTYPE_HIDE_COAT, &CDPSrvr::OnHideCoat);

#ifdef __FL_SHOP_SEARCH
	ON_MSG(PACKETTYPE_REQUEST_SHOP_SEARCH, &CDPSrvr::OnRequestShopSearch);
	ON_MSG(PACKETTYPE_TELEPORT_TO_THIS_SHOP, &CDPSrvr::OnTeleportToShop);
#endif

#ifdef __FL_PET_FILTER
	ON_MSG(PACKETTYPE_PETLOOTTYPE_REQ, &CDPSrvr::OnPetLootOption);
	ON_MSG(PACKETTYPE_PETFILTER_EXCEPTION, &CDPSrvr::OnPetFilterException);
#endif

#ifdef __FL_EQUALIZED_MODE
	ON_MSG(PACKETTYPE_SELECT_TMP_CLASS, &CDPSrvr::OnSelectTmpClass);
#endif

	ON_MSG(PACKETTYPE_ADDPARTYMEMBER, &CDPSrvr::OnConfirmPartyRequest);
	ON_MSG(PACKETTYPE_ADDFRIEND, &CDPSrvr::OnConfirmFriendRequest);
	ON_MSG(PACKETTYPE_ADD_GUILD_MEMBER, &CDPSrvr::OnConfirmGuildRequest);

#ifdef __FL_FFA
	ON_MSG(PACKETTYPE_REQUEST_FFA, &CDPSrvr::OnRequestFFA);
	ON_MSG(PACKETTYPE_REQUEST_FFA_REGISTER, &CDPSrvr::OnRequestFFARegister);
	ON_MSG(PACKETTYPE_REQUEST_FFA_JOIN, &CDPSrvr::OnRequestFFAJoin);
#endif

#ifdef __FL_DAILY_REWARDS
	ON_MSG(PACKETTYPE_COLLECT_DAILY_GIFT, &CDPSrvr::OnCollectDailyGift);
#endif

#ifdef __WIKI_ITEMS_V2
	ON_MSG(PACKETTYPE_WIKI_CREATE, &CDPSrvr::OnWikiCreate);
#endif

#ifdef __FL_TELEPORT
	ON_MSG(PACKETTYPE_TELEPORT_REQUEST, &CDPSrvr::OnTeleportRequest);
#endif

#ifdef __JOB_CHANGE
	ON_MSG(PACKETTYPE_SEND_JOB_CHANGE, &CDPSrvr::OnSendJobChange);
#endif

#ifdef __FL_RECYCLE
	ON_MSG(PACKETTYPE_SEND_RECYCLE, &CDPSrvr::OnRecycle);
#endif

#ifdef __FL_PARTY_FINDER
	ON_MSG(PACKETTYPE_REQUEST_PARTY_FINDER, &CDPSrvr::OnPartyFinderRequest);
	ON_MSG(PACKETTYPE_REQUEST_PARTY_FINDER_JOIN, &CDPSrvr::OnPartyFinderJoin);
#endif

#ifdef __FL_VENDORS
	ON_MSG(PACKETTYPE_VENDOR_ACTION, &CDPSrvr::OnVendorAction);
#endif

#ifdef __FL_CASH_SHOP
	ON_MSG(PACKETTYPE_CSHOP_BALANCE, &CDPSrvr::OnGetCShopBalance);
	ON_MSG(PACKETTYPE_CSHOP_ITEM, &CDPSrvr::OnBuyCShopItem);
#endif

#ifdef __FL_NEW_BOXES
	ON_MSG(PACKETTYPE_NEWBOX_OPEN, &CDPSrvr::OnNewBoxOpen);
#endif

	ON_MSG(PACKETTYPE_USE_TRANSY, &CDPSrvr::OnUseTransy);

#ifdef __FL_PENYA_CONVERTER
	ON_MSG(PACKETTYPE_CONVERT_PENYA, &CDPSrvr::OnConvertPenya);
#endif
#ifdef __FL_SWITCH_EQ
	ON_MSG(PACKETTYPE_SWITCH_ADD, &CDPSrvr::OnSwitchAdd);
	ON_MSG(PACKETTYPE_SWITCH_DELETE, &CDPSrvr::OnSwitchDelete);
	ON_MSG(PACKETTYPE_SWITCH_USE, &CDPSrvr::OnSwitchUse);
#endif
#ifdef __FL_GUILD_FINDER
	ON_MSG(PACKETTYPE_REQUEST_GUILD_FINDER, &CDPSrvr::OnGuildFinderRequest);
	ON_MSG(PACKETTYPE_GUILD_FINDERJOIN, &CDPSrvr::OnGuildFinderJoin);
	ON_MSG(PACKETTYPE_GUILD_FINDER_ADDON, &CDPSrvr::OnGuildFinderAddon);
#endif
#ifdef __FL_PACKED_ITEMS
	ON_MSG(PACKETTYPE_PACKAGE_OPEN, &CDPSrvr::OnPackageOpen);
	ON_MSG(PACKETTYPE_PACKAGE_ADD, &CDPSrvr::OnPackageAdd);
	ON_MSG(PACKETTYPE_PACKAGE_RESTORE, &CDPSrvr::OnPackageRestore);
#endif
#ifdef __FL_WHEEL_OF_FORTUNE
	ON_MSG(PACKETTYPE_WOF_REQUEST, &CDPSrvr::OnWofRequest);
	ON_MSG(PACKETTYPE_WOF_START, &CDPSrvr::OnWofStart);
	ON_MSG(PACKETTYPE_WOF_FINISH, &CDPSrvr::OnWofFinish);
#endif
#ifdef __FL_RECORD_BOOK
	ON_MSG(PACKETTYPE_RECORD_BOOK, &CDPSrvr::OnRecordBook);
#endif
#ifdef __FL_MONSTER_ALBUM
	ON_MSG(PACKETTYPE_MA_BOSSCARDSLOT_RESTORE, &CDPSrvr::OnMABossCardSlotRestore);
#endif
#ifdef __ZCK_ACHIEVEMENT
	ON_MSG(PACKETTYPE_ZCK_ACHIEVEMENT_CLAIM, &CDPSrvr::OnZckAchievementClaim);
#endif
#ifdef __ZCK_QUEST
	ON_MSG(PACKETTYPE_ZCK_QUEST, &CDPSrvr::OnZckQuest);
#endif // __ZCK_QUEST
#ifdef __ZCK_CLASSEMENT
	ON_MSG(PACKETTYPE_ZCK_CLASSEMENT, &CDPSrvr::OnZckClassement);
#endif
#ifdef __ZCK_FENETRE_CHAT_MJ
	ON_MSG(PACKETTYPE_ZCK_FENETRE_CHAT_MJ, &CDPSrvr::OnZckFenetreChatMj);
#endif
#ifdef __ZCK_PRESTIGE
	ON_MSG(PACKETTYPE_ZCK_PRESTIGE_REQUEST, &CDPSrvr::OnZckPrestigeRequest);
#endif
#ifdef __ZCK_SYSTEME_EVEIL
    ON_MSG(PACKETTYPE_ZCK_SYSTEME_EVEIL, &CDPSrvr::OnZckSystemeEveil);
    ON_MSG(PACKETTYPE_ZCK_AWAKE_AFFINITY, &CDPSrvr::OnZckAwakeAffinity);
#endif
#ifdef __ZCK_MINIJEU_PVP
	ON_MSG(PACKETTYPE_ZCK_MINIGAME_CREATE, &CDPSrvr::OnZckPvPMinigameCreate);
	ON_MSG(PACKETTYPE_ZCK_MINIGAME_COMMAND, &CDPSrvr::OnZckPvPMinigameCommand);
	ON_MSG(PACKETTYPE_ZCK_MINIGAME_CHAT, &CDPSrvr::OnZckPvPMinigameChat);
	ON_MSG(PACKETTYPE_ZCK_MINIGAME_GET_LIST, &CDPSrvr::OnZckPvPMinigameGetList);
#endif
#ifdef __ZCK_ANARCHY
	ON_MSG(PACKETTYPE_ZCK_ANARCHY, &CDPSrvr::OnZckAnarchy);
#endif // __ZCK_ANARCHY
#ifdef __ZCK_INVASION
	ON_MSG(PACKETTYPE_ZCK_INVASION, &CDPSrvr::OnZckInvasion);
#endif // __ZCK_INVASION
#ifdef __ZCK_BADGE
	ON_MSG(PACKETTYPE_ZCK_BADGE, &CDPSrvr::OnZckBadge);
#endif // __ZCK_BADGE
#ifdef __ZCK_AURA_SYSTEM
	ON_MSG(PACKETTYPE_ZCK_AURA, &CDPSrvr::OnZckAura);
#endif // __ZCK_AURA_SYSTEM
#ifdef __ZCK_PET_GLOW
	ON_MSG(PACKETTYPE_ZCK_PET_GLOW, &CDPSrvr::OnZckPetGlow);
#endif // __ZCK_PET_GLOW
#ifdef __ZCK_TRAILS
	ON_MSG(PACKETTYPE_ZCK_TRAILS, &CDPSrvr::OnZckTrails);
#endif // __ZCK_TRAILS
#ifdef __ZCK_MOUNTURE_VOLANTE
	ON_MSG(PACKETTYPE_ZCK_MONTURE_VOLANTE, &CDPSrvr::OnZckMontureVolante);
#endif // __ZCK_MOUNTURE_VOLANTE
#ifdef __ZCK_ELEMENT_RGB
	ON_MSG(PACKETTYPE_ZCK_ELEMENT_RGB, &CDPSrvr::OnZckElementRgb);
#endif // __ZCK_ELEMENT_RGB
#ifdef __ZCK_VOIR_INVENTAIRE_JOUEURS
	ON_MSG(PACKETTYPE_ZCK_VOIR_INVENTAIRE, &CDPSrvr::OnZckVoirInventaire);
#endif // __ZCK_VOIR_INVENTAIRE_JOUEURS
#ifdef __ZCK_CHANGE_DST_NIVEAU
	ON_MSG(PACKETTYPE_ZCK_CHANGE_DST_NIVEAU, &CDPSrvr::OnZckChangeDstNiveau);
#endif // __ZCK_CHANGE_DST_NIVEAU
#ifdef __ZCK_IA_FARM
	ON_MSG(PACKETTYPE_ZCK_IA_FARM, &CDPSrvr::OnZckIaFarm);
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
	ON_MSG(PACKETTYPE_ZCK_MONDIAL_BUFF, &CDPSrvr::OnZckMondialBuff);
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
	ON_MSG(PACKETTYPE_ZCK_PERIN_BUFF, &CDPSrvr::OnZckPerinBuff);
#endif // __ZCK_PERIN_BUFF
#ifdef __ZCK_AMELIORATION_TICKET
	ON_MSG(PACKETTYPE_ZCK_TICKET_CARTE, &CDPSrvr::OnZckTicketCarte);
#endif // __ZCK_AMELIORATION_TICKET
#ifdef __ZCK_LISTE_JOUEURS
	ON_MSG(PACKETTYPE_PLAYER_LIST_SEND_REQUEST, &CDPSrvr::OnPlayerListRequest);
	ON_MSG(PACKETTYPE_PLAYER_LIST_UPDATE_MODS, &CDPSrvr::OnPlayerListUpdateMods);
#endif // __ZCK_LISTE_JOUEURS
#ifdef __ZCK_COMBAT_MC
	ON_MSG(PACKETTYPE_ZCK_COMBAT_MC_REGISTER_WINDOW, &CDPSrvr::OnZckCombatMCRegisterWindow);
	ON_MSG(PACKETTYPE_ZCK_COMBAT_MC_REGISTER_MEMBER_WINDOW, &CDPSrvr::OnZckCombatMCRegisterMemberWindow);
	ON_MSG(PACKETTYPE_ZCK_COMBAT_MC_REGISTER, &CDPSrvr::OnZckCombatMCRegister);
	ON_MSG(PACKETTYPE_ZCK_COMBAT_MC_REGISTER_MEMBER, &CDPSrvr::OnZckCombatMCRegisterMember);
	ON_MSG(PACKETTYPE_ZCK_COMBAT_MC_UNREGISTER_MEMBER, &CDPSrvr::OnZckCombatMCUnregisterMember);
#endif // __ZCK_COMBAT_MC
#ifdef __ZCK_TOUR_INFINI
	ON_MSG(PACKETTYPE_ZCK_TOUR_INFINI_ENTER, &CDPSrvr::OnZckTourInfiniEnter);
	ON_MSG(PACKETTYPE_ZCK_TOUR_INFINI_LEAVE, &CDPSrvr::OnZckTourInfiniLeave);
	ON_MSG(PACKETTYPE_ZCK_TOUR_INFINI_RANKING, &CDPSrvr::OnZckTourInfiniRanking);
#endif // __ZCK_TOUR_INFINI
#ifdef __ZCK_COLOSSEUM
	ON_MSG(PACKETTYPE_ZCK_COLOSSEUM, &CDPSrvr::OnZckColosseum);
#endif // __ZCK_COLOSSEUM
#ifdef __FL_TDM
	ON_MSG(PACKETTYPE_REQUEST_TDM, &CDPSrvr::OnRequestTDM);
	ON_MSG(PACKETTYPE_REQUEST_TDM_REGISTER, &CDPSrvr::OnRequestTDMRegister);
	ON_MSG(PACKETTYPE_REQUEST_TDM_JOIN, &CDPSrvr::OnRequestTDMJoin);
#endif
#ifdef __FL_BUYBACK
	ON_MSG(PACKETTYPE_BUYBACK, &CDPSrvr::OnBuyback);
	ON_MSG(PACKETTYPE_BUYBACK_REQUEST, &CDPSrvr::OnBuybackRequest);
#endif
#ifdef __FL_WIKI_HONORS
	ON_MSG(PACKETTYPE_REQUEST_HONORS, &CDPSrvr::OnRequestHonors);
#endif
#ifdef __FL_SEASON_PASS
	ON_MSG(PACKETTYPE_SEASONPASS_UNLOCK, &CDPSrvr::OnSeasonPassUnlock);
	ON_MSG(PACKETTYPE_SEASONPASS_CLAIM, &CDPSrvr::OnSeasonPassClaim);
#endif
#ifdef __FL_WARDROBE
	ON_MSG(PACKETTYPE_WARDROBE_PRESET_CREATE, &CDPSrvr::OnWardrobePresetCreate);
	ON_MSG(PACKETTYPE_WARDROBE_PRESET_DELETE, &CDPSrvr::OnWardrobePresetDelete);
	ON_MSG(PACKETTYPE_WARDROBE_PRESET_USE, &CDPSrvr::OnWardrobePresetUse);
	ON_MSG(PACKETTYPE_WARDROBE_ITEM_ACTIVATE, &CDPSrvr::OnWardrobeItemActivate);
	ON_MSG(PACKETTYPE_WARDROBE_ITEM_DEACTIVATE, &CDPSrvr::OnWardrobeItemDeactivate);
	ON_MSG(PACKETTYPE_WARDROBE_ITEM_UNLOCK, &CDPSrvr::OnWardrobeItemUnlock);
#endif
#ifdef __FL_QUICK_SELL
	ON_MSG(PACKETTYPE_QUICKSELL, &CDPSrvr::OnQuickSell);
#endif
#ifdef __SIZED_SNAPSHOTS_V2
	ON_MSG(PACKETTYPE_SNAPSHOT_REPORT, &CDPSrvr::OnSnapshotReport);
#endif
#ifdef __FL_WORLDBOSS
	ON_MSG(PACKETTYPE_WORLDBOSS_TELEPORT, &CDPSrvr::OnWorldBossTeleport);
#endif
	ON_MSG(PACKETTYPE_EXP_UP_STOP, &CDPSrvr::OnExpUpStop);
#ifdef __ZCK_CRAFT_LOAD_TEX
	ON_MSG(PACKETTYPE_ZCK_CRAFT, &CDPSrvr::OnZckCraft);
#else
#line 744 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#ifdef __ZCK_BURNOUT
	ON_MSG(PACKETTYPE_ZCK_BURNOUT, &CDPSrvr::OnZckBurnout);
#endif // __ZCK_BURNOUT
#ifdef __FL_AUTO_STAT
	ON_MSG(PACKETTYPE_AUTO_STAT, &CDPSrvr::OnAutoStat);
#endif
#ifdef __ZCK_UPGRADE
	ON_MSG(PACKETTYPE_SEND_UPGRADE, &CDPSrvr::OnUpgrade);
#endif
#ifdef __ZCK_RARE
	ON_MSG(PACKETTYPE_ZCK_RARE, &CDPSrvr::OnZckRare);
#endif
#ifdef __ZCK_ARME_REBORN
	ON_MSG(PACKETTYPE_ZCK_ARME_REBORN, &CDPSrvr::OnZckArmeReborn);
#endif // __ZCK_ARME_REBORN
#ifdef __ZCK_DIFFICULTY
	ON_MSG(PACKETTYPE_DUNGEON_DIFFICULTY, &CDPSrvr::OnDungeonDifficulty);
#endif
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	ON_MSG(PACKETTYPE_ZCK_RETIRER_BUFF, &CDPSrvr::OnZckRetirerBuff);
#else
#line 693 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
#ifdef __FL_PLAYER_STATUE
	ON_MSG(PACKETTYPE_PLAYER_STATUE_BUFF_RECEIVE, &CDPSrvr::OnPlayerStatueBuffReceive);
#endif
#ifdef __ZCK_LINK
	ON_MSG(PACKETTYPE_ZCK_LIEN_DEMANDE, &CDPSrvr::OnZckLienDemande);
#else
#line 691
#endif // __ZCK_LINK
}

CDPSrvr::~CDPSrvr()
{
	m_dpidCache = DPID_UNKNOWN;
}

void CDPSrvr::SysMessageHandler(LPDPMSG_GENERIC lpMsg, DWORD dwMsgSize, DPID idFrom)
{
	switch (lpMsg->dwType)
	{
	case DPSYS_CREATEPLAYERORGROUP:
	{
		LPDPMSG_CREATEPLAYERORGROUP lpCreatePlayer = (LPDPMSG_CREATEPLAYERORGROUP)lpMsg;
		OnAddConnection(lpCreatePlayer->dpId);
		break;
	}
	case DPSYS_DESTROYPLAYERORGROUP:
	{
		LPDPMSG_DESTROYPLAYERORGROUP lpDestroyPlayer = (LPDPMSG_DESTROYPLAYERORGROUP)lpMsg;
		OnRemoveConnection(lpDestroyPlayer->dpId);
		break;
	}
	}
}

void CDPSrvr::UserMessageHandler(LPDPMSG_GENERIC lpMsg, DWORD dwMsgSize, DPID idFrom)
{
	LPBYTE lpBuffer = (LPBYTE)lpMsg + sizeof(DPID);
	u_long uBufSize = dwMsgSize - sizeof(DPID);

	CAr ar(lpBuffer, uBufSize);
	GETTYPE(ar)

		void (theClass:: * pfn)(theParameters) = GetHandler(dw);

	if (pfn)
	{
#ifdef __ZCK_ANTICHEAT
		if (CZckAnticheatManager::GetInstance()->OnPacket(idFrom, *(UNALIGNED LPDPID)lpMsg, dw))
			return;
#endif // __ZCK_ANTICHEAT
		(this->*(pfn))(ar, idFrom, *(UNALIGNED LPDPID)lpMsg, lpBuffer, uBufSize);
	}

}

void CDPSrvr::OnAddConnection(DPID dpid)
{
}

void CDPSrvr::OnRemoveConnection(DPID dpid)
{
	if (dpid == m_dpidCache)
	{
#ifdef __ZCK_SPD_LOG
		ZCK_LOG_WARNING("Liaison CacheServer perdue : suppression des utilisateurs connectés.");
#endif // __ZCK_SPD_LOG
		g_UserMng.RemoveAllUsers();
		m_dpidCache = DPID_UNKNOWN;
	}
}

void CDPSrvr::OnAddUser(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	m_dpidCache = dpidCache;

	TCHAR	lpszAccount[MAX_ACCOUNT], lpszpw[MAX_PASSWORD], lpAddr[16];
	DWORD	dwAuthKey;
	u_long	idPlayer;
	BYTE	nSlot;
	DPID	dpidSocket;

	ar >> dwAuthKey >> idPlayer >> nSlot;
	ar >> dpidSocket;
	ar.ReadString(lpszAccount, MAX_ACCOUNT);
	ar.ReadString(lpszpw, MAX_PASSWORD);
	ar.ReadString(lpAddr, 16);

	if (nSlot >= 3)
	{
		Error("CDPSrvr::OnAddUser: slot %d idplayer %d", nSlot, idPlayer);
		return;
	}

	CUser* pUser = (CUser*)prj.GetUserByID(idPlayer);
#ifdef __ZCK_IA_FARM
	// Le personnage qui revient farme hors ligne : le fantome est sauvegarde et
	// retire tout de suite (RemoveUser -> DestroyPlayer, SavePlayer bLogout),
	// AVANT le JOIN envoye plus bas au DatabaseServer sur la meme liaison, qui
	// le traite donc apres la sauvegarde. La connexion entrante est ensuite
	// une entree en jeu normale.
	if (pUser && g_ZckIaFarmServeur.EstFantome(pUser))
	{
		g_ZckIaFarmServeur.TerminerImmediat(pUser, ZCK_IA_FARM_FIN_RECONNEXION, NULL);
		pUser = NULL;
	}
#endif // __ZCK_IA_FARM
	if (pUser)
	{
		Error("CDPSrvr::OnAddUser exist user. account(%s), idPlayer(%07d), DPID(%d) ]", lpszAccount, idPlayer, dpidUser);
		QueryDestroyPlayer(pUser->m_Snapshot.dpidCache, pUser->m_Snapshot.dpidUser, pUser->m_dwSerial, pUser->m_idPlayer);
		QueryDestroyPlayer(dpidCache, dpidSocket, dpidUser, idPlayer);
		return;
	}

	pUser = g_UserMng.AddUser(dpidCache, dpidUser, dpidSocket);
	if (!pUser)
	{
		Error("CDPSrvr::OnAddUser: AddUser NULL err. New acc: %s, Playerid: %d", lpszAccount, idPlayer);
		return;
	}

	pUser->m_dwAuthKey = dwAuthKey;
	memcpy(pUser->m_playAccount.lpAddr, lpAddr, 16);

	//	TRANS
	BEFORESENDDUAL(arJoin, PACKETTYPE_JOIN, dpidCache, dpidUser);
	arJoin << dwAuthKey;
	arJoin.WriteString(lpszAccount);
	arJoin.WriteString(lpszpw);
	arJoin << nSlot << idPlayer;
	SEND(arJoin, &g_dpDBClient, DPID_SERVERPLAYER);
}


void CDPSrvr::OnRemoveUser(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	g_UserMng.RemoveUser((DWORD)dpidUser);
}

void CDPSrvr::OnChat(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	static	TCHAR	sChat[1024];
	if (uBufSize > 1031 || uBufSize < 0)
		return;

	DWORD dwAuth;
	ar >> dwAuth;

	ar.ReadString(sChat, 1024);
	CString strChat = sChat;
	strChat.Replace("\\n", " ");
	strChat.Replace("@", " ");
	strChat.Replace("@@", " ");

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_dwAuthorization != dwAuth)
		{
			QueryDestroyPlayer(pUser->m_Snapshot.dpidCache, pUser->m_Snapshot.dpidUser, pUser->m_dwSerial, pUser->m_idPlayer);
			return;
		}

#ifdef __FL_UPDATE_CHATTING
		if (IsChatSpamString(sChat))
		{
			if (pUser->GetLastChatMessage() + 500 > GetTickCount())
			{
				pUser->AddDefinedText(TID_GAME_ERROR_CHATTING_1);
				return;
			}
			else
				pUser->SetLastChatMessage(GetTickCount());
		}
#endif

#ifdef __ZCK_LINK
		// Codes de lien : reecrits par le serveur, ou retires, avant toute autre lecture
		// du message ; un message reduit a rien ne part pas.
		if (ZckLienReecrire(pUser, sChat))
		{
			if (sChat[0] == '\0')
				return;
			strChat = sChat;
		}
#else
#line 859
#endif // __ZCK_LINK
		if (sChat[0] == '/' && ParsingCommand(strChat, (CMover*)pUser))
			return;

		if (pUser->IsMode(TALK_MODE))
			return;

		int nText = pUser->GetMuteText();
		if (nText)
		{
			pUser->AddDefinedText(nText);
			return;
		}

		if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
			ParsingEffect(sChat, strlen(sChat));

		strChat = sChat;
		strChat.Replace("\\n", " ");
		strChat.Replace("@", " ");
		strChat.Replace("@@", " ");
#ifdef __ZCK_LINK
		// Texte final : seuls les codes ecrits par le serveur pour ce message restent.
		if (strChat.Find('#') >= 0)
		{
			TCHAR szZckLien[1024];
			_tcsncpy(szZckLien, strChat, 1023);
			szZckLien[1023] = '\0';
			ZckLienAssainir(pUser, szZckLien);
			strChat = szZckLien;
		}
#else
#line 879
#endif // __ZCK_LINK

#ifdef __ZCK_FENETRE_CHAT_MJ
		// Capture EN LECTURE SEULE, apres mute / spam / TALK_MODE et
		// apres ParsingCommand, juste avant la publication. Ne renvoie
		// rien, ne peut donc ni bloquer ni retarder le message.
		CZckChatMjManager::GetInstance()->Capture(
			ZCK_CHATMJ_CAT_PUBLIC, pUser, NULL, strChat);
#endif // __ZCK_FENETRE_CHAT_MJ

		g_UserMng.AddChat(pUser, strChat);
	}
}

#ifdef __ZCK_LINK
// -----------------------------------------------------------------------------------------
// Lien d'objet dans le chat : le WorldServer decide de tout. Il verifie chaque lien, le
// reecrit avec ses propres donnees, garde la copie de l'objet 15 minutes, l'envoie au
// CoreServer (qui la rediffuse aux autres canaux) et ne sert que ses propres copies.
// -----------------------------------------------------------------------------------------
BOOL CDPSrvr::ZckLienReecrire(CUser* pUser, TCHAR* pszChat)
{
	pUser->m_nZckLienMessage = 0;
	memset(pUser->m_abZckLienPris, 0, sizeof(pUser->m_abZckLienPris));

	// Remplacements qu'OnChat fait deja plus loin, faits d'abord : ils ne decalent plus les
	// sequences # autour d'un code.
	CString strChat = pszChat;
	strChat.Replace("\\n", " ");
	strChat.Replace("@", " ");
	strChat.Replace("@@", " ");
	if (ZckLienPresent(strChat) == FALSE)
		return FALSE;

	// Liens acceptes dans un message de chat (texte simple, /w, /say, /s, /p, /g) d'au plus
	// ZCK_LIEN_MESSAGE_MAX caracteres, codes compris ; sinon tous les codes sont retires.
	const BOOL bAccepte = ((int)_tcslen(pszChat) <= ZCK_LIEN_MESSAGE_MAX && ZckLienCommandeDeChat(strChat)) ? TRUE : FALSE;
	TCHAR szSortie[1024];
	LPCTSTR lpsz = strChat;
	const int nLen = strChat.GetLength();
	int n = 0;
	for (int i = 0; i < nLen; )
	{
		ZCK_LIEN lien;
		if (ZckLienLire(lpsz + i, nLen - i, &lien))
		{
			// #j valide : objet verifie, copie gardee, code #k du serveur a sa place. #k envoye
			// par un client, #j refuse, liens au-dela du 3e : retires, le reste du message part.
			TCHAR szCode[ZCK_LIEN_TAILLE + 1];
			if (bAccepte && lien.nGenre == ZCK_LIEN_GENRE_CLIENT && pUser->m_nZckLienMessage < ZCK_LIEN_PAR_MESSAGE
				&& ZckLienCreer(pUser, &lien, szCode))
			{
				memcpy(szSortie + n, szCode, ZCK_LIEN_TAILLE * sizeof(TCHAR));
				n += ZCK_LIEN_TAILLE;
			}
			else if (n > 0 && i + ZCK_LIEN_TAILLE < nLen)
			{
				// code retire entre deux textes : un espace a sa place, sinon "#k" + code retire
				// + 30 chiffres formerait un nouveau code
				szSortie[n++] = ' ';
			}
			i += ZCK_LIEN_TAILLE;
		}
		else
		{
			// n <= i : la sortie n'est jamais plus longue que le message (moins de 1024)
			const int nJeton = ZckLienJeton(lpsz + i, nLen - i);
			memcpy(szSortie + n, lpsz + i, nJeton * sizeof(TCHAR));
			n += nJeton;
			i += nJeton;
		}
	}
	szSortie[n] = '\0';
	_tcscpy(pszChat, szSortie);
	return TRUE;
}

BOOL CDPSrvr::ZckLienCreer(CUser* pUser, const ZCK_LIEN* pDemande, TCHAR* pszCode)
{
	// au plus ZCK_LIEN_CREATIONS creations par ZCK_LIEN_CREATIONS_DUREE ms et par joueur
	const DWORD dwMaintenant = GetTickCount();
	if (dwMaintenant - pUser->m_adwZckLienCreation[pUser->m_nZckLienCreation] < (DWORD)ZCK_LIEN_CREATIONS_DUREE)
		return FALSE;

	// l'objet est dans l'inventaire de l'emetteur (equipement porte compris), avec le meme
	// identifiant d'objet et le meme numero de serie
	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(pDemande->dwObjId);
	if (pItemElem == NULL || pItemElem->IsEmpty() || pItemElem->GetProp() == NULL
		|| pItemElem->m_dwItemId != pDemande->dwItemId || (DWORD)pItemElem->GetSerialNumber() != pDemande->dwSerie)
		return FALSE;

	// la copie : CItemElem::Serialize, relue telle quelle par l'infobulle du client
	CAr ar;
	pItemElem->Serialize(ar);
	int nTaille = 0;
	LPBYTE lpOctets = ar.GetBuffer(&nTaille);
	if (lpOctets == NULL || nTaille <= 0 || nTaille > ZCK_LIEN_COPIE_MAX)
		return FALSE;

	// identifiant de lien : seconde de creation (jamais en arriere), 16 bits bas de la cle du
	// WorldServer (unique par canal), compteur dans la seconde
	DWORD dwSeconde = (DWORD)time(NULL);
	if (dwSeconde < m_dwZckLienSeconde)
		dwSeconde = m_dwZckLienSeconde;
	if (dwSeconde == m_dwZckLienSeconde)
	{
		if (m_dwZckLienCompteur >= 0xFFFF)
		{
			++dwSeconde;
			m_dwZckLienCompteur = 0;
		}
		else
			++m_dwZckLienCompteur;
	}
	else
		m_dwZckLienCompteur = 0;
	m_dwZckLienSeconde = dwSeconde;
	const DWORD dwHaut = dwSeconde;
	const DWORD dwBas = (((DWORD)g_uKey & 0xFFFF) << 16) | m_dwZckLienCompteur;
	if (ZckLienRanger(dwHaut, dwBas, lpOctets, nTaille) == FALSE)
		return FALSE;
	// la copie part au CoreServer avant le message : meme liaison, traitee dans l'ordre
	g_DPCoreClient.SendZckLienCopie(dwHaut, dwBas, lpOctets, nTaille);

	// code #k ecrit avec les donnees du serveur
	ZCK_LIEN lien;
	ZckLienDepuisObjet(pItemElem, &lien);
	lien.nGenre = ZCK_LIEN_GENRE_SERVEUR;
	lien.dwLienHaut = dwHaut;
	lien.dwLienBas = dwBas;
	ZckLienEcrire(&lien, pszCode);

	// contexte du message (ZckLienAssainir) et anti-flood
	memcpy(pUser->m_aszZckLienMessage[pUser->m_nZckLienMessage], pszCode, (ZCK_LIEN_TAILLE + 1) * sizeof(TCHAR));
	pUser->m_abZckLienPris[pUser->m_nZckLienMessage] = FALSE;
	++pUser->m_nZckLienMessage;
	pUser->m_adwZckLienCreation[pUser->m_nZckLienCreation] = dwMaintenant;
	pUser->m_nZckLienCreation = (pUser->m_nZckLienCreation + 1) % ZCK_LIEN_CREATIONS;
	return TRUE;
}

BOOL CDPSrvr::ZckLienRanger(DWORD dwHaut, DWORD dwBas, const BYTE* pOctets, int nTaille)
{
	if (pOctets == NULL || nTaille <= 0 || nTaille > ZCK_LIEN_COPIE_MAX)
		return FALSE;
	const unsigned __int64 n64Lien = ((unsigned __int64)dwHaut << 32) | (unsigned __int64)dwBas;
	if (m_mapZckLien.find(n64Lien) != m_mapZckLien.end())
		return FALSE;
	ZCK_LIEN_STOCK& stock = m_mapZckLien[n64Lien];
	stock.dwHeure = GetTickCount();
	stock.aOctets.assign(pOctets, pOctets + nTaille);
	m_dqZckLien.push_back(n64Lien);
	m_nZckLienOctets += (size_t)nTaille;
	ZckLienPurger();
	return TRUE;
}

void CDPSrvr::ZckLienPurger()
{
	// les plus anciennes d'abord : copies de plus de 15 minutes, puis au-dela des plafonds
	const DWORD dwMaintenant = GetTickCount();
	while (m_dqZckLien.empty() == false)
	{
		map<unsigned __int64, ZCK_LIEN_STOCK>::iterator it = m_mapZckLien.find(m_dqZckLien.front());
		if (it != m_mapZckLien.end())
		{
			if (dwMaintenant - it->second.dwHeure < (DWORD)ZCK_LIEN_DUREE && m_mapZckLien.size() <= (size_t)ZCK_LIEN_STOCK_MAX
				&& m_nZckLienOctets <= (size_t)ZCK_LIEN_STOCK_OCTETS)
				break;
			m_nZckLienOctets -= it->second.aOctets.size();
			m_mapZckLien.erase(it);
		}
		m_dqZckLien.pop_front();
	}
}

void CDPSrvr::OnZckLienDemande(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	DWORD dwHaut = 0;
	DWORD dwBas = 0;
	ar >> dwHaut >> dwBas;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	// au plus ZCK_LIEN_DEMANDES demandes par ZCK_LIEN_DEMANDES_DUREE ms ; les autres sont ignorees
	const DWORD dwMaintenant = GetTickCount();
	if (dwMaintenant - pUser->m_adwZckLienDemande[pUser->m_nZckLienDemande] < (DWORD)ZCK_LIEN_DEMANDES_DUREE)
		return;
	pUser->m_adwZckLienDemande[pUser->m_nZckLienDemande] = dwMaintenant;
	pUser->m_nZckLienDemande = (pUser->m_nZckLienDemande + 1) % ZCK_LIEN_DEMANDES;

	// seules les copies gardees par ce WorldServer sont servies, et 15 minutes seulement
	ZckLienPurger();
	map<unsigned __int64, ZCK_LIEN_STOCK>::iterator it = m_mapZckLien.find(((unsigned __int64)dwHaut << 32) | (unsigned __int64)dwBas);
	if (it != m_mapZckLien.end() && dwMaintenant - it->second.dwHeure < (DWORD)ZCK_LIEN_DUREE && it->second.aOctets.empty() == false)
		pUser->AddZckLien(ZCK_LIEN_ETAT_TROUVE, dwHaut, dwBas, &it->second.aOctets[0], (int)it->second.aOctets.size());
	else
		pUser->AddZckLien(ZCK_LIEN_ETAT_EXPIRE, dwHaut, dwBas, NULL, 0);
}
#else
#line 892
#endif // __ZCK_LINK
void CDPSrvr::OnMoveItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nItemType, nSrcIndex, nDstIndex;
	ar >> nItemType >> nSrcIndex >> nDstIndex;

	if (nSrcIndex == nDstIndex)
		return;
	if (nDstIndex >= MAX_INVENTORY || nSrcIndex >= MAX_INVENTORY)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CItemElem* pItemSrc = pUser->m_Inventory.GetAt(nSrcIndex);
	CItemElem* pItemDst = pUser->m_Inventory.GetAt(nDstIndex);
	if (pItemDst == NULL || IsUsableItem(pItemDst))
	{
		if (IsUsableItem(pItemSrc))
		{
			pUser->m_Inventory.Swap(nSrcIndex, nDstIndex);
			pUser->AddMoveItem(0, nSrcIndex, nDstIndex);
		}
	}
}

void CDPSrvr::OnDropItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwItemType;
	DWORD dwItemId;
	short nDropNum;
	D3DXVECTOR3 vPos;

	ar >> dwItemType >> dwItemId >> nDropNum >> vPos;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwItemId);
	if (!IsUsableItem(pItemElem))
		return;

	if (nDropNum > pItemElem->m_nItemNum)
		nDropNum = pItemElem->m_nItemNum;
	if (nDropNum < 1)
		nDropNum = 1;

	if (!g_eLocal.GetState(EVE_DROPITEMREMOVE))
	{
		static int min = ::GetTickCount() / 60000;
		static int count = 0;
		int min2 = ::GetTickCount() / 60000;
		if (min2 != min)
		{
			min = min2;
			count = 0;
		}
		if (count > 100)
		{
			pUser->AddDefinedText(TID_GAME_DIALOGNODROPITEM);
			return;
		}
		count++;
	}

	if (g_eLocal.GetState(EVE_DROPITEMREMOVE))
	{
		if (pUser->IsDropable(pItemElem, FALSE))
		{
#ifdef __FL_BUYBACK
			pUser->m_Buyback.AddItem(pItemElem, nDropNum, 0);
#endif
			pUser->RemoveItem((BYTE)dwItemId, nDropNum);
		}
	}
	else
	{
		pUser->DropItem((DWORD)dwItemId, nDropNum, vPos);
	}
}

void CDPSrvr::OnDropGold(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	return;
}


void CDPSrvr::OnScriptDialogReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	static TCHAR lpKey[256];
	OBJID objid;
	int nGlobal1, nGlobal2, nGlobal3, nGlobal4;

	ar >> objid;
	ar.ReadString(lpKey, 256);

	ar >> nGlobal1 >> nGlobal2 >> nGlobal3 >> nGlobal4;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __QUEST_1208
		DWORD dwTickCount = GetTickCount();
		if (dwTickCount < pUser->m_tickScript + 400)
			return;
		pUser->m_tickScript = dwTickCount;
#endif	// __QUEST_1208
		CMover* pMover = prj.GetMover(objid);
		if (IsValidObj(pMover))
		{
#ifdef __HACK_1130
			char lpOutputString[512] = { 0, };
			sprintf(lpOutputString, "npc = %s, key = %s, n1 = %d, n2 = %d, n3 = %d, n4 = %d",
				pMover->GetName(), lpKey, nGlobal1, nGlobal2, nGlobal3, nGlobal4);
			OutputDebugString(lpOutputString);
#endif	// __HACK_1130

			D3DXVECTOR3 vOut = pUser->GetPos() - pMover->GetPos();
			if (fabs((double)D3DXVec3LengthSq(&vOut)) > MAX_LEN_MOVER_MENU)
			{
				return;
			}
#if !defined(__REMOVE_SCIRPT_060712)
			CScriptDialog::SetLatestDialog(pMover->GetName(), lpKey);
#endif
			if (pMover->m_pNpcProperty &&
				pMover->m_pNpcProperty->IsDialogLoaded())
			{
				if (lstrlen(lpKey) == 0)
					lstrcpy(lpKey, _T("#init"));
				if (nGlobal3 == 0)
					nGlobal3 = (int)pMover->GetId();
				if (nGlobal4 == 0)
					nGlobal4 = (int)pUser->GetId();

				pMover->m_pNpcProperty->RunDialog(lpKey, NULL, nGlobal1, (int)pMover->GetId(), (int)pUser->GetId(), nGlobal2);


				for (int i = 0; i < pUser->m_nQuestSize; i++)
				{
					LPQUEST lpQuest = &pUser->m_aQuest[i];
					QuestProp* pQuestProp = pUser->m_aQuest[i].GetProp();
					if (pQuestProp)
					{
						if (strcmp(pQuestProp->m_szEndCondDlgCharKey, pMover->m_szCharacterKey) == 0)
						{
							if (strcmp(pQuestProp->m_szEndCondDlgAddKey, lpKey) == 0)
							{
								lpQuest->m_bDialog = TRUE;
								pUser->AddSetQuest(lpQuest);
								break;
							}
						}
					}
				}
			}
		}
	}
}

void CDPSrvr::OnResurrectionCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) && pUser->m_Resurrection_Data.bUseing)
	{
		pUser->m_Resurrection_Data.bUseing = FALSE;
	}
}


void CDPSrvr::OnResurrectionOK(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) && pUser->m_Resurrection_Data.bUseing)
	{
		if (!pUser->IsDie())
		{
			pUser->m_Resurrection_Data.bUseing = FALSE;
			return;
		}

		RESURRECTION_DATA* pData = &(((CMover*)pUser)->m_Resurrection_Data);
		CUser* pSrc = (CUser*)prj.GetUserByID(pData->dwPlayerID);

		if (IsValidObj(pSrc))
		{
			pUser->MakeCharacterAlive(TRUE, FALSE);
			pUser->m_Resurrection_Data.bUseing = FALSE;
		}
		else
			pUser->m_Resurrection_Data.bUseing = FALSE;
	}
}


void CDPSrvr::OnRevival(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->m_Resurrection_Data.bUseing = FALSE;
	pUser->MakeCharacterAlive(TRUE, TRUE);
}

void CDPSrvr::OnRevivalLodestar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->m_Resurrection_Data.bUseing = FALSE;
	pUser->MakeCharacterAlive(FALSE, FALSE);
}

void CDPSrvr::OnCorrReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID idObj;
	ar >> idObj;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CMover* pMover = prj.GetMover(idObj);
		if (IsValidObj(pMover))
		{
			pUser->AddCorrReq(pMover);
		}
	}
}

void CDPSrvr::OnPartyRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long uMemberid;
	BOOL bTroup;
	ar >> uMemberid;
	ar >> bTroup;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		InviteParty(pUser->m_idPlayer, uMemberid, bTroup);
}

void CDPSrvr::OnPartyRequestCancle(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long uLeaderid, uMemberid;
	int nMode;
	ar >> uLeaderid >> uMemberid >> nMode;

	CUser* pUser = g_UserMng.GetUserByPlayerID(uLeaderid);
	if (IsValidObj(pUser))
		pUser->AddPartyRequestCancel(uLeaderid, uMemberid, nMode);
}

void CDPSrvr::OnPartySkillUse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nSkill;
	ar >> nSkill;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CParty* pParty = g_PartyMng.GetParty(pUser->m_idparty);
	if (pParty)
	{
		if (pParty->IsLeader(pUser->m_idPlayer))
			pParty->DoUsePartySkill(pUser->m_idparty, pUser->m_idPlayer, nSkill);
	}
}

void CDPSrvr::OnAddFriendReqest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long uMemberid;
	ar >> uMemberid;

	CUser* pLeader = g_UserMng.GetUser(dpidCache, dpidUser);
	CUser* pMember = g_UserMng.GetUserByPlayerID(uMemberid);

	if (!IsValidObj(pLeader))
		return;

	if (!IsValidObj(pMember))
		return;

	if (pLeader == pMember)
		return;

	if (!pLeader->m_RTMessenger.GetFriend(uMemberid))
	{
#ifdef __FL_FIX_IDCHANGE_EXPLOIT // Friend by ID
		BOOL bFound = FALSE;
		for (auto& it : pLeader->vecFriendInvites)
		{
			if (it.dwInvieMember == uMemberid)
			{
				it.dwTimeEnd = GetTickCount() + MIN(10);
				bFound = TRUE;
				break;
			}
		}

		if (!bFound)
		{
			INVITE_REQUESTS tmp;
			tmp.dwInvieMember = uMemberid;
			tmp.dwTimeEnd = GetTickCount() + MIN(10);
			pLeader->vecFriendInvites.push_back(tmp);
		}
#endif
		pMember->AddFriendReqest(pLeader->m_idPlayer, pLeader->m_nJob, (BYTE)pLeader->GetSex(), pLeader->GetName());
	}
}


void CDPSrvr::OnAddFriendNameReqest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long uMember;
	char szMemberName[64] = { 0, };
	ar.ReadString(szMemberName, 64);

	CUser* pLeader = g_UserMng.GetUser(dpidCache, dpidUser);
	uMember = CPlayerDataCenter::GetInstance()->GetPlayerId(szMemberName);
	CUser* pMember = g_UserMng.GetUserByPlayerID(uMember);

	if (!IsValidObj(pLeader))
		return;

	if (!IsValidObj(pMember))
	{
		pLeader->AddFriendError(2, szMemberName);
		return;
	}

	if (pLeader == pMember)
		return;

	if (!pLeader->m_RTMessenger.GetFriend(uMember))
	{
#ifdef __FL_FIX_IDCHANGE_EXPLOIT // Friend by name
		BOOL bFound = FALSE;
		for (auto& it : pLeader->vecFriendInvites)
		{
			if (it.dwInvieMember == uMember)
			{
				it.dwTimeEnd = GetTickCount() + MIN(10);
				bFound = TRUE;
				break;
			}
		}

		if (!bFound)
		{
			INVITE_REQUESTS tmp;
			tmp.dwInvieMember = uMember;
			tmp.dwTimeEnd = GetTickCount() + MIN(10);
			pLeader->vecFriendInvites.push_back(tmp);
		}
#endif
		pMember->AddFriendReqest(pLeader->m_idPlayer, pLeader->m_nJob, (BYTE)pLeader->GetSex(), pLeader->GetName());
	}
	else
		pLeader->AddFriendError(1, szMemberName);
}


void CDPSrvr::OnAddFriendCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long uLeaderid;
	ar >> uLeaderid;

	CUser* pLeader = g_UserMng.GetUserByPlayerID(uLeaderid);
	if (IsValidObj(pLeader))
		pLeader->AddFriendCancel();	// uMemberid
}

void CDPSrvr::OnRemoveQuest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwQuestCancelID;
	ar >> dwQuestCancelID;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __QUEST_1208
		DWORD dwTickCount = GetTickCount();
		if (dwTickCount < pUser->m_tickScript + 400)
			return;
		pUser->m_tickScript = dwTickCount;
#endif	// __QUEST_1208
		LPQUEST lpQuest = pUser->FindQuest(dwQuestCancelID);
		if (lpQuest)
		{
			if (lpQuest->m_nState != QS_END)
			{
				QuestProp* pQuestProp = prj.m_aPropQuest.GetAt(lpQuest->m_wId);
				if (pQuestProp && pQuestProp->m_bNoRemove == FALSE)
				{
					pUser->RemoveQuest(dwQuestCancelID);
					pUser->AddCancelQuest(dwQuestCancelID);
					g_dpDBClient.CalluspLoggingQuest(pUser->m_idPlayer, dwQuestCancelID, 30);
				}
			}
		}
	}
}

void CDPSrvr::OnQueryPlayerData(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long idPlayer;
	ar >> idPlayer;
	int nVer;
	ar >> nVer;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		PlayerData* pPlayerData = CPlayerDataCenter::GetInstance()->GetPlayerData(idPlayer);
		if (pPlayerData && pPlayerData->data.nVer != nVer)
			pUser->AddQueryPlayerData(idPlayer, pPlayerData);
	}
}

void CDPSrvr::OnQueryPlayerData2(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nSize;
	//	u_long idPlayer;
	ar >> nSize;

	if (nSize > 1024)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		for (int i = 0; i < nSize; i++)
		{
			PDVer	pdv;
			ar.Read(&pdv, sizeof(PDVer));
			PlayerData* pPlayerData = CPlayerDataCenter::GetInstance()->GetPlayerData(pdv.idPlayer);
			if (pPlayerData && pPlayerData->data.nVer != pdv.nVer)
				pUser->AddQueryPlayerData(pdv.idPlayer, pPlayerData);
		}
	}
}

void CDPSrvr::OnGuildInvite(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objid;
	ar >> objid;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	InviteCompany(pUser, objid);
}

void CDPSrvr::OnIgnoreGuildInvite(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long idPlayer;
	ar >> idPlayer;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CUser* pPlayer = g_UserMng.GetUserByPlayerID(idPlayer);		// kingpin
		if (IsValidObj(pPlayer))
		{
			pPlayer->AddDefinedText(TID_GAME_COMACCEPTDENY, "%s", pUser->GetName(TRUE));
		}
	}
}


void CDPSrvr::OnGuildLogo(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwLogo;
	ar >> dwLogo;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	if (dwLogo > CUSTOM_LOGO_MAX)
		return;

	if (dwLogo > 20 && !pUser->IsAuthHigher(AUTH_GAMEMASTER))
		return;

	g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_LOGO, dwLogo);
}

void CDPSrvr::OnGuildContribution(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE cbPxpCount, cbItemFlag;
	int nGold;

	cbItemFlag = 0;
	ar >> cbPxpCount >> nGold;
	ar >> cbItemFlag;

	if (g_eLocal.GetState(ENABLE_GUILD_INVENTORY) == FALSE)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "contribution de guilde"))
		return;
#else
#line 1632 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	if (pUser->IsDie() == TRUE)
		return;

	if (nGold > 0)
	{
		if (pUser->CheckUserGold(nGold, false) == true)
		{
			if (g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_PENYA, nGold))
			{
				pUser->AddGold(-nGold);

				if (pUser->GetWorld())
					g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

				LogItemInfo aLogItem;
				aLogItem.Action = "W";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "GUILDBANK";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold() + nGold;
				aLogItem.Gold2 = pUser->GetGold();
				_stprintf(aLogItem.szItemName, "%d", II_GOLD_SEED1);
				aLogItem.itemNumber = nGold;
				OnLogItem(aLogItem);
			}
		}
		else
		{
			pUser->AddDefinedText(TID_GAME_GUILDNOTENGGOLD, "");
		}
	}
	else if (cbItemFlag)
	{
		for (int i = 0; i < pUser->m_Inventory.GetMax(); ++i)
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtId(i);
			if (IsUsableItem(pItemElem) == FALSE)
				continue;

			if (pItemElem->GetProp()->dwItemKind3 != IK3_GEM)
				continue;

			int nValue = 0;

			if (pItemElem->m_nItemNum > 0)
			{
				nValue = (pItemElem->GetProp()->dwItemLV + 1) / 2;
				nValue *= pItemElem->m_nItemNum;
			}

			if (nValue > 0)
			{
				if (g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_PXPCOUNT, nValue))
				{
					LogItemInfo aLogItem;
					aLogItem.Action = "V";
					aLogItem.SendName = pUser->GetName();
					aLogItem.RecvName = "GUILDBANK";
					aLogItem.WorldId = pUser->GetWorld()->GetID();
					aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
					OnLogItem(aLogItem, pItemElem, pItemElem->m_nItemNum);

					pUser->RemoveItem((BYTE)i, pItemElem->m_nItemNum);
				}
			}
		}

	}
}


void CDPSrvr::OnGuildNotice(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	char szNotice[MAX_BYTE_NOTICE];
	ar.ReadString(szNotice, MAX_BYTE_NOTICE);
	szNotice[MAX_BYTE_NOTICE - 1] = '\0';

	if (strlen(szNotice) == 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_NOTICE, (DWORD)szNotice);
}

void CDPSrvr::OnSkillTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nCount;
	ar >> nCount;

	if (nCount > (MAX_SLOT_QUEUE * MAX_SLOT_QUEUE_COUNT))
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	for (int i = 0; i < nCount; i++)
	{
		BYTE nIndex, nIndex2;
		ar >> nIndex >> nIndex2;

		if (nIndex >= MAX_SLOT_QUEUE_COUNT || nIndex2 >= MAX_SLOT_QUEUE)
			return;

		ar >> pUser->m_playTaskBar.m_aSlotQueue[nIndex][nIndex2].m_dwShortcut >> pUser->m_playTaskBar.m_aSlotQueue[nIndex][nIndex2].m_dwId >> pUser->m_playTaskBar.m_aSlotQueue[nIndex][nIndex2].m_dwType;
		ar >> pUser->m_playTaskBar.m_aSlotQueue[nIndex][nIndex2].m_dwIndex >> pUser->m_playTaskBar.m_aSlotQueue[nIndex][nIndex2].m_dwUserId >> pUser->m_playTaskBar.m_aSlotQueue[nIndex][nIndex2].m_dwData;
	}
}

void CDPSrvr::OnAddAppletTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nIndex;
	ar >> nIndex;

	if (nIndex >= MAX_SLOT_APPLET)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		ar >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwShortcut >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwId >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwType;
		ar >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwIndex >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwUserId >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwData;
		ar >> pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_nLocation;

		if (pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwShortcut == SHORTCUT_CHAT)
		{
			ar.ReadString(pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_szString, MAX_SHORTCUT_STRING);
			pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_szString[MAX_SHORTCUT_STRING - 1] = '\0';
		}
	}
}
void CDPSrvr::OnRemoveAppletTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nIndex;
	ar >> nIndex;

	if (nIndex >= MAX_SLOT_APPLET)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwShortcut == SHORTCUT_CHAT)
		{
			memset(pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_szString, 0, sizeof(pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_szString));
		}
		pUser->m_playTaskBar.m_aSlotApplet[nIndex].m_dwShortcut = SHORTCUT_NONE;
	}
}

void CDPSrvr::OnAddItemTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nSlotIndex, nIndex;
	ar >> nSlotIndex >> nIndex;

	if (nSlotIndex >= MAX_SLOT_ITEM_COUNT || nIndex >= MAX_SLOT_ITEM)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwShortCut;
		ar >> dwShortCut;

		if (dwShortCut == SHORTCUT_CHAT)
		{
			int nchatshortcut = 0;
			for (int i = 0; i < MAX_SLOT_ITEM_COUNT; i++)
			{
				for (int j = 0; j < MAX_SLOT_ITEM; j++)
				{
					if (pUser->m_playTaskBar.m_aSlotItem[i][j].m_dwShortcut == SHORTCUT_CHAT)
						nchatshortcut++;
				}
			}

			if (nchatshortcut > 9)
			{
				pUser->AddDefinedText(TID_GAME_MAX_SHORTCUT_CHAT);
				return;
			}
		}

		pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut = dwShortCut;
		ar >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwId >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwType;
		ar >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwIndex >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwUserId >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwData;
		ar >> pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_nLocation;

		if (pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut == SHORTCUT_CHAT)
		{
			ar.ReadString(pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_szString, MAX_SHORTCUT_STRING);
			pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_szString[MAX_SHORTCUT_STRING - 1] = '\0';
		}
	}
}
void CDPSrvr::OnRemoveItemTaskBar(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nSlotIndex, nIndex;
	ar >> nSlotIndex >> nIndex;

	if (nSlotIndex >= MAX_SLOT_ITEM_COUNT || nIndex >= MAX_SLOT_ITEM)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut == SHORTCUT_CHAT)
		{
			memset(pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_szString, 0, sizeof(pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_szString));
		}
		pUser->m_playTaskBar.m_aSlotItem[nSlotIndex][nIndex].m_dwShortcut = SHORTCUT_NONE;
	}
}

void CDPSrvr::OnPlayerBehavior(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (pUser->GetWorld() == NULL)
		return;

	if (pUser->IsDie() == TRUE)
		return;

	if (pUser->GetIndex() == 0)
		return;

	if (pUser->m_pActMover->IsActAttack())
		return;

	pUser->AutoSynchronizer()->Serialize(ar);
#ifdef __ZCK_ANTICHEAT
	CZckAnticheatManager::GetInstance()->OnMove(pUser);
#endif // __ZCK_ANTICHEAT
}

void CDPSrvr::OnPlayerSetDestObj(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->IsDie() == TRUE)
			return;

		OBJID objid;
		float fRange;
		ar >> objid >> fRange;

		CCtrl* pCtrl;

		pCtrl = prj.GetCtrl(objid);
		if (IsValidObj(pCtrl))
		{
			if (pUser->GetDestId() == objid && pUser->m_fArrivalRange == fRange)
				return;

			pUser->SetDestObj(objid, fRange, TRUE);
		}
	}
}

void CDPSrvr::OnDoUseItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwData;
	int nType;
	char szInput[MAX_INPUT_LEN] = { 0, };

	ar >> dwData >> nType;
	ar.ReadString(szInput, MAX_INPUT_LEN);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->SetInput(szInput);
	pUser->DoUseItem(dwData, nType);
	pUser->ResetInput();
}

void CDPSrvr::OnOpenShopWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	OBJID objid;
	ar >> objid;

	CMover* pVendor = prj.GetMover(objid);
	if (IsValidObj(pVendor) && pUser->m_vtInfo.GetOther() == NULL)
	{
		if (pVendor->IsNPC() == FALSE)
			return;

		if (pUser->IsChaotic())
		{
			CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty(pUser->GetPKPropensity());
			if (!Propensity.nShop)
				return;
		}

		if (pVendor->IsVendorNPC() == FALSE)
			return;

		if (pUser->m_bBank)
		{
			pUser->AddDefinedText(TID_GAME_TRADELIMITNPC, "");
			return;
		}

		if (pUser->m_vtInfo.VendorIsVendor())
			return;

#ifdef __S_SERVER_UNIFY
		if (pUser->m_bAllAction == FALSE)
			return;
#endif // __S_SERVER_UNIFY

		pUser->m_vtInfo.SetOther(pVendor);
		pUser->AddOpenShopWnd(pVendor);
	}
}

void CDPSrvr::OnCloseShopWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CMover* pMover = pUser->m_vtInfo.GetOther();
	if (!IsValidObj(pMover))
		return;

	if (!pMover->IsNPC())
		return;

	pUser->m_vtInfo.SetOther(NULL);
}

void CDPSrvr::OnBuyItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CHAR cTab;
	DWORD dwItemObjID;
	short nNum;
	int nType;

	ar >> cTab >> dwItemObjID >> nNum;
	ar >> nType;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_TRADE, pUser->GetWorld(), pUser->GetPos()))
		return;

	CMover* pVendor = pUser->m_vtInfo.GetOther();
	if (!IsValidObj(pVendor))
		return;

	if (!pVendor->IsNPC())
		return;

	LPCHARACTER lpChar = prj.GetCharacter(pVendor->m_szCharacterKey);
	if (!lpChar || lpChar->m_nVenderType != 0)
		return;

	if (cTab >= MAX_VENDOR_INVENTORY_TAB || cTab < 0)
		return;

	CItemElem* pItemElem = pVendor->m_ShopInventory[cTab]->GetAtId(dwItemObjID);
	if (!pItemElem)
		return;

	if (nNum > pItemElem->m_nItemNum)
		nNum = pItemElem->m_nItemNum;
	if (nNum < 1)
		nNum = 1;

#ifdef __OCCUPATION_SHOPITEM
	if (CTax::GetInstance()->IsOccupationShopItem(pItemElem->m_dwItemId) && !CTax::GetInstance()->IsOccupationGuildMember(pUser))
	{
		pUser->AddDefinedText(TID_GAME_SECRETROOM_STORE_BUY);
		return;
	}
#endif // 

	__int64 n64_TotalCost = 0;
	__int64 n64_TotalTax = 0;
	pItemElem->GetBuyingPrice_Penya(pUser, nNum, n64_TotalCost, n64_TotalTax);

	if (n64_TotalCost < 1 || n64_TotalCost > pUser->GetTotalGold())
	{
		pUser->AddDefinedText(TID_DIAG_0009);
		return;
	}

	CItemElem itemElem;
	itemElem = *pItemElem;
	itemElem.m_nItemNum = nNum;
	itemElem.SetSerialNumber();

	if (pUser->CreateItem(&itemElem, nType))
	{
		LogItemInfo aLogItem;
		aLogItem.Action = "B";
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = pVendor->GetName();
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		pItemElem->SetSerialNumber(itemElem.GetSerialNumber());
		OnLogItem(aLogItem, pItemElem, nNum);
		pItemElem->SetSerialNumber(0);

		pUser->RemoveTotalGold(n64_TotalCost);

		__int64 n64_Tax_tmp = n64_TotalTax;
		while (n64_Tax_tmp >= INT_MAX)
		{
			CTax::GetInstance()->AddTax(CTax::GetInstance()->GetContinent(pUser), INT_MAX, TAX_PURCHASE);
			n64_Tax_tmp -= INT_MAX;
		}

		if (n64_Tax_tmp > 0)
			CTax::GetInstance()->AddTax(CTax::GetInstance()->GetContinent(pUser), static_cast<int>(n64_Tax_tmp), TAX_PURCHASE);
	}
	else
		pUser->AddDefinedText(TID_GAME_LACKSPACE);
}

void CDPSrvr::OnBuyChipItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CHAR cTab;
	DWORD dwItemObjID;
	short nNum;
	int nType;

	ar >> cTab >> dwItemObjID >> nNum;
	ar >> nType;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_TRADE, pUser->GetWorld(), pUser->GetPos()))
		return;

	CMover* pVendor = pUser->m_vtInfo.GetOther();
	if (!IsValidObj(pVendor))
		return;

	if (!pVendor->IsNPC())
		return;

	LPCHARACTER lpChar = prj.GetCharacter(pVendor->m_szCharacterKey);
	if (!lpChar || lpChar->m_nVenderType == 0)
		return;

	if (cTab >= MAX_VENDOR_INVENTORY_TAB || cTab < 0)
		return;

	CItemElem* pItemElem = pVendor->m_ShopInventory[cTab]->GetAtId(dwItemObjID);
	if (!pItemElem)
		return;

	ItemProp* pItemProp = pItemElem->GetProp();
	if (!pItemProp)
		return;

	if (nNum > pItemElem->m_nItemNum)
		nNum = pItemElem->m_nItemNum;
	if (nNum < 1)
		nNum = 1;

#ifdef __OCCUPATION_SHOPITEM
	if (CTax::GetInstance()->IsOccupationShopItem(pItemElem->m_dwItemId) && !CTax::GetInstance()->IsOccupationGuildMember(pUser))
	{
		pUser->AddDefinedText(TID_GAME_SECRETROOM_STORE_BUY);
		return;
	}
#endif // 

	__int64 n64_TotalCost = 0;
	pItemElem->GetBuyingPrice_Currency(nNum, n64_TotalCost);

	if (n64_TotalCost < 1 || n64_TotalCost > INT_MAX)
	{
		pUser->AddDefinedText(TID_DIAG_0009);
		return;
	}

	int n_TotalCost = static_cast<int>(n64_TotalCost);
	int nTotalItems = pUser->GetAvailableItemNum(lpChar->m_nVenderType);

	if (nTotalItems < n_TotalCost)
	{
		pUser->AddDefinedText(TID_GAME_LACKCHIP);
		return;
	}

	CItemElem itemElem;
	itemElem = *pItemElem;
	itemElem.m_nItemNum = nNum;
	itemElem.SetSerialNumber();

	if (pUser->CreateItem(&itemElem, nType))
	{
		LogItemInfo aLogItem;
		aLogItem.Action = "B";
		aLogItem.SendName = pUser->GetName();
		CString strTemp;
		strTemp.Format("%s_C", pVendor->GetName());
		aLogItem.RecvName = (LPCTSTR)strTemp;
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		OnLogItem(aLogItem, &itemElem, nNum);

		pUser->RemoveAvailableItem(lpChar->m_nVenderType, n_TotalCost);
	}
	else
		pUser->AddDefinedText(TID_GAME_LACKSPACE);
}

void CDPSrvr::OnSellItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId;
	int nNum;
	int nType;

	ar >> dwId >> nNum;
	ar >> nType;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_TRADE, pUser->GetWorld(), pUser->GetPos()))
		return;

	CMover* pVendor = pUser->m_vtInfo.GetOther();
	if (!IsValidObj(pVendor))
		return;

	if (!pVendor->IsNPC())
		return;

	vector<DWORD> vecItemObjID;
	vecItemObjID.push_back(dwId);

	DoSellItem(pUser, pVendor, vecItemObjID, nNum, nType);
}
#ifdef __FL_QUICK_SELL
void CDPSrvr::OnQuickSell(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_TRADE, pUser->GetWorld(), pUser->GetPos()))
		return;

	CMover* pVendor = pUser->m_vtInfo.GetOther();
	if (!IsValidObj(pVendor))
		return;

	if (!pVendor->IsNPC())
		return;

	size_t nSize;
	ar >> nSize;

	if (static_cast<int>(nSize) > pUser->m_Inventory.GetSize())
		return;

	vector<DWORD> vecItemObjID;
	vecItemObjID.reserve(nSize);

	for (size_t i = 0; i < nSize; i++)
	{
		DWORD dwItemObjID;
		ar >> dwItemObjID;
		vecItemObjID.push_back(dwItemObjID);
	}

	DoSellItem(pUser, pVendor, vecItemObjID);
}
void CDPSrvr::DoSellItem(CUser* pUser, CMover* pVendor, vector<DWORD>& refVecItemObjID, int nItemNum, int nType)
{
	if (refVecItemObjID.empty())
		return;

	CItemContainer<CItemElem>* pContainer = pUser->GetContainerByType(nType);
	if (!pContainer)
		return;

#ifdef __FL_BUYBACK
	const bool bAddBuybackToClient = refVecItemObjID.size() == 1;
#endif

	// All penya for all items
	__int64 n64PenyaAll = 0;
	__int64 n64TaxAll = 0;

	// Single item cost
	__int64 n64_TotalCost = 0;
	__int64 n64_TotalTax = 0;

	for (auto& it : refVecItemObjID)
	{
		CItemElem* pItemElem = pContainer->GetAtId(it);
		if (!IsUsableItem(pItemElem))
			continue;

		if (nType == TYPE_INVENTORY)
		{
			if (pUser->IsUsing(pItemElem))
				continue;

			if (pUser->m_Inventory.IsEquip(it))
				continue;
		}

		if (pItemElem->IsQuest())
			continue;

		if (pItemElem->m_dwItemId == II_SYS_SYS_SCR_PERIN)
			continue;

		ItemProp* pProp = pItemElem->GetProp();
		if (!pProp)
			continue;

		if (pProp->dwItemKind3 == IK3_EVENTMAIN)
			continue;

		int nNum = nItemNum == 0 ? pItemElem->m_nItemNum : nItemNum;
		if (nNum > pItemElem->m_nItemNum)
			nNum = pItemElem->m_nItemNum;
		if (nNum < 1)
			nNum = 1;

		n64_TotalCost = 0;
		n64_TotalTax = 0;
		pItemElem->GetSellingPrice(pUser, nNum, n64_TotalCost, n64_TotalTax);

		if (n64_TotalCost < 1)
			continue;

		n64PenyaAll += n64_TotalCost;
		n64TaxAll += n64_TotalTax;

		LogItemInfo aLogItem;
		aLogItem.Action = "S";
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = pVendor->GetName();
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		OnLogItem(aLogItem, pItemElem, nNum);

#ifdef __FL_BUYBACK
		pUser->m_Buyback.AddItem(pItemElem, nNum, n64_TotalCost + n64_TotalTax, bAddBuybackToClient);
#endif
		pUser->RemoveItem((BYTE)it, nNum, nType);
	}

	int nGivePerin = n64PenyaAll / PERIN_VALUE;
	int nGivePenya = n64PenyaAll % PERIN_VALUE;

	if (pUser->GetGold() > (INT_MAX - PERIN_VALUE))
	{
		pUser->AddGold(-(PERIN_VALUE));
		nGivePerin++;
	}

	if (nGivePerin > 0)
	{
		CItemElem itemPerin;
		itemPerin.m_dwItemId = II_SYS_SYS_SCR_PERIN;
		itemPerin.m_nHitPoint = 0;
		itemPerin.SetSerialNumber();

		const int nMaxPerinsInPack = static_cast<int>(itemPerin.GetProp()->dwPackMax);
		while (nGivePerin >= nMaxPerinsInPack)
		{
			itemPerin.m_nItemNum = nMaxPerinsInPack;

			if (!pUser->CreateItem(&itemPerin))
				g_dpDBClient.SendQueryPostMail(pUser->m_idPlayer, 0, itemPerin, 0, "", "");

			nGivePerin -= nMaxPerinsInPack;
		}

		if (nGivePerin > 0)
		{
			itemPerin.m_nItemNum = nGivePerin;

			if (!pUser->CreateItem(&itemPerin))
				g_dpDBClient.SendQueryPostMail(pUser->m_idPlayer, 0, itemPerin, 0, "", "");
		}

	}

	if (nGivePenya > 0)
		pUser->AddGold(nGivePenya);

	while (n64TaxAll >= INT_MAX)
	{
		CTax::GetInstance()->AddTax(CTax::GetInstance()->GetContinent(pUser), INT_MAX, TAX_SALES);
		n64TaxAll -= INT_MAX;
	}

	if (n64TaxAll > 0)
		CTax::GetInstance()->AddTax(CTax::GetInstance()->GetContinent(pUser), static_cast<int>(n64TaxAll), TAX_SALES);

#ifdef __FL_BUYBACK
	if (!bAddBuybackToClient)
		pUser->AddBuyback();
#endif
}
#endif

void CDPSrvr::OnOpenBankWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD	dwId, dwItemId;
	ar >> dwId >> dwItemId;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (dwId == NULL_ID && !CNpcChecker::GetInstance()->IsCloseNpc(MMI_BANKING, pUser->GetWorld(), pUser->GetPos()))
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	if (pUser->IsChaotic())
	{
		CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty(pUser->GetPKPropensity());
		if (!Propensity.nBank)
			return;
	}

	if (0 == strcmp(pUser->m_szBankPass, "0000"))
		pUser->AddBankWindow(0, dwId, dwItemId);
	else
		pUser->AddBankWindow(1, dwId, dwItemId);
}

void CDPSrvr::OnOpenGuildBankWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (g_eLocal.GetState(ENABLE_GUILD_INVENTORY) == FALSE)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif
	if (pUser->m_vtInfo.GetOther())
		return;
	if (pUser->m_vtInfo.VendorIsVendor())
		return;
	if (pUser->m_bBank)
		return;
#ifdef __S_SERVER_UNIFY
	if (pUser->m_bAllAction == FALSE)
		return;
#endif // 

	pUser->AddGuildBankWindow(0);
	pUser->m_bGuildBank = TRUE;
}

void CDPSrvr::OnCloseBankWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->m_bBank = FALSE;
	pUser->m_bInstantBank = FALSE;
}

void CDPSrvr::OnCloseGuildBankWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (g_eLocal.GetState(ENABLE_GUILD_INVENTORY) == FALSE)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->m_bGuildBank = FALSE;
}

void CDPSrvr::OnBankToBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	BYTE nFlag, nPutSlot, nSlot;
	ar >> nFlag >> nPutSlot >> nSlot;

	if (nPutSlot >= 3 || nSlot >= 3)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "banque"))
		return;
#else
#line 2453 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif
	if (pUser->IsDie() == TRUE)
		return;

	if (pUser->m_idPlayerBank[nPutSlot] != 0 && pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank())
	{
		if (nFlag == 1)
		{
			DWORD dwItemObjID;
			int nItemNum;
			ar >> dwItemObjID >> nItemNum;
			CItemElem* pItemElem = pUser->m_Bank[nPutSlot].GetAtId(dwItemObjID);
			if (pItemElem == NULL)
				return;

			if (nItemNum > pItemElem->m_nItemNum)
				nItemNum = pItemElem->m_nItemNum;
			if (nItemNum < 1)
				nItemNum = 1;

			if (MAX_BANK > pUser->m_Bank[nSlot].GetCount())
			{
				CItemElem itemElem;
				itemElem = *pItemElem;
				itemElem.m_nItemNum = nItemNum;
				pUser->AddPutItemBank(nSlot, &itemElem);
				pUser->m_Bank[nSlot].Add(&itemElem);

				int nType = -1;
				switch (nPutSlot)
				{
				case 0: nType = TYPE_BANK_0; break;
				case 1: nType = TYPE_BANK_1; break;
				case 2: nType = TYPE_BANK_2; break;
				default: break;
				}

				pUser->RemoveItem((BYTE)dwItemObjID, nItemNum, nType);

				LogItemInfo aLogItem;
				aLogItem.Action = "A";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "BANK";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
				aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
				aLogItem.nSlot = nSlot;
				aLogItem.nSlot1 = nPutSlot;
				OnLogItem(aLogItem, &itemElem, itemElem.m_nItemNum);
			}
			else
				pUser->AddBankIsFull();
		}
		else
		{
			DWORD dwGold;
			ar >> dwGold;

			if (dwGold > pUser->m_dwGoldBank[nPutSlot])
				dwGold = pUser->m_dwGoldBank[nPutSlot];

			int nGold = dwGold;
			if (nGold < 0)
				return;

			if (CanAdd(pUser->m_dwGoldBank[nSlot], nGold))
			{
				pUser->m_dwGoldBank[nSlot] += nGold;
				pUser->m_dwGoldBank[nPutSlot] -= nGold;

				pUser->AddPutGoldBank(nSlot, pUser->GetGold(), pUser->m_dwGoldBank[nSlot]);
				pUser->AddPutGoldBank(nPutSlot, pUser->GetGold(), pUser->m_dwGoldBank[nPutSlot]);

				LogItemInfo aLogItem;
				aLogItem.Action = "A";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "BANK";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
				_stprintf(aLogItem.szItemName, "%d", II_GOLD_SEED1);
				aLogItem.itemNumber = nGold;
				aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
				aLogItem.nSlot = nSlot;
				aLogItem.nSlot1 = nPutSlot;
				OnLogItem(aLogItem);
			}
		}
	}
}

void CDPSrvr::OnPutItemBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	BYTE nSlot;
	DWORD dwItemObjID;
	int nItemNum;

	ar >> nSlot >> dwItemObjID >> nItemNum;
	if (nSlot >= 3)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "banque"))
		return;
#else
#line 2563 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	if (pUser->IsDie() == TRUE)
		return;

	if (!pUser->m_bInstantBank)
	{
		if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_BANKING, pUser->GetWorld(), pUser->GetPos()))
			return;
	}

	if (pUser->m_nSlot == nSlot || (pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank()))
	{
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwItemObjID);
		if (IsUsableItem(pItemElem) == FALSE)
			return;

		if (nSlot != pUser->m_nSlot)
		{
			if (pItemElem->IsQuest())
				return;
		}

		if (pItemElem->IsBinds())
			return;

		ItemProp* pProp = pItemElem->GetProp();
		if (!pProp)
			return;

		if (pUser->IsUsing(pItemElem))
		{
			pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
			return;
		}

		if (pUser->m_Inventory.IsEquip(dwItemObjID))
		{
			pUser->AddDefinedText(TID_GAME_EQUIPTRADE, "");
			return;
		}

		if (nItemNum > pItemElem->m_nItemNum)
			nItemNum = pItemElem->m_nItemNum;
		if (nItemNum < 1)
			nItemNum = 1;

		if (pUser->m_Bank[nSlot].IsFull(pItemElem, pProp, nItemNum) == TRUE)
		{
			pUser->AddBankIsFull();
			return;
		}
		else
		{
			CItemElem itemElem;
			itemElem = *pItemElem;
			itemElem.m_nItemNum = nItemNum;

			LogItemInfo aLogItem;
			aLogItem.Action = "P";
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "BANK";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
			aLogItem.nSlot1 = nSlot;
			OnLogItem(aLogItem, pItemElem, nItemNum);

			pUser->RemoveItem((BYTE)dwItemObjID, nItemNum);
			pUser->m_Bank[nSlot].Add(&itemElem);
			pUser->AddPutItemBank(nSlot, &itemElem);
		}
	}
}

void CDPSrvr::OnPutItemGuildBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	if (g_eLocal.GetState(ENABLE_GUILD_INVENTORY) == FALSE)
		return;

	DWORD dwItemObjID;
	int nItemNum;
	BYTE mode;

	ar >> dwItemObjID >> nItemNum >> mode;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "banque de guilde"))
		return;
#else
#line 2659 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	if (pUser->IsDie() == TRUE)
		return;

	if (!pUser->GetWorld() || !GuildHouseMng->IsGuildHouse(pUser->GetWorld()->GetID()))
		if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_GUILDBANKING, pUser->GetWorld(), pUser->GetPos()))
			return;

	if (mode == 0)
		return;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwItemObjID);
	if (IsUsableItem(pItemElem) == FALSE)
		return;

	if (pItemElem->IsQuest())
		return;

	if (pItemElem->IsBinds())
		return;

	if (pUser->IsUsing(pItemElem))
	{
		pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
		return;
	}

	ItemProp* pItemProp = pItemElem->GetProp();
	if (pItemProp == NULL)
		return;

	if (pUser->m_Inventory.IsEquip(dwItemObjID))
	{
		pUser->AddDefinedText(TID_GAME_EQUIPTRADE, "");
		return;
	}

	if (nItemNum > pItemElem->m_nItemNum)
		nItemNum = pItemElem->m_nItemNum;
	if (nItemNum < 1)
		nItemNum = 1;


	CGuild* pGuild = pUser->GetGuild();
	if (pGuild)
	{
		if (pGuild->m_GuildBank.IsFull(pItemElem, pItemProp, nItemNum))
		{
			pUser->AddDefinedText(TID_GAME_GUILDBANKFULL, "");
			return;
		}

		CItemElem itemElem;
		itemElem = *pItemElem;
		itemElem.m_nItemNum = nItemNum;

		pUser->RemoveItem((BYTE)dwItemObjID, nItemNum);
		pGuild->m_GuildBank.Add(&itemElem);

		UpdateGuildBank(pGuild, GUILD_PUT_ITEM, 0, pUser->m_idPlayer, &itemElem, 0, nItemNum);
		CWorld* pWorld = pUser->GetWorld();
		if (pWorld)
			g_dpDBClient.SavePlayer(pUser, pWorld->GetID(), pUser->GetPos(), pUser->GetLayer());

		LogItemInfo aLogItem;
		aLogItem.Action = "W";
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = "GUILDBANK";
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
		OnLogItem(aLogItem, &itemElem, nItemNum);

		pUser->AddPutItemGuildBank(&itemElem);

		CGuildMember* pMember;
		CUser* pUsertmp;
		map<u_long, CGuildMember*>::iterator i = pGuild->m_mapPMember.begin();
		for (; i != pGuild->m_mapPMember.end(); ++i)
		{
			pMember = i->second;
			pUsertmp = (CUser*)prj.GetUserByID(pMember->m_idPlayer);
			if (IsValidObj(pUsertmp) && pUsertmp != pUser && pUsertmp->m_bGuildBank)
				pUsertmp->AddPutItemGuildBank(&itemElem);
		}
	}
}

void CDPSrvr::OnGetItemGuildBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	if (g_eLocal.GetState(ENABLE_GUILD_INVENTORY) == FALSE)
		return;

	DWORD dwItemObjID = NULL_ID;
	int nItemNum = 0;
	BYTE byMode = 0;

	ar >> dwItemObjID >> nItemNum >> byMode;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "banque de guilde"))
		return;
#else
#line 2768 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	CGuild* pGuild = pUser->GetGuild();
	if (pGuild == NULL)
		return;

	if (pGuild->IsMember(pUser->m_idPlayer) == FALSE)
		return;

	if (pUser->IsDie() == TRUE)
		return;

	CWorld* pWorld = pUser->GetWorld();
	if (pWorld == NULL)
		return;

	if (GuildHouseMng->IsGuildHouse(pWorld->GetID()) == FALSE && CNpcChecker::GetInstance()->IsCloseNpc(MMI_GUILDBANKING, pWorld, pUser->GetPos()) == FALSE)
		return;

	if (byMode < 0 || byMode > 1)
		return;

	if (byMode == 0)
	{
		if (pGuild->IsGetPenya(pUser->m_idPlayer) == FALSE)
			return;

		const int nGetGold = nItemNum;
		if (nGetGold <= 0 || nGetGold > INT_MAX)
			return;

		if (static_cast<DWORD>(nGetGold) > pGuild->m_nGoldGuild)
			return;

		if (pUser->CheckUserGold(nGetGold, true) == false)
			return;

		pUser->AddGold(nGetGold, FALSE);
		pGuild->m_nGoldGuild -= nGetGold;
		pUser->AddGetGoldGuildBank(nGetGold, 0, pUser->m_idPlayer, 0);
		pGuild->DecrementMemberContribution(pUser->m_idPlayer, nGetGold, 0);
		UpdateGuildBank(pGuild, GUILD_GET_PENYA, 1, pUser->m_idPlayer, NULL, nGetGold);

		LogItemInfo aLogItem;
		aLogItem.Action = "Y";
		aLogItem.SendName = "GUILDBANK";
		aLogItem.RecvName = pUser->GetName();
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = pUser->GetGold() - nGetGold;
		aLogItem.Gold2 = pUser->GetGold();
		_stprintf(aLogItem.szItemName, "%d", II_GOLD_SEED1);
		aLogItem.itemNumber = nGetGold;
		OnLogItem(aLogItem);

		CGuildMember* pMember;
		CUser* pUsertmp;
		map<u_long, CGuildMember*>::iterator i = pGuild->m_mapPMember.begin();
		for (; i != pGuild->m_mapPMember.end(); ++i)
		{
			pMember = i->second;
			pUsertmp = (CUser*)prj.GetUserByID(pMember->m_idPlayer);
			if (IsValidObj(pUsertmp) && pUsertmp != pUser)
				pUsertmp->AddGetGoldGuildBank(nGetGold, 2, pUser->m_idPlayer, 0);
		}

		g_DPCoreClient.SendGuildMsgControl_Bank_Penya(pUser, nGetGold, 2, 0);
	}
	else if (byMode == 1)
	{
		if (pGuild->IsGetItem(pUser->m_idPlayer) == FALSE)
			return;

		CItemElem* const pItemElem = pGuild->m_GuildBank.GetAtId(dwItemObjID);
		if (NULL == pItemElem)
			return;

		ItemProp* pItemSpec = pItemElem->GetProp();
		if (pItemSpec == NULL)
			return;

		const int nGetItemQuantity = nItemNum;
		if (nGetItemQuantity <= 0 || static_cast<DWORD>(nGetItemQuantity) > pItemSpec->dwPackMax)
			return;

		if (nGetItemQuantity > pItemElem->m_nItemNum)
			return;

		if (pUser->m_Inventory.IsFull(pItemElem, pItemSpec, nGetItemQuantity) == TRUE)
		{
			pUser->AddBankIsFull();
			return;
		}

		CItemElem itemElem;
		itemElem = *pItemElem;
		itemElem.m_nItemNum = nGetItemQuantity;
		itemElem.m_dwObjId = pItemElem->m_dwObjId;

		if (pUser->m_Inventory.Add(&itemElem))
		{
			if (itemElem.m_nItemNum < pItemElem->m_nItemNum)
				pItemElem->m_nItemNum = pItemElem->m_nItemNum - nGetItemQuantity;
			else
				pGuild->m_GuildBank.RemoveAtId(dwItemObjID);

			UpdateGuildBank(pGuild, GUILD_GET_ITEM, 0, pUser->m_idPlayer, &itemElem, 0, (short)(nItemNum));
			LogItemInfo aLogItem;
			aLogItem.Action = "Y";
			aLogItem.SendName = "GUILDBANK";
			aLogItem.RecvName = pUser->GetName();
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			OnLogItem(aLogItem, &itemElem, nItemNum);

			pUser->AddGetItemGuildBank(&itemElem);

			CGuildMember* pMember;
			CUser* pUsertmp;
			map<u_long, CGuildMember*>::iterator i = pGuild->m_mapPMember.begin();
			for (; i != pGuild->m_mapPMember.end(); ++i)
			{
				pMember = i->second;
				pUsertmp = (CUser*)prj.GetUserByID(pMember->m_idPlayer);
				if (IsValidObj(pUsertmp) && pUsertmp != pUser && pUsertmp->m_bGuildBank)
					pUsertmp->AddGetItemGuildBank(&itemElem, FALSE);
			}
		}
		else
			pUser->AddBankIsFull();
	}
	else
	{
		Error("[ INVALID GUILD BANK OUTPUT MODE. byMode(%d), PLAYER_ID(%07d) ]", byMode, pUser->m_idPlayer);
		return;
	}

	if (pUser->GetWorld())
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

}


void CDPSrvr::OnGuildBankMoveItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{

}

void CDPSrvr::UpdateGuildBank(CGuild* p_GuildBank, int p_Mode, BYTE cbUpdate, u_long idPlayer, CItemElem* pItemElem, DWORD dwPenya, short nItemCount)
{
	BEFORESENDDUAL(ar, PACKETTYPE_GUILD_BANK_UPDATE, DPID_UNKNOWN, DPID_UNKNOWN);

	if (p_GuildBank)
	{
		ar << p_GuildBank->m_idGuild;
		ar << p_GuildBank->m_nGoldGuild;
		p_GuildBank->m_GuildBank.Serialize(ar);
		ar << cbUpdate;
		ar << idPlayer;
		ar << p_Mode;
		if (pItemElem == NULL)
		{
			ar << (DWORD)0;
			ar << (int)0;
			ar << (SERIALNUMBER)0;
		}
		else
		{
			ar << pItemElem->m_dwItemId;
			ar << pItemElem->GetAbilityOption();
			ar << pItemElem->GetSerialNumber();
		}
		ar << nItemCount;
		ar << dwPenya;
		SEND(ar, &g_dpDBClient, DPID_SERVERPLAYER);
	}
}


void CDPSrvr::OnGetItemBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	BYTE nSlot;
	DWORD dwItemObjID;
	int nItemNum;

	ar >> nSlot >> dwItemObjID >> nItemNum;
	if (nSlot >= 3)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser))
	{
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
		if (ZckRefusStaff(pUser, "banque"))
			return;
#else
#line 2967 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif

		if (pUser->IsDie() == TRUE)
			return;

		if (!pUser->m_bInstantBank)
		{
			if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_BANKING, pUser->GetWorld(), pUser->GetPos()))
				return;
		}

		if (pUser->m_nSlot == nSlot || (pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank()))
		{
			CItemElem* pItemElem = pUser->m_Bank[nSlot].GetAtId(dwItemObjID);
			if (NULL == pItemElem)
				return;

			ItemProp* pItemProp = pItemElem->GetProp();
			if (!pItemProp)
				return;

			if (nItemNum > pItemElem->m_nItemNum)
				nItemNum = pItemElem->m_nItemNum;
			if (nItemNum < 1)
				nItemNum = 1;

			if (pUser->m_Inventory.IsFull(pItemElem, pItemProp, nItemNum))
			{
				pUser->AddBankIsFull();
				return;
			}

			CItemElem itemElem;
			itemElem = *pItemElem;
			itemElem.m_nItemNum = nItemNum;

			LogItemInfo aLogItem;
			aLogItem.Action = "G";
			aLogItem.SendName = "BANK";
			aLogItem.RecvName = pUser->GetName();
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
			aLogItem.nSlot = nSlot;
			OnLogItem(aLogItem, pItemElem, nItemNum);

			int nType = -1;
			switch (nSlot)
			{
			case 0: nType = TYPE_BANK_0; break;
			case 1: nType = TYPE_BANK_1; break;
			case 2: nType = TYPE_BANK_2; break;
			default: break;
			}

			pUser->RemoveItem((BYTE)dwItemObjID, nItemNum, nType);
			pUser->m_Inventory.Add(&itemElem);
			pUser->AddGetItemBank(&itemElem);
		}
	}
}

void CDPSrvr::OnPutGoldBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpbuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	DWORD dwGold;
	BYTE nSlot;
	ar >> nSlot >> dwGold;

	int nGold = dwGold;
	if (nGold <= 0)
		return;

	if (nSlot >= 3)
		return;

	if (IsValidObj(pUser))
	{
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
		if (ZckRefusStaff(pUser, "banque"))
			return;
#else
#line 3051 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
		if (pUser->IsDie() == TRUE)
			return;

		if (!pUser->m_bInstantBank)
		{
			if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_BANKING, pUser->GetWorld(), pUser->GetPos()))
				return;
		}

		if (pUser->m_nSlot == nSlot || (pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank()))
		{
			if (pUser->CheckUserGold(nGold, false) == false)
				return;

			if (CanAdd(pUser->m_dwGoldBank[nSlot], nGold) == TRUE)
			{
				LogItemInfo aLogItem;
				aLogItem.Action = "P";
				aLogItem.SendName = pUser->GetName();
				aLogItem.RecvName = "BANK";
				aLogItem.WorldId = pUser->GetWorld()->GetID();
				aLogItem.Gold = pUser->GetGold();
				aLogItem.Gold2 = pUser->GetGold() - nGold;
				_stprintf(aLogItem.szItemName, "%d", II_GOLD_SEED1);
				aLogItem.itemNumber = nGold;
				aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
				aLogItem.nSlot1 = nSlot;
				OnLogItem(aLogItem);

				pUser->m_dwGoldBank[nSlot] += nGold;
				pUser->AddGold(-nGold, FALSE);

				pUser->AddPutGoldBank(nSlot, pUser->GetGold(), pUser->m_dwGoldBank[nSlot]);
			}
		}
	}
}


void CDPSrvr::OnGetGoldBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpbuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	BYTE nSlot;
	DWORD dwMoveGold;
	ar >> nSlot >> dwMoveGold;

	int nMoveGold = dwMoveGold;
	if (nMoveGold <= 0)
		return;

	if (nSlot >= 3)
		return;

	if (IsValidObj(pUser) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "banque"))
		return;
#else
#line 3107 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	if (pUser->IsDie() == TRUE)
		return;

	if (!pUser->m_bInstantBank)
	{
		if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_BANKING, pUser->GetWorld(), pUser->GetPos()))
			return;
	}

	if (pUser->m_nSlot == nSlot || (pUser->m_idPlayerBank[nSlot] != 0 && pUser->IsCommBank()))
	{
		int nBankGold = pUser->m_dwGoldBank[nSlot];
		if (nBankGold < 0)
			return;

#undef min
		nMoveGold = std::min(nBankGold, nMoveGold);

		if (pUser->CheckUserGold(nMoveGold, true) == false)
			return;

		LogItemInfo aLogItem;
		aLogItem.Action = "G";
		aLogItem.SendName = "BANK";
		aLogItem.RecvName = pUser->GetName();
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = pUser->GetGold();
		aLogItem.Gold2 = pUser->GetGold() + nMoveGold;
		_stprintf(aLogItem.szItemName, "%d", II_GOLD_SEED1);
		aLogItem.itemNumber = nMoveGold;
		aLogItem.Gold_1 = pUser->m_dwGoldBank[pUser->m_nSlot];
		aLogItem.nSlot = nSlot;
		OnLogItem(aLogItem);

		pUser->AddGold(nMoveGold, FALSE);
		pUser->m_dwGoldBank[nSlot] -= nMoveGold;
		pUser->AddPutGoldBank(nSlot, pUser->GetGold(), pUser->m_dwGoldBank[nSlot]);
	}
}

void CDPSrvr::OnMoveBankItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
}

void CDPSrvr::OnChangeBankPass(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	char szLastPass[10] = { 0, };
	char szNewPass[10] = { 0, };
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		ar.ReadString(szLastPass, 10);
		ar.ReadString(szNewPass, 10);

		if (strlen(szLastPass) > 4 || strlen(szNewPass) > 4)
		{
			WriteError("%s %d, %s, %s", __FILE__, __LINE__, szLastPass, szNewPass);
			return;
		}

		DWORD dwId, dwItemId;
		ar >> dwId >> dwItemId;


		if (0 == strcmp(szLastPass, pUser->m_szBankPass))
		{

			strcpy(pUser->m_szBankPass, szNewPass);
			g_dpDBClient.SendChangeBankPass(pUser->GetName(), szNewPass, pUser->m_idPlayer);
			pUser->AddChangeBankPass(1, dwId, dwItemId);
		}
		else
		{


			pUser->AddChangeBankPass(0, dwId, dwItemId);
		}
	}
}

void CDPSrvr::OnConfirmBank(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	char szPass[10] = { 0, };
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_vtInfo.GetOther())
			return;
		if (pUser->m_vtInfo.VendorIsVendor())
			return;
		if (pUser->m_bGuildBank)
			return;
#ifdef __S_SERVER_UNIFY
		if (pUser->m_bAllAction == FALSE)
			return;
#endif // __S_SERVER_UNIFY
#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif

		ar.ReadString(szPass, 10);

		DWORD dwId, dwItemId;
		ar >> dwId >> dwItemId;

		if (dwId == NULL_ID && !CNpcChecker::GetInstance()->IsCloseNpc(MMI_BANKING, pUser->GetWorld(), pUser->GetPos()))
			return;

		if (0 == strcmp(szPass, pUser->m_szBankPass))
		{
			if (dwId != NULL_ID)
			{
				CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwId);
				if (IsUsableItem(pItemElem) == FALSE || pItemElem->m_dwItemId != II_SYS_SYS_SCR_CUSTODY)
				{
					return;
				}
				else
				{
					pUser->m_bInstantBank = TRUE;
					pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), 1);
				}
			}
			pUser->m_bBank = TRUE;
			pUser->AddconfirmBankPass(1, dwId, dwItemId);
		}
		else
			pUser->AddconfirmBankPass(0, dwId, dwItemId);
	}
}

void CDPSrvr::OnSfxHit(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int idSfxHit;
	DWORD dwSkill;
	OBJID idAttacker;
	CMover* pAttacker = NULL;

	ar >> idSfxHit >> dwSkill >> idAttacker;

	if (idAttacker == NULL_ID)
		pAttacker = g_UserMng.GetUser(dpidCache, dpidUser);
	else
		pAttacker = prj.GetMover(idAttacker);

	if (IsValidObj(pAttacker) == FALSE)
		return;

	PSfxHit pSfxHit = pAttacker->m_sfxHitArray.GetSfxHit(idSfxHit);
	if (pSfxHit == NULL)
		return;

	CMover* pTarget = prj.GetMover(pSfxHit->objid);

	pAttacker->RemoveSFX(pSfxHit->objid, idSfxHit, (IsInvalidObj(pTarget) || pTarget->IsDie()), dwSkill);
	pAttacker->m_sfxHitArray.RemoveSfxHit(idSfxHit, TRUE);
}


void CDPSrvr::OnSfxID(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID	idTarget;
	int		idSfxHit;
	DWORD	dwType, dwSkill;
	int		nMaxDmgCnt;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		ar >> idTarget >> idSfxHit >> dwType >> dwSkill >> nMaxDmgCnt;
		pUser->m_sfxHitArray.Add(idSfxHit, idTarget, dwType, dwSkill, nMaxDmgCnt);
	}
}


void CDPSrvr::OnSfxClear(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID	idMover = NULL_ID;
	int	  idSfxHit;

	ar >> idSfxHit;
	ar >> idMover;

	CMover* pMover;

	if (idMover == NULL_ID)
		pMover = g_UserMng.GetUser(dpidCache, dpidUser);
	else
		pMover = prj.GetMover(idMover);

	if (IsValidObj(pMover))
	{
		PSfxHit pSfxHit = pMover->m_sfxHitArray.GetSfxHit(idSfxHit);
		pMover->m_sfxHitArray.RemoveSfxHit(idSfxHit, TRUE);
	}
}

void CDPSrvr::OnMeleeAttack(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	OBJMSG dwAtkMsg;
	OBJID objid;

	ar >> dwAtkMsg >> objid;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CMover* pTargetObj = prj.GetMover(objid);
	if (!IsValidObj(pTargetObj))
		return;

	if (pUser->IsDie() || pTargetObj->IsDie())
		return;

	if (pTargetObj->IsMode(TRANSPARENT_MODE))
		return;

	bool bHack = false;
	switch (dwAtkMsg)
	{
	case OBJMSG_ATK1:
		pUser->SetLastMeleeHit(OBJMSG_ATK1);
		break;
	case OBJMSG_ATK2:
		if (pUser->GetLastMeleeHit() == OBJMSG_ATK1)
			pUser->SetLastMeleeHit(OBJMSG_ATK2);
		else
			bHack = true;
		break;
	case OBJMSG_ATK3:
		if (pUser->GetLastMeleeHit() == OBJMSG_ATK2)
			pUser->SetLastMeleeHit(OBJMSG_ATK3);
		else
			bHack = true;
		break;
	case OBJMSG_ATK4:
		if (pUser->GetLastMeleeHit() == OBJMSG_ATK3)
			pUser->SetLastMeleeHit(OBJMSG_ATK4);
		else
			bHack = true;
		break;
	default: bHack = true; break;
	}

	ItemProp* pItemProp = pUser->GetActiveHandItemProp();
	if (pItemProp && pItemProp->dwItemKind3 == IK3_YOYO)
	{
		if (dwAtkMsg != OBJMSG_ATK1 && dwAtkMsg != OBJMSG_ATK2)
			bHack = true;
	}

	if (bHack)
	{
		pUser->SetLastMeleeHit(OBJMSG_NONE);
		return;
	}

	bool bValidateRange = true;
	if (dwAtkMsg != OBJMSG_ATK1 && dwAtkMsg != OBJMSG_ATK3)
		bValidateRange = false;

	pUser->DoAttackMelee(pTargetObj, dwAtkMsg, 0, bValidateRange);
}

void CDPSrvr::OnMeleeAttack2(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objid;
	ar >> objid;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->GetIndex() == 0)
		{
			WriteError("PACKETTYPE_MELEE_ATTACK2");
			return;
		}

		CMover* pTargetObj = prj.GetMover(objid);
		if (IsValidObj(pTargetObj))
		{
			if (pUser->IsDie() == TRUE || pTargetObj->IsDie() == TRUE || pUser->IsFly() == FALSE)
				return;

			int nRet = pUser->SendActMsg(OBJMSG_ATK1, objid);

			if (nRet == 0)
				pUser->m_pActMover->m_qMeleeAtkMsg.AddTail(new ACTMSG(OBJMSG_ATK1, objid, 0, 0));

			if (nRet != -2)
				g_UserMng.AddMeleeAttack2(pUser, objid);
		}
	}
}


void CDPSrvr::OnMagicAttack(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	OBJID objid;
	int nMagicPower, idSfxHit;
	ar >> objid >> nMagicPower >> idSfxHit;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CMover* pTargetObj = prj.GetMover(objid);
	if (!IsValidObj(pTargetObj))
		return;

	if (pUser->IsDie() == TRUE || pTargetObj->IsDie() == TRUE)
		return;

	if (pTargetObj->IsMode(TRANSPARENT_MODE))
		return;

	int nRet = pUser->DoAttackMagic(pTargetObj, nMagicPower, idSfxHit);

	if (nRet == 0 && pUser->IsFly() == FALSE)
		pUser->m_pActMover->m_qMagicAtkMsg.AddTail(new MAGICATKMSG(OBJMSG_ATK_MAGIC1, objid, 0, 0, nMagicPower, idSfxHit));
}


void CDPSrvr::OnRangeAttack(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	OBJID objid = 0;
	DWORD dwItemID = 0;
	int idSfxHit = 0;

	ar >> objid >> dwItemID >> idSfxHit;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CMover* pTargetObj = prj.GetMover(objid);
	if (IsValidObj(pTargetObj) == FALSE)
		return;

	if (pUser->IsDie() == TRUE || pTargetObj->IsDie() == TRUE)
		return;

	if (pTargetObj->IsMode(TRANSPARENT_MODE))
		return;

	ItemProp* pHandItemProp = pUser->GetActiveHandItemProp();
	if (pHandItemProp == NULL)
		return;

	if (pUser->DoAttackRange(pTargetObj, dwItemID, idSfxHit) == 0)
		pUser->m_pActMover->m_qMagicAtkMsg.AddTail(new MAGICATKMSG(OBJMSG_ATK_RANGE1, objid, 1, dwItemID, 0, idSfxHit));
}

void CDPSrvr::OnTeleSkill(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	D3DXVECTOR3 vPos;
	ar >> vPos;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (pUser->IsDie())
		return;

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	LPSKILL pSkill = pUser->GetSkill(SI_MAG_MAG_BLINKPOOL);
	if (!pSkill || pSkill->dwLevel == 0)
		return;

	ItemProp* pPropSkill = pSkill->GetProp();
	if (!pPropSkill)
		return;

	AddSkillProp* pAddSkillProp = prj.GetAddSkillProp(pPropSkill->dwSubDefine, pSkill->dwLevel);
	if (!pAddSkillProp)
		return;

	const float fMaxDistance = (float)pAddSkillProp->dwSkillRange;
	const D3DXVECTOR3 vPosDifference = vPos - pUser->GetPos();
	float fTotalDistance = ::sqrt(D3DXVec3LengthSq(&vPosDifference));
	if (fTotalDistance > fMaxDistance)
		fTotalDistance = fMaxDistance;

	const float fPower = fTotalDistance * 0.1f;
	pUser->pushedByAnotherPower(GetDegree(vPos, pUser->GetPos()), fPower);
}

void CDPSrvr::OnSetTarget(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID idTarget;
	BYTE bClear;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		ar >> idTarget >> bClear;

		pUser->ClearCastingSkills(TRUE);

		if (bClear == 2)
			pUser->m_idSetTarget = idTarget;

		if (bClear < 2)
		{
			CMover* pTarget = prj.GetMover(idTarget);
			if (IsValidObj(pTarget))
			{
				if (pUser->IsDie() || pTarget->IsDie())
					return;

				if (bClear)
				{
					if (pTarget->m_idTargeter == pUser->GetId())
						pTarget->m_idTargeter = NULL_ID;
				}
				else
				{
					if (pTarget->m_idTargeter == NULL_ID)
						pTarget->m_idTargeter = pUser->GetId();
				}
			}
		}
	}
}


void CDPSrvr::OnSnapshot(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		BYTE c;
		ar >> c;

		while (c--)
		{
			WORD wHdr;
			ar >> wHdr;
			switch (wHdr)
			{
			case SNAPSHOTTYPE_DESTPOS:	OnPlayerDestPos(ar, pUser);	break;
			default:
			{
				ASSERT(0);
				break;
			}
			}
		}
	}
}


void CDPSrvr::OnPlayerDestPos(CAr& ar, CUser* pUser)
{
	D3DXVECTOR3 vPos;
	BYTE fForward;
	ar >> vPos >> fForward;

	if (IsValidObj(pUser) == FALSE)
		return;
	if (pUser->IsDie() == TRUE)
		return;

	bool bForward = (fForward != 0);

	pUser->SetDestPos(vPos, bForward);
	g_UserMng.AddSetDestPos(pUser, vPos, bForward);
}

void CDPSrvr::OnModifyMode(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwMode;
		BYTE f;
		u_long idFrom;

		ar >> dwMode >> f >> idFrom;

		DPID dpid;
		ar >> dpid;
		if (pUser->m_Snapshot.dpidUser != dpid)
		{
			Error("[%s] try to hack : PACKETTYPE_MODIFYMODE", pUser->GetName());
			return;
		}

		if (f)
			pUser->m_dwMode |= dwMode;
		else
			pUser->m_dwMode &= ~dwMode;

		g_UserMng.AddModifyMode(pUser);
	}
}

void CDPSrvr::OnChangeFace(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwFaceNum;
	BOOL bUseCoupon;

	ar >> dwFaceNum >> bUseCoupon;

	if (dwFaceNum >= MAX_HEAD || dwFaceNum < 0)
		return;

	int cost = CHANGE_FACE_COST;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (dwFaceNum == pUser->m_dwHeadMesh)
			return;

		if (!bUseCoupon)
		{
			if (pUser->CheckUserGold(cost, false) == false)
			{
				pUser->AddDefinedText(TID_GAME_LACKMONEY, "");
				return;
			}
			pUser->AddGold(-(cost));
		}
		else
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_FACEOFFFREE);
			if (IsUsableItem(pItemElem) == FALSE)
			{
				pUser->AddDefinedText(TID_GAME_WARNNING_COUPON, "");
				return;
			}

			pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), 1);
		}
		pUser->SetHead(dwFaceNum);
		g_UserMng.AddChangeFace(pUser->m_idPlayer, dwFaceNum);
	}
}

void CDPSrvr::OnExpUp(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if ((DWORD)AUTH_GAMEMASTER <= pUser->m_dwAuthorization)
		{
			EXPINTEGER nExp;
			ar >> nExp;

			if (pUser->AddExperience(nExp, TRUE, TRUE, TRUE))
			{
				pUser->AddSetExperience(pUser->GetExp1(), (WORD)pUser->m_nLevel);
				pUser->LevelUpSetting();
			}
			else
				pUser->AddSetExperience(pUser->GetExp1(), (WORD)pUser->m_nLevel);
		}
	}
}

void	CDPSrvr::OnLogItem(LogItemInfo& info, CItemElem* pItemElem, int nItemCount)
{
	if (pItemElem != NULL)
	{
		info.ItemNo = pItemElem->GetSerialNumber();
		_stprintf(info.szItemName, "%d", pItemElem->GetProp()->dwID);
		info.itemNumber = nItemCount;
		info.nItemResist = pItemElem->m_bItemResist;
		info.nResistAbilityOption = pItemElem->m_nResistAbilityOption;
		info.nAbilityOption = pItemElem->GetAbilityOption();
		info.Negudo = pItemElem->m_nHitPoint;
		info.m_dwKeepTime = pItemElem->m_dwKeepTime;
		info.nPiercedSize = pItemElem->GetPiercingSize();
		for (int i = 0; i < pItemElem->GetPiercingSize(); i++)
			info.adwItemId[i] = pItemElem->GetPiercingItem(i);
		info.nUMPiercedSize = pItemElem->GetUltimatePiercingSize();
		for (int i = 0; i < pItemElem->GetUltimatePiercingSize(); i++)
			info.adwUMItemId[i] = pItemElem->GetUltimatePiercingItem(i);
		info.m_iRandomOptItemId = pItemElem->GetRandomOptItemId();
		if (pItemElem->m_pPet)
		{
			CPet* pPet = pItemElem->m_pPet;

			info.nPetKind = pPet->GetKind();
			info.nPetLevel = pPet->GetLevel();
			info.dwPetExp = pPet->GetExp();
			info.wPetEnergy = pPet->GetEnergy();
			info.wPetLife = pPet->GetLife();
			info.nPetAL_D = pPet->GetAvailLevel(PL_D);
			info.nPetAL_C = pPet->GetAvailLevel(PL_C);
			info.nPetAL_B = pPet->GetAvailLevel(PL_B);
			info.nPetAL_A = pPet->GetAvailLevel(PL_A);
			info.nPetAL_S = pPet->GetAvailLevel(PL_S);
		}
		else if (pItemElem->IsTransformVisPet() == TRUE)
		{
			info.nPetKind = (BYTE)100;
		}
	}

	BEFORESENDDUAL(ar, PACKETTYPE_LOG_ALLITEM, DPID_UNKNOWN, DPID_UNKNOWN);
	ar.WriteString(info.Action);
	ar.WriteString(info.SendName);
	ar.WriteString(info.RecvName);
	ar << info.WorldId;
	ar << info.Gold;
	ar << info.Gold2;
	ar << info.ItemNo;
	ar << info.Negudo;
	if (_tcslen(info.szItemName) == 0)
	{
		_stprintf(info.szItemName, "%d", -1);
	}
	ar.WriteString(info.szItemName);
	ar << info.itemNumber;
	ar << info.nAbilityOption;
	ar << info.Gold_1;
	ar << info.nSlot;
	ar << info.nSlot1;
	ar << info.nItemResist;
	ar << info.nResistAbilityOption;
	ar << info.m_dwKeepTime;
	ar << info.nPiercedSize;
	for (int i = 0; i < info.nPiercedSize; i++)
		ar << info.adwItemId[i];
	ar << info.nUMPiercedSize;
	for (int i = 0; i < info.nUMPiercedSize; i++)
		ar << info.adwUMItemId[i];
	ar << info.m_iRandomOptItemId;
	ar << info.nPetKind;
	ar << info.nPetLevel;
	ar << info.dwPetExp;
	ar << info.wPetEnergy;
	ar << info.wPetLife;
	ar << info.nPetAL_D;
	ar << info.nPetAL_C;
	ar << info.nPetAL_B;
	ar << info.nPetAL_A;
	ar << info.nPetAL_S;

	SEND(ar, &g_dpDBClient, DPID_SERVERPLAYER);
}


void CDPSrvr::OnSetHair(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nHair, nR, nG, nB;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __NEWYEARDAY_EVENT_COUPON
		BOOL bUseCoupon;
		ar >> nHair >> nR >> nG >> nB >> bUseCoupon;
#else //__NEWYEARDAY_EVENT_COUPON
		ar >> nHair >> nR >> nG >> nB;// >> nCost;
#endif //__NEWYEARDAY_EVENT_COUPON

		int nCost = CMover::GetHairCost((CMover*)pUser, nR, nG, nB, nHair);

#ifdef __NEWYEARDAY_EVENT_COUPON
		if (pUser->CheckUserGold(nCost, false) == false && bUseCoupon == FALSE)
#else //__NEWYEARDAY_EVENT_COUPON
		if (pUser->CheckUserGold(nCost, false) == false)
#endif //__NEWYEARDAY_EVENT_COUPON
		{
			pUser->AddDefinedText(TID_GAME_LACKMONEY, "");
			return;
		}

#ifdef __NEWYEARDAY_EVENT_COUPON
		if (!bUseCoupon)
			pUser->AddGold(-(nCost));
		else
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtItemId(II_SYS_SYS_SCR_HAIRCHANGE);
			if (IsUsableItem(pItemElem) == FALSE)
			{
				pUser->AddDefinedText(TID_GAME_WARNNING_COUPON, "");
				return;
			}

			pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), 1);
		}
#else //__NEWYEARDAY_EVENT_COUPON
		pUser->AddGold(-(nCost));
#endif //__NEWYEARDAY_EVENT_COUPON

		pUser->SetHair(nHair);
		float r, g, b;
		r = (float)nR / 255.0f;
		g = (float)nG / 255.0f;
		b = (float)nB / 255.0f;

		pUser->SetHairColor(r, g, b);
		g_UserMng.AddSetHair(pUser, nHair, nR, nG, nB);
	}
}

void CDPSrvr::OnBlock(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nGu;
	char szNameFrom[MAX_NAME] = { 0, };

	ar >> nGu;
	ar.ReadString(szNameFrom, MAX_NAME);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	u_long uidPlayerFrom = CPlayerDataCenter::GetInstance()->GetPlayerId(szNameFrom);
	if (uidPlayerFrom == 0)
		return;

	if (pUser->m_idPlayer == uidPlayerFrom)
		return;

	g_DPCoreClient.SendBlock(nGu, pUser->m_idPlayer, (char*)pUser->GetName(), uidPlayerFrom);
}


void CDPSrvr::OnItemTransy(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objidTarget, objidTransy;
	ar >> objidTarget;
	ar >> objidTransy;
#ifdef __SYS_ITEMTRANSY
	DWORD dwChangeId;
	BOOL bCash;
	ar >> dwChangeId;
	ar >> bCash;
#endif // __SYS_ITEMTRANSY
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		CItemUpgrade::GetInstance()->OnItemTransy(pUser, objidTarget, objidTransy, dwChangeId, bCash);

}


void CDPSrvr::OnPiercing(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId1, dwId2;

	ar >> dwId1;
	ar >> dwId2;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser))
		CItemUpgrade::GetInstance()->OnPiercing(pUser, dwId1, dwId2);
}


void CDPSrvr::OnPiercingRemove(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objId;
	ar >> objId;
	int nSlot;
	ar >> nSlot;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CItemUpgrade::GetInstance()->OnPiercingRemove(pUser, objId, nSlot);
}

void CDPSrvr::OnCreateSfxObj(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwSfxId;
	u_long uIdPlayer;
	BOOL bFlag;
	ar >> dwSfxId >> uIdPlayer >> bFlag;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (uIdPlayer == NULL_ID)
		{
			g_UserMng.AddCreateSfxObj((CMover*)pUser, dwSfxId, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z, bFlag);
		}
		else
		{
			CUser* pUsertmp = (CUser*)prj.GetUserByID(uIdPlayer);
			if (IsValidObj(pUsertmp))
				g_UserMng.AddCreateSfxObj((CMover*)pUsertmp, dwSfxId, pUsertmp->GetPos().x, pUsertmp->GetPos().y, pUsertmp->GetPos().z, bFlag);
		}
	}
}

void CDPSrvr::OnRemoveItemLevelDown(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId;
	ar >> dwId;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwId);
		if (!IsUsableItem(pItemElem))
			return;

		if (pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
		{
			pUser->AddDiagText(prj.GetText(TID_GAME_EQUIPPUT));
			return;
		}

		if (pItemElem->GetLevelDown() == 0)
		{
			pUser->AddDefinedText(TID_GAME_INVALID_TARGET_ITEM);
			return;
		}

		PutItemLog(pUser, "v", "OnRemoveItemLevelDown", pItemElem);

		pItemElem->SetLevelDown();
		pUser->UpdateItemEx((BYTE)(pItemElem->m_dwObjId), UI_RANDOMOPTITEMID, pItemElem->GetRandomOptItemId());
	}
}

void CDPSrvr::OnDoUseItemTarget(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwMaterial, dwTarget;
	ar >> dwMaterial >> dwTarget;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!pUser->IsPossibleUseItem())
		return;

	CItemElem* pMaterial = pUser->m_Inventory.GetAtId(dwMaterial);
	CItemElem* pTarget = pUser->m_Inventory.GetAtId(dwTarget);
	if (!IsUsableItem(pMaterial) || !IsUsableItem(pTarget))
		return;

	if (pUser->m_Inventory.IsEquip(dwMaterial) || pUser->m_Inventory.IsEquip(dwTarget))
	{
		pUser->AddDefinedText(TID_GAME_EQUIPPUT);
		return;
	}

	ItemProp* pMaterialProp = pMaterial->GetProp();
	if (!pMaterialProp)
		return;

	BOOL	b = FALSE;
	switch (pMaterial->m_dwItemId)
	{
	case II_SYS_SYS_QUE_PETRESURRECTION02_S:
	case II_SYS_SYS_QUE_PETRESURRECTION02_A:
	case II_SYS_SYS_QUE_PETRESURRECTION02_B:
	{
		CPet* pPet = pTarget->m_pPet;
		if (!pPet || !pTarget->IsFlag(CItemElem::expired))
		{
			pUser->AddDefinedText(TID_GAME_PETRESURRECTION_WRONG_TARGET_01);
		}
		else
		{
			BYTE nLevel = pPet->GetLevel();
			if ((nLevel == PL_B && pMaterial->m_dwItemId != II_SYS_SYS_QUE_PETRESURRECTION02_B)
				|| (nLevel == PL_A && pMaterial->m_dwItemId != II_SYS_SYS_QUE_PETRESURRECTION02_A)
				|| (nLevel == PL_S && pMaterial->m_dwItemId != II_SYS_SYS_QUE_PETRESURRECTION02_S)
				|| (nLevel < PL_B)
				)
			{
				pUser->AddDefinedText(TID_GAME_PETRESURRECTION_WRONG_TARGET_02);
			}
			else
			{
				PutItemLog(pUser, "r", "::PetResurrection", pTarget);

				pTarget->ResetFlag(CItemElem::expired);
				pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_FLAG, MAKELONG(pTarget->m_dwObjIndex, pTarget->m_byFlag));
				pPet->SetLife(0);
				pPet->SetEnergy(pPet->GetMaxEnergy() / 2);
				pUser->AddPetState(pTarget->m_dwObjId, pPet->GetLife(), pPet->GetEnergy(), pPet->GetExp());
				pUser->AddDefinedText(TID_GAME_PETRESURRECTION_SUCCESS);
				b = TRUE;
			}
		}
		break;
	}
	case II_SYS_SYS_SCR_AWAKECANCEL:
	case II_SYS_SYS_SCR_AWAKECANCEL02:
		b = DoUseItemTarget_InitializeRandomOption(pUser, pTarget, CRandomOptionProperty::eAwakening,
			TID_GAME_AWAKECANCEL_INFO, TID_GAME_AWAKECANCEL,
			"r", "::AwakeCancel");
		break;
	case II_SYS_SYS_SCR_AWAKE:
		b = DoUseItemTarget_GenRandomOption(pUser, pTarget, CRandomOptionProperty::eAwakening,
			0, TID_GAME_INVALID_TARGET_ITEM, TID_GAME_AWAKE_OR_BLESSEDNESS01,
			"r", "::Awake");
		break;
	case II_SYS_SYS_SCR_BLESSEDNESS:
	case II_SYS_SYS_SCR_BLESSEDNESS02:
		b = DoUseItemTarget_GenRandomOption(pUser, pTarget, CRandomOptionProperty::eBlessing,
			0, TID_GAME_USE_BLESSEDNESS_INFO, TID_GAME_BLESSEDNESS_INVALID_ITEM,
			"r", "::Blessedness");
		break;
	case II_SYS_SYS_SCR_EATPETAWAKE:
		b = DoUseItemTarget_GenRandomOption(pUser, pTarget, CRandomOptionProperty::eEatPet,
			TID_GAME_PETAWAKE_S00, TID_GAME_PETAWAKE_E00, TID_GAME_PETAWAKE_E00,
			"r", "EATPETAWAKE");
		break;
	case II_SYS_SYS_SCR_PETAWAKE:
		b = DoUseItemTarget_GenRandomOption(pUser, pTarget, CRandomOptionProperty::eSystemPet,
			TID_GAME_PETAWAKE_S00, TID_GAME_PETAWAKE_E00, TID_GAME_PETAWAKE_E00,
			"r", "PETAWAKE");
		break;
	case II_SYS_SYS_SCR_PETAWAKECANCEL:
		b = DoUseItemTarget_InitializeRandomOption(pUser, pTarget, CRandomOptionProperty::eSystemPet,
			TID_GAME_PETAWAKECANCEL_S00, TID_GAME_PETAWAKECANCEL_E00,
			"r", "PETAWAKECANCEL");
		break;
	case II_SYS_SYS_SCR_LEVELDOWN01:
	case II_SYS_SYS_SCR_LEVELDOWN02:
		b = DoUseItemTarget_ItemLevelDown(pUser, pMaterial, pTarget);
		break;
	case II_SYS_SYS_SCR_CANCELLATION:
		b = UnbindScroll(pUser, pMaterial, pTarget);
		break;
#ifdef __FL_ITEM_RUNE
	case II_SYS_SYS_SCR_FASHRUNE_REMOVE:
		b = DoUseItemTarget_FashRuneRemove(pUser, pMaterial, pTarget, false);
		break;
	case II_SYS_SYS_SCR_FASHRUNE_RESTORE:
		b = DoUseItemTarget_FashRuneRemove(pUser, pMaterial, pTarget, true);
		break;
#endif
	default:
		break;
	}

#ifdef __FL_ITEM_RUNE
	switch (pMaterialProp->dwItemKind3)
	{
	case IK3_FASHION_RUNE:
		b = DoUseItemTarget_FashRuneAdd(pUser, pMaterial, pTarget);
		break;
	default: break;
	}
#endif

	if (b)
	{
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if (pUser->IsMode(TRANSPARENT_MODE) == 0)
			g_UserMng.AddCreateSfxObj(pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);

		PutItemLog(pUser, "u", "OnDoUseItemTarget", pMaterial);

		pUser->RemoveItem((BYTE)(pMaterial->m_dwObjId), 1);
	}
}

void CDPSrvr::OnSmeltSafety(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID dwItemId, dwItemMaterialId, dwItemProtScrId, dwItemSmeltScrId;

	ar >> dwItemId >> dwItemMaterialId >> dwItemProtScrId >> dwItemSmeltScrId;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser))
	{
		if (pUser->m_vtInfo.GetOther() || pUser->m_vtInfo.VendorIsVendor())
		{
			pUser->AddSmeltSafety(0);
			return;
		}

		CItemElem* pItemElem0 = pUser->m_Inventory.GetAtId(dwItemId);
		CItemElem* pItemElem1 = pUser->m_Inventory.GetAtId(dwItemMaterialId);
		CItemElem* pItemElem2 = pUser->m_Inventory.GetAtId(dwItemProtScrId);
		CItemElem* pItemElem3 = NULL;
		if (dwItemSmeltScrId != NULL_ID)
		{
			pItemElem3 = pUser->m_Inventory.GetAtId(dwItemSmeltScrId);
			if (!IsUsableItem(pItemElem3))
				return;
		}

		if (IsUsableItem(pItemElem0) == FALSE || IsUsableItem(pItemElem1) == FALSE || IsUsableItem(pItemElem2) == FALSE)
		{
			pUser->AddSmeltSafety(0);
			return;
		}


		if (pUser->m_Inventory.IsEquip(dwItemId))
		{
			pUser->AddSmeltSafety(0);
			return;
		}

#ifdef __AIO_PETS
		if (pItemElem0->IsEatPet())
		{
			pUser->AddSmeltSafety(0);
			return;
		}
#endif

		BYTE nResult = CItemUpgrade::GetInstance()->OnSmeltSafety(pUser, pItemElem0, pItemElem1, pItemElem2, pItemElem3);

		pUser->AddSmeltSafety(nResult);
	}
}

void CDPSrvr::OnEnchant(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwItemId, dwItemMaterialId;

	ar >> dwItemId;
	ar >> dwItemMaterialId;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_vtInfo.GetOther())
			return;
		if (pUser->m_vtInfo.VendorIsVendor())
			return;

		CItemElem* pItemElem0 = pUser->m_Inventory.GetAtId(dwItemId);
		CItemElem* pItemElem1 = pUser->m_Inventory.GetAtId(dwItemMaterialId);

		if (IsUsableItem(pItemElem0) == FALSE || IsUsableItem(pItemElem1) == FALSE)
			return;

		CItemUpgrade::GetInstance()->OnEnchant(pUser, pItemElem0, pItemElem1);
	}
}

#if __VER >= 10 // __REMOVE_ATTRIBUTE
void CDPSrvr::OnRemoveAttribute(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nPayPenya = 100000;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	OBJID objItemId;
	ar >> objItemId;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(objItemId);
	if (IsUsableItem(pItemElem) == FALSE)
	{
		pUser->AddRemoveAttribute(FALSE);
		return;
	}

	ItemProp* pProp = pItemElem->GetProp();
	if (!pProp)
		return;

	if (!pProp->IsEleRefineryAble())
	{
		pUser->AddRemoveAttribute(FALSE);
		pUser->AddDefinedText(TID_GAME_NOTEQUALITEM, "");
		return;
	}

	if (pUser->m_Inventory.IsEquip(objItemId))
	{
		pUser->AddRemoveAttribute(FALSE);
		pUser->AddDefinedText(TID_GAME_EQUIPPUT, "");
		return;
	}

	if (pUser->CheckUserGold(nPayPenya, false) == false)
	{
		pUser->AddRemoveAttribute(FALSE);
		pUser->AddDefinedText(TID_GAME_LACKMONEY, "");
		return;
	}


	if ((pItemElem->m_bItemResist != SAI79::NO_PROP) && (pItemElem->m_nResistAbilityOption > 0))
	{
		pUser->AddGold(-nPayPenya);
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if ((pUser->IsMode(TRANSPARENT_MODE)) == 0)
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);

		pUser->UpdateItem((BYTE)pItemElem->m_dwObjId, UI_IR, SAI79::NO_PROP);
		pUser->UpdateItem((BYTE)pItemElem->m_dwObjId, UI_RAO, 0);
		pUser->AddRemoveAttribute(TRUE);

		LogItemInfo aLogItem;
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = "REMOVE_ATTRIBUTE";
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = pUser->GetGold() + nPayPenya;
		aLogItem.Gold2 = pUser->GetGold();
		aLogItem.Gold_1 = -nPayPenya;
		aLogItem.Action = "O";
		OnLogItem(aLogItem, pItemElem, 1);
	}
	else
		pUser->AddRemoveAttribute(FALSE);

}
#endif // __REMOVE_ATTRIBUTE


void CDPSrvr::OnRandomScroll(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize)
{
	DWORD dwId1, dwId2;

	ar >> dwId1;
	ar >> dwId2;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CItemElem* pItemElem0 = pUser->m_Inventory.GetAtId(dwId1);
		CItemElem* pItemElem1 = pUser->m_Inventory.GetAtId(dwId2);
		if (IsUsableItem(pItemElem0) == FALSE || IsUsableItem(pItemElem1) == FALSE)
		{
			return;
		}

		if (pUser->m_Inventory.IsEquip(dwId1))
		{
			pUser->AddDefinedText(TID_GAME_EQUIPPUT, "");
			return;
		}

		if (pItemElem1->GetProp()->dwItemKind3 != IK3_RANDOM_SCROLL)
		{
			return;
		}

		if (!(pItemElem0->GetProp()->dwItemKind1 == IK1_WEAPON || pItemElem0->GetProp()->dwItemKind2 == IK2_ARMOR || pItemElem0->GetProp()->dwItemKind2 == IK2_ARMORETC))
		{
			pUser->AddDefinedText(TID_GAME_RANDOMSCROLL_ERROR, "");
			return;
		}

		int nSTR[4] = { 1,  9, 21, 37 };
		int nDEX[4] = { 2, 10, 22, 38 };
		int nINT[4] = { 3, 11, 23, 39 };
		int nSTA[4] = { 4, 12, 24, 40 };

		int nValue = 0;
		int nRandom = xRandom(100);
		if (nRandom < 64)
			nValue = 1;
		else if (nRandom < 94)
			nValue = 2;
		else if (nRandom < 99)
			nValue = 3;
		else if (nRandom < 100)
			nValue = 4;

		if (0 < nValue)
		{
			int nKind = 0;
			int nToolKind = 0;
			if (pItemElem1->GetProp()->dwID == II_SYS_SYS_SCR_RANDOMSTR)
			{
				nKind = nSTR[nValue - 1];
				nToolKind = DST_STR;
			}
			else if (pItemElem1->GetProp()->dwID == II_SYS_SYS_SCR_RANDOMDEX)
			{
				nKind = nDEX[nValue - 1];
				nToolKind = DST_DEX;
			}
			else if (pItemElem1->GetProp()->dwID == II_SYS_SYS_SCR_RANDOMINT)
			{
				nKind = nINT[nValue - 1];
				nToolKind = DST_INT;
			}
			else if (pItemElem1->GetProp()->dwID == II_SYS_SYS_SCR_RANDOMSTA)
			{
				nKind = nSTA[nValue - 1];
				nToolKind = DST_STA;
			}

			pUser->UpdateItem((BYTE)pItemElem0->m_dwObjId, UI_RANDOMOPTITEMID, nKind);

			LogItemInfo aLogItem;
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "RANDOMSCROLL";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			aLogItem.Action = "(";
			OnLogItem(aLogItem, pItemElem0, pItemElem0->m_nItemNum);
			aLogItem.Action = ")";
			OnLogItem(aLogItem, pItemElem1, pItemElem1->m_nItemNum);

			pUser->RemoveItem((BYTE)(dwId2), (short)1);


			pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);

			DWORD dwStringNum = 0;
			switch (nToolKind)
			{
			case DST_STR:
				dwStringNum = TID_TOOLTIP_STR;
				break;
			case DST_DEX:
				dwStringNum = TID_TOOLTIP_DEX;
				break;
			case DST_STA:
				dwStringNum = TID_TOOLTIP_STA;
				break;
			default: //case DST_INT:
				dwStringNum = TID_TOOLTIP_INT;
				break;
			}
			CString strMessage;
			strMessage.Format(prj.GetText(TID_GAME_RANDOMSCROLL_SUCCESS), pItemElem0->GetProp()->szName, prj.GetText(dwStringNum), nValue);
			pUser->AddText(strMessage);
		}
	}
}

void CDPSrvr::OnEnterChattingRoom(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long uidChattingRoom;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		BOOL bChatting = FALSE;
		if (pUser->m_idChatting == 0)
		{
			ar >> uidChattingRoom;

			CChatting* pChatting = g_ChattingMng.GetChttingRoom(uidChattingRoom);
			if (pChatting)
			{
				if (pChatting->AddChattingMember(pUser->m_idPlayer))
				{
					CUser* pUsertmp;
					pUser->m_idChatting = uidChattingRoom;

					for (int i = 0; i < pChatting->GetChattingMember() - 1; ++i)
					{
						pUsertmp = (CUser*)prj.GetUserByID(pChatting->m_idMember[i]);
						if (IsValidObj(pUsertmp))
							pUsertmp->AddEnterChatting(pUser);
					}

					pUser->AddNewChatting(pChatting);
				}
				else
				{
					bChatting = TRUE;
				}
			}

		}
		else
		{
			bChatting = TRUE;
		}
	}
}

void CDPSrvr::OnChatting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	static	TCHAR	sChat[1024];
	ar.ReadString(sChat, 1024);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __JEFF_9_20
#if __VER >= 12 // __LORD
		int nText = pUser->GetMuteText();
		if (nText)
		{
			pUser->AddDefinedText(nText);
			return;
		}
#else	// __LORD
		if (pUser->IsMute())
			return;
#endif	// __LORD
#endif	// __JEFF_9_20

		if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
			ParsingEffect(sChat, strlen(sChat));

		RemoveCRLF(sChat);

		CChatting* pChatting = g_ChattingMng.GetChttingRoom(pUser->m_idChatting);
		if (pChatting)
		{
			int nFind = pChatting->FindChattingMember(pUser->m_idPlayer);
			if (nFind != -1)
			{
				CUser* pUsertmp;
				for (int i = 0; i < pChatting->GetChattingMember(); ++i)
				{
					pUsertmp = (CUser*)prj.GetUserByID(pChatting->m_idMember[i]);
					if (IsValidObj(pUsertmp))
						pUsertmp->AddChatting(pUser->m_idPlayer, sChat);
				}
			}
			else
			{

				pUser->m_idChatting = 0;
				pUser->AddDeleteChatting();
			}
		}
		else
		{

			pUser->m_idChatting = 0;
			pUser->AddDeleteChatting();
		}

	}
}


void CDPSrvr::OnOpenChattingRoom(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{

		CChatting* pChatting = g_ChattingMng.GetChttingRoom(pUser->m_idChatting);
		if (pChatting)
		{
			pChatting->m_bState = TRUE;
			CUser* pUsertmp;
			for (int i = 0; i < pChatting->GetChattingMember(); ++i)
			{
				pUsertmp = (CUser*)prj.GetUserByID(pChatting->m_idMember[i]);
				if (IsValidObj(pUsertmp) && pUser->m_idPlayer != pUsertmp->m_idPlayer)
					pUsertmp->AddChttingRoomState(pChatting->m_bState);
			}
		}
	}
}

void CDPSrvr::OnCloseChattingRoom(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{

		CChatting* pChatting = g_ChattingMng.GetChttingRoom(pUser->m_idChatting);
		if (pChatting)
		{
			pChatting->m_bState = FALSE;
			CUser* pUsertmp;

			for (int i = 0; i < pChatting->GetChattingMember(); ++i)
			{
				pUsertmp = (CUser*)prj.GetUserByID(pChatting->m_idMember[i]);
				if (IsValidObj(pUsertmp) && pUser->m_idPlayer != pUsertmp->m_idPlayer)
				{
					pUsertmp->AddChttingRoomState(pChatting->m_bState);
				}
			}
		}

	}
}


void CDPSrvr::QueryDestroyPlayer(DPID dpidCache, DPID dpidSocket, DWORD dwSerial, u_long idPlayer)
{
#ifdef __ZCK_IA_FARM
	// Un fantome n'a plus de liaison Cache (dpidCache = DPID_UNKNOWN) : la
	// demande n'aurait aucun destinataire. Sa fin est programmee a la place
	// (KickAllPlayers, CDPCoreClient::OnDestroyPlayer, controle d'autorisation).
	if (g_ZckIaFarmServeur.DemanderFinSerial(dwSerial, ZCK_IA_FARM_FIN_SERVEUR))
		return;
#endif // __ZCK_IA_FARM
	BEFORESENDSOLE(ar, PACKETTYPE_QUERY_DESTROY_PLAYER, dpidSocket);
	ar << dwSerial;
	ar << idPlayer;
	SEND(ar, this, dpidCache);
}

void CDPSrvr::OnSetNaviPoint(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	NaviPoint nv;
	OBJID objidTarget;
	ar >> nv.Pos >> objidTarget;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (objidTarget == NULL_ID)
		{
			CParty* pParty = g_PartyMng.GetParty(pUser->m_idparty);
			if (pParty)
			{
				for (int i = 0; i < pParty->GetSizeofMember(); ++i)
				{
					CUser* pUsertmp = (CUser*)prj.GetUserByID(pParty->GetPlayerId(i));
					if (IsValidObj(pUsertmp))
					{
						pUsertmp->AddSetNaviPoint(nv, pUser->GetId(), pUser->GetName(TRUE));
					}
				}
			}
		}
		else
		{
			CUser* pUsertmp = prj.GetUser(objidTarget);
			if (IsValidObj(pUsertmp))
			{
				pUser->AddSetNaviPoint(nv, pUser->GetId(), pUser->GetName(TRUE));
				pUsertmp->AddSetNaviPoint(nv, pUser->GetId(), pUser->GetName(TRUE));
			}
		}
	}
}


void CDPSrvr::OnStateMode(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwStateMode;
	BYTE nFlag;
	ar >> dwStateMode;
	ar >> nFlag;


	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->IsStateMode(dwStateMode))
		{
			if (nFlag == STATEMODE_BASEMOTION_CANCEL)
			{
				pUser->SetStateNotMode(STATE_BASEMOTION_MODE, STATEMODE_BASEMOTION_CANCEL);
				pUser->m_nReadyTime = 0;
				pUser->m_dwUseItemId = 0;
			}
		}
	}
}

void CDPSrvr::OnChangeMode(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nFlag;
	DWORD dwMode;
	ar >> dwMode;
	ar >> nFlag;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		switch (nFlag)
		{
		case 0:
			pUser->SetMode(FREEPK_MODE);
			break;
		case 1:
			pUser->SetNotMode(FREEPK_MODE);
			break;
		case 2:
			pUser->SetMode(PVPCONFIRM_MODE);
			break;
		case 3:
			pUser->SetNotMode(PVPCONFIRM_MODE);
			break;
		}
		g_UserMng.AddModifyMode(pUser);
	}
}

void CDPSrvr::OnQuerySetPlayerName(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwData;
	char lpszPlayer[MAX_PLAYER] = { 0, };

	ar >> dwData;
	ar.ReadString(lpszPlayer, MAX_PLAYER);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_GUILDWAR)
		{
			pUser->AddDiagText(prj.GetText(TID_GAME_GUILDCOMBAT_NOT_USE));
			return;
		}

		if (prj.IsInvalidName(lpszPlayer) || IsInvalidGameName(lpszPlayer))
		{
			pUser->AddDiagText(prj.GetText(TID_DIAG_0020));
			return;
		}

		prj.Formalize(lpszPlayer);

#ifdef __S_SERVER_UNIFY
		if (pUser->m_bAllAction)
#endif
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwData);
			if (IsUsableItem(pItemElem) && pItemElem->m_dwItemId == II_SYS_SYS_SCR_CHANAM && pItemElem->m_bQuery == FALSE)
			{
				pItemElem->m_bQuery = TRUE;
				g_dpDBClient.SendQuerySetPlayerName(pUser->m_idPlayer, lpszPlayer, dwData);
				pUser->RemoveItem((BYTE)dwData, 1);
			}
		}
#ifdef __S_SERVER_UNIFY
		else
			g_dpDBClient.SendQuerySetPlayerName(pUser->m_idPlayer, lpszPlayer, dwData);
#endif // __S_SERVER_UNIFY
	}
}

void CDPSrvr::OnQuerySetGuildName(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nId;
	char lpszGuild[MAX_G_NAME] = { 0, };

	ar >> nId;
	ar.ReadString(lpszGuild, MAX_G_NAME);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (!IsInviteAbleGuild(pUser->m_idGuild, pUser))
			return;

		//__FIX_SQL_INJECTS
		if (prj.IsInvalidName(lpszGuild) || IsInvalidGameName(lpszGuild))
		{
			pUser->AddDiagText(prj.GetText(TID_DIAG_0020));
			return;
		}

#ifdef __S_SERVER_UNIFY
		if (pUser->m_bAllAction)
#endif
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtId(nId);
			if (IsUsableItem(pItemElem) && pItemElem->m_bQuery == FALSE && pItemElem->m_dwItemId == II_SYS_SYS_SCR_GCHANAM)
			{
				pItemElem->m_bQuery = TRUE;
				g_DPCoreClient.SendQuerySetGuildName(pUser->m_idPlayer, pUser->m_idGuild, lpszGuild, nId);
				pUser->RemoveItem(nId, 1);
			}
		}
#ifdef __S_SERVER_UNIFY
		else
			g_DPCoreClient.SendQuerySetGuildName(pUser->m_idPlayer, pUser->m_idGuild, lpszGuild, nId);
#endif
	}
}

#ifndef __FL_FIX_USELESS_LOGS
void CDPSrvr::PutCreateItemLog(CUser* pUser, CItemElem* pItemElem, const char* szAction, const char* recv)
{
	LogItemInfo logitem;
	logitem.Action = szAction;
	logitem.SendName = pUser->GetName();
	logitem.RecvName = recv;
	logitem.WorldId = pUser->GetWorld()->GetID();
	logitem.Gold = pUser->GetGold();
	logitem.Gold2 = 0;
	logitem.ItemNo = pItemElem->GetSerialNumber();
	//logitem.ItemName = pItemElem->GetProp()->szName;
	_stprintf(logitem.szItemName, "%d", pItemElem->GetProp()->dwID);
	logitem.itemNumber = pItemElem->m_nItemNum;
	logitem.nAbilityOption = 0;
	logitem.Gold_1 = 0;
	logitem.nItemResist = pItemElem->m_bItemResist;
	logitem.nResistAbilityOption = pItemElem->m_nResistAbilityOption;
	logitem.Negudo = 100;
	OnLogItem(logitem);
}
#endif

void CDPSrvr::OnDoEscape(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		ItemProp* pItemProp = prj.GetItemProp(II_CHR_SYS_SCR_ESCAPEBLINKWING);
		if (pItemProp)
		{
			if (!pUser->IsSMMode(SM_ESCAPE))
				pUser->DoUseItemVirtual(II_CHR_SYS_SCR_ESCAPEBLINKWING, FALSE);
			else
				pUser->AddDefinedText(TID_GAME_STILLNOTUSE);
		}
	}
}

void CDPSrvr::OnCheering(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objid;
	ar >> objid;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->GetId() == objid)
			return;

		CMover* pTarget = prj.GetMover(objid);
		if (IsValidObj(pTarget) && pTarget->GetType() == OT_MOVER && pTarget->IsPlayer())
		{
#ifndef __FL_STACKABLE_POWERUPS
			if (pTarget->HasBuff(BUFF_ITEM, II_CHEERUP))
			{
				pUser->AddText("This player already have cheer-effect. Please wait for the effect to finish.");
				return;
			}
#else
			ItemProp* pItemProp = prj.GetItemProp(II_CHEERUP);
			if (!pItemProp)
				return;

			DWORD dwCurr = g_tmCurrent;
			IBuff* pBuff = pTarget->m_buffs.GetBuff(BUFF_ITEM, (WORD)(pItemProp->dwID));
			if (pBuff && static_cast<int>(pItemProp->dwSkillTime) > static_cast<int>(pItemProp->dwSkillTime + (pBuff->GetTotal() - (dwCurr - pBuff->GetInst()))))
				return;
#endif

			DWORD dwTickCount = g_tmCurrent;
			if (pUser->m_nCheerPoint <= 0)
			{
				pUser->AddDefinedText(TID_CHEER_NO1, "%d", (pUser->m_dwTickCheer - dwTickCount) / 60000);
				return;
			}

			if (pUser->m_nCheerPoint == MAX_CHEERPOINT)
				pUser->SetCheerParam(pUser->m_nCheerPoint - 1, dwTickCount, TICK_CHEERPOINT);
			else
				pUser->SetCheerParam(pUser->m_nCheerPoint - 1, dwTickCount, pUser->m_dwTickCheer - dwTickCount);

			FLOAT fAngle = GetDegree(pTarget->GetPos(), pUser->GetPos());
			pUser->SetAngle(fAngle);

			if (pTarget->GetSex() == pUser->GetSex())
			{
				((CUser*)pTarget)->AddDefinedText(TID_CHEER_MESSAGE3, "%s", pUser->GetName());
				pUser->SendActMsg(OBJMSG_MOTION, MTI_CHEERSAME, ANILOOP_1PLAY);
			}
			else
			{
				((CUser*)pTarget)->AddDefinedText(TID_CHEER_MESSAGE4, "%s", pUser->GetName());
				pUser->SendActMsg(OBJMSG_MOTION, MTI_CHEEROTHER, ANILOOP_1PLAY);
			}

			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_CHEERSENDEFFECT);
			g_UserMng.AddCreateSfxObj(pTarget, XI_CHEERRECEIVEEFFECT);

			CMover* pSrc = (CMover*)pUser;
			g_UserMng.AddMoverBehavior(pSrc, TRUE);

#ifdef __FL_RECORD_BOOK
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::CHEERS_GIVEN, 1, true);
			CRecordBook::GetInstance()->AddPlayerRecord(pTarget, RecordType::CHEERS_RECEIVED, 1, true);
#endif

#ifndef __FL_STACKABLE_POWERUPS
			ItemProp* pItemProp = prj.GetItemProp(II_CHEERUP);
			if (pItemProp)
				pTarget->DoApplySkill(pTarget, pItemProp, NULL);
#else
			pTarget->DoApplySkill(pTarget, pItemProp, NULL);
#endif
		}
		else
		{
			pUser->AddDefinedText(TID_CHEER_NO2, "");
		}
	}
}

void CDPSrvr::OnQueryEquip(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objid;
	ar >> objid;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CUser* pUsertmp = prj.GetUser(objid);
		if (IsValidObj(pUsertmp))
		{

#ifdef __ZCK_4_CLASSES
			if (pUsertmp->IsMode(EQUIP_DENIAL_MODE) && pUser->IsAuthHigher(AUTH_GAMEMASTER) == FALSE)
			{
				if (pUser->HasBuff(BUFF_SKILL, SI_WINDL_U_SKILL_02) == FALSE)
				{
					pUser->AddDefinedText(TID_DIAG_0088);
					return;
				}
				if (pUsertmp->IsAuthHigher(AUTH_GAMEMASTER))
				{
					CString str;
					str.Format(prj.GetText(TID_4TH_JOB_ER_02), __NEUZ_TITLE);
					pUser->AddText(str, 0xFFFFFFFF);
					return;
				}
				pUser->RemoveBuff(BUFF_SKILL, SI_WINDL_U_SKILL_02);
			}
#else
			if (pUsertmp->IsMode(EQUIP_DENIAL_MODE) && pUser->IsAuthHigher(AUTH_GAMEMASTER) == FALSE)
			{
				pUser->AddDefinedText(TID_DIAG_0088);
				return;
			}
#endif // __ZCK_4_CLASSES
			pUser->AddQueryEquip(pUsertmp);
		}
	}
}

void CDPSrvr::OnQueryEquipSetting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BOOL bAllow;
	ar >> bAllow;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (bAllow)
			pUser->SetNotMode(EQUIP_DENIAL_MODE);
		else
			pUser->SetMode(EQUIP_DENIAL_MODE);
		g_UserMng.AddModifyMode(pUser);
	}
}

void CDPSrvr::OnReturnScroll(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nSelect;
	ar >> nSelect;
	if (nSelect < -1 || nSelect > 2)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	if (nSelect >= 0)
	{
		static char* szPos[] = { "flaris",	"saintmorning",	"darkon" };
		pUser->m_lpszVillage = szPos[nSelect];
		pUser->AddReturnScroll();
	}
	else
	{

		if (pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_RETURN))
			pUser->DoUseItemVirtual(II_SYS_SYS_SCR_RETURN, TRUE);
	}
}

void CDPSrvr::OnEndSkillQueue(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		pUser->m_playTaskBar.OnEndSkillQueue(pUser);
}

void CDPSrvr::OnQueryPostMail(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	char lpszReceiver[MAX_PLAYER] = { 0, };
	char lpszTitle[MAX_MAILTITLE] = { 0, };
	char lpszText[MAX_MAILTEXT] = { 0, };
	BYTE nItem;
	short nItemNum;
	int nGold;

	ar >> nItem >> nItemNum;
	ar.ReadString(lpszReceiver, MAX_PLAYER);

	ar >> nGold;
	ar.ReadString(lpszTitle, MAX_MAILTITLE);
	ar.ReadString(lpszText, MAX_MAILTEXT);

	const int nCommissionGold = 100;
	const int nTotGold = nCommissionGold + nGold;
	if (nGold < 0 || nTotGold <= 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
		if (ZckRefusStaff(pUser, "envoi de courrier"))
			return;
#else
#line 4915 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
		if (pUser->m_vtInfo.GetOther())
			return;
		if (pUser->m_vtInfo.VendorIsVendor())
			return;
		if (pUser->m_bBank)
			return;
#ifdef __S_SERVER_UNIFY
		if (pUser->m_bAllAction == FALSE)
			return;
#endif // __S_SERVER_UNIFY
#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif

		u_long idReceiver = CPlayerDataCenter::GetInstance()->GetPlayerId(lpszReceiver);
		if (idReceiver > 0)
		{
			if (CPlayerDataCenter::GetInstance()->GetPlayerId((char*)pUser->GetName()) == idReceiver)
			{
				pUser->AddDiagText(prj.GetText(TID_GAME_MSGSELFSENDERROR));
				return;
			}

			CMailBox* pMailBox = CPost::GetInstance()->GetMailBox(idReceiver);
			if (pMailBox && pMailBox->size() >= MAX_MAIL)
			{
				pUser->AddDefinedText(TID_GAME_MAILBOX_FULL, "%s", lpszReceiver);
				return;
			}

			CItemElem* pItemElem = pUser->m_Inventory.GetAtId(nItem);
			if (pItemElem)
			{
				if (IsUsableItem(pItemElem) == FALSE)
				{
					pUser->AddDiagText(prj.GetText(TID_GAME_CANNOT_POST));
					return;
				}
				if (pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
				{
					pUser->AddDiagText(prj.GetText(TID_GAME_CANNOT_POST));
					return;
				}
				if (pItemElem->IsQuest())
				{
					pUser->AddDiagText(prj.GetText(TID_GAME_CANNOT_POST));
					return;
				}
				if (pItemElem->IsBinds())
				{
					pUser->AddDiagText(prj.GetText(TID_GAME_CANNOT_POST));
					return;
				}
				if (pUser->IsUsing(pItemElem))
				{
					pUser->AddDiagText(prj.GetText(TID_GAME_CANNOT_DO_USINGITEM));
					return;
				}
				ItemProp* pProp = pItemElem->GetProp();

				if (nItemNum > pItemElem->m_nItemNum)
					nItemNum = pItemElem->m_nItemNum;
				if (nItemNum < 1)
					nItemNum = 1;
			}

			if (pUser->CheckUserGold(nTotGold, false) == false)
			{
				pUser->AddDiagText(prj.GetText(TID_GAME_LACKMONEY));
				return;
			}

			pUser->AddGold(-nTotGold, TRUE);

			CItemElem	itemElem;
			if (pItemElem)
			{
				itemElem = *pItemElem;
				itemElem.m_nItemNum = nItemNum;
				pUser->RemoveItem((BYTE)pItemElem->m_dwObjId, nItemNum);
			}

			CWorld* pWorld = pUser->GetWorld();
			if (pWorld)
				g_dpDBClient.SavePlayer(pUser, pWorld->GetID(), pUser->GetPos(), pUser->GetLayer());

			g_dpDBClient.SendQueryPostMail(idReceiver, pUser->m_idPlayer, itemElem, nGold, lpszTitle, lpszText);
		}
		else
			pUser->AddDiagText(prj.GetText(TID_MAIL_UNKNOW));
	}

}

void CDPSrvr::OnQueryRemoveMail(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long nMail;
	ar >> nMail;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif
		CMailBox* pMailBox = CPost::GetInstance()->GetMailBox(pUser->m_idPlayer);
		if (pMailBox != NULL)
		{
			CMail* pMail = pMailBox->GetMail(nMail);
			if (pMail != NULL)
			{
				g_dpDBClient.SendQueryRemoveMail(pUser->m_idPlayer, nMail);
			}
		}
	}
}

void CDPSrvr::OnQueryGetMailItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long nMail;
	ar >> nMail;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_Inventory.GetEmptyCount() < 1)
		{
			pUser->AddDiagText(prj.GetText(TID_GAME_LACKSPACE));
			return;
		}

#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif

		CMailBox* pMailBox = CPost::GetInstance()->GetMailBox(pUser->m_idPlayer);
		if (pMailBox)
		{
			CMail* pMail = pMailBox->GetMail(nMail);
			if (pMail && pMail->m_pItemElem)
			{
				int nDay = 0;
				DWORD dwTime = 0;
				pMail->GetMailInfo(&nDay, &dwTime);

				if ((MAX_KEEP_MAX_DAY * 24) - dwTime > (MAX_KEEP_BASIC_DAY * 24))
				{
					FLOAT fCustody = 0.0f;
					FLOAT fPay = 0.0f;
					fCustody = (FLOAT)((FLOAT)(MAX_KEEP_MAX_DAY - MAX_KEEP_BASIC_DAY - nDay) / (FLOAT)(MAX_KEEP_MAX_DAY - MAX_KEEP_BASIC_DAY));
					fPay = pMail->m_pItemElem->GetPenyaCost() * fCustody;
					if (fPay < 0.0f)
						fPay = 0.0f;

					const int pay = (int)fPay;
					if (pay < 0 || pUser->CheckUserGold(pay, false) == false)
					{
						pUser->AddDiagText(prj.GetText(TID_GAME_LACKMONEY));
						return;
					}
					pUser->AddGold(-pay);
				}
			}
		}
		g_dpDBClient.SendQueryGetMailItem(pUser->m_idPlayer, nMail);
	}
}

void CDPSrvr::OnQueryGetMailGold(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long nMail;
	ar >> nMail;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CMailBox* pMailBox = CPost::GetInstance()->GetMailBox(pUser->m_idPlayer);
		if (pMailBox != NULL)
		{
			CMail* pMail = pMailBox->GetMail(nMail);
			if (pMail != NULL)
			{
				if (pMail->m_nGold <= INT_MAX && pMail->m_nGold > 0 && pUser->CheckUserGold(pMail->m_nGold, true) == true)
					g_dpDBClient.SendQueryGetMailGold(pUser->m_idPlayer, nMail);
				else
					return;
			}
		}
	}
}

void CDPSrvr::OnQueryReadMail(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long nMail;
	ar >> nMail;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CMailBox* pMailBox = CPost::GetInstance()->GetMailBox(pUser->m_idPlayer);
		if (pMailBox != NULL)
		{
			CMail* pMail = pMailBox->GetMail(nMail);
			if (pMail != NULL)
			{
				g_dpDBClient.SendQueryReadMail(pUser->m_idPlayer, nMail);
			}
		}
	}
}

void CDPSrvr::OnQueryMailBox(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	int	nClientReqCount = 1;

	if (IsValidObj(pUser))
	{
		if (pUser->CheckClientReq() == false)
		{
			nClientReqCount = 1;
		}
		else
		{
			nClientReqCount = pUser->GetCountClientReq();
		}

		CMailBox* pMailBox = CPost::GetInstance()->GetMailBox(pUser->m_idPlayer);
		if (pMailBox)
		{
			switch (pMailBox->m_nStatus)
			{
			case CMailBox::data:
			{
				if (nClientReqCount <= 1)
				{
					pUser->AddMailBox(pMailBox);
				}
				else
				{
					g_dpDBClient.SendQueryMailBoxCount(pUser->m_idPlayer, pUser->GetCountClientReq());
				}
			}
			break;
			case CMailBox::nodata:
			{
				if (nClientReqCount >= 2)
				{
					g_dpDBClient.SendQueryMailBoxCount(pUser->m_idPlayer, pUser->GetCountClientReq());
				}
				else
				{
					g_dpDBClient.SendQueryMailBox(pUser->m_idPlayer);
				}

				pMailBox->m_nStatus = CMailBox::read;
			}
			break;
			case CMailBox::read:
			{
				if (nClientReqCount >= 2)
				{
					g_dpDBClient.SendQueryMailBoxCount(pUser->m_idPlayer, pUser->GetCountClientReq());
				}
			}
			break;
			default:
			{
			}
			break;
			}
		}
		else
		{
			if (pUser->GetCheckTransMailBox() == FALSE)
			{
				g_dpDBClient.SendQueryMailBoxReq(pUser->m_idPlayer);
			}
			else
			{
				pUser->SendCheckMailBoxReq(FALSE);
			}
		}
	}
}

void CDPSrvr::OnGCApp(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (g_eLocal.GetState(EVE_GUILDCOMBAT) == 0)
		return;

	BYTE nState;
	ar >> nState;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CGuild* pGuild = pUser->GetGuild();
		if (pGuild == NULL || pGuild->IsMaster(pUser->m_idPlayer) == FALSE)
		{
			pUser->AddDiagText(prj.GetText(TID_GAME_GUILDCOMBAT_NOT_GUILD_LEADER));
			return;
		}

		if (nState == GC_IN_WINDOW)
		{
			CGuild* pGuild = g_GuildMng.GetGuild(pUser->m_idGuild);
			if (pGuild && pGuild->IsMaster(pUser->m_idPlayer))
			{
				if (strlen(pGuild->m_szGuild) < 3)
				{
					pUser->AddDiagText(prj.GetText(TID_DIAG_0020));
					return;
				}
				pUser->AddGCWindow(g_GuildCombatMng.GetPrizePenya(2), g_GuildCombatMng.GetRequstPenya(pUser->m_idGuild), g_GuildCombatMng.m_nJoinPanya);
			}
		}
		else if (nState == GC_IN_APP)
		{
			DWORD dwPenya;
			ar >> dwPenya;
			g_GuildCombatMng.GuildCombatRequest(pUser, dwPenya);
		}
	}
}
void CDPSrvr::OnGCCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (g_eLocal.GetState(EVE_GUILDCOMBAT) == 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		g_GuildCombatMng.GuildCombatCancel(pUser);
}
void CDPSrvr::OnGCRequestStatus(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (g_eLocal.GetState(EVE_GUILDCOMBAT) == 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		pUser->AddGCRequestStatus(g_GuildCombatMng.GetPrizePenya(2), g_GuildCombatMng.vecRequestRanking);
}
void CDPSrvr::OnGCSelectMap(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nMap;
	ar >> nMap;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		g_GuildCombatMng.SetSelectMap(pUser, nMap);
}
void CDPSrvr::OnGCSelectPlayer(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (g_eLocal.GetState(EVE_GUILDCOMBAT) == 0)
		return;

	BOOL bWindow;
	ar >> bWindow;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{

		if (g_GuildCombatMng.m_nGCState != CGuildCombat::NOTENTER_COUNT_STATE)
		{
			pUser->AddText(prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_MAKEUP));
			return;
		}


		if (g_GuildCombatMng.IsRequestWarGuild(pUser->m_idGuild, FALSE) == FALSE)
		{
			pUser->AddText(prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_MAKEUP_FAIL));
			return;
		}

		CGuild* pGuild = g_GuildMng.GetGuild(pUser->m_idGuild);

		BOOL bMK = FALSE;
		if (pGuild)
		{
			CGuildMember* pGuildMember = pGuild->GetMember(pUser->m_idPlayer);
			if (pGuildMember)
			{
				if (pGuildMember->m_nMemberLv == GUD_KINGPIN || pGuildMember->m_nMemberLv == GUD_MASTER)
					bMK = TRUE;
			}
		}


		if (pGuild && bMK)
		{
			if (bWindow == FALSE)
			{

				int nSize;
				u_long uidPlayer, uidDefender;
				vector< u_long > vecSelectPlayer;
				BOOL bMasterOrKinpin = FALSE;
				BOOL bDefender = FALSE;
				BOOL bLevel = FALSE;
				BOOL bLogOut = FALSE;
				BOOL bGuildMember = FALSE;
				BOOL bMastertoDefender = FALSE;
				vecSelectPlayer.clear();
				ar >> uidDefender;
				ar >> nSize;
				if (nSize > g_GuildCombatMng.m_nMaxJoinMember)
					return;

				for (int i = 0; i < nSize; ++i)
				{
					ar >> uidPlayer;
					vecSelectPlayer.push_back(uidPlayer);
					CUser* pUsertmp = g_UserMng.GetUserByPlayerID(uidPlayer);
					if (IsValidObj(pUsertmp))
					{
						CGuildMember* pGuildMember = pGuild->GetMember(uidPlayer);

						if (pGuildMember)
						{

							if (pGuild->IsMaster(pUsertmp->m_idPlayer))
								bMasterOrKinpin = TRUE;

							if (pGuildMember->m_nMemberLv == GUD_KINGPIN)
								bMasterOrKinpin = TRUE;

							if (pUsertmp->m_idPlayer == uidDefender)
								bDefender = TRUE;
						}
					}
				}

				if (1 < nSize && pGuild->IsMaster(uidDefender))
					bMastertoDefender = TRUE;

				if (bMasterOrKinpin && bMastertoDefender == FALSE
#ifndef _DEBUG
					&& bDefender
#endif // _DEBUG
					)
				{
					g_GuildCombatMng.SelectPlayerClear(pUser->m_idGuild);
					for (int veci = 0; veci < (int)(vecSelectPlayer.size()); ++veci)
					{

						if (veci >= g_GuildCombatMng.m_nMaxJoinMember)
							break;

						u_long uidSelectPlayer = vecSelectPlayer[veci];
						CUser* pUsertmp = g_UserMng.GetUserByPlayerID(uidSelectPlayer);
						{
							if (IsValidObj(pUsertmp))
							{
								CGuildMember* pGuildMember = pGuild->GetMember(uidPlayer);

								if (pGuildMember)
								{

									if (30 <= pUsertmp->GetLevel())
									{
										g_GuildCombatMng.AddSelectPlayer(pUser->m_idGuild, uidSelectPlayer);
									}
								}
							}
						}
					}
					g_GuildCombatMng.SetDefender(pUser->m_idGuild, uidDefender);
				}
			}

			vector<CGuildCombat::__JOINPLAYER> vecSelectList;
			g_GuildCombatMng.GetSelectPlayer(pUser->m_idGuild, vecSelectList);
			pUser->AddGCSelectPlayerWindow(vecSelectList, g_GuildCombatMng.GetDefender(pUser->m_idGuild), bWindow, g_GuildCombatMng.IsRequestWarGuild(pUser->m_idGuild, FALSE));
			if (bWindow == FALSE)
			{
				g_UserMng.AddGCGuildStatus(pUser->m_idGuild);
				g_UserMng.AddGCWarPlayerlist(pUser->m_idGuild);
			}
		}
	}
}
void CDPSrvr::OnGCJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (g_eLocal.GetState(EVE_GUILDCOMBAT) == 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_GUILDWAR_JOIN, pUser->GetWorld(), pUser->GetPos()))
			return;
		g_GuildCombatMng.GuildCombatEnter(pUser);
	}
}
void CDPSrvr::OnGCTele(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	DWORD dwState = pUser->GetSummonState(FALSE);
	if (dwState != 0)
	{
		pUser->AddDefinedText(dwState);
		return;
	}

	if (g_eLocal.GetState(EVE_GUILDCOMBAT) == 0)
		return;

	if (g_GuildCombatMng.m_nGCState != CGuildCombat::ENTER_STATE)
		return;

	if (!g_GuildCombatMng.IsSelectPlayer(pUser))
		return;

	PRegionElem pRgnElem = g_WorldMng.GetRevivalPos(WI_WORLD_MADRIGAL, "flaris");
	if (pRgnElem)
		((CMover*)pUser)->REPLACE(g_uIdofMulti, WI_WORLD_MADRIGAL, D3DXVECTOR3(6983.0f, 0.0f, 3330.0f), REPLACE_NORMAL, nDefaultLayer);
}
void CDPSrvr::OnGCPlayerPoint(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (g_eLocal.GetState(EVE_GUILDCOMBAT) == 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		pUser->AddGCPlayerPoint();
}

void CDPSrvr::OnSummonFriend(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwData;
	char lpszPlayer[MAX_PLAYER] = { 0, };

	ar >> dwData;
	ar.ReadString(lpszPlayer, MAX_PLAYER);

	if (strlen(lpszPlayer) >= MAX_NAME)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwData);
	if (!IsUsableItem(pItemElem))
		return;

	if (pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_A && pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_B)
		return;

	if (pItemElem->m_bQuery)
		return;

	CUser* pUsertmp = g_UserMng.GetUserByPlayerID(CPlayerDataCenter::GetInstance()->GetPlayerId(lpszPlayer));
	if (!IsValidObj((CObj*)pUsertmp))
	{
		pUser->AddDefinedText(TID_ERROR_SUMMONFRIEND_NOUSER, "\"%s\"", lpszPlayer);
		return;
	}

	if (pUser->m_idPlayer == pUsertmp->m_idPlayer)
		pUser->AddDefinedText(TID_GAME_SUMMON_FRIEND_MY_NOUSE);
	else if (prj.IsGuildQuestRegion(pUser->GetPos()))
		pUser->AddDefinedText(TID_GAME_STATE_NOTUSE, "\"%s\"", prj.GetText(TID_GAME_EVENT_WORLD_NOTUSE));
	else if (prj.IsGuildQuestRegion(pUsertmp->GetPos()))
		pUser->AddDefinedText(TID_GAME_STATE_NOTUSE, "\"%s\"", prj.GetText(TID_GAME_EVENT_WORLD_NOTUSE1));
	else if (pUser->GetWorld()->GetID() != pUsertmp->GetWorld()->GetID() || pUser->GetLayer() != pUsertmp->GetLayer())
	{
		CString strtmp;
		strtmp.Format(prj.GetText(TID_GAME_WORLD_NOTUSE), pUser->GetWorld()->m_szWorldName, pUsertmp->GetWorld()->m_szWorldName);
		pUser->AddDefinedText(TID_GAME_STATE_NOTUSE, "\"%s\"", strtmp);
	}
	else
	{
		if (pUsertmp->m_RTMessenger.IsBlock(pUser->m_idPlayer))
		{
			pUser->AddDefinedText(TID_ERROR_SUMMONFRIEND_NOUSER, "\"%s\"", lpszPlayer);
			return;
		}

		pItemElem->m_bQuery = TRUE;
		pUsertmp->AddSummonFriendConfirm(pUser->GetId(), dwData, pUser->GetName(), pUser->GetWorld()->m_szWorldName);
		pUser->AddDefinedText(TID_GAME_SUMMONFRIEND_CONFIRM, "\"%s\"", lpszPlayer);
	}
}
void CDPSrvr::OnSummonFriendConfirm(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objid;
	DWORD dwData;

	ar >> objid >> dwData;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CUser* pUsertmp = prj.GetUser(objid);
	if (!IsValidObj((CObj*)pUsertmp))
		return;

	CItemElem* pItemElem = pUsertmp->m_Inventory.GetAtId(dwData);
	if (!pItemElem)
		return;

	if (pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_A && pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_B)
		return;

	if (pItemElem->m_bQuery == FALSE)
		return;

	pItemElem->m_bQuery = FALSE;

	if (!IsUsableItem(pItemElem))
		return;

	DWORD dwState = pUser->GetSummonState(FALSE);
	if (dwState != 0)
	{
		pUser->AddDefinedText(dwState);
		pUsertmp->AddDefinedText(dwState);
		return;
	}

	dwState = pUsertmp->GetSummonState(TRUE);
	if (dwState != 0)
	{
		pUser->AddDefinedText(dwState);
		pUsertmp->AddDefinedText(dwState);
		return;
	}

	if (pUser->GetWorld()->GetID() != pUsertmp->GetWorld()->GetID() || pUser->GetLayer() != pUsertmp->GetLayer())
	{
		CString strtmp;
		strtmp.Format(prj.GetText(TID_GAME_WORLD_NOTUSE), pUser->GetWorld()->m_szWorldName, pUsertmp->GetWorld()->m_szWorldName);
		pUser->AddDefinedText(TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", strtmp);
		strtmp.Format(prj.GetText(TID_GAME_WORLD_NOTUSE), pUsertmp->GetWorld()->m_szWorldName, pUser->GetWorld()->m_szWorldName);
		pUsertmp->AddDefinedText(TID_GAME_STATE_NOTSUMMON, "\"%s\"", strtmp);
	}
	else
	{
		pUser->REPLACE(g_uIdofMulti, pUsertmp->GetWorld()->GetID(), pUsertmp->GetPos(), REPLACE_FORCE, pUsertmp->GetLayer());
		pUsertmp->RemoveItem((BYTE)(dwData), (short)1);
		pUser->AddDefinedText(TID_GAME_SUMMON_SUCCESS1, "\"%s\"", pUsertmp->GetName());
		pUsertmp->AddDefinedText(TID_GAME_SUMMON_SUCCESS, "\"%s\"", pUser->GetName());
	}
}

void CDPSrvr::OnSummonFriendCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objid;
	DWORD dwData;
	ar >> objid >> dwData;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CUser* pUsertmp = prj.GetUser(objid);
	if (!IsValidObj((CObj*)pUsertmp))
		return;

	WORD wId = LOWORD(dwData);
	CItemElem* pItemElem = pUsertmp->m_Inventory.GetAtId(wId);
	if (!pItemElem)
		return;

	if (pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_A && pItemElem->m_dwItemId != II_SYS_SYS_SCR_FRIENDSUMMON_B)
		return;

	if (pItemElem->m_bQuery == FALSE)
		return;

	pItemElem->m_bQuery = FALSE;

	pUsertmp->AddDefinedText(TID_GAME_SUMMON_FRIEND_CANCEL, "\"%s\"", pUser->GetName());
}

void CDPSrvr::OnSummonParty(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwData;

	ar >> dwData;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	DWORD dwState = pUser->GetSummonState(TRUE);
	if (dwState != 0)
	{
		pUser->AddDefinedText(dwState);
		return;
	}

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwData);
	if (!IsUsableItem(pItemElem))
		return;

	if (pItemElem->GetProp()->dwID != II_SYS_SYS_SCR_PARTYSUMMON)
		return;

	CParty* pParty = g_PartyMng.GetParty(pUser->GetPartyId());
	if (!pParty)
		return;

	if (pParty->IsLeader(pUser->m_idPlayer))
	{
		if (!pUser->HasBuff(BUFF_ITEM, (WORD)(pItemElem->GetProp()->dwID)))
		{
			pParty->m_dwWorldId = pUser->GetWorld()->GetID();

			ItemProp* pItemProptmp = prj.GetItemProp(II_SYS_SYS_SCR_PARTYSUMMON);
			for (int i = 1; i < pParty->m_nSizeofMember; i++)
			{
				CUser* pUsertmp = g_UserMng.GetUserByPlayerID(pParty->GetPlayerId(i));
				if (IsValidObj((CObj*)pUsertmp))
				{
					pUser->DoApplySkill((CCtrl*)pUsertmp, pItemElem->GetProp(), NULL);
					pUsertmp->AddSummonPartyConfirm(pUser->GetId(), dwData, pUser->GetWorld()->m_szWorldName);
					if (pItemProptmp)
						g_UserMng.AddCreateSfxObj((CMover*)pUsertmp, pItemProptmp->dwSfxObj3);
					pUser->AddDefinedText(TID_GAME_SUMMONFRIEND_CONFIRM, "\"%s\"", pUsertmp->GetName());
				}
				else
					pUser->AddDefinedText(TID_ERROR_SUMMONFRIEND_NOUSER, "\"%s\"", CPlayerDataCenter::GetInstance()->GetPlayerString(pParty->GetPlayerId(i)));
			}

			pUser->DoApplySkill((CCtrl*)pUser, pItemElem->GetProp(), NULL);
			pUser->RemoveItem((BYTE)(dwData), (short)1);

			if (pItemProptmp)
				g_UserMng.AddCreateSfxObj((CMover*)pUser, pItemProptmp->dwSfxObj3);
		}
		else
			pUser->AddDefinedText(TID_GAME_LIMITED_USE);
	}
}

void CDPSrvr::OnSummonPartyConfirm(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objid;
	DWORD dwData;
	ar >> objid;
	ar >> dwData;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CParty* pParty = g_PartyMng.GetParty(pUser->GetPartyId());
	if (!pParty)
	{
		pUser->AddDefinedText(TID_GAME_NOPARTY);
		return;
	}

	CMover* pLeader = prj.GetUser(objid);
	if (!IsValidObj(pLeader))
	{
		pUser->AddDefinedText(TID_ERROR_SUMMONPARTY_NOTTIME);
		return;
	}

	if (pParty->IsLeader(pLeader->m_idPlayer) && pLeader->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PARTYSUMMON))
	{
		if (pUser == pLeader)
			return;

		DWORD dwState = pUser->GetSummonState(FALSE);
		if (dwState != 0)
		{
			pUser->AddDefinedText(dwState);
			return;
		}

		dwState = pLeader->GetSummonState(TRUE);
		if (dwState != 0)
		{
			pUser->AddDefinedText(dwState);
			return;
		}

		if (pUser->GetWorld()->GetID() != pParty->m_dwWorldId)
		{
			CWorld* pWorld = g_WorldMng.GetWorld(pParty->m_dwWorldId);
			if (pWorld)
			{
				CString strtmp;
				strtmp.Format(prj.GetText(TID_GAME_WORLD_NOTUSE), pUser->GetWorld()->m_szWorldName, pWorld->m_szWorldName);
				pUser->AddDefinedText(TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", strtmp);
			}
		}
		else if (pParty->m_dwWorldId != pLeader->GetWorld()->GetID())
		{
			CWorld* pWorld = g_WorldMng.GetWorld(pParty->m_dwWorldId);
			if (pWorld)
			{
				CString strtmp;
				strtmp.Format(prj.GetText(TID_GAME_WORLDLEADER_NOTUSE));
				pUser->AddDefinedText(TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", strtmp);
			}
		}
		else if (pLeader->GetLayer() != pUser->GetLayer())
		{
			CString strtmp;
			strtmp.Format(prj.GetText(TID_GAME_WORLD_NOTUSE));
			pUser->AddDefinedText(TID_GAME_STATE_NOTSUMMONOK, "\"%s\"", strtmp);
		}
		else
		{
			pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_SCR_PARTYSUMMON);
			pUser->REPLACE(g_uIdofMulti, pLeader->GetWorld()->GetID(), pLeader->GetPos(), REPLACE_FORCE, pLeader->GetLayer());
			pUser->AddDefinedText(TID_GAME_SUMMON_SUCCESS1, "\"%s\"", pLeader->GetName());
			((CUser*)pLeader)->AddDefinedText(TID_GAME_SUMMON_SUCCESS, "\"%s\"", pUser->GetName());
			ItemProp* pItemProptmp = prj.GetItemProp(II_SYS_SYS_SCR_PARTYSUMMON);
			if (pItemProptmp)
				g_UserMng.AddCreateSfxObj((CMover*)pUser, pItemProptmp->dwSfxObj3);
		}
	}
	else
		pUser->AddDefinedText(TID_ERROR_SUMMONPARTY_NOTTIME);
}

void CDPSrvr::OnRemoveInvenItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD	dwId;
	int		nNum;
	int nType;

	ar >> dwId;
	ar >> nNum;
	ar >> nType;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

#ifdef __FL_EQUALIZED_MODE
#ifdef __ZCK_AUTH
	if (pUser->bTmpMode && (pUser->m_dwAuthorization == AUTH_GENERAL || pUser->m_dwAuthorization == AUTH_ANIMATEUR || pUser->m_dwAuthorization == AUTH_GUIDE))
#else
	if (pUser->bTmpMode && pUser->m_dwAuthorization == AUTH_GENERAL)
#endif // __ZCK_AUTH
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	CItemContainer<CItemElem>* pContainer = pUser->GetContainerByType(nType);
	if (!pContainer)
		return;

	CItemElem* pItemElem = pContainer->GetAtId(dwId);
	if (!IsUsableItem(pItemElem))
		return;

	if (nType == TYPE_INVENTORY)
	{
		if (pUser->m_Inventory.IsEquip(dwId))
			return;

		if (pUser->IsUsing(pItemElem))
		{
			pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
			return;
		}
	}

	if (nNum > pItemElem->m_nItemNum)
		nNum = pItemElem->m_nItemNum;
	if (nNum < 1)
		nNum = 1;

	if (pItemElem->IsUndestructable())
		return;

	CString strNum;
	strNum.Format("%d", nNum);
	pUser->AddDefinedText(TID_GAME_SUCCESS_REMOVE_ITEM, "\"%s\" \"%s\"", pItemElem->GetProp()->szName, strNum);

	LogItemInfo aLogItem;
	aLogItem.Action = "*";
	aLogItem.SendName = pUser->GetName();
	aLogItem.RecvName = "GARBAGE";
	aLogItem.WorldId = pUser->GetWorld()->GetID();
	aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
	OnLogItem(aLogItem, pItemElem, nNum);

#ifdef __FL_BUYBACK
	pUser->m_Buyback.AddItem(pItemElem, nNum, 0);
#endif

	pUser->RemoveItem((BYTE)(dwId), (short)nNum, nType);
}

void CDPSrvr::OnCreateMonster(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwItemIdRec;
	D3DXVECTOR3 vPos;
	ar >> dwItemIdRec;
	ar >> vPos;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!pUser->IsPossibleUseItem())
		return;

	CCreateMonster::GetInstance()->CreateMonster(pUser, dwItemIdRec, vPos);
}

void CDPSrvr::OnFoucusObj(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objid;
	ar >> objid;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		pUser->AddFocusObj(objid);
}

void CDPSrvr::OnTrade(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objidTrader;
	ar >> objidTrader;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (pUser->m_vtInfo.GetOther() == NULL)
	{
		CMover* pTrader = prj.GetMover(objidTrader);
		if (IsValidObj(pTrader) && pTrader->GetWorld() && pTrader->m_vtInfo.GetOther() == NULL)
		{
			if (pTrader->IsPlayer())
			{
				if (pUser->IsDie() || pTrader->IsDie())
					return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
				if (ZckRefusStaffEchange(pUser, pTrader))
					return;
#else
#line 5876 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __FL_EQUALIZED_MODE
				if (pUser->bTmpMode || ((CUser*)pTrader)->bTmpMode)
				{
					pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
					return;
				}
#endif
				if (pUser->m_vtInfo.VendorIsVendor() || pUser->m_vtInfo.IsVendorOpen() ||
					pTrader->m_vtInfo.VendorIsVendor() || pTrader->m_vtInfo.IsVendorOpen())
				{
					return;
				}
				if (pUser->m_bAllAction == FALSE || ((CUser*)pTrader)->m_bAllAction == FALSE)
					return;

				if (pUser->m_bBank || pTrader->m_bBank)
				{
					pUser->AddDefinedText(TID_GAME_TRADELIMITPC, "");
					return;
				}

				if (pUser->m_bGuildBank || pTrader->m_bGuildBank)
				{
					pUser->AddDefinedText(TID_GAME_TRADELIMITPC, "");
					return;
				}

				pUser->m_vtInfo.SetOther(pTrader);
				pTrader->m_vtInfo.SetOther(pUser);

				pUser->AddTrade((CUser*)pTrader, pUser->m_idPlayer);
				((CUser*)pTrader)->AddTrade(pUser, pUser->m_idPlayer);
#ifdef __ZCK_FENETRE_CHAT_MJ
#ifdef __ZCK_TRAD_FR
				CZckChatMjManager::GetInstance()->CaptureTradeStep(
					pUser, pTrader, _T("ouverture de l'\351change"));
#else
				CZckChatMjManager::GetInstance()->CaptureTradeStep(
					pUser, pTrader, _T("ouverture de l'echange"));
#endif // __ZCK_TRAD_FR
#endif // __ZCK_FENETRE_CHAT_MJ
			}
		}
	}
}

void CDPSrvr::OnConfirmTrade(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objidTrader;
	ar >> objidTrader;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (pUser->m_vtInfo.GetOther() == NULL)
	{
		CMover* pTrader = prj.GetMover(objidTrader);
		if (IsValidObj(pTrader) && pTrader->GetWorld() && pTrader->m_vtInfo.GetOther() == NULL)
		{
			if (pUser->IsDie() || pTrader->IsDie())
				return;

			if (pTrader->IsPlayer() == FALSE)
				return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
			if (ZckRefusStaffEchange(pUser, pTrader))
				return;
#else
#line 5946 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __FL_EQUALIZED_MODE
			if (pUser->bTmpMode || ((CUser*)pTrader)->bTmpMode)
			{
				pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
				return;
			}
#endif

			if (pTrader->IsAttackMode())
				pUser->AddDefinedText(TID_GAME_BATTLE_NOTTRADE, "");
			else
				((CUser*)pTrader)->AddComfirmTrade(pUser->GetId());
		}

		pUser->RemoveInvisibleSkill();
	}
}

void CDPSrvr::OnConfirmTradeCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objidTrader;
	ar >> objidTrader;

	CMover* pTrader = prj.GetMover(objidTrader);
	if (IsValidObj(pTrader) && pTrader->GetWorld() && pTrader->m_vtInfo.GetOther() == NULL)
		((CUser*)pTrader)->AddComfirmTradeCancel(objidTrader);
}

void CDPSrvr::OnTradePut(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE byNth;
	DWORD dwItemObjID;
	int nItemNum;

	ar >> byNth >> dwItemObjID >> nItemNum;

	if (byNth >= MAX_TRADE)
		return;

	if (nItemNum < 1)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CMover* pTrader = pUser->m_vtInfo.GetOther();
	if (IsValidObj(pTrader) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaffEchange(pUser, pTrader))
		return;
#else
#line 5996 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser)
	{
		if (pUser->IsDie() || pTrader->IsDie())
			return;

#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode || ((CUser*)pTrader)->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif

		CItemElem* pItem = pUser->m_Inventory.GetAtId(dwItemObjID);
		if (pItem && pItem->IsFlag(CItemElem::expired))
			return;

		if (pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM && pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM)
		{
			int nItemNumResult = nItemNum;
			DWORD dwText = pUser->m_vtInfo.TradeSetItem2(dwItemObjID, byNth, nItemNumResult);
			if (dwText == 0)
			{
				pUser->AddTradePut(pUser->GetId(), byNth, pItem, nItemNumResult);
				((CUser*)pTrader)->AddTradePut(pUser->GetId(), byNth, pItem, nItemNumResult);
#ifdef __ZCK_FENETRE_CHAT_MJ
				CZckChatMjManager::GetInstance()->CaptureTradeItem(
					pUser, pTrader, (int)byNth, pItem, nItemNumResult, TRUE);
#endif // __ZCK_FENETRE_CHAT_MJ
			}
			else
				pUser->AddDefinedText(dwText);
		}
		else
			pUser->AddTradePutError();
	}
}

void CDPSrvr::OnTradePull(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE byNth;
	ar >> byNth;

	if (byNth >= MAX_TRADE)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CMover* pTrader = pUser->m_vtInfo.GetOther();
	if (IsValidObj(pTrader) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaffEchange(pUser, pTrader))
		return;
#else
#line 6054 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser)
	{
		if (pUser->IsDie() || pTrader->IsDie())
			return;

		if (pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM && pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM)
		{
			if (pUser->m_vtInfo.TradeClearItem(byNth))
			{
				pUser->AddTradePull(pUser->GetId(), byNth);
				((CUser*)pUser->m_vtInfo.GetOther())->AddTradePull(pUser->GetId(), byNth);
#ifdef __ZCK_FENETRE_CHAT_MJ
				CZckChatMjManager::GetInstance()->CaptureTradeItem(
					pUser, pTrader, (int)byNth, NULL, 0, FALSE);
#endif // __ZCK_FENETRE_CHAT_MJ
			}
		}
	}
}

void CDPSrvr::OnTradePutGold(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwGold;
	ar >> dwGold;

	int nGold = (int)(dwGold);
	if (nGold <= 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CMover* pTrader = pUser->m_vtInfo.GetOther();
	if (IsValidObj(pTrader) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaffEchange(pUser, pTrader))
		return;
#else
#line 6095 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser)
	{
		if (pUser->IsDie() || pTrader->IsDie())
			return;

		if (pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM && pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM)
		{
			if (nGold > pUser->GetGold())
				nGold = pUser->GetGold();

			if (pUser->CheckUserGold(nGold, false) == false)
				return;

			pUser->m_vtInfo.TradeSetGold(nGold);
			pUser->AddGold(-nGold, FALSE);

			pUser->AddTradePutGold(pUser->GetId(), nGold);
			((CUser*)pTrader)->AddTradePutGold(pUser->GetId(), nGold);
#ifdef __ZCK_FENETRE_CHAT_MJ
			CZckChatMjManager::GetInstance()->CaptureTradeGold(pUser, pTrader, nGold);
#endif // __ZCK_FENETRE_CHAT_MJ
		}
	}
}

void CDPSrvr::OnTradeCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nMode;
	ar >> nMode;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CMover* pTrader = pUser->m_vtInfo.GetOther();
	if (IsValidObj(pTrader) == FALSE)
		return;

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser)
	{
		pUser->m_vtInfo.TradeClear();
		pTrader->m_vtInfo.TradeClear();

		pUser->AddTradeCancel(pUser->GetId(), pUser->m_idPlayer, nMode);
		((CUser*)pTrader)->AddTradeCancel(pUser->GetId(), pUser->m_idPlayer, nMode);
#ifdef __ZCK_FENETRE_CHAT_MJ
#ifdef __ZCK_TRAD_FR
		CZckChatMjManager::GetInstance()->CaptureTradeStep(
			pUser, pTrader, _T("\351change annul\351"));
#else
		CZckChatMjManager::GetInstance()->CaptureTradeStep(
			pUser, pTrader, _T("echange annule"));
#endif // __ZCK_TRAD_FR
#endif // __ZCK_FENETRE_CHAT_MJ
	}
}

void CDPSrvr::OnTradelastConfrim(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CMover* pTrader = pUser->m_vtInfo.GetOther();
	if (IsValidObj(pTrader) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaffEchange(pUser, pTrader))
		return;
#else
#line 6170 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser)
	{
		if (pUser->IsDie() || pTrader->IsDie())
			return;

		if (pUser->m_vtInfo.TradeGetState() != TRADE_STEP_OK)
			return;

#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode || ((CUser*)pTrader)->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif

		switch (pTrader->m_vtInfo.TradeGetState())
		{
		case TRADE_STEP_OK:
			pUser->m_vtInfo.TradeSetState(TRADE_STEP_CONFIRM);

			pUser->AddTradelastConfirmOk(pUser->GetId());
			((CUser*)pTrader)->AddTradelastConfirmOk(pUser->GetId());
			break;

		case TRADE_STEP_CONFIRM:
		{
			BEFORESENDDUAL(out, PACKETTYPE_LOG_ALLITEM, DPID_UNKNOWN, DPID_UNKNOWN);
			TRADE_CONFIRM_TYPE type = pUser->m_vtInfo.TradeLastConfirm(out);
			switch (type)
			{
			case TRADE_CONFIRM_ERROR:
				pUser->AddTradeCancel(NULL_ID, pUser->m_idPlayer);
				((CUser*)pTrader)->AddTradeCancel(NULL_ID, pUser->m_idPlayer);
				break;
			case TRADE_CONFIRM_OK:
				SEND(out, &g_dpDBClient, DPID_SERVERPLAYER);

				pUser->AddTradeConsent();
				((CUser*)pTrader)->AddTradeConsent();
#ifdef __ZCK_FENETRE_CHAT_MJ
				// C'est ICI que les biens changent reellement de mains.
				// OnTradeOk ne fait que passer l'etat a TRADE_STEP_OK.
#ifdef __ZCK_TRAD_FR
				CZckChatMjManager::GetInstance()->CaptureTradeStep(
					pUser, pTrader, _T("\311CHANGE VALID\311"));
#else
				CZckChatMjManager::GetInstance()->CaptureTradeStep(
					pUser, pTrader, _T("ECHANGE VALIDE"));
#endif // __ZCK_TRAD_FR
#endif // __ZCK_FENETRE_CHAT_MJ
				break;
			}
		}
		break;
		}
	}
}

void CDPSrvr::OnTradeOk(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	CMover* pTrader = pUser->m_vtInfo.GetOther();
	if (IsValidObj(pTrader) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaffEchange(pUser, pTrader))
		return;
#else
#line 6243 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (pTrader->GetWorld() == pWorld && pTrader->m_vtInfo.GetOther() == pUser)
	{
		if (pUser->IsDie() || pTrader->IsDie())
			return;

#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode || ((CUser*)pTrader)->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif

		if (pUser->m_vtInfo.TradeGetState() == TRADE_STEP_ITEM)
		{
			pUser->m_vtInfo.TradeSetState(TRADE_STEP_OK);

			if (pTrader->m_vtInfo.TradeGetState() == TRADE_STEP_OK)
			{
				pUser->AddTradelastConfirm();
				((CUser*)pTrader)->AddTradelastConfirm();
			}
			else
			{
				pUser->AddTradeOk(pUser->GetId());
				((CUser*)pTrader)->AddTradeOk(pUser->GetId());
			}
		}
	}
}

void CDPSrvr::OnPVendorClose(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objidVendor;
	ar >> objidVendor;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		ClosePVendor(pUser, objidVendor);
	}
}

BOOL CDPSrvr::ClosePVendor(CUser* pUser, OBJID objidVendor)
{
	if (pUser->GetId() == objidVendor)
	{
		if (pUser->m_vtInfo.IsVendorOpen() == FALSE &&
			pUser->m_vtInfo.VendorIsVendor() == FALSE)
		{
			return FALSE;
		}

#ifdef __FL_SHOP_SEARCH
		prj.RemoveFromShopSearch(pUser->GetId());
#endif

		CMover* pTrader = pUser->m_vtInfo.GetOther();   //raiders.2006.11.27

		pUser->m_vtInfo.VendorClose();

		//raiders.2006.11.27
		pUser->m_vtInfo.TradeClear();
		if (pTrader)
			pTrader->m_vtInfo.TradeClear();
		//--

		g_UserMng.AddPVendorClose(pUser);

		CChatting* pChatting = g_ChattingMng.GetChttingRoom(pUser->m_idChatting);
		if (pChatting)
		{
			for (int i = 0; i < pChatting->GetChattingMember(); ++i)
			{
				CUser* pUserBuf = (CUser*)prj.GetUserByID(pChatting->m_idMember[i]);
				if (IsValidObj(pUserBuf))
				{

					pUserBuf->AddDeleteChatting();
					pUserBuf->m_idChatting = 0;
				}
			}
		}
		g_ChattingMng.DeleteChattingRoom(pUser->m_idPlayer);
		pUser->m_idChatting = 0;
	}
	else
	{
		if (IsValidObj(pUser->m_vtInfo.GetOther()))
		{
			pUser->m_vtInfo.SetOther(NULL);
			pUser->AddPVendorClose(objidVendor);

			CChatting* pChatting = g_ChattingMng.GetChttingRoom(pUser->m_idChatting);
			if (pChatting)
			{
				for (int i = 0; i < pChatting->GetChattingMember(); ++i)
				{
					CUser* pUserBuf = (CUser*)prj.GetUserByID(pChatting->m_idMember[i]);
					if (IsValidObj(pUserBuf))
					{
						pUserBuf->AddRemoveChatting(pUser->m_idPlayer);
					}
				}
				pChatting->RemoveChattingMember(pUser->m_idPlayer);
				pUser->m_idChatting = 0;
			}
		}
#ifdef __FL_VENDORS
		else
		{
			pUser->m_vtInfo.SetOther(NULL);

			CChatting* pChatting = g_ChattingMng.GetChttingRoom(pUser->m_idChatting);
			if (pChatting)
			{
				for (int i = 0; i < pChatting->GetChattingMember(); ++i)
				{
					CUser* pUserBuf = (CUser*)prj.GetUserByID(pChatting->m_idMember[i]);
					if (IsValidObj(pUserBuf))
					{
						pUserBuf->AddRemoveChatting(pUser->m_idPlayer);
					}
				}
				pChatting->RemoveChattingMember(pUser->m_idPlayer);
				pUser->m_idChatting = 0;
			}
		}
#endif
	}

	return TRUE;
}

void CDPSrvr::OnBuyPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objidVendor;
	BYTE nItem;
	short nNum;

	ar >> objidVendor >> nItem >> nNum;

	if (nItem >= MAX_VENDITEM || nNum <= 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "boutique personnelle"))
		return;
#else
#line 6396 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

#ifndef __FL_VENDORS
	CUser* pPVendor = prj.GetUser(objidVendor);
#else
	CMover* pPVendor = prj.GetMover(objidVendor);
#endif
	if (IsValidObj(pPVendor))
	{
		VENDOR_SELL_RESULT result;
		BOOL bOK = pPVendor->m_vtInfo.VendorSellItem(pUser, nItem, nNum, result);
		if (bOK)
		{
			LogItemInfo info;

			info.Action = "Z";
			info.SendName = pUser->GetName();
			info.RecvName = pPVendor->GetName();
			info.WorldId = pUser->GetWorld()->GetID();
			info.Gold = pUser->GetGold() + (result.item.m_nCost * nNum);
			info.Gold2 = pUser->GetGold();
			info.Gold_1 = pPVendor->GetGold();
			OnLogItem(info, &result.item, nNum);

			info.Action = "X";
			info.SendName = pPVendor->GetName();
			info.RecvName = pUser->GetName();
			info.WorldId = pPVendor->GetWorld()->GetID();
			info.Gold = pPVendor->GetGold() - (result.item.m_nCost * nNum);
			info.Gold2 = pPVendor->GetGold();
			info.Gold_1 = pUser->GetGold();
			OnLogItem(info, &result.item, nNum);
		}
		else
		{
			if (result.nErrorCode)
				pUser->AddDefinedText(result.nErrorCode, "");
		}
	}
}

void CDPSrvr::OnQueryPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	OBJID objidVendor;
	ar >> objidVendor;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->m_vtInfo.GetOther())
			return;
		if (pUser->m_pActMover->IsFly())
			return;

#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif

		CUser* pPVendor = prj.GetUser(objidVendor);
		if (IsValidObj(pPVendor))
		{
			BOOL bChatting = TRUE;
			CChatting* pChatting = g_ChattingMng.GetChttingRoom(pPVendor->m_idChatting);
			if (pChatting)
				bChatting = pChatting->m_bState;

			if (pPVendor->m_vtInfo.IsVendorOpen())
			{
				pUser->m_vtInfo.SetOther(pPVendor);
				pUser->AddPVendorItem(pPVendor, bChatting);
			}
		}
#ifdef __FL_VENDORS
		else
		{
			CMover* pPVendor = prj.GetMover(objidVendor);
			if (IsValidObj(pPVendor))
			{
				if (pPVendor->m_vtInfo.IsVendorOpen())
				{
					pUser->m_vtInfo.SetOther(pPVendor);
					pUser->AddPVendorItem((CUser*)pPVendor, FALSE);
				}
			}
		}
#endif

	}
}

void CDPSrvr::OnCreateAngel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nSuns, nMoons;
	ar >> nSuns >> nMoons;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!g_eLocal.GetState(EVE_PK))
		return;

	if (nSuns < 0 || nMoons < 0 || nSuns > 10 || nMoons > 10 || nSuns + nMoons < 3 || nSuns + nMoons > 20)
	{
		pUser->AddDefinedText(TID_GAME_SUMMONANGEL_ERROR2);
		return;
	}

	if (pUser->GetAvailableItemNum(II_GEN_MAT_ORICHALCUM01) < nSuns)
	{
		pUser->AddDefinedText(TID_UPGRADE_ERROR_NOSUPSTON);
		return;
	}

	if (pUser->GetAvailableItemNum(II_GEN_MAT_MOONSTONE) < nMoons)
	{
		pUser->AddDefinedText(TID_UPGRADE_ERROR_NOSUPSTON);
		return;
	}

	if (pUser->m_Inventory.GetEmptyCount() < 1)
	{
		pUser->AddDiagText(prj.GetText(TID_GAME_LACKSPACE));
		return;
	}

	// Select random angel based on item amount
	float greenAngelRate, whiteAngelRate, blueAngelRate, redAngelRate;
	FLOAT fRate[4];
	static DWORD adwItemId[4] = { II_SYS_SYS_QUE_ANGEL_RED, II_SYS_SYS_QUE_ANGEL_BLUE, II_SYS_SYS_QUE_ANGEL_GREEN, II_SYS_SYS_QUE_ANGEL_WHITE };

	greenAngelRate = (nSuns * 1.0f) + (nMoons * 1.0f);
	whiteAngelRate = greenAngelRate / 10.0f;
	blueAngelRate = greenAngelRate * 2.0f;
	redAngelRate = 100.0f - (whiteAngelRate + greenAngelRate + blueAngelRate);

	fRate[0] = redAngelRate;
	fRate[1] = fRate[0] + blueAngelRate;
	fRate[2] = fRate[1] + greenAngelRate;
	fRate[3] = fRate[2] + whiteAngelRate;

	float rand = xRandom(1000) / 10.0f;
	DWORD dwItemId = NULL_ID;
	for (int i = 0; i < 4; i++)
	{
		if (rand <= fRate[i])
		{
			dwItemId = adwItemId[i];
			break;
		}
	}

	// Remove suns/moons and create angel
	if (dwItemId == NULL_ID)
		return;

	pUser->RemoveAvailableItem(II_GEN_MAT_ORICHALCUM01, nSuns);
	pUser->RemoveAvailableItem(II_GEN_MAT_MOONSTONE, nMoons);

	CItemElem itemElem;
	itemElem.m_dwItemId = dwItemId;
	itemElem.m_nItemNum = 1;
	if (pUser->CreateItem(&itemElem))
	{
		LogItemInfo aLogItem;
		aLogItem.Action = "&";
		aLogItem.SendName = pUser->GetName();
		aLogItem.RecvName = "ANGEL_CREATE";
		aLogItem.WorldId = pUser->GetWorld()->GetID();
		aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
		OnLogItem(aLogItem, &itemElem, 1);
	}
}

void CDPSrvr::OnAngleBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->HasBuffByIk3(IK3_ANGEL_BUFF) == FALSE)
			return;

		IBuff* pBuff = pUser->m_buffs.GetBuffByIk3(IK3_ANGEL_BUFF);
		if (!pBuff)
			return;

		ItemProp* pItemProp = pBuff->GetProp();
		if (pItemProp == NULL)
			return;
#ifdef __ZCK_4_CLASSES
		// Invocations [Vicious Summoning] des 4emes classes (objets IK3_ANGEL_BUFF poses par CMover::ProcessQuest) :
		// ce ne sont pas des anges, aucun objet n'est cree. Sans ce refus, le paquet cree un
		// II_SYS_SYS_QUE_ANGEL_WHITE100 (branche default) puis retire l'invocation, reposee au passage suivant
		// tant que dure le buff du skill : creation d'objets illimitee (defaut identique chez le donneur).
		switch (pItemProp->dwID)
		{
		case II_SYS_SYS_MONSTERSKILL_01:
		case II_SYS_SYS_MONSTERSKILL_02:
		case II_SYS_SYS_MONSTERSKILL_03:
		case II_SYS_SYS_MONSTERSKILL_04:
		case II_SYS_SYS_MONSTERSKILL_05:
		case II_SYS_SYS_MONSTERSKILL_06:
		case II_SYS_SYS_MONSTERSKILL_07:
		case II_SYS_SYS_MONSTERSKILL_08:
			return;
		}
#endif // __ZCK_4_CLASSES

		int nAngel = (int)((float)pItemProp->nAdjParamVal1);
		if (nAngel <= 0 || 100 < nAngel)
			nAngel = 100;

		EXPINTEGER nMaxAngelExp = prj.m_aExpCharacter[pUser->m_nAngelLevel].nExp1 / 100 * nAngel;
		if (pUser->m_nAngelExp < nMaxAngelExp)
			return;

		CItemElem itemElem;
		switch (pItemProp->dwID)
		{
		case II_SYS_SYS_QUE_ANGEL_RED:
			itemElem.m_dwItemId = II_SYS_SYS_QUE_ANGEL_RED100;
			break;
		case II_SYS_SYS_QUE_ANGEL_BLUE:
			itemElem.m_dwItemId = II_SYS_SYS_QUE_ANGEL_BLUE100;
			break;
		case II_SYS_SYS_QUE_ANGEL_GREEN:
			itemElem.m_dwItemId = II_SYS_SYS_QUE_ANGEL_GREEN100;
			break;
		default:
			itemElem.m_dwItemId = II_SYS_SYS_QUE_ANGEL_WHITE100;
			break;
		}

		itemElem.m_nItemNum = 1;
		if (pUser->CreateItem(&itemElem))
		{
			pUser->RemoveIk3Buffs(IK3_ANGEL_BUFF);

			LogItemInfo aLogItem;
			aLogItem.Action = "&";
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "ANGEL_CREATE_COMPLETED";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			OnLogItem(aLogItem, &itemElem, 1);

			char szMessage[512] = { 0, };
			sprintf(szMessage, prj.GetText(TID_EVE_REAPITEM), itemElem.GetProp()->szName);
			pUser->AddText(szMessage);
		}
		else
			pUser->AddDefinedText(TID_GAME_NOT_INVEN_ANGEL, "");
	}
}

#ifdef __EVE_MINIGAME
void CDPSrvr::OnKawibawiboStart(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	if (CNpcChecker::GetInstance()->IsCloseNpc(MMI_KAWIBAWIBO, pUser->GetWorld(), pUser->GetPos()) == FALSE)
		return;

	pUser->m_nKawibawiboState = prj.m_MiniGame.Result_Kawibawibo(pUser);
	if (pUser->m_nKawibawiboState == CMiniGame::KAWIBAWIBO_WIN)
	{
		CMiniGame::__KAWIBAWIBO Kawibawibo = prj.m_MiniGame.FindKawibawibo(pUser->m_nKawibawiboWin);
		CMiniGame::__KAWIBAWIBO KawibawiboNext = prj.m_MiniGame.FindKawibawibo(pUser->m_nKawibawiboWin + 1);
		pUser->AddKawibawiboResult(pUser->m_nKawibawiboState, pUser->m_nKawibawiboWin, Kawibawibo.dwItemId, Kawibawibo.nItemCount, KawibawiboNext.dwItemId, KawibawiboNext.nItemCount);
	}
	else
		pUser->AddKawibawiboResult(pUser->m_nKawibawiboState, pUser->m_nKawibawiboWin);
}
void CDPSrvr::OnKawibawiboGetItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	prj.m_MiniGame.ResultItem_Kawibawibo(pUser);
}
#endif // __EVE_MINIGAME

void CDPSrvr::OnUltimateMakeItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	OBJID objSunId, objMoonId;
	ar >> objSunId >> objMoonId;

	CItemElem* pItemSun = pUser->m_Inventory.GetAtId(objSunId);
	CItemElem* pItemMoon = pUser->m_Inventory.GetAtId(objMoonId);

	if (!IsUsableItem(pItemSun) || !IsUsableItem(pItemMoon))
	{
		pUser->AddUltimateMakeItem(FALSE);
		return;
	}

	if (pItemSun->m_dwItemId != II_GEN_MAT_ORICHALCUM01 || pItemMoon->m_dwItemId != II_GEN_MAT_MOONSTONE)
	{
		pUser->AddUltimateMakeItem(FALSE);
		return;
	}

	if (pItemSun->m_nItemNum < 5 || pItemMoon->m_nItemNum < 5)
	{
		pUser->AddUltimateMakeItem(FALSE);
		return;
	}

	CItemElem itemElem;
	itemElem.m_dwItemId = II_GEN_MAT_ORICHALCUM02;
	itemElem.m_nItemNum = 1;
	itemElem.SetSerialNumber();
	itemElem.m_nHitPoint = 0;

	if (pUser->CreateItem(&itemElem))
	{
		pUser->RemoveItem((BYTE)objSunId, 5);
		pUser->RemoveItem((BYTE)objMoonId, 5);
		pUser->AddUltimateMakeItem(TRUE);
	}
	else
	{
		pUser->AddDefinedText(TID_GAME_EXTRACTION_ERROR);
		pUser->AddUltimateMakeItem(FALSE);
	}
}
void CDPSrvr::OnUltimateMakeGem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	OBJID objItemId;
	ar >> objItemId;

	int nNum;
	int nResult = prj.m_UltimateWeapon.MakeGem(pUser, objItemId, nNum);
	pUser->AddUltimateMakeGem(nResult, nNum);
}

void CDPSrvr::OnUltimateTransWeapon(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	OBJID objItemWeapon;
	OBJID objItemGem1;
	OBJID objItemGem2;
	OBJID objItemScroll;

	ar >> objItemWeapon;
	ar >> objItemGem1;
	ar >> objItemGem2;
	ar >> objItemScroll;

	int nResult = prj.m_UltimateWeapon.TransWeapon(pUser, objItemWeapon, objItemGem1, objItemGem2, objItemScroll);
	pUser->AddSmeltSafety(nResult);
}

void CDPSrvr::OnUltimateSetGem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	OBJID objItemWeapon;
	OBJID objItemGem;

	ar >> objItemWeapon;
	ar >> objItemGem;

	int nResult = prj.m_UltimateWeapon.SetGem(pUser, objItemWeapon, objItemGem);
	pUser->AddUltimateWeapon(ULTIMATE_SETGEM, nResult);
}

void CDPSrvr::OnUltimateRemoveGem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	OBJID objItemWeapon;
	OBJID objItemGem;

	ar >> objItemWeapon;
	ar >> objItemGem;

	int nSlot2;
	ar >> nSlot2;

	if (nSlot2 < 0 || nSlot2 > 4)
		return;

	int nResult = prj.m_UltimateWeapon.RemoveGem(pUser, objItemWeapon, objItemGem, nSlot2);

	if (nResult == CUltimateWeapon::ULTIMATE_SUCCESS)
	{

		pUser->AddDefinedText(TID_GAME_REMOVEGEM_SUCCESS, "");
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if ((pUser->IsMode(TRANSPARENT_MODE)) == 0)
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	}
	else if (nResult == CUltimateWeapon::ULTIMATE_FAILED)
	{

		pUser->AddDefinedText(TID_GAME_REMOVEGEM_FAILED, "");
		pUser->AddPlaySound(SND_INF_UPGRADEFAIL);
		if ((pUser->IsMode(TRANSPARENT_MODE)) == 0)
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_FAIL, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	}
	pUser->AddUltimateWeapon(ULTIMATE_REMOVEGEM, nResult);
}

void CDPSrvr::OnUltimateEnchantWeapon(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	OBJID objItemWeapon;
	OBJID objItemGem;

	ar >> objItemWeapon;
	ar >> objItemGem;

	int nResult = prj.m_UltimateWeapon.EnchantWeapon(pUser, objItemWeapon, objItemGem);

	if (nResult == CUltimateWeapon::ULTIMATE_SUCCESS)
	{

		pUser->AddDefinedText(TID_UPGRADE_SUCCEEFUL, "");
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if ((pUser->IsMode(TRANSPARENT_MODE)) == 0)
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	}
	else if (nResult == CUltimateWeapon::ULTIMATE_FAILED)
	{

		pUser->AddDefinedText(TID_UPGRADE_FAIL, "");
		pUser->AddPlaySound(SND_INF_UPGRADEFAIL);
		if ((pUser->IsMode(TRANSPARENT_MODE)) == 0)
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_FAIL, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	}
	pUser->AddUltimateWeapon(ULTIMATE_ENCHANTWEAPON, nResult);
}

void CDPSrvr::InviteParty(u_long uLeaderid, u_long uMemberid, BOOL bTroup)
{
	CUser* pLeader = g_UserMng.GetUserByPlayerID(uLeaderid);
	CUser* pMember = g_UserMng.GetUserByPlayerID(uMemberid);

	if (IsValidObj(pLeader) == FALSE)
	{
		return;
	}

	if (IsValidObj(pMember) == FALSE)
	{
		pLeader->AddDefinedText(TID_GAME_PARTYINVATEOTHERSVR);
		return;
	}

	if (pLeader == pMember)
		return;

	const DWORD dwResult = g_PartyMng.CanInviteParty(uLeaderid, uMemberid);
	if (dwResult == 5)
	{
#ifdef __FL_FIX_IDCHANGE_EXPLOIT // Party
		BOOL bFound = FALSE;
		for (auto& it : pLeader->vecPartyInvites)
		{
			if (it.dwInvieMember == uMemberid)
			{
				it.dwTimeEnd = GetTickCount() + MIN(10);
				bFound = TRUE;
				break;
			}
		}

		if (!bFound)
		{
			INVITE_REQUESTS tmp;
			tmp.dwInvieMember = uMemberid;
			tmp.dwTimeEnd = GetTickCount() + MIN(10);
			pLeader->vecPartyInvites.push_back(tmp);
		}
#endif

		pMember->AddPartyRequest(pLeader, pMember, bTroup);
	}
	else
	{
		switch (dwResult)
		{
		case 1:
			pLeader->AddDefinedText(TID_GAME_PARTYEXISTCHR, "\"%s\"", pMember->GetName());
			break;

		case 2:
			pLeader->AddDefinedText(TID_GAME_PARTYNOINVATE);
			break;

		case 3:
			pLeader->AddDefinedText(TID_GAME_FULLPARTY3);
			break;

		case 4:
			pLeader->AddDefinedText(TID_GAME_GUILDCOMBAT_CANNOT_PARTY);
			break;

		default:
			break;
		}
	}
}

void CDPSrvr::InviteCompany(CUser* pUser, OBJID objid)
{
#if __VER >= 12 // __SECRET_ROOM
	if (!IsInviteAbleGuild(pUser ? pUser->m_idGuild : NULL, pUser))
	{
		return;
	}
#endif // __SECRET_ROOM

	if (IsValidObj(pUser))
	{
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
		if (ZckRefusStaff(pUser, "invitation de guilde"))
			return;
#else
#line 6951 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
		CUser* pUsertmp = prj.GetUser(objid);
		if (IsValidObj(pUsertmp))
		{
			if (pUser == pUsertmp)
				return;

			CGuild* pGuild = g_GuildMng.GetGuild(pUser->m_idGuild);
			if (pGuild)
			{
				CGuildMember* pMember = pGuild->GetMember(pUser->m_idPlayer);
				if (!pMember)
				{
					// is not member
					return;
				}
				if (!pGuild->IsCmdCap(pMember->m_nMemberLv, PF_INVITATION))
				{
					// have no power
					pUser->AddDefinedText(TID_GAME_GUILDINVAITNOTWARR);
					return;
				}
				CGuild* pGuildtmp = g_GuildMng.GetGuild(pUsertmp->m_idGuild);
				if (pGuildtmp && pGuildtmp->IsMember(pUsertmp->m_idPlayer))
				{
					// is already guild member
					pUser->AddDefinedText(TID_GAME_COMACCEPTHAVECOM, "%s", pUsertmp->GetName(TRUE));
				}
				else
				{

#ifdef __FL_FIX_IDCHANGE_EXPLOIT // Guild
					BOOL bFound = FALSE;
					for (auto& it : pUser->vecGuildInvites)
					{
						if (it.dwInvieMember == pUsertmp->m_idPlayer)
						{
							it.dwTimeEnd = GetTickCount() + MIN(10);
							bFound = TRUE;
							break;
						}
					}

					if (!bFound)
					{
						INVITE_REQUESTS tmp;
						tmp.dwInvieMember = pUsertmp->m_idPlayer;
						tmp.dwTimeEnd = GetTickCount() + MIN(10);
						pUser->vecGuildInvites.push_back(tmp);
					}
#endif

					pUsertmp->m_idGuild = 0;
					pUsertmp->AddGuildInvite(pGuild->m_idGuild, pUser->m_idPlayer);
					pUser->AddDefinedText(TID_GAME_COMACCEPTKINGPIN, "%s", pUsertmp->GetName(TRUE));
				}
			}
		}
	}
}

#if __VER >= 12 // __SECRET_ROOM
#ifndef __FL_GUILD_FINDER
BOOL CDPSrvr::IsInviteAbleGuild(CUser* pUser)
{
	CGuild* pGuild = pUser->GetGuild();
	if (!pGuild)
		return FALSE;


	if (g_GuildCombatMng.m_nState != CGuildCombat::CLOSE_STATE)
	{
		if (g_GuildCombatMng.FindGuildCombatMember(pUser->m_idGuild) &&
			g_GuildCombatMng.FindGuildCombatMember(pUser->m_idGuild)->bRequest)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_INVITATION_GUILD);
			return FALSE;
		}
	}


	if (CSecretRoomMng::GetInstance()->m_nState != SRMNG_CLOSE)
	{
		map<BYTE, CSecretRoomContinent*>::iterator it = CSecretRoomMng::GetInstance()->m_mapSecretRoomContinent.begin();
		for (; it != CSecretRoomMng::GetInstance()->m_mapSecretRoomContinent.end(); it++)
		{
			CSecretRoomContinent* pSRCont = it->second;
			if (pSRCont && (pSRCont->GetTenderGuild(pGuild->GetGuildId()) != NULL_ID))
			{
				pUser->AddDefinedText(TID_GAME_SECRETROOM_NOT_INVITATION_GUILD);
				return FALSE;
			}
		}
	}

	return TRUE;
}
#else
BOOL CDPSrvr::IsInviteAbleGuild(u_long idGuild, CUser* pUser)
{
	CGuild* pGuild = g_GuildMng.GetGuild(idGuild);
	if (!pGuild)
		return FALSE;

	if (g_GuildCombatMng.m_nState != CGuildCombat::CLOSE_STATE)
	{
		if (g_GuildCombatMng.FindGuildCombatMember(idGuild) &&
			g_GuildCombatMng.FindGuildCombatMember(idGuild)->bRequest)
		{
			if (IsValidObj(pUser))
				pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_INVITATION_GUILD);

			return FALSE;
		}
	}


	if (CSecretRoomMng::GetInstance()->m_nState != SRMNG_CLOSE)
	{
		map<BYTE, CSecretRoomContinent*>::iterator it = CSecretRoomMng::GetInstance()->m_mapSecretRoomContinent.begin();
		for (; it != CSecretRoomMng::GetInstance()->m_mapSecretRoomContinent.end(); it++)
		{
			CSecretRoomContinent* pSRCont = it->second;
			if (pSRCont && (pSRCont->GetTenderGuild(idGuild) != NULL_ID))
			{
				if (IsValidObj(pUser))
					pUser->AddDefinedText(TID_GAME_SECRETROOM_NOT_INVITATION_GUILD);

				return FALSE;
			}
		}
	}

	return TRUE;
}
#endif
#endif // __SECRET_ROOM

void CDPSrvr::OnPetRelease(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (!pUser->HasActivatedSystemPet())
			pUser->AddDefinedText(TID_GAME_PET_NOT_FOUND);
		else
		{
			CItemElem* pItemElem = pUser->GetPetItem();
			if (pItemElem && pItemElem->m_pPet)
				pUser->PetRelease();
		}
	}
}

void CDPSrvr::OnUsePetFeed(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CPet* pPet = pUser->GetPet();
		if (pPet == NULL)
		{
			pUser->AddDefinedText(TID_GAME_PET_NOT_FOUND);
			return;
		}
#ifdef __ZCK_FISH_AND_QOL
		// __PET_EXP de Sakura : l'experience vient des monstres tues (CAttackArbiter::OnDied) ; la nourriture
		// est refusee avant toute lecture du paquet, rien n'est consomme.
		pUser->AddText("Les familiers ne mangent plus : ils gagnent de l'exp\351rience quand vous tuez des monstres.", ZCK_FAQ_COULEUR_REFUS);
		return;
#else
#line 7335 // __ZCK_FISH_AND_QOL
#endif // __ZCK_FISH_AND_QOL

		DWORD dwFeedId;
		ar >> dwFeedId;

		CItemElem* pFeed = static_cast<CItemElem*>(pUser->m_Inventory.GetAtId(dwFeedId));
		if (IsUsableItem(pFeed) == FALSE)
			return;

		if (!pFeed->IsFeed())
			return;

		short nNum = pFeed->m_nItemNum;

		int nMaxNum = 0;
		if (pPet->GetLevel() == PL_EGG)
			nMaxNum = MAX_PET_EGG_EXP - pPet->GetExp();
		else
		{
			nMaxNum = pPet->GetMaxEnergy() - pPet->GetEnergy();
			nMaxNum /= 2;
		}

		if (nNum > nMaxNum)
			nNum = nMaxNum;
		if (nNum < 1)
			return;

		if (pPet->GetLevel() == PL_EGG)
		{
			pPet->SetExp(pPet->GetExp() + nNum);
			pUser->AddPetSetExp(pPet->GetExp());
		}
		else
		{
			pPet->SetEnergy(pPet->GetEnergy() + nNum * 2);
			g_UserMng.AddPetFeed(pUser, pPet->GetEnergy());
		}

		pUser->RemoveItem((BYTE)(pFeed->m_dwObjId), nNum);
		pUser->AddDefinedText(TID_GAME_PETFEED_S01, "%d", nNum);
	}
}

void CDPSrvr::OnMakePetFeed(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		DWORD dwMaterialId, dwToolId;
		short nNum;

		ar >> dwMaterialId >> dwToolId >> nNum;

		BOOL bTool = FALSE;
		CItemElem* pTool = NULL;
		if (dwToolId != NULL_ID)
		{
			pTool = pUser->m_Inventory.GetAtId(dwToolId);
			if (IsUsableItem(pTool))
			{
				if (pTool->m_dwItemId == II_SYS_SYS_FEED_MAKER)
					bTool = TRUE;
			}

			if (!bTool)	// error
				return;
		}

		if (bTool == FALSE && CNpcChecker::GetInstance()->IsCloseNpc(MMI_PET_FOODMILL, pUser->GetWorld(), pUser->GetPos()) == FALSE)
			return;

		CItemElem* pMaterial = pUser->m_Inventory.GetAtId(dwMaterialId);
		if (!IsUsableItem(pMaterial))
			return;

		ItemProp* pProp = pMaterial->GetProp();
		if (pProp == NULL)
			return;

		if (pProp->dwItemKind3 != IK3_GEM)
		{
			pUser->AddDefinedText(TID_GAME_PET_IS_NOT_FEED);
			return;
		}

		if (nNum < 1)
			nNum = 1;
		if (nNum > pMaterial->m_nItemNum)
			nNum = pMaterial->m_nItemNum;

		if (pUser->m_Inventory.IsEquip(dwMaterialId))
		{
			pUser->AddDefinedText(TID_GAME_PET_FEED_EQUIPED);
			return;
		}

		CItemElem itemElem;
		itemElem.m_dwItemId = II_SYS_SYS_FEED_01;
		int nTotalFeed = 0;
		int nPackMax = itemElem.GetProp()->dwPackMax;
		for (int i = 0; i < nNum; i++)
		{
			int nFeed = CPetProperty::GetInstance()->GetFeedEnergy(pProp->dwCost, (int)bTool);
			if (nTotalFeed + nFeed > nPackMax)
			{
				nNum = i;
				break;
			}
			nTotalFeed += nFeed;
		}
		itemElem.m_nItemNum = nTotalFeed;
		itemElem.m_nHitPoint = -1;

		int nResult = pUser->CreateItem(&itemElem);
		if (nResult)
		{
			LogItemInfo aLogItem;
			aLogItem.Action = "~";
			aLogItem.SendName = pUser->GetName();
			aLogItem.RecvName = "PET_FOOD_MATERIAL_REMOVE";
			aLogItem.WorldId = pUser->GetWorld()->GetID();
			aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();
			OnLogItem(aLogItem, pMaterial, nNum);

			aLogItem.RecvName = "PET_FOOD_CREATE";
			OnLogItem(aLogItem, &itemElem, itemElem.m_nItemNum);

			pUser->RemoveItem((BYTE)(pMaterial->m_dwObjId), nNum);
			if (bTool)
				pUser->RemoveItem((BYTE)(pTool->m_dwObjId), 1);
		}
		pUser->AddPetFoodMill(nResult, itemElem.m_nItemNum);
	}
}

void CDPSrvr::OnPetTamerMistake(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		ar >> dwId;
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwId);
		if (IsUsableItem(pItemElem) && pItemElem->m_dwItemId == II_SYS_SYS_SCR_PET_TAMER_MISTAKE) // m_dwItemId
		{
			CPet* pPet = pUser->GetPet();
			if (pPet)
			{
				if (pPet->GetLevel() >= PL_C && pPet->GetLevel() <= PL_S)
				{
					pPet->SetAvailLevel(pPet->GetLevel(), 0);
					pPet->SetLevel(pPet->GetLevel() - 1);
					pPet->SetExp(MAX_PET_EXP);

					if (pUser->HasPet())
						pUser->RemovePet();
					pUser->AddPet(pPet, PF_PET_LEVEL_DOWN);
					g_UserMng.AddPetLevelup(pUser, MAKELONG((WORD)pPet->GetIndex(), (WORD)pPet->GetLevel()));
					pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), 1);
#ifdef __ZCK_FISH_AND_QOL
					// __PET_AUTO_LEVEL_UP de Sakura : le familier redescendu a 100 % d'experience remonte aussitot,
					// avec un nouveau tirage de la caracteristique de ce niveau (PetLevelup, comme le dresseur).
					pUser->PetLevelup();
#else
#line 7494 // __ZCK_FISH_AND_QOL
#endif // __ZCK_FISH_AND_QOL
				}
				else
					pUser->AddDefinedText(TID_GAME_PET_BETWEEN_C_TO_S);
			}
			else
				pUser->AddDefinedText(TID_GAME_PET_NOT_FOUND);
		}
	}
}

void CDPSrvr::OnPetTamerMiracle(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		ar >> dwId;
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwId);
		if (IsUsableItem(pItemElem) && pItemElem->m_dwItemId == II_SYS_SYS_SCR_PET_TAMER_MIRACLE)
		{
			CPet* pPet = pUser->GetPet();
			if (pPet)
			{
				if (pPet->GetLevel() >= PL_B && pPet->GetLevel() <= PL_S)
				{
					pPet->SetAvailLevel(pPet->GetLevel() - 1, 0);
					pPet->SetAvailLevel(pPet->GetLevel(), 0);

					BYTE nAvailLevel = CPetProperty::GetInstance()->GetLevelupAvailLevel(pPet->GetLevel() - 1);
					pPet->SetAvailLevel(pPet->GetLevel() - 1, nAvailLevel);
					nAvailLevel = CPetProperty::GetInstance()->GetLevelupAvailLevel(pPet->GetLevel());
					pPet->SetAvailLevel(pPet->GetLevel(), nAvailLevel);

					if (pUser->HasPet())
						pUser->RemovePet();
					pUser->AddPet(pPet, PF_PET_GET_AVAIL);
					g_UserMng.AddPetLevelup(pUser, MAKELONG((WORD)pPet->GetIndex(), (WORD)pPet->GetLevel()));
					pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), 1);
				}
				else
					pUser->AddDefinedText(TID_GAME_PET_BETWEEN_B_TO_S);
			}
			else
				pUser->AddDefinedText(TID_GAME_PET_NOT_FOUND);
		}
	}
}

void CDPSrvr::OnFeedPocketInactive(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_PET_FEED_POCKET))
			pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_SCR_PET_FEED_POCKET);
	}
}

void CDPSrvr::OnModifyStatus(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nStrCount, nStaCount, nDexCount, nIntCount;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	ar >> nStrCount >> nStaCount >> nDexCount >> nIntCount;

	const int remainStatPoint = pUser->m_nRemainGP;

	if ((nStrCount < 0 || nStaCount < 0 || nDexCount < 0 || nIntCount < 0)
		|| (remainStatPoint < nStrCount || remainStatPoint < nStaCount || remainStatPoint < nDexCount || remainStatPoint < nIntCount))
	{
		return;
	}

	const __int64 sumModifyStatPoint = static_cast<__int64>(nStrCount) + static_cast<__int64>(nStaCount) + static_cast<__int64>(nDexCount) + static_cast<__int64>(nIntCount);
	if (sumModifyStatPoint <= 0 || remainStatPoint < sumModifyStatPoint)
	{
		return;
	}

	if (remainStatPoint >= (nStrCount + nStaCount + nDexCount + nIntCount))
	{
		pUser->m_nStr += nStrCount;
		pUser->m_nSta += nStaCount;
		pUser->m_nDex += nDexCount;
		pUser->m_nInt += nIntCount;
		pUser->m_nRemainGP = remainStatPoint - (nStrCount + nStaCount + nDexCount + nIntCount);
		g_UserMng.AddStatInfo(pUser, FALSE);

		pUser->RefreshGrilledEel();

		pUser->CheckHonorStat();
		pUser->AddHonorListAck();
		g_UserMng.AddHonorTitleChange(pUser, pUser->m_nHonor);

#ifdef __FL_RECORD_BOOK
		if (nStrCount > 0)
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::STR, pUser->GetStr(), false);

		if (nStaCount > 0)
		{
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::STA, pUser->GetSta(), false);
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::HP, pUser->GetMaxHitPoint(), false);
		}

		if (nDexCount > 0)
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::DEX, pUser->GetDex(), false);

		if (nIntCount > 0)
			CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::INTT, pUser->GetInt(), false);
#endif
	}
}

void CDPSrvr::OnQueryStartCollecting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (!pUser->GetWorld() || pUser->GetWorld()->GetID() != WI_WORLD_MADRIGAL)
			return;

		if (pUser->IsDie())
			return;
#ifdef __ZCK_FISH_AND_QOL
		// MAX_FISH_BY_IP de Sakura, recode : au plus ZCK_FAQ_MAX_PECHEURS_PAR_IP personnages qui collectent en meme
		// temps depuis une meme IP. Compte fait par ce WorldServer sur ses propres joueurs : la limite vaut par
		// canal. Un personnage qui collecte deja n'est pas recompte ; une IP vide n'est pas limitee.
		if (!pUser->IsCollecting() && pUser->m_playAccount.lpAddr[0] != '\0')
		{
			int nZckFaqPecheurs = 0;
			for (unordered_map<DWORD, CUser*>::iterator it = g_UserMng.m_users.begin(); it != g_UserMng.m_users.end(); ++it)
			{
				CUser* pZckFaqAutre = it->second;
				if (pZckFaqAutre == pUser || !IsValidObj(pZckFaqAutre) || !pZckFaqAutre->IsCollecting())
					continue;
				if (_tcsncmp(pZckFaqAutre->m_playAccount.lpAddr, pUser->m_playAccount.lpAddr, 16) == 0)
					++nZckFaqPecheurs;
			}
			if (nZckFaqPecheurs >= ZCK_FAQ_MAX_PECHEURS_PAR_IP)
			{
				CString strZckFaq;
				strZckFaq.Format("Collecte refus\351e : %d personnages collectent d\351j\340 depuis votre adresse IP sur ce canal (%d au plus).", nZckFaqPecheurs, ZCK_FAQ_MAX_PECHEURS_PAR_IP);
				pUser->AddText(strZckFaq, ZCK_FAQ_COULEUR_REFUS);
				return;
			}
		}
#else
#line 7620 // __ZCK_FISH_AND_QOL
#endif // __ZCK_FISH_AND_QOL

		pUser->StartCollecting();
	}
}

void CDPSrvr::OnQueryStopCollecting(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		pUser->StopCollecting();
}

#if __VER >= 11
void CDPSrvr::OnQueryGuildBankLogList(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	bool bMK = FALSE;
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		BYTE byListType;
		ar >> byListType;
		CGuild* pGuild = pUser->GetGuild();

		if (pGuild)
		{
			CGuildMember* pGuildMember = pGuild->GetMember(pUser->m_idPlayer);
			if (pGuildMember)
			{
				if (pGuildMember->m_nMemberLv == GUD_KINGPIN || pGuildMember->m_nMemberLv == GUD_MASTER)
					g_dpDBClient.SendQueryGetGuildBankLogList(pUser->m_idPlayer, pGuild->m_idGuild, byListType);
			}
		}

	}
}
#endif
#if __VER >= 13
void CDPSrvr::OnHonorListReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		pUser->AddHonorListAck();
	}
}
void CDPSrvr::OnHonorChangeReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		int nChange;
		ar >> nChange;
		if (nChange > -1 && nChange < MAX_HONOR_TITLE)
		{
			int nNeed = CTitleManager::Instance()->GetNeedCount(nChange, -1);
			if (nNeed < 0)
				return;
			if (pUser->GetHonorTitle(nChange) >= nNeed)
			{
				pUser->m_nHonor = nChange;
				g_UserMng.AddHonorTitleChange(pUser, nChange);
			}
		}
		else if (nChange == -1)
		{
			pUser->m_nHonor = nChange;
			g_UserMng.AddHonorTitleChange(pUser, nChange);
		}
	}
}
#endif

void	CDPSrvr::OnBlessednessCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_BLESSING_CANCEL, pUser->GetWorld(), pUser->GetPos()))
			return;

		int nItem;
		ar >> nItem;
		CItemElem* pItem = pUser->m_Inventory.GetAtId(nItem);
		if (IsUsableItem(pItem))
		{
			if (pUser->m_Inventory.IsEquip(pItem->m_dwObjId))
				return;

			if (g_xRandomOptionProperty->GetRandomOptionKind(pItem) == CRandomOptionProperty::eBlessing
				&& g_xRandomOptionProperty->GetRandomOptionSize(pItem->GetRandomOptItemId()) > 0)
			{
				g_xRandomOptionProperty->InitializeRandomOption(pItem->GetRandomOptItemIdPtr());
				pUser->UpdateItemEx((BYTE)(pItem->m_dwObjId), UI_RANDOMOPTITEMID, pItem->GetRandomOptItemId());
				pUser->AddDiagText(prj.GetText(TID_GAME_BLESSEDNESS_CANCEL_INFO));

				// log
				LogItemInfo	log;
				log.Action = "r";
				log.SendName = pUser->GetName();
				log.RecvName = "OnBlessednessCancel";
				log.WorldId = pUser->GetWorld()->GetID();
				log.Gold = pUser->GetGold();
				log.Gold2 = pUser->GetGold();
				OnLogItem(log, pItem, 1);
			}
			else
			{
				pUser->AddDefinedText(TID_GAME_BLESSEDNESS_CANCEL);
			}
		}
	}
}

#ifdef __NPC_BUFF
void	CDPSrvr::OnNPCBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CHAR	m_szKey[64];
		ar.ReadString(m_szKey, 64);
		LPCHARACTER lpChar = prj.GetCharacter(m_szKey);

		if (lpChar)
		{
			if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_NPC_BUFF, pUser->GetWorld(), pUser->GetPos()))
				return;

#ifdef __ZCK_BUFF_GROUPE
			// Bifurcation SOLO / GROUPE, juste apres le controle de proximite
			// du NPC, qui ne concerne que le joueur qui clique.
			//
			//   GROUPE : ZckBuffClasse.inc pour tous les membres valides du
			//            groupe presents dans WI_WORLD_MADRIGAL, lanceur
			//            compris, chacun selon sa propre lignee et son propre
			//            niveau, sans aucune condition de distance. Puis
			//            SORTIE : la boucle m_vecNPCBuffSkill (character.inc)
			//            ci-dessous n'est pas executee.
			//   SOLO   : on tombe dans la boucle m_vecNPCBuffSkill d'origine,
			//            character.inc uniquement ; ZckBuffClasse.inc
			//            n'intervient pas.
			//
			// Propager revalide lpChar->m_abMoverMenu[MMI_NPC_BUFF] et le
			// cooldown du lanceur de son cote.
			if (CZckBuffGroupeManager::GetGroupe(pUser) != NULL)
			{
				CZckBuffGroupeManager::GetInstance()->Propager(pUser, lpChar);
				return;
			}
#else
#ifdef __ZCK_BUFF_CLASSE
			// Sans __ZCK_BUFF_GROUPE : comportement d'origine de
			// __ZCK_BUFF_CLASSE, buffs de classe au joueur qui clique, puis
			// boucle character.inc ci-dessous.
			CZckBuffClasseManager::GetInstance()->Appliquer(pUser, lpChar);
#endif // __ZCK_BUFF_CLASSE
#endif // __ZCK_BUFF_GROUPE

			vector<NPC_BUFF_SKILL> vecNPCBuff = lpChar->m_vecNPCBuffSkill;
			for (int i = 0; i < (int)(vecNPCBuff.size()); i++)
			{
				if (pUser->GetLevel() >= vecNPCBuff[i].nMinPlayerLV && pUser->GetLevel() <= vecNPCBuff[i].nMaxPlayerLV)
				{
					ItemProp* pSkillProp = prj.GetSkillProp(vecNPCBuff[i].dwSkillID);
					if (pSkillProp)
					{
						if (vecNPCBuff[i].dwSkillLV < pSkillProp->dwExpertLV || vecNPCBuff[i].dwSkillLV > pSkillProp->dwExpertMax)
							continue;

						if ((pSkillProp->dwID == SI_GEN_EVE_QUICKSTEP && pUser->HasBuff(BUFF_SKILL, SI_ASS_CHEER_QUICKSTEP))
							|| (pSkillProp->dwID == SI_GEN_EVE_HASTE && pUser->HasBuff(BUFF_SKILL, SI_ASS_CHEER_HASTE))
							|| (pSkillProp->dwID == SI_GEN_EVE_HEAPUP && pUser->HasBuff(BUFF_SKILL, SI_ASS_CHEER_HEAPUP))
							|| (pSkillProp->dwID == SI_GEN_EVE_ACCURACY && pUser->HasBuff(BUFF_SKILL, SI_ASS_CHEER_ACCURACY)))
						{
							pUser->AddDefinedText(TID_GAME_NPCBUFF_FAILED, "\"%s\"", pSkillProp->szName);
							continue;
						}

						AddSkillProp* pAddSkillProp = prj.GetAddSkillProp(pSkillProp->dwSubDefine + vecNPCBuff[i].dwSkillLV - 1);
						if (pAddSkillProp)
						{


							DWORD dwReferTarget1Backup = pSkillProp->dwReferTarget1;
							pSkillProp->dwReferTarget1 = NULL_ID;
							DWORD dwReferTarget2Backup = pSkillProp->dwReferTarget2;
							pSkillProp->dwReferTarget2 = NULL_ID;
							DWORD dwSkillTimeBackup = pAddSkillProp->dwSkillTime;
							pAddSkillProp->dwSkillTime = vecNPCBuff[i].dwSkillTime;

							pUser->DoApplySkill(pUser, pSkillProp, pAddSkillProp);
							g_UserMng.AddDoApplySkill(pUser, pUser->GetId(), vecNPCBuff[i].dwSkillID, vecNPCBuff[i].dwSkillLV);

							pSkillProp->dwReferTarget1 = dwReferTarget1Backup;
							pSkillProp->dwReferTarget2 = dwReferTarget2Backup;
							pAddSkillProp->dwSkillTime = dwSkillTimeBackup;
						}
					}
				}
				else
				{
					ItemProp* pSkillProp = prj.GetSkillProp(vecNPCBuff[i].dwSkillID);
					if (pSkillProp)
						pUser->AddDefinedText(TID_GAME_NPCBUFF_LEVELLIMIT, "%d %d \"%s\"", vecNPCBuff[i].nMinPlayerLV, vecNPCBuff[i].nMaxPlayerLV, pSkillProp->szName);
				}
			}
		}
	}
}
#endif // __NPC_BUFF

#ifdef __JEFF_11_4
void	CDPSrvr::OnArenaEnter(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		pUser->SetMarkingPos();
		pUser->REPLACE(g_uIdofMulti, WI_WORLD_ARENA, D3DXVECTOR3(540.0F, 140.0F, 485.0F), REPLACE_NORMAL, nDefaultLayer);
	}
}

void	CDPSrvr::OnArenaExit(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		if (pUser->GetWorld() && pUser->GetWorld()->IsArena())
		{
			if (pUser->m_idMarkingWorld)
				pUser->REPLACE(g_uIdofMulti, pUser->m_idMarkingWorld, pUser->m_vMarkingPos, REPLACE_NORMAL, nTempLayer);
			else
				pUser->REPLACE(g_uIdofMulti, WI_WORLD_MADRIGAL, D3DXVECTOR3(6968.0f, 0.0f, 3328.8f), REPLACE_NORMAL, nDefaultLayer);
		}
	}
}
#endif	// __JEFF_11_4

void	CDPSrvr::OnQuePetResurrection(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		int nItem;
		ar >> nItem;
		CItemElem* pItem = pUser->m_Inventory.GetAtId(nItem);
		if (!IsUsableItem(pItem))
			return;

		CPet* pPet = pItem->m_pPet;
		if (!pPet || pUser->GetPetId() == pItem->m_dwObjId || pItem->IsFlag(CItemElem::expired))
		{
			pUser->AddQuePetResurrectionResult(FALSE);
			return;
		}

		BYTE nLevel = pPet->GetLevel();
		if (nLevel < PL_B || nLevel > PL_S)
		{
			pUser->AddQuePetResurrectionResult(FALSE);
			return;
		}

		CItemElem itemElem;
		itemElem.m_nItemNum = 1;
		switch (nLevel)
		{
		case PL_B:	itemElem.m_dwItemId = II_SYS_SYS_QUE_PETRESURRECTION01_B;	break;
		case PL_A:	itemElem.m_dwItemId = II_SYS_SYS_QUE_PETRESURRECTION01_A;	break;
		case PL_S:	itemElem.m_dwItemId = II_SYS_SYS_QUE_PETRESURRECTION01_S;	break;
		}

		// log
		LogItemInfo	log;
		log.Action = "x";
		log.SendName = pUser->GetName();
		log.RecvName = "OnQuePetResurrection";
		OnLogItem(log, pItem, 1);

		pUser->RemoveItem(nItem, 1);
		pUser->CreateItem(&itemElem);
		pUser->AddQuePetResurrectionResult(TRUE);
	}
}

#if __VER >= 12 // __SECRET_ROOM
void	CDPSrvr::OnSecretRoomTenderOpenWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CSecretRoomMng::GetInstance()->SetTenderOpenWnd(pUser);
}

void	CDPSrvr::OnSecretRoomTender(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	int nPenya;
	ar >> nPenya;

	if (nPenya <= 0)
		return;

	CSecretRoomMng::GetInstance()->SetTender(pUser, nPenya);
}

void	CDPSrvr::OnSecretRoomTenderCancelReturn(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CSecretRoomMng::GetInstance()->SetTenderCancelReturn(pUser);
}

void	CDPSrvr::OnSecretRoomLineUpOpenWnd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CSecretRoomMng::GetInstance()->SetLineUpOpenWnd(pUser);
}

void	CDPSrvr::OnSecretRoomLineUpMember(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	set<DWORD> checker;
	vector<DWORD> vecLineUpMember;
	int nSize;
	ar >> nSize;

	if (nSize > CSecretRoomMng::GetInstance()->m_nMaxGuildMemberNum)
		return;

	for (int i = 0; i < nSize; i++)
	{
		DWORD dwIdPlayer;
		ar >> dwIdPlayer;


		PlayerData* pData = CPlayerDataCenter::GetInstance()->GetPlayerData(dwIdPlayer);
		if (!pData)
			return;


		if (!checker.insert(dwIdPlayer).second)
			return;

		vecLineUpMember.push_back(dwIdPlayer);
	}

	CSecretRoomMng::GetInstance()->SetLineUp(pUser, vecLineUpMember);
}

void	CDPSrvr::OnSecretRoomEntrance(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CSecretRoomMng::GetInstance()->SetTeleportSecretRoom(pUser);
}

void	CDPSrvr::OnSecretRoomTeleportToNPC(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;
	pUser->REPLACE(g_uIdofMulti, WI_WORLD_MADRIGAL, CSecretRoomMng::GetInstance()->GetRevivalPos(pUser), REPLACE_NORMAL, nDefaultLayer);
}

void CDPSrvr::OnSecretRoomTenderView(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	CSecretRoomMng::GetInstance()->GetTenderView(pUser);
}

#endif // __SECRET_ROOM

#if __VER >= 12 // __LORD
void CDPSrvr::OnElectionAddDeposit(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		__int64 iTotal;
		ar >> iTotal;

		__int64 iDeposit;
		int nRet = election::AddDepositRequirements(pUser, iTotal, iDeposit);
		if (nRet)
		{
			pUser->AddDefinedText(nRet);
			return;
		}
		pUser->AddGold(-static_cast<int>(iDeposit));
		g_dpDBClient.SendElectionAddDeposit(pUser->m_idPlayer, iDeposit);

		PutPenyaLog(pUser, "d", "DEPOSIT", static_cast<int>(iDeposit));
	}
}

void CDPSrvr::PutItemLog(CUser* pUser, const char* szAction, const char* szContext, CItemElem* pItem, int nNum)
{
	if (!IsValidObj(pUser))
		return;

	LogItemInfo	log;
	log.Action = szAction;
	log.SendName = pUser->GetName();
	log.RecvName = szContext;
	log.WorldId = pUser->GetWorld() ? pUser->GetWorld()->GetID() : WI_WORLD_NONE;
	log.Gold = pUser->GetGold();
	log.Gold2 = pUser->GetGold();
	if (nNum == 0)
		nNum = pItem->m_nItemNum;
	OnLogItem(log, pItem, nNum);
}

void CDPSrvr::PutPenyaLog(CUser* pUser, const char* szAction, const char* szContext, int nCost)
{
	LogItemInfo	log;
	log.Action = szAction;
	log.SendName = pUser->GetName();
	log.RecvName = szContext;
	log.WorldId = pUser->GetWorld() ? pUser->GetWorld()->GetID() : WI_WORLD_NONE;
	//log.ItemName	= "SEED";
	_stprintf(log.szItemName, "%d", II_GOLD_SEED1);
	log.Gold = pUser->GetGold() + nCost;
	log.Gold2 = pUser->GetGold();
	log.Gold_1 = -nCost;
	OnLogItem(log);
}

void CDPSrvr::OnElectionSetPledge(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	char szPledge[CCandidate::nMaxPledgeLen] = { 0, };
	ar.ReadString(szPledge, CCandidate::nMaxPledgeLen);
	if (strlen(szPledge) == 0)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{

#ifdef __FIX_SQL_INJECTS // test thingy
		CString str = szPledge;
		if (str.Find("--") >= 0 || str.Find("'") >= 0 || str.Find("/*") >= 0 || str.Find("*/") >= 0 || str.Find(";") >= 0
			|| str.Find("--") >= 0 || str.Find("'") >= 0 || str.Find("/*") >= 0 || str.Find("*/") >= 0 || str.Find(";") >= 0)
		{
			pUser->AddDefinedText(TID_DIAG_0013);
			return;
		}
#endif

		int nCost;
		int nRet = election::SetPledgeRequirements(pUser, nCost);
		if (nRet)
		{
			pUser->AddDefinedText(nRet);
			return;
		}
		pUser->AddGold(-nCost);
		g_dpDBClient.SendElectionSetPledge(pUser->m_idPlayer, szPledge);

		PutPenyaLog(pUser, "p", "PLEDGE", nCost);
	}
}

void CDPSrvr::OnElectionIncVote(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		u_long idPlayer;
		ar >> idPlayer;

		int nRet = election::IncVoteRequirements(pUser, idPlayer);
		if (nRet)
		{
			pUser->AddDefinedText(nRet);
			return;
		}
		g_dpDBClient.SendElectionIncVote(idPlayer, pUser->m_idPlayer);
	}
}

#ifndef __FL_UPDATE_LORDEVENT
void CDPSrvr::OnLEventCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		int iEEvent, iIEvent;
		ar >> iEEvent >> iIEvent;
		int nRet = lordevent::CreateRequirements(pUser, iEEvent, iIEvent);
		if (nRet)
		{
			pUser->AddDefinedText(nRet);
			return;
		}
		ILordEvent* pEvent = CSLord::Instance()->GetEvent();

		int nPerin = pUser->RemoveTotalGold(pEvent->GetCost(iEEvent, iIEvent));
		char szContext[100] = { 0, };
		sprintf(szContext, "OnLEventCreate: cost: %d(perin), %I64d(penya)", nPerin, pEvent->GetCost(iEEvent, iIEvent) - (nPerin * PERIN_VALUE));
		PutPenyaLog(pUser, "e", szContext, 0);

		g_dpDBClient.SendLEventCreate(pUser->m_idPlayer, iEEvent, iIEvent);
	}
}
#else
void CDPSrvr::OnLEventCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		int iEEvent, iIEvent;
		ar >> iEEvent >> iIEvent;
		int iPEvent;
		ar >> iPEvent;

		int nRet = lordevent::CreateRequirements(pUser, iEEvent, iIEvent, iPEvent);
		if (nRet)
		{
			pUser->AddDefinedText(nRet);
			return;
		}
		ILordEvent* pEvent = CSLord::Instance()->GetEvent();

		int nPerin = pUser->RemoveTotalGold(pEvent->GetCost(iEEvent, iIEvent, iPEvent));
		char szContext[100] = { 0, };
		sprintf(szContext, "OnLEventCreate: cost: %d(perin), %I64d(penya)", nPerin, pEvent->GetCost(iEEvent, iIEvent, iPEvent) - (nPerin * PERIN_VALUE));
		PutPenyaLog(pUser, "e", szContext, 0);

		g_dpDBClient.SendLEventCreate(pUser->m_idPlayer, iEEvent, iIEvent, iPEvent);
	}
}
#endif

void CDPSrvr::OnLordSkillUse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		int nSkill;
		char szTarget[MAX_PLAYER] = { 0, };
		ar >> nSkill;
		ar.ReadString(szTarget, MAX_PLAYER);
		u_long idTarget;
		int nRet = lordskill::UseRequirements(pUser, szTarget, nSkill, idTarget);
		if (nRet)
		{
			pUser->AddDefinedText(nRet);
			return;
		}
		g_dpDBClient.SendLordSkillUse(pUser->m_idPlayer, idTarget, nSkill);
	}
}
#endif	// __LORD

#if __VER >= 12 // __TAX
void CDPSrvr::OnSetTaxRate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	BYTE nCont;
	int nSalesTaxRate, nPurchaseTaxRate;
	ar >> nCont;
	ar >> nSalesTaxRate >> nPurchaseTaxRate;

	__TAXINFO* pTaxInfo = CTax::GetInstance()->GetTaxInfo(nCont);
	if (pTaxInfo && pUser->m_idGuild == pTaxInfo->dwNextId && pUser->IsGuildMaster())
		CTax::GetInstance()->SetNextTaxRate(nCont, nSalesTaxRate, nPurchaseTaxRate);
}
#endif // __TAX

#if __VER >= 12 // __HEAVEN_TOWER
void CDPSrvr::OnTeleportToHeavenTower(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_HEAVEN_TOWER, pUser->GetWorld(), pUser->GetPos()))
		return;

	int nFloor;
	ar >> nFloor;

	int nCost = 0;
	DWORD dwWorldId = NULL_ID;
	float fAngle = 0.0f;
	D3DXVECTOR3 vPos;

	switch (nFloor)
	{
	case 1:
		nCost = 10000;	dwWorldId = WI_WORLD_HEAVEN01; vPos = D3DXVECTOR3(253, 102, 78); fAngle = 183.0f;
		break;
	case 2:
		nCost = 30000;	dwWorldId = WI_WORLD_HEAVEN02; vPos = D3DXVECTOR3(251, 102, 95); fAngle = 183.0f;
		break;
	case 3:
		nCost = 50000;	dwWorldId = WI_WORLD_HEAVEN03; vPos = D3DXVECTOR3(264, 102, 227); fAngle = 183.0f;
		break;
	case 4:
		nCost = 70000;	dwWorldId = WI_WORLD_HEAVEN04; vPos = D3DXVECTOR3(253, 102, 86); fAngle = 174.0f;
		break;
	case 5:
		nCost = 100000;	dwWorldId = WI_WORLD_HEAVEN05; vPos = D3DXVECTOR3(218, 102, 101); fAngle = 176.0f;
		break;

	default:
		Error("CDPSrvr::OnTeleportToHeavenTower() - �߸��� �� : %d, Name = %s", nFloor, pUser->GetName());
		return;
	}

	if (pUser->CheckUserGold(nCost, false) == false)
	{
		pUser->AddDefinedText(TID_GAME_LACKMONEY);
		return;
	}


	BYTE nCont = CTax::GetInstance()->GetContinent(pUser);
	if (pUser->REPLACE(g_uIdofMulti, dwWorldId, vPos, REPLACE_NORMAL, nDefaultLayer))
	{
		pUser->AddGold(-nCost);
		pUser->SetAngle(fAngle);

		__TAXINFO* pTaxInfo = CTax::GetInstance()->GetTaxInfo(nCont);
		if (pTaxInfo && pTaxInfo->dwId != NULL_ID)
			CTax::GetInstance()->AddTax(nCont, nCost, TAX_ADMISSION);

		CString strFloor;
		strFloor.Format("HEAVEN_TOWER_%2d", nFloor);
		PutPenyaLog(pUser, "h", strFloor, nCost);
	}
	else
		return;
}
#endif // __HEAVEN_TOWER

BOOL CDPSrvr::DoUseItemTarget_GenRandomOption(
	CUser* pUser, CItemElem* pTarget, int nKind,
	int nOk, int nMismatchKind, int nHasOption,
	const char* szOperation, const char* szReceive)
{
	int nRandomOptionKind = g_xRandomOptionProperty->GetRandomOptionKind(pTarget);
	if (nRandomOptionKind != nKind || pTarget->IsFlag(CItemElem::expired))
	{
		pUser->AddDefinedText(nMismatchKind);
		return FALSE;
	}

#ifdef __ZCK_SYSTEME_EVEIL
	// Liste blanche : le parchemin d'eveil natif suit la meme regle que la
	// fenetre. Bouclier, bijou, cape, masque : refus, parchemin non consomme.
	if (nKind == CRandomOptionProperty::eAwakening && !ZckAwakeIsAwakenableItem(pTarget))
	{
		pUser->AddDefinedText(nMismatchKind);
		return FALSE;
	}

    const BOOL bZckProtectionStaged =
        (nKind == CRandomOptionProperty::eAwakening &&
         pUser->IsZckAwakeProtectionStaged(pTarget));
#else
    const BOOL bZckProtectionStaged = FALSE;
#endif

	if (
#if __VER >= 12 // __J12_0
		nKind != CRandomOptionProperty::eBlessing && nKind != CRandomOptionProperty::eEatPet &&
#endif
        !bZckProtectionStaged &&
		g_xRandomOptionProperty->GetRandomOptionSize(pTarget->GetRandomOptItemId()) > 0
		)
	{
		pUser->AddDefinedText(nHasOption);
		return FALSE;
	}

	if (nOk > 0)
		pUser->AddDefinedText(nOk);

	if (pUser->IsUsing(pTarget)
		&& (nKind == CRandomOptionProperty::eSystemPet || nKind == CRandomOptionProperty::eEatPet))
		pUser->ResetDestParamRandomOptExtension(pTarget);


	//g_xRandomOptionProperty->InitializeRandomOption( pTarget->GetRandomOptItemIdPtr() );
	//g_xRandomOptionProperty->GenRandomOption( pTarget->GetRandomOptItemIdPtr(), nRandomOptionKind, pTarget->GetProp()->dwParts );
	bool bCheckedSafeFlag =
        g_xRandomOptionProperty->IsCheckedSafeFlag(pTarget->GetRandomOptItemId());

#ifdef __ZCK_SYSTEME_EVEIL
    ZCK_AWAKE_MASTERY_ROLL zckRoll;
    BOOL bZckAwakeGenerated = FALSE;
#endif

	if (bCheckedSafeFlag == true)
	{
		g_xRandomOptionProperty->ResetSafeFlag(pTarget->GetRandomOptItemIdPtr());

#ifdef __ZCK_SYSTEME_EVEIL
        if (nRandomOptionKind == CRandomOptionProperty::eAwakening)
        {
            if (!pUser->GenerateZckAwakeOption(
                pTarget,
                pTarget->GetNewRandomOptionPtr(),
                TRUE,
                FALSE,
                zckRoll))
            {
                // Restaure l'état Safe Awakening si la génération échoue.
                g_xRandomOptionProperty->SetSafeFlag(pTarget->GetRandomOptItemIdPtr());
                return FALSE;
            }
            bZckAwakeGenerated = TRUE;
        }
        else
#endif
        {
            g_xRandomOptionProperty->InitializeRandomOption(pTarget->GetNewRandomOptionPtr());
            if (!g_xRandomOptionProperty->GenRandomOption(
                pTarget->GetNewRandomOptionPtr(),
                nRandomOptionKind,
                pTarget->GetProp()->dwParts,
                true))
            {
                g_xRandomOptionProperty->SetSafeFlag(pTarget->GetRandomOptItemIdPtr());
                return FALSE;
            }
        }

		TCHAR szNewOption[128];
		::memset(szNewOption, 0, sizeof(szNewOption));
		::_stprintf(szNewOption, "%I64d", pTarget->GetNewRandomOption());
		g_DPSrvr.PutItemLog(pUser, "z", szNewOption, pTarget, 1);

		pUser->SendNewRandomOption(
            (BYTE)pTarget->m_dwObjId,
            (DWORD)pTarget->GetSerialNumber(),
            pTarget->GetNewRandomOption());
	}
	else
	{
#ifdef __ZCK_SYSTEME_EVEIL
        if (nRandomOptionKind == CRandomOptionProperty::eAwakening)
        {
            // Correctif 4 : ici la generation ecrit DIRECTEMENT dans
            // l'objet. Le mot d'origine est donc releve avant l'appel,
            // et n'est memorise qu'apres une generation reussie.
            const __int64 n64ZckBeforeAwake =
                pTarget->GetRandomOptItemId();

            if (!pUser->GenerateZckAwakeOption(
                pTarget,
                pTarget->GetRandomOptItemIdPtr(),
                FALSE,
                FALSE,
                zckRoll))
            {
                return FALSE;
            }

            pUser->ZckStorePreviousAwake(
                pTarget,
                n64ZckBeforeAwake);

            bZckAwakeGenerated = TRUE;
        }
        else
#endif
        {
            g_xRandomOptionProperty->InitializeRandomOption(pTarget->GetRandomOptItemIdPtr());
            if (!g_xRandomOptionProperty->GenRandomOption(
                pTarget->GetRandomOptItemIdPtr(),
                nRandomOptionKind,
                pTarget->GetProp()->dwParts))
            {
                return FALSE;
            }
        }
	}


	pUser->UpdateItemEx((BYTE)(pTarget->m_dwObjId), UI_RANDOMOPTITEMID, pTarget->GetRandomOptItemId());

#ifdef __ZCK_SYSTEME_EVEIL
    if (bZckAwakeGenerated)
    {
        const __int64 nZckGeneratedOption =
            bCheckedSafeFlag ? pTarget->GetNewRandomOption() : pTarget->GetRandomOptItemId();

        pUser->CommitZckAwakeMastery(
            pTarget,
            nZckGeneratedOption,
            zckRoll);
    }
#endif

#if __VER >= 12 // __PET_0519

	if (pUser->IsUsing(pTarget)
		&& (nKind == CRandomOptionProperty::eSystemPet || nKind == CRandomOptionProperty::eEatPet))
		pUser->SetDestParamRandomOptExtension(pTarget);
#endif	// __PET_0519

#ifdef __FL_RECORD_BOOK
	CRecordBook::GetInstance()->AddPlayerRecord(pUser, RecordType::AWAKES_COUNT, 1, true);
#endif

	// log
	LogItemInfo	log;
	log.Action = szOperation;
	log.SendName = pUser->GetName();
	log.RecvName = szReceive;
	log.WorldId = pUser->GetWorld()->GetID();
	log.Gold = pUser->GetGold();
	log.Gold2 = pUser->GetGold();
	OnLogItem(log, pTarget, 1);

	return TRUE;
}

BOOL CDPSrvr::DoUseItemTarget_InitializeRandomOption(
	CUser* pUser, CItemElem* pTarget, int nKind,
	int nOk, int nError,
	const char* szOperation, const char* szRecv)
{
	int nRandomOptionKind = g_xRandomOptionProperty->GetRandomOptionKind(pTarget);
	if (nRandomOptionKind == nKind && g_xRandomOptionProperty->GetRandomOptionSize(pTarget->GetRandomOptItemId()) > 0)
	{
#ifdef __ZCK_SYSTEME_EVEIL
		// Correctif 4 : mot d'eveil releve AVANT toute destruction.
		// Sert au bloc de fin de fonction a decider si le point de
		// retour persiste est devenu perime.
		const __int64 n64ZckBeforeCancel = pTarget->GetRandomOptItemId();
#endif // __ZCK_SYSTEME_EVEIL
#if __VER >= 12 // __PET_0519

		if (pUser->IsUsing(pTarget)
			&& (nKind == CRandomOptionProperty::eSystemPet || nKind == CRandomOptionProperty::eEatPet))
			pUser->ResetDestParamRandomOptExtension(pTarget);
#endif	// __PET_0519


		//g_xRandomOptionProperty->InitializeRandomOption( pTarget->GetRandomOptItemIdPtr() );
#ifdef __PROTECT_AWAKE
		if (pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_AWAKESAFE) == TRUE &&
            nKind == CRandomOptionProperty::eAwakening)
		{
			nOk = TID_GAME_REGARDLESS_USE04;
			g_xRandomOptionProperty->SetSafeFlag(pTarget->GetRandomOptItemIdPtr());

			pUser->RemoveBuff(BUFF_ITEM, II_SYS_SYS_SCR_AWAKESAFE);
			g_DPSrvr.PutItemLog(pUser, "z", "USE_AWAKESAVE_ITEM", pTarget, 1);
		}
		else
		{
#ifdef __ZCK_SYSTEME_EVEIL
            if (nKind != CRandomOptionProperty::eAwakening ||
                !pUser->StageZckAwakeProtection(pTarget))
#endif
            {
                g_xRandomOptionProperty->InitializeRandomOption(pTarget->GetRandomOptItemIdPtr());
            }
		}
#else // __PROTECT_AWAKE
#ifdef __ZCK_SYSTEME_EVEIL
        if (nKind != CRandomOptionProperty::eAwakening ||
            !pUser->StageZckAwakeProtection(pTarget))
#endif
        {
            g_xRandomOptionProperty->InitializeRandomOption(pTarget->GetRandomOptItemIdPtr());
        }
#endif // __PROTECT_AWAKE

#ifdef __ZCK_SYSTEME_EVEIL
		// Correctif 4 : si les bits 8 a 60 ont bouge, l'eveil courant a ete
		// detruit (parchemin d'annulation) ou reduit (palier de protection),
		// et le point de retour persiste est devenu perime.
		// La branche Safe Flag ne touche que le bit 61 : la comparaison la
		// laisse passer, et le point de retour y survit comme il doit.
		if (nKind == CRandomOptionProperty::eAwakening
			&& pTarget->GetZckPrevRandomOpt() != 0
			&& ZckAwakePackPrevious(pTarget->GetRandomOptItemId())
				!= ZckAwakePackPrevious(n64ZckBeforeCancel))
		{
			pUser->UpdateItemEx(
				(BYTE)(pTarget->m_dwObjId),
				UI_ZCK_PREV_AWAKE,
				(__int64)0);
		}
#endif // __ZCK_SYSTEME_EVEIL

		pUser->UpdateItemEx((BYTE)(pTarget->m_dwObjId), UI_RANDOMOPTITEMID, pTarget->GetRandomOptItemId());
		pUser->AddText(prj.GetText(nOk), 0xffffffff);

		// log
		LogItemInfo	log;
		log.Action = szOperation;
		log.SendName = pUser->GetName();
		log.RecvName = szRecv;
		log.WorldId = pUser->GetWorld()->GetID();
		log.Gold = pUser->GetGold();
		log.Gold2 = pUser->GetGold();
		OnLogItem(log, pTarget, 1);

		return TRUE;
	}
	pUser->AddDefinedText(nError);
	return FALSE;
}

BOOL CDPSrvr::DoUseItemTarget_ItemLevelDown(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget)
{
	ItemProp* pProp = pTarget->GetProp();
	if (pProp->dwParts == NULL_ID || pProp->dwLimitLevel1 == 0xFFFFFFFF)
	{
		pUser->AddDefinedText(TID_GAME_INVALID_TARGET_ITEM);
		return FALSE;
	}

	int nLevelDown = pTarget->GetLevelDown();
	if (nLevelDown == 0 || (nLevelDown == -5 && pMaterial->m_dwItemId == II_SYS_SYS_SCR_LEVELDOWN02))
	{
		pTarget->SetLevelDown(pMaterial->m_dwItemId == II_SYS_SYS_SCR_LEVELDOWN01 ? CItemElem::e5LevelDown : CItemElem::e10LevelDown);
		pUser->UpdateItemEx((BYTE)(pTarget->m_dwObjId), UI_RANDOMOPTITEMID, pTarget->GetRandomOptItemId());

		// log
		LogItemInfo	log;
		log.Action = "r";
		log.SendName = pUser->GetName();
		log.RecvName = "::ItemLevelDown";
		log.WorldId = pUser->GetWorld()->GetID();
		log.Gold = pUser->GetGold();
		log.Gold2 = pUser->GetGold();
		OnLogItem(log, pTarget, 1);

		return TRUE;
	}
	else
		pUser->AddDefinedText(TID_GAME_ITEM_LEVELDOWN01);

	return FALSE;
}

void CDPSrvr::OnPickupPetAwakeningCancel(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_PET_AWAK_CANCEL, pUser->GetWorld(), pUser->GetPos()))
		return;

	DWORD dwItem;
	ar >> dwItem;
	CItemElem* pItem = pUser->m_Inventory.GetAtId(dwItem);
	if (!IsUsableItem(pItem))
		return;

	if (DoUseItemTarget_InitializeRandomOption(pUser, pItem, CRandomOptionProperty::eEatPet,
		TID_GAME_PICKUP_PET_AWAKENING_CANCEL_S001, TID_GAME_PICKUP_PET_AWAKENING_CANCEL_E001,
		"k", "PPAC"))
	{
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if (pUser->IsMode(TRANSPARENT_MODE) == 0)
			g_UserMng.AddCreateSfxObj(pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	}
}

#ifdef __PET_1024
void CDPSrvr::OnClearPetName(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CPet* pPet = pUser->GetPet();
		if (!pPet)
		{
			pUser->AddDefinedText(TID_GAME_NAME_PET_E00);
			return;
		}
		pPet->SetName("");
		g_UserMng.AddSetPetName(pUser, pPet->GetName());
	}
}
#endif	// __PET_1024

#if __VER >= 13 // __HOUSING
void CDPSrvr::OnHousingSetupFurniture(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	HOUSINGINFO housingInfo;
	housingInfo.Serialize(ar);


	CHousingMng::GetInstance()->ReqSetupFurniture(pUser, housingInfo);
}

void CDPSrvr::OnHousingSetVisitAllow(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	DWORD dwPlayerId;
	BOOL  bAllow;

	ar >> dwPlayerId >> bAllow;

	CHousingMng::GetInstance()->ReqSetAllowVisit(pUser, dwPlayerId, bAllow);
}

void CDPSrvr::OnHousingVisitRoom(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	DWORD dwPlayerId;
	ar >> dwPlayerId;

	if (dwPlayerId == NULL_ID)
		dwPlayerId = pUser->m_idPlayer;

	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_VISIT_MYROOM, pUser->GetWorld(), pUser->GetPos()))
		return;

	CHousingMng::GetInstance()->SetVisitRoom(pUser, dwPlayerId);
}

void CDPSrvr::OnHousingVisitableList(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CHousingMng::GetInstance()->OnReqVisitableList(pUser);
}

void CDPSrvr::OnHousingGoOut(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CHousingMng::GetInstance()->GoOut(pUser);
}
#endif // __HOUSING

#if __VER >= 13 // __QUEST_HELPER
void CDPSrvr::OnReqQuestNPCPos(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	char szCharKey[64] = { 0, };
	ar.ReadString(szCharKey, 64);

	LPCHARACTER lpChar = prj.GetCharacter(szCharKey);
	if (lpChar)
	{
		if (pUser->GetWorld() && pUser->GetWorld()->GetID() == lpChar->m_dwWorldId)
			pUser->AddNPCPos(lpChar->m_vPos);
		else
			pUser->AddDefinedText(TID_GAME_QUESTINFO_FAIL);
	}
}
#endif // __QUEST_HELPER

#if __VER >= 13 // __COUPLE_1117
void CDPSrvr::OnPropose(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		char szPlayer[MAX_PLAYER] = { 0, };
		ar.ReadString(szPlayer, MAX_PLAYER);
		CCoupleHelper::Instance()->OnPropose(pUser, szPlayer);
	}
}

void CDPSrvr::OnRefuse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		CCoupleHelper::Instance()->OnRefuse(pUser);
}

void CDPSrvr::OnCouple(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		CCoupleHelper::Instance()->OnCouple(pUser);
}

void CDPSrvr::OnDecouple(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		CCoupleHelper::Instance()->OnDecouple(pUser);
}
#endif	// __COUPLE_1117

#ifdef __MAP_SECURITY
void CDPSrvr::OnMapKey(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		char szFileName[33] = { 0, }, szMapKey[33] = { 0, };
		ar.ReadString(szFileName, 33);
		ar.ReadString(szMapKey, 33);
		g_WorldMng.CheckMapKey(pUser, szFileName, szMapKey);
	}
}
#endif // __MAP_SECURITY

#if __VER >= 15 // __PETVIS
void CDPSrvr::OnRemoveVis(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	int nPos;
	ar >> nPos;

	CItemUpgrade::GetInstance()->RemovePetVisItem(pUser, nPos);
}

void CDPSrvr::OnSwapVis(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	int nPos1, nPos2;
	ar >> nPos1 >> nPos2;

	CItemUpgrade::GetInstance()->SwapVis(pUser, nPos1, nPos2);
}
#endif // __PETVIS

#if __VER >= 15 // __GUILD_HOUSE
void CDPSrvr::OnBuyGuildHouse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	GuildHouseMng->ReqBuyGuildHouse(pUser);
}

void CDPSrvr::OnGuildHousePacket(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	int nPacketType, nIndex;
	GH_Fntr_Info gfi;

	ar >> nPacketType >> nIndex;
	gfi.Serialize(ar);

	if (nPacketType == GUILDHOUSE_PCKTTYPE_LISTUP)
		return;

	GuildHouseMng->SendWorldToDatabase(pUser, nPacketType, gfi, nIndex);
}

void CDPSrvr::OnGuildHouseEnter(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	GuildHouseMng->EnteranceGuildHouse(pUser);
}

void CDPSrvr::OnGuildHouseGoOut(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	GuildHouseMng->GoOutGuildHouse(pUser);
}
#endif // __GUILD_HOUSE

#if __VER >= 15 // __TELEPORTER
void CDPSrvr::OnTeleporterReq(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		CHAR	m_szKey[64];
		int		nIndex;
		ar.ReadString(m_szKey, 64);
		ar >> nIndex;

		LPCHARACTER lpChar = prj.GetCharacter(m_szKey);
		if (lpChar)
		{
			if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_TELEPORTER, pUser->GetWorld(), pUser->GetPos()))
				return;

			if ((int)(lpChar->m_vecTeleportPos.size()) <= nIndex)
				return;

			pUser->REPLACE(g_uIdofMulti, WI_WORLD_MADRIGAL, lpChar->m_vecTeleportPos[nIndex], REPLACE_NORMAL, nDefaultLayer);
		}
	}
}
#endif // __TELEPORTER

#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
void CDPSrvr::OnCheckedQuest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
		int nQuestid;
		BOOL bCheck;
		ar >> nQuestid >> bCheck;
		if (bCheck)
		{
			if (pUser->m_nCheckedQuestSize >= MAX_CHECKED_QUEST)
				return;

			for (int i = 0; i < pUser->m_nCheckedQuestSize; ++i)
			{
				if (pUser->m_aCheckedQuest[i] == nQuestid)
				{
					for (int j = i; j < pUser->m_nCheckedQuestSize - 1; ++j)
						pUser->m_aCheckedQuest[j] = pUser->m_aCheckedQuest[j + 1];
					pUser->m_aCheckedQuest[--pUser->m_nCheckedQuestSize] = 0;
					break;
				}
			}
			pUser->m_aCheckedQuest[pUser->m_nCheckedQuestSize++] = nQuestid;
		}
		else
		{
			if (pUser->m_nCheckedQuestSize <= 0)
				return;

			for (int i = 0; i < pUser->m_nCheckedQuestSize; ++i)
			{
				if (pUser->m_aCheckedQuest[i] == nQuestid)
				{
					for (int j = i; j < pUser->m_nCheckedQuestSize - 1; ++j)
						pUser->m_aCheckedQuest[j] = pUser->m_aCheckedQuest[j + 1];
					pUser->m_aCheckedQuest[--pUser->m_nCheckedQuestSize] = 0;
					break;
				}
			}
		}
		pUser->AddCheckedQuest();
	}
}
#endif // __IMPROVE_QUEST_INTERFACE


void	CDPSrvr::OnItemSelectAwakeningValue(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pRequest = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pRequest) == TRUE)
	{
		DWORD	dwItemObjID = 0;
		DWORD	dwSerialNumber = 0;
		BYTE	bySelectFlag = 0;

		ar >> dwItemObjID;
		ar >> dwSerialNumber;
		ar >> bySelectFlag;

		pRequest->SelectAwakeningValue(dwItemObjID, dwSerialNumber, bySelectFlag);
	}
	else
	{
		WriteLog("pUser is invalid in OnItemSelectAwakeningValue function.");
	}
}

#ifdef __FL_DUNGEON_TREASURE
void CDPSrvr::OnDungeonTreasureSelect(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	int nSelected;
	ar >> nSelected;

	if (nSelected < 1 || nSelected > 4)
		return;

	if (pUser->GetTreasureOpenState() == FALSE)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Vous ne pouvez pas ouvrir le tr\351sor pour le moment.");
#else
		pUser->AddText("You cant open treasure right now.");
#endif // __ZCK_TRAD_FR
		return;
	}

	for (auto& it : prj.m_vecDungeonTreasures)
	{
		if (it.dwWorldID != pWorld->GetID())
			continue;

		int nRandom = rand() % 4 + 1;
		if (nRandom == nSelected)
		{
			ItemProp* pItemProp = prj.GetItemProp(it.dwItemID);
			if (!pItemProp)
				break;

			CItemElem pItemElem;
			pItemElem.m_dwItemId = pItemProp->dwID;
			pItemElem.m_nItemNum = it.nItemAmount;
			pItemElem.m_nHitPoint = pItemProp->dwEndurance;
			pItemElem.SetSerialNumber();

			if (!pUser->CreateItem(&pItemElem))
#ifdef __ZCK_TRAD_FR
				g_dpDBClient.SendQueryPostMail(pUser->m_idPlayer, 0, pItemElem, 0, "Tr\351sor du donjon", "Votre r\351compense du tr\351sor du donjon !");
#else
				g_dpDBClient.SendQueryPostMail(pUser->m_idPlayer, 0, pItemElem, 0, "Dungeon Treasure", "Your dungeon treasure reward!");
#endif // __ZCK_TRAD_FR

			pUser->AddDungeonTreasureResult(nRandom, TRUE);
		}
		else
			pUser->AddDungeonTreasureResult(nRandom, FALSE);

		break;
	}

	pUser->SetTreasureOpenState(FALSE);
}
#endif

#ifdef __FL_CONSUMABLES_STORAGE
void	CDPSrvr::OnMoveItemToChest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	BYTE nItem;
	short nNum;
	BOOL bFromInventoryToChest;
	ar >> nItem >> nNum >> bFromInventoryToChest;

	if (!pUser->m_bAllAction)
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	if (bFromInventoryToChest) // Inventory -> Chest
	{
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(nItem);
		if (!IsUsableItem(pItemElem))
			return;

		ItemProp* pProp = pItemElem->GetProp();
		if (!pProp)
			return;

		if (pUser->IsUsing(pItemElem))
		{
			pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
			return;
		}

		if (pUser->m_Inventory.IsEquip(nItem))
		{
			pUser->AddDefinedText(TID_GAME_EQUIPTRADE, "");
			return;
		}

		if (nNum > pItemElem->m_nItemNum)
			nNum = pItemElem->m_nItemNum;
		if (nNum < 1)
			nNum = 1;

		if (pUser->m_Chest.IsFull(pItemElem, pProp, nNum) == FALSE)
		{
			CItemElem itemElem;
			itemElem = *pItemElem;
			itemElem.m_nItemNum = nNum;

			pUser->m_Chest.Add(&itemElem); // Add item in chest in server side
			pUser->AddPutItemToChest(&itemElem); // Add item in chest in client side
			pUser->RemoveItem(nItem, nNum); // Remove item from inventory in server & client side
		}
		else
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Votre coffre est plein... Impossible d'ajouter l'objet !", 0xffffffff);
#else
			pUser->AddText("Your chest is full... Not possible to add item!", 0xffffffff);
#endif // __ZCK_TRAD_FR
			return;
		}
	}
	else // Chest -> Inventory
	{
		CItemElem* pItemElem = pUser->m_Chest.GetAtId(nItem);
		if (IsUsableItem(pItemElem) == FALSE)
			return;

		ItemProp* pProp = pItemElem->GetProp();
		if (!pProp)
			return;

		if (nNum > pItemElem->m_nItemNum)
			nNum = pItemElem->m_nItemNum;
		if (nNum < 1)
			nNum = 1;

		if (pUser->m_Inventory.IsFull(pItemElem, pProp, nNum) == FALSE)
		{
			CItemElem itemElem;
			itemElem = *pItemElem;
			itemElem.m_nItemNum = nNum;

			pUser->m_Inventory.Add(&itemElem); // Add item in inventory in server side
			pUser->AddGetItemBank(&itemElem); // Add item in inventory in client side
			pUser->RemoveItem(nItem, nNum, TYPE_CHEST);
		}
		else
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Votre inventaire est plein... Impossible d'ajouter l'objet !", 0xffffffff);
#else
			pUser->AddText("Your inventory is full... Not possible to add item!", 0xffffffff);
#endif // __ZCK_TRAD_FR
			return;
		}
	}
}
void CDPSrvr::OnMoveItemInsideChest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nSrcIndex, nDstIndex;
	ar >> nSrcIndex >> nDstIndex;

	if (nSrcIndex == nDstIndex)
		return;
	if (nDstIndex >= MAX_CHEST || nSrcIndex >= MAX_CHEST)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	if (!pUser->m_bAllAction)
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	CItemElem* pItemSrc = pUser->m_Chest.GetAt(nSrcIndex);
	CItemElem* pItemDst = pUser->m_Chest.GetAt(nDstIndex);
	if (pItemDst == NULL || IsUsableItem(pItemDst))
	{
		if (IsUsableItem(pItemSrc))
		{
			pUser->m_Chest.Swap(nSrcIndex, nDstIndex);
			pUser->AddMoveItemInsideChest(nSrcIndex, nDstIndex);
		}
	}
}
void CDPSrvr::OnMoveAllItemsToChest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!pUser->m_bAllAction)
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	BOOL bWasSomethingToAdd = FALSE;

	// Step 1: need to be sure what server + client both have "Not in use" state for all suitable items. Client ok, now server:
	for (int i = 0; i < MAX_INVENTORY; i++)
	{
		CItemElem* pItemElem = pUser->m_Inventory.GetAt(i);
		if (!pItemElem)
			continue;

		ItemProp* pProp = pItemElem->GetProp();
		if (!pProp)
			continue;

		if (!pUser->CanBeUsedOutsideInventory(pProp))
			continue;

		// UsableItem different for world and client, if user currently on trade/vendor, we should return it
		if (!IsUsableItem(pItemElem) || pUser->IsUsing(pItemElem))
		{
			pUser->AddDefinedText(TID_GAME_BANKNOTRADE);
			return;
		}

		bWasSomethingToAdd = TRUE;
	}

	// Step 2: Its ok, all suitable items is ready to move, thats why we here.
	if (bWasSomethingToAdd)
	{
		bWasSomethingToAdd = FALSE;

		int nNum = 0;
		for (int i = 0; i < MAX_INVENTORY; i++)
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAt(i);
			if (!pItemElem)
				continue;

			ItemProp* pProp = pItemElem->GetProp();
			if (!pProp)
				continue;

			if (!pUser->CanBeUsedOutsideInventory(pProp))
				continue;

			nNum = pItemElem->m_nItemNum;

			if (pUser->m_Chest.IsFull(pItemElem, pProp, nNum))
				continue;

			CItemElem itemElem;
			itemElem = *pItemElem;
			itemElem.m_nItemNum = nNum;

			pUser->m_Inventory.RemoveAtId(pItemElem->m_dwObjId); // Remove item from inventory in server side
			pUser->m_Chest.Add(&itemElem); // Add item in chest in server side

			bWasSomethingToAdd = TRUE;
		}

		if (bWasSomethingToAdd)
			pUser->AddHdr(NULL_ID, SNAPSHOTTYPE_PUT_ALL_ITEMS_TO_CHEST);
	}
}

#endif


#ifdef __TRADESYS
void CDPSrvr::OnExchange(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	int nMMIid;
	int nListNum;
	int nCount;

	ar >> nMMIid;
	ar >> nListNum;
	ar >> nCount;

	if (nCount <= 0 || nCount > MAX_BULK_EXCHANGE)
		return;

	for (int i = 0; i < nCount; i++)
	{
		int	nResult = prj.m_Exchange.ResultExchange(pUser, nMMIid, nListNum);
		if (nResult != CExchange::EXCHANGE_SUCCESS)
			break;
	}

	pUser->AddExchangeResult(EXCHANGE_RESULT);
}
#endif // __TRADESYS

#ifdef __FL_BOXES_V2
void CDPSrvr::OnBulkBoxOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwId;
	ar >> dwId;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwId);
	if (!IsUsableItem(pItemElem))
		return;

	int nBoxNumber = pItemElem->m_nItemNum;
	int nTotalOpenedBoxes = 0;

	PPACKITEMELEM pPackItemElem = CPackItem::GetInstance()->Open(pItemElem->m_dwItemId);
	if (pPackItemElem)
	{
		for (int i = 0; i < nBoxNumber; i++)
		{
			if (pUser->DoUsePackItem(pItemElem, pPackItemElem, TYPE_INVENTORY, true) == FALSE)
				break;
			else
				nTotalOpenedBoxes++;
		}
	}
	else
	{
		for (int i = 0; i < nBoxNumber; i++)
		{
			if (pUser->DoUseGiftbox(pItemElem, TYPE_INVENTORY, true) == FALSE)
				break;
			else
				nTotalOpenedBoxes++;
		}
	}

	if (nTotalOpenedBoxes > 0)
	{
#ifdef __ZCK_ACHIEVEMENT
		CZckAchievementManager::GetInstance()->OnItemUsed(pUser, pItemElem->m_dwItemId, nTotalOpenedBoxes);
#endif
		pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), nTotalOpenedBoxes);

#ifdef __ZCK_TRAD_FR
		CString str; str.Format("Ouverture group\351e termin\351e ! V\351rifiez votre inventaire. Total : %d", nTotalOpenedBoxes);
#else
		CString str; str.Format("Bulk processing completed! Check your inventory. Total - %d", nTotalOpenedBoxes);
#endif // __ZCK_TRAD_FR
		pUser->AddText(str, 0xffffffff);
	}
}
#endif

BOOL CDPSrvr::UnbindScroll(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget)
{
	if (pUser)
	{
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
		if (ZckRefusStaff(pUser, "d\351liaison d'objet"))
			return FALSE;
#else
#line 9106 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
		if (!pTarget || !pTarget->GetProp() || !pMaterial || !pMaterial->GetProp())
			return FALSE;

		if (pTarget->IsFlag(CItemElem::binds) && pMaterial->m_dwItemId == II_SYS_SYS_SCR_CANCELLATION && (pTarget->GetProp()->dwFlag & IP_FLAG_EQUIP_BIND))
		{
			pTarget->ResetFlag(CItemElem::binds);
			pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_FLAG, MAKELONG(pTarget->m_dwObjIndex, pTarget->m_byFlag));
			return TRUE;
		}
		else
			pUser->AddDefinedText(TID_GAME_LORD_SKILL_USE_E001);
	}

	return FALSE;
}

#ifdef __FL_FAST_ELEMENT
void CDPSrvr::OnChangeAttributeNew(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize)
{
	OBJID objScroll;
	int nAttribute, nPosition;

	ar >> objScroll;
	ar >> nAttribute;
	ar >> nPosition;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (nPosition != PARTS_RWEAPON && nPosition != PARTS_LWEAPON && nPosition != PARTS_SHIELD && nPosition != PARTS_UPPER_BODY)
		return;

	CItemElem* pTargetItemElem = pUser->GetEquipItem(nPosition);
	CItemElem* pScrollItemElem = pUser->m_Inventory.GetAtId(objScroll);
	if (!IsUsableItem(pTargetItemElem) || !IsUsableItem(pScrollItemElem))
		return;

	if (pScrollItemElem->m_dwItemId != __FL_FAST_ELEMENT)
		return;

	ItemProp* pTargetProp = pTargetItemElem->GetProp();
	if (!pTargetProp)
		return;

	if (!pTargetProp->IsEleRefineryAble())
		return;

	if (nAttribute >= SAI79::END_PROP || nAttribute <= SAI79::NO_PROP)
		return;

	if (pTargetItemElem->m_bItemResist == SAI79::NO_PROP || pTargetItemElem->m_bItemResist == nAttribute)
	{
		pUser->AddDefinedText(TID_GAME_NOCHANGE_SAME_ATTRIBUTE);
		return;
	}

	if (pTargetItemElem->IsFlag(CItemElem::expired))
	{
		pUser->AddDefinedText(TID_GAME_ITEM_EXPIRED);
		return;
	}

	if (pUser->m_Inventory.IsEquip(pTargetItemElem->m_dwObjId) == FALSE)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("L'objet doit \352tre \351quip\351 pour cette action !");
#else
		pUser->AddText("Item should be equipped for this action!");
#endif // __ZCK_TRAD_FR
		return;
	}

	if (pTargetItemElem->m_nResistAbilityOption <= 0)
	{
		pUser->AddDefinedText(TID_GAME_NOTELEMENT);
		return;
	}

	pUser->RemoveItem((BYTE)(pScrollItemElem->m_dwObjId), 1);

	((CMover*)pUser)->UpdateElementResist(pTargetItemElem, FALSE);

	pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
	if ((pUser->IsMode(TRANSPARENT_MODE)) == 0)
		g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	pUser->UpdateItem((BYTE)pTargetItemElem->m_dwObjId, UI_IR, nAttribute);

	((CMover*)pUser)->UpdateElementResist(pTargetItemElem, TRUE);

	pUser->RedoEquip(FALSE);
	g_UserMng.AddElementChange((CMover*)pUser, nPosition, pTargetItemElem->GetAttrOption());
}
#endif

void CDPSrvr::OnHideCoat(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nPosition;
	BOOL bHide;
	ar >> nPosition >> bHide;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (nPosition < 0 || nPosition >= hft_MAX_HIDEFASHION_TYPES)
		return;

	pUser->m_bHideFashion[nPosition] = bHide;
	g_UserMng.AddHideFashionUpdate(pUser, nPosition, bHide);
}

#ifdef __FL_SHOP_SEARCH
void CDPSrvr::OnRequestShopSearch(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
		pUser->AddShopSearch();
}
void CDPSrvr::OnTeleportToShop(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpbuf, u_long uBufSize)
{
	OBJID objTarget;
	ar >> objTarget;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	DWORD dwState = pUser->GetSummonState(FALSE);
	if (dwState != 0)
	{
		pUser->AddDefinedText(dwState);
		return;
	}

	CMover* pMoverShop = prj.GetMover(objTarget);
	if (!IsValidObj(pMoverShop))
		return;

	CWorld* pMoverShopWorld = pMoverShop->GetWorld();
	if (!pMoverShopWorld)
		return;

	if (pMoverShopWorld->GetID() != WI_WORLD_MADRIGAL)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Vous ne pouvez vous t\351l\351porter que si le joueur s\351lectionn\351 se trouve \340 Madrigal");
#else
		pUser->AddText("You can teleport only if selected player located in Madrigal");
#endif // __ZCK_TRAD_FR
		return;
	}

	if (pMoverShop->IsPlayer() && pUser == ((CUser*)pMoverShop))
		return;

	if (!pMoverShop->m_vtInfo.VendorIsVendor() || !pMoverShop->m_vtInfo.IsVendorOpen())
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Ce joueur n'a pas de boutique ouverte. Veuillez actualiser la liste.");
#else
		pUser->AddText("This user not have opened shop. Please, refresh the list.");
#endif // __ZCK_TRAD_FR
		return;
	}

	pUser->REPLACE(g_uIdofMulti, WI_WORLD_MADRIGAL, pMoverShop->GetPos(), REPLACE_FORCE, nDefaultLayer);
}
#endif


#ifdef __FL_PET_FILTER
void	CDPSrvr::OnPetLootOption(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser) == FALSE)
		return;

	int nLootType;
	BYTE nLootPlace;

	ar >> nLootType >> nLootPlace;
	if (nLootPlace >= TYPE_MAX)
		nLootPlace = TYPE_INVENTORY;

	pUser->m_nPetLootType = nLootType;
	pUser->m_nLootPlace = nLootPlace;
}
void	CDPSrvr::OnPetFilterException(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	bool bAdd;
	bool bBlack;
	DWORD dwItemID;

	ar >> bAdd >> bBlack >> dwItemID;

	bool bResult = false;
	if (bAdd)
		bResult = pUser->PetFilterExceptionAdd(bBlack, dwItemID);
	else
		bResult = pUser->PetFilterExceptionRemove(bBlack, dwItemID);

	if (bResult)
		pUser->AddPetFilterException(bAdd, bBlack, dwItemID);

}
#endif

#ifdef __FL_EQUALIZED_MODE
void CDPSrvr::OnSelectTmpClass(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);

	if (IsValidObj(pUser) == FALSE)
		return;

	if (!pUser->GetWorld())
		return;

	int nTmpClass;
	ar >> nTmpClass;

	DWORD dwWorldID = pUser->GetWorld()->GetID();
	int nTypeOfClass = -1;

	for (auto& it : prj.m_vecTmpWorlds)
	{
		if (it.dwWorldID == dwWorldID)
		{
			if (pUser->TemporalPreCheck(dwWorldID))
				nTypeOfClass = it.nMode;

			break;
		}
	}

	if (nTypeOfClass == -1)
		return;

	if (pUser->bTmpMode)
		return;

	if (pUser->m_vtInfo.GetOther() || pUser->m_vtInfo.VendorIsVendor() || pUser->m_vtInfo.IsVendorOpen() || pUser->m_bBank || pUser->m_bGuildBank)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Fermez la banque, la banque de guilde et la boutique, annulez l'\351change, puis r\351essayez.");
#else
		pUser->AddText("Please, close bank, guildbank, shop and cancel trade. After that try again..");
#endif // __ZCK_TRAD_FR
		pUser->AddOpenTempWindow(nTypeOfClass);
		return;
	}

	if (nTmpClass >= 0 && nTmpClass <= 7)
	{
		int nJob = 0;
		switch (nTypeOfClass)
		{
		case 0:
		{
			switch (nTmpClass)
			{
			case 0:	nJob = JOB_BLADE;	break;
			case 1:	nJob = JOB_KNIGHT;	break;
			case 2:	nJob = JOB_JESTER;	break;
			case 3:	nJob = JOB_RANGER;	break;
			case 4:	nJob = JOB_PSYCHIKEEPER;	break;
			case 5: nJob = JOB_ELEMENTOR;	break;
			case 6:	nJob = JOB_BILLPOSTER;	break;
			case 7:	nJob = JOB_RINGMASTER;	break;
			}
			break;
		}
		case 1:
		{
			switch (nTmpClass)
			{
			case 0:	nJob = JOB_STORMBLADE_HERO;	break;
			case 1:	nJob = JOB_LORDTEMPLER_HERO;	break;
			case 2:	nJob = JOB_WINDLURKER_HERO;	break;
			case 3:	nJob = JOB_CRACKSHOOTER_HERO;	break;
			case 4:	nJob = JOB_MENTALIST_HERO;	break;
			case 5: nJob = JOB_ELEMENTORLORD_HERO;	break;
			case 6:	nJob = JOB_FORCEMASTER_HERO;	break;
			case 7:	nJob = JOB_FLORIST_HERO;	break;
			}
			break;
		}
		default: Error("Something wrong in CDPSrvr::OnSelectTmpClass: %s", pUser->GetName()); pUser->REPLACE(g_uIdofMulti, WI_WORLD_MADRIGAL, D3DXVECTOR3(6968.0f, 0.0f, 3328.8f), REPLACE_NORMAL, nDefaultLayer); return;
		}

		BOOL bAllowToEnter = FALSE;

		map<u_long, vector<TEMPORAL_LIMITS>>::iterator it = prj.map_DynamicTemporalCounter.find(dwWorldID);
		if (it != prj.map_DynamicTemporalCounter.end())
		{
			for (auto& it2 : it->second) // check "dynamic" vector inside map
			{
				if (it2.nJob == nTmpClass)
				{
					for (auto& it3 : prj.m_vecTmpWorlds) // check "static" vector to know limit
					{
						if (it3.dwWorldID == dwWorldID)
						{
							if (it2.nCurrentAmountOfPlayers >= it3.nMaxJob[nTmpClass])
								bAllowToEnter = FALSE;
							else
								bAllowToEnter = TRUE;

							break;
						}
					}

					break;
				}
			}
		}

		if (!bAllowToEnter)
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Trop de personnages de cette classe dans ce monde : veuillez choisir une autre classe.");
#else
			pUser->AddText("Too much same jobs for this world, please, select another job.");
#endif // __ZCK_TRAD_FR
			pUser->AddOpenTempWindow(nTypeOfClass);
			return;
		}

		((CMover*)pUser)->TemporalEnter(nTypeOfClass, nJob);
	}
}
#endif

void	CDPSrvr::OnConfirmPartyRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	u_long uLeaderPlayerID;
	ar >> uLeaderPlayerID;

	CUser* pMember = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pMember))
		return;

	CUser* pLeader = g_UserMng.GetUserByPlayerID(uLeaderPlayerID);
	if (!IsValidObj(pLeader))
		return;

	if (pLeader == pMember)
		return;

#ifdef __FL_FIX_IDCHANGE_EXPLOIT
	BOOL bAllowed = FALSE;
	for (auto it = pLeader->vecPartyInvites.begin(); it != pLeader->vecPartyInvites.end(); it++)
	{
		if (it->dwInvieMember == pMember->m_idPlayer)
		{
			pLeader->vecPartyInvites.erase(it);
			bAllowed = TRUE;
			break;
		}
	}
	if (!bAllowed)
	{
#ifdef __ZCK_TRAD_FR
		pMember->AddText("Cette invitation a expir\351 ou vous n'avez pas la permission de rejoindre ce groupe.", 0xffffffff);
#else
		pMember->AddText("This invite was expired or you have not permissions to join.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}
#endif

	const DWORD dwResult = g_PartyMng.CanInviteParty(uLeaderPlayerID, pMember->m_idPlayer);
	if (dwResult == 5)
	{
		g_PartyMng.RequestAddPartyMemberToCS(uLeaderPlayerID, pMember->m_idPlayer);
	}
	else
	{
		switch (dwResult)
		{
		case 1:
			pLeader->AddDefinedText(TID_GAME_PARTYEXISTCHR, "\"%s\"", pMember->GetName());
			break;

		case 2:
			pLeader->AddDefinedText(TID_GAME_PARTYNOINVATE);
			break;

		case 3:
			pLeader->AddDefinedText(TID_GAME_FULLPARTY3);
			break;

		case 4:
			pLeader->AddDefinedText(TID_GAME_GUILDCOMBAT_CANNOT_PARTY);
			break;

		default:
			break;
		}
	}
}


void	CDPSrvr::OnConfirmFriendRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	u_long uLeaderPlayerID;
	ar >> uLeaderPlayerID;

	CUser* pMember = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pMember))
		return;

	CUser* pLeader = g_UserMng.GetUserByPlayerID(uLeaderPlayerID);
	if (!IsValidObj(pLeader))
		return;

	if (pLeader == pMember)
		return;

	if (pLeader->m_RTMessenger.GetFriend(pMember->m_idPlayer))
		return;

	BOOL bFullA = pMember->m_RTMessenger.size() >= MAX_FRIEND;
	BOOL bFullB = pLeader->m_RTMessenger.size() >= MAX_FRIEND;
	if (bFullA)
		return;

	if (bFullB)
		return;

#ifdef __FL_FIX_IDCHANGE_EXPLOIT
	BOOL bAllowed = FALSE;
	for (auto it = pLeader->vecFriendInvites.begin(); it != pLeader->vecFriendInvites.end(); it++)
	{
		if (it->dwInvieMember == pMember->m_idPlayer)
		{
			pLeader->vecFriendInvites.erase(it);
			bAllowed = TRUE;
			break;
		}
	}
	if (!bAllowed)
	{
#ifdef __ZCK_TRAD_FR
		pMember->AddText("Cette demande d'ami a expir\351 ou vous n'avez pas la permission d'ajouter ce joueur.", 0xffffffff);
#else
		pMember->AddText("This invite was expired or you have not permissions to add.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}
#endif

	BEFORESENDDUAL(out, PACKETTYPE_ADDFRIEND, DPID_UNKNOWN, DPID_UNKNOWN);
	out << uLeaderPlayerID;
	out << pMember->m_idPlayer;
	SEND(out, &g_DPCoreClient, DPID_SERVERPLAYER);

}

void	CDPSrvr::OnConfirmGuildRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	u_long idMaster;
	ar >> idMaster;

	CUser* pMember = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pMember))
		return;

	CUser* pLeader = g_UserMng.GetUserByPlayerID(idMaster);
	if (!IsValidObj(pLeader))
		return;

	if (pLeader == pMember)
		return;

	CGuild* pGuild = g_GuildMng.GetGuild(pLeader->m_idGuild);
	if (!pGuild || !pGuild->IsMember(idMaster))
		return;

	if (!IsInviteAbleGuild(pLeader->m_idGuild, pLeader))
		return;

	CGuild* pGuildtmp = g_GuildMng.GetGuild(pMember->m_idGuild);
	if (pGuildtmp && pGuildtmp->IsMember(pMember->m_idPlayer))
		return;

	if (pGuild->GetSize() >= pGuild->GetMaxMemberSize())
		return;

#ifdef __FL_FIX_IDCHANGE_EXPLOIT
	BOOL bAllowed = FALSE;
	for (auto it = pLeader->vecGuildInvites.begin(); it != pLeader->vecGuildInvites.end(); it++)
	{
		if (it->dwInvieMember == pMember->m_idPlayer)
		{
			pLeader->vecGuildInvites.erase(it);
			bAllowed = TRUE;
			break;
		}
	}
	if (!bAllowed)
	{
#ifdef __ZCK_TRAD_FR
		pMember->AddText("Cette invitation a expir\351 ou vous n'avez pas la permission de rejoindre cette guilde.", 0xffffffff);
#else
		pMember->AddText("This invite was expired or you have not permissions to join.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}
#endif


	BEFORESENDDUAL(out, PACKETTYPE_ADD_GUILD_MEMBER, DPID_UNKNOWN, DPID_UNKNOWN);
	out << pMember->m_idPlayer << pGuild->m_idGuild; //__FL_GUILD_FINDER
	SEND(out, &g_DPCoreClient, DPID_SERVERPLAYER);

}

#ifdef __FL_FFA
void CDPSrvr::OnRequestFFA(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->AddFFAData();
}
void CDPSrvr::OnRequestFFARegister(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CFFAManager::GetInstance()->RegisterPlayer(pUser);
}
void CDPSrvr::OnRequestFFAJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (!CFFAManager::GetInstance()->JoinFFAWorld(pUser))
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT1TO1_NOENTRANCETIME);
}
#endif

#ifdef __FL_DAILY_REWARDS
void CDPSrvr::OnCollectDailyGift(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (pUser->m_nLastDailyReward < 0)
		return;

	auto it = prj.mapDailyRewards.find(pUser->m_nLastDailyReward);
	if (it == prj.mapDailyRewards.end())
		return;

	ItemProp* pRewardProp = prj.GetItemProp(it->second.dwItemID);
	if (!pRewardProp)
		return;

	CItemElem pItemElem;
	pItemElem.m_dwItemId = it->second.dwItemID;
	pItemElem.m_nItemNum = it->second.nItemNum;
	pItemElem.m_nHitPoint = pRewardProp->dwEndurance;
	if (it->second.bItemBind)
		pItemElem.SetFlag(CItemElem::binds);
	pItemElem.SetSerialNumber();

	if (pUser->CreateItem(&pItemElem) == FALSE)
#ifdef __ZCK_TRAD_FR
		g_dpDBClient.SendQueryPostMail(pUser->m_idPlayer, 0, pItemElem, 0, "Cadeau quotidien", "Votre cadeau quotidien !");

	CString str;
	str.Format("Vous avez bien re\347u la r\351compense du jour %d !", pUser->m_nLastDailyReward + 1);
#else
		g_dpDBClient.SendQueryPostMail(pUser->m_idPlayer, 0, pItemElem, 0, "Daily Gift", "Your daily gift!");

	CString str;
	str.Format("You've successfully received reward for Day %d!", pUser->m_nLastDailyReward + 1);
#endif // __ZCK_TRAD_FR
	pUser->AddText(str, 0xffffffff);

	g_dpDBClient.SendUpdateDailyGift(pUser->m_idPlayer, pUser->m_nLastDailyReward + 1);

	pUser->m_nLastDailyReward = -1;
}
#endif

#ifdef __WIKI_ITEMS_V2
void CDPSrvr::OnWikiCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (pUser->IsAuthHigher(AUTH_ADMINISTRATOR) == FALSE)
		return;

	BOOL dwId;
	int nNum;

	ar >> dwId >> nNum;

	char szName[32];
	ar.ReadString(szName, 32);

	ItemProp* pProp = prj.GetItemProp(dwId);
	if (!pProp)
		return;

	if (nNum < 1)
		nNum = 1;
	if (nNum > pProp->dwPackMax)
		nNum = pProp->dwPackMax;

	CUser* pReceiver = pUser;
	if (szName[0] != '\0')
	{
		u_long idReceiver = CPlayerDataCenter::GetInstance()->GetPlayerId(szName);
		pReceiver = g_UserMng.GetUserByPlayerID(idReceiver);
		if (!IsValidObj(pReceiver))
		{
			pUser->AddText("Joueur introuvable.");
			return;
		}
	}

	CItemElem itemElem;
	itemElem.m_dwItemId = dwId;
	itemElem.m_nItemNum = nNum;
	itemElem.SetSerialNumber();
	itemElem.m_nHitPoint = 0;

	if (!pReceiver->CreateItem(&itemElem))
		pUser->AddDefinedText(TID_GAME_LACKSPACE);
	else
	{
		CString str;
#ifdef __ZCK_TRAD_FR
		str.Format("%s (x%d) envoy\351 avec succ\350s \340 %s", pProp->szName, nNum, pReceiver->GetName());
#else
		str.Format("%s (x%d) envoyé avec succès à %s", pProp->szName, nNum, pReceiver->GetName());
#endif // __ZCK_TRAD_FR
		pUser->AddText(str);

		if (pUser != pReceiver)
		{
			str.Format("L'administrateur %s vient de vous envoyer l'objet suivant : %s (x%d)", pUser->GetName(), pProp->szName, nNum);
			pReceiver->AddText(str);
		}
	}
}
#endif

#ifdef __FL_TELEPORT
void CDPSrvr::OnTeleportRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	int nKey;
	ar >> nKey;

	CTeleporter::GetInstance()->DoTeleport(nKey, pUser);
}
#endif

#ifdef __JOB_CHANGE
void CDPSrvr::OnSendJobChange(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	int nJob;
	ar >> nJob;

	if (!IsValidObj(pUser))
		return;

	if (pUser->GetLevel() == MAX_JOB_LEVEL && pUser->IsBaseJob())
	{
		switch (nJob)
		{
		case JOB_MERCENARY: pUser->ChangeJob(JOB_MERCENARY); break;
		case JOB_ASSIST: pUser->ChangeJob(JOB_ASSIST); break;
		case JOB_ACROBAT: pUser->ChangeJob(JOB_ACROBAT); break;
		case JOB_MAGICIAN: pUser->ChangeJob(JOB_MAGICIAN); break;
		default: Error("[Warning] CDPSrvr::OnSendJobChange (1) - %s", pUser->GetName()); break;
		}
	}
	else if (pUser->GetLevel() == (MAX_JOB_LEVEL + MAX_EXP_LEVEL) && pUser->IsExpert())
	{
		switch (nJob)
		{
		case JOB_KNIGHT: if (pUser->GetJob() == JOB_MERCENARY) pUser->ChangeJob(JOB_KNIGHT); break;
		case JOB_BLADE: if (pUser->GetJob() == JOB_MERCENARY) pUser->ChangeJob(JOB_BLADE); break;
		case JOB_JESTER: if (pUser->GetJob() == JOB_ACROBAT) pUser->ChangeJob(JOB_JESTER); break;
		case JOB_RANGER: if (pUser->GetJob() == JOB_ACROBAT) pUser->ChangeJob(JOB_RANGER); break;
		case JOB_RINGMASTER: if (pUser->GetJob() == JOB_ASSIST) pUser->ChangeJob(JOB_RINGMASTER); break;
		case JOB_BILLPOSTER: if (pUser->GetJob() == JOB_ASSIST) pUser->ChangeJob(JOB_BILLPOSTER); break;
		case JOB_PSYCHIKEEPER: if (pUser->GetJob() == JOB_MAGICIAN) pUser->ChangeJob(JOB_PSYCHIKEEPER); break;
		case JOB_ELEMENTOR: if (pUser->GetJob() == JOB_MAGICIAN) pUser->ChangeJob(JOB_ELEMENTOR); break;
		default: Error("[Warning] CDPSrvr::OnSendJobChange (2) - %s", pUser->GetName()); break;
		}
	}
	else if (pUser->GetLevel() == MAX_GENERAL_LEVEL && pUser->IsPro() && pUser->GetExpPercent() >= 9999)
	{
		switch (nJob)
		{
		case JOB_KNIGHT_MASTER: if (pUser->GetJob() == JOB_KNIGHT) pUser->ChangeJob(JOB_KNIGHT_MASTER); break;
		case JOB_BLADE_MASTER: if (pUser->GetJob() == JOB_BLADE) pUser->ChangeJob(JOB_BLADE_MASTER); break;
		case JOB_JESTER_MASTER: if (pUser->GetJob() == JOB_JESTER) pUser->ChangeJob(JOB_JESTER_MASTER); break;
		case JOB_RANGER_MASTER: if (pUser->GetJob() == JOB_RANGER) pUser->ChangeJob(JOB_RANGER_MASTER); break;
		case JOB_RINGMASTER_MASTER: if (pUser->GetJob() == JOB_RINGMASTER) pUser->ChangeJob(JOB_RINGMASTER_MASTER); break;
		case JOB_BILLPOSTER_MASTER: if (pUser->GetJob() == JOB_BILLPOSTER) pUser->ChangeJob(JOB_BILLPOSTER_MASTER); break;
		case JOB_PSYCHIKEEPER_MASTER: if (pUser->GetJob() == JOB_PSYCHIKEEPER) pUser->ChangeJob(JOB_PSYCHIKEEPER_MASTER); break;
		case JOB_ELEMENTOR_MASTER: if (pUser->GetJob() == JOB_ELEMENTOR) pUser->ChangeJob(JOB_ELEMENTOR_MASTER); break;
		default: Error("[Warning] CDPSrvr::OnSendJobChange (3) - %s", pUser->GetName()); break;
		}
	}
	else if (pUser->GetLevel() == MAX_GENERAL_LEVEL && pUser->IsMaster() && pUser->GetExpPercent() >= 9999)
	{
		switch (nJob)
		{
		case JOB_KNIGHT_HERO: if (pUser->GetJob() == JOB_KNIGHT_MASTER) pUser->ChangeJob(JOB_KNIGHT_HERO); break;
		case JOB_BLADE_HERO: if (pUser->GetJob() == JOB_BLADE_MASTER) pUser->ChangeJob(JOB_BLADE_HERO); break;
		case JOB_JESTER_HERO: if (pUser->GetJob() == JOB_JESTER_MASTER) pUser->ChangeJob(JOB_JESTER_HERO); break;
		case JOB_RANGER_HERO: if (pUser->GetJob() == JOB_RANGER_MASTER) pUser->ChangeJob(JOB_RANGER_HERO); break;
		case JOB_RINGMASTER_HERO: if (pUser->GetJob() == JOB_RINGMASTER_MASTER) pUser->ChangeJob(JOB_RINGMASTER_HERO); break;
		case JOB_BILLPOSTER_HERO: if (pUser->GetJob() == JOB_BILLPOSTER_MASTER) pUser->ChangeJob(JOB_BILLPOSTER_HERO); break;
		case JOB_PSYCHIKEEPER_HERO: if (pUser->GetJob() == JOB_PSYCHIKEEPER_MASTER) pUser->ChangeJob(JOB_PSYCHIKEEPER_HERO); break;
		case JOB_ELEMENTOR_HERO: if (pUser->GetJob() == JOB_ELEMENTOR_MASTER) pUser->ChangeJob(JOB_ELEMENTOR_HERO); break;
		default: Error("[Warning] CDPSrvr::OnSendJobChange (4) - %s", pUser->GetName()); break;
		}
	}
	else if (pUser->GetLevel() == MAX_LEGEND_LEVEL && pUser->IsHero())
	{
		switch (nJob)
		{
		case JOB_LORDTEMPLER_HERO: if (pUser->GetJob() == JOB_KNIGHT_HERO) pUser->ChangeJob(JOB_LORDTEMPLER_HERO); break;
		case JOB_STORMBLADE_HERO: if (pUser->GetJob() == JOB_BLADE_HERO) pUser->ChangeJob(JOB_STORMBLADE_HERO); break;
		case JOB_WINDLURKER_HERO: if (pUser->GetJob() == JOB_JESTER_HERO) pUser->ChangeJob(JOB_WINDLURKER_HERO); break;
		case JOB_CRACKSHOOTER_HERO: if (pUser->GetJob() == JOB_RANGER_HERO) pUser->ChangeJob(JOB_CRACKSHOOTER_HERO); break;
		case JOB_FLORIST_HERO: if (pUser->GetJob() == JOB_RINGMASTER_HERO) pUser->ChangeJob(JOB_FLORIST_HERO); break;
		case JOB_FORCEMASTER_HERO: if (pUser->GetJob() == JOB_BILLPOSTER_HERO) pUser->ChangeJob(JOB_FORCEMASTER_HERO); break;
		case JOB_MENTALIST_HERO: if (pUser->GetJob() == JOB_PSYCHIKEEPER_HERO) pUser->ChangeJob(JOB_MENTALIST_HERO); break;
		case JOB_ELEMENTORLORD_HERO: if (pUser->GetJob() == JOB_ELEMENTOR_HERO) pUser->ChangeJob(JOB_ELEMENTORLORD_HERO); break;
		default: Error("[Warning] CDPSrvr::OnSendJobChange (5) - %s", pUser->GetName()); break;
		}
	}
#ifdef __ZCK_4_CLASSES
	else if (pUser->GetLevel() == MAX_3RD_LEGEND_LEVEL && pUser->IsLegendHero())
	{
		switch (nJob)
		{
		case JOB_LORDTEMPLER_HERO_ULTIMATE: if (pUser->GetJob() == JOB_LORDTEMPLER_HERO) pUser->ChangeJob(JOB_LORDTEMPLER_HERO_ULTIMATE); break;
		case JOB_STORMBLADE_HERO_ULTIMATE: if (pUser->GetJob() == JOB_STORMBLADE_HERO) pUser->ChangeJob(JOB_STORMBLADE_HERO_ULTIMATE); break;
		case JOB_WINDLURKER_HERO_ULTIMATE: if (pUser->GetJob() == JOB_WINDLURKER_HERO) pUser->ChangeJob(JOB_WINDLURKER_HERO_ULTIMATE); break;
		case JOB_CRACKSHOOTER_HERO_ULTIMATE: if (pUser->GetJob() == JOB_CRACKSHOOTER_HERO) pUser->ChangeJob(JOB_CRACKSHOOTER_HERO_ULTIMATE); break;
		case JOB_FLORIST_HERO_ULTIMATE: if (pUser->GetJob() == JOB_FLORIST_HERO) pUser->ChangeJob(JOB_FLORIST_HERO_ULTIMATE); break;
		case JOB_FORCEMASTER_HERO_ULTIMATE: if (pUser->GetJob() == JOB_FORCEMASTER_HERO) pUser->ChangeJob(JOB_FORCEMASTER_HERO_ULTIMATE); break;
		case JOB_MENTALIST_HERO_ULTIMATE: if (pUser->GetJob() == JOB_MENTALIST_HERO) pUser->ChangeJob(JOB_MENTALIST_HERO_ULTIMATE); break;
		case JOB_ELEMENTORLORD_HERO_ULTIMATE: if (pUser->GetJob() == JOB_ELEMENTORLORD_HERO) pUser->ChangeJob(JOB_ELEMENTORLORD_HERO_ULTIMATE); break;
		default: Error("[Warning] CDPSrvr::OnSendJobChange (6) - %s", pUser->GetName()); break;
		}
	}
#endif // __ZCK_4_CLASSES
}
#endif

#ifdef __FL_RECYCLE
void CDPSrvr::OnRecycle(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwItem;
	ar >> dwItem;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwItem);
	if (!IsUsableItem(pItemElem))
		return;

	auto it = prj.mapRecycle.find(pItemElem->m_dwItemId);
	if (it == prj.mapRecycle.end())
		return;

	if (pUser->IsUsing(pItemElem))
	{
		pUser->AddDefinedText(TID_GAME_EQUIPPUT);
		return;
	}

	if (pUser->m_Inventory.IsEquip(dwItem))
	{
		pUser->AddDefinedText(TID_GAME_EQUIPPUT);
		return;
	}

	ItemProp* pRewardProp = prj.GetItemProp(__FL_RECYCLE);
	if (!pRewardProp)
		return;

	CItemElem pItemReward;
	pItemReward.m_dwItemId = pRewardProp->dwID;
	pItemReward.m_nItemNum = it->second;
	pItemReward.m_nHitPoint = pRewardProp->dwEndurance;
	pItemReward.SetSerialNumber();

	if (pUser->CreateItem(&pItemReward))
	{
		pUser->RemoveItem((BYTE)dwItem, 1);
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Recyclage termin\351, v\351rifiez votre inventaire !");
#else
		pUser->AddText("Recycling is done, check your inventory!");
#endif // __ZCK_TRAD_FR
	}
	else
		pUser->AddDefinedText(TID_GAME_LACKSPACE);
}
#endif

#ifdef __FL_PARTY_FINDER
void CDPSrvr::OnPartyFinderRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	g_PartyMng.AddPartyList(pUser);
}
void CDPSrvr::OnPartyFinderJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	u_long uPartyId;
	ar >> uPartyId;

	CUser* pMember = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pMember))
		return;

	CParty* pParty = g_PartyMng.GetParty(uPartyId);
	if (!pParty || !pParty->m_bAllowed)
	{
		pMember->AddDefinedText(TID_GAME_NOPARTY);
		return;
	}

	CParty* pMemberParty = g_PartyMng.GetParty(pMember->m_idparty);
	if (pMemberParty)
	{
#ifdef __ZCK_TRAD_FR
		pMember->AddText("Vous \352tes d\351j\340 dans un groupe.", 0xffffffff);
#else
		pMember->AddText("You already in party.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}

	if (pParty->GetSizeofMember() >= MAX_PTMEMBER_SIZE_SPECIAL)
	{
		pMember->AddDefinedText(TID_DIAG_0007);
		return;
	}

	g_PartyMng.RequestAddPartyMemberToCS(pParty->m_aMember[0].m_uPlayerId, pMember->m_idPlayer);
}
#endif

#ifndef __FL_VENDORS
void CDPSrvr::OnRegisterPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE iIndex, nType, nId;
	short nNum;
	int nCost;
	ar >> iIndex >> nType >> nId >> nNum >> nCost;

	if (iIndex >= MAX_VENDOR_REVISION)
		return;

	if (nCost < 1)
		nCost = 1;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
		if (ZckRefusStaff(pUser, "boutique personnelle"))
			return;
#else
#line 10001 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
		if (pUser->m_vtInfo.GetOther())
			return;
		if (pUser->m_vtInfo.IsVendorOpen())
			return;
#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif
		if (pUser->IsRegionAttr(RA_FIGHT))
		{
			pUser->AddDefinedText(TID_GAME_FAIL_TO_OPEN_SHOP);
			return;
		}

		if (pUser->GetWorld() && pUser->GetWorld()->GetID() == WI_WORLD_MINIROOM)
			return;

		if (CNpcChecker::GetInstance()->IsCloseNpc(pUser->GetWorld(), pUser->GetPos()))
		{
			pUser->AddDiagText(prj.GetText(TID_GAME_NPC_RADIUS));
			return;
		}

		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(nId);
		if (IsUsableItem(pItemElem))
		{
			if (pItemElem->IsQuest())
				return;

			if (pItemElem->IsBinds())
				return;
			if (pUser->IsUsing(pItemElem))
			{
				pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
				return;
			}

			ItemProp* pProp = pItemElem->GetProp();

			if (pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
				return;

			if (pItemElem->IsFlag(CItemElem::expired))
				return;

			if (nNum > pItemElem->m_nItemNum)
				nNum = pItemElem->m_nItemNum;
			if (nNum < 1)
				nNum = 1;

			pUser->m_vtInfo.VendorSetItem(nId, iIndex, nNum, nCost);
			pUser->AddRegisterPVendorItem(iIndex, 0, nId, nNum, nCost);
		}
	}
}

void CDPSrvr::OnUnregisterPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE i;
	ar >> i;

	if (i >= MAX_VENDITEM)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
		if (ZckRefusStaff(pUser, "boutique personnelle"))
			return;
#else
#line 10071 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
		if (pUser->m_vtInfo.GetOther())
			return;
		if (pUser->m_vtInfo.IsVendorOpen())
			return;

		if (pUser->m_vtInfo.VendorClearItem(i))
			pUser->AddUnregisterPVendorItem(i);
	}
}
void CDPSrvr::OnPVendorOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (uBufSize > 55)
		return;

	char szPVendor[MAX_VENDORNAME];
	ar.ReadString(szPVendor, MAX_VENDORNAME);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsValidObj(pUser))
	{
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
		if (ZckRefusStaff(pUser, "boutique personnelle"))
			return;
#else
#line 10091 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
		if (_tcslen(szPVendor) < 6 || _tcslen(szPVendor) > 32)
		{
			pUser->AddDefinedText(TID_DIAG_0011);
			return;
		}

		if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
			ParsingEffect(szPVendor, strlen(szPVendor));

		CWorld* pWorld = pUser->GetWorld();
		if (!pWorld)
			return;

		if (pWorld->GetID() == WI_WORLD_GUILDWAR)
		{
			pUser->AddText(prj.GetText(TID_GAME_GUILDCOMBAT_CANNOT_TRADE));
			return;
		}

		if (pWorld->GetID() == WI_WORLD_MINIROOM)
			return;

		if (pUser->m_vtInfo.GetOther())
			return;

		if (pUser->IsAttackMode())
			return;

#ifdef __FL_EQUALIZED_MODE
		if (pUser->bTmpMode)
		{
			pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
			return;
		}
#endif
		if (pUser->m_pActMover->IsFly())
			return;

		if (pUser->IsChaotic())
		{
			CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty(pUser->GetPKPropensity());
			if (!Propensity.nVendor)
			{
				pUser->AddDefinedText(TID_GAME_CHAOTIC_NOT_VENDOR);
				return;
			}
		}

#ifdef __S_SERVER_UNIFY
		if (pUser->m_bAllAction == FALSE)
			return;
#endif // __S_SERVER_UNIFY

		pUser->m_vtInfo.SetTitle(szPVendor);

		if (pUser->m_vtInfo.IsVendorOpen())
		{
			if (pUser->m_vtInfo.VendorIsVendor())
			{
#ifdef __FL_SHOP_SEARCH
				prj.AddToShopSearch(pUser->GetId());
#endif

				g_ChattingMng.NewChattingRoom(pUser->m_idPlayer);
				CChatting* pChatting = g_ChattingMng.GetChttingRoom(pUser->m_idPlayer);

				g_UserMng.AddPVendorOpen(pUser);
				if (pChatting)
				{
					pChatting->m_bState = TRUE;
					if (pChatting->AddChattingMember(pUser->m_idPlayer))
						pUser->m_idChatting = pUser->m_idPlayer;
					pUser->AddNewChatting(pChatting);
				}
				pUser->m_dwHonorCheckTime = GetTickCount();

			}
		}
	}
}
#else 
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
// define retire : numeros de ligne retablis au debut de cette branche
#else
#line 10172 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
void CDPSrvr::OnRegisterPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE iIndex, nType, nId;
	short nNum;
	int nCost;
	int nPerinCost;
	BOOL bOwnShop;

	ar >> iIndex >> nType >> nId >> nNum >> nCost >> nPerinCost;
	ar >> bOwnShop;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "boutique personnelle"))
		return;
#else
#line 10186 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	if (!pUser->GetWorld())
		return;

	if (bOwnShop && (pUser->m_vtInfo.IsVendorOpen() || pUser->m_vtInfo.GetOther()))
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(nId);
	if (!IsUsableItem(pItemElem))
		return;

	if (pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId) || pUser->IsUsing(pItemElem))
		return;

	if (pItemElem->IsFlag(CItemElem::expired))
		return;

	if (pItemElem->IsQuest() || pItemElem->IsBinds())
		return;

	if (iIndex >= MAX_VENDOR_REVISION)
		return;

	if (nPerinCost < 0)
		nPerinCost = 0;
	if (nPerinCost > 9999)
		nPerinCost = 9999;

	if (nCost > PERIN_VALUE - 1)
		nCost = PERIN_VALUE - 1;
	if (nCost < 1 && nPerinCost < 1)
		nCost = 1;

	if (nNum > pItemElem->m_nItemNum)
		nNum = pItemElem->m_nItemNum;
	if (nNum < 1)
		nNum = 1;

	if (bOwnShop) // Own private shop
	{
		if (pUser->m_vtInfo.GetItem(iIndex))
			return;

		pUser->m_vtInfo.VendorSetItem(nId, iIndex, nNum, nCost, nPerinCost);
		pUser->AddRegisterPVendorItem(iIndex, 0, nId, nNum, nCost, nPerinCost);
	}
	else
	{
		auto it = prj.m_mapPlayerShops.find(pUser->m_idPlayer);
		if (it == prj.m_mapPlayerShops.end())
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Vous n'avez pas activ\351 votre vendeur.", 0xffffffff);
#else
			pUser->AddText("You have not activated vendor.", 0xffffffff);
#endif // __ZCK_TRAD_FR
			return;
		}

		CMover* pMoverVendor = prj.GetMover(it->second);
		if (!IsValidObj(pMoverVendor))
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Vendeur invalide.", 0xffffffff);
#else
			pUser->AddText("Invalid vendor.", 0xffffffff);
#endif // __ZCK_TRAD_FR
			return;
		}

		if (!pMoverVendor->m_vtInfo.IsVendorOpen())
			return;

		if (pMoverVendor->m_vtInfo.GetItem(iIndex))
			return;

		// Remove from player, add to vendor
		pMoverVendor->m_vtInfo.PlayerToVendorSingle(pUser, pItemElem, iIndex, nNum, nCost, nPerinCost);

		// Save vendor, save player (TODO: delayed saving)
		g_dpDBClient.SendUpdateVendor(pMoverVendor);
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

		// Add in clients side
		g_UserMng.AddNewItemToLiveVendor(pMoverVendor, iIndex);
		pUser->AddVendorPreview(pMoverVendor);
	}
}

void CDPSrvr::OnUnregisterPVendorItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE i;
	BOOL bOwnShop;

	ar >> i;
	ar >> bOwnShop;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "boutique personnelle"))
		return;
#else
#line 10294 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	if (!pUser->GetWorld())
		return;

	if (bOwnShop && (pUser->m_vtInfo.IsVendorOpen() || pUser->m_vtInfo.GetOther()))
		return;

	if (i >= MAX_VENDITEM)
		return;

	if (bOwnShop) // Own private shop
	{
		if (pUser->m_vtInfo.VendorClearItem(i))
			pUser->AddUnregisterPVendorItem(i);
	}
	else // Own vendor shop
	{
		auto it = prj.m_mapPlayerShops.find(pUser->m_idPlayer);
		if (it == prj.m_mapPlayerShops.end())
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Vous n'avez pas activ\351 votre vendeur.", 0xffffffff);
#else
			pUser->AddText("You have not activated vendor.", 0xffffffff);
#endif // __ZCK_TRAD_FR
			return;
		}

		CMover* pMoverVendor = prj.GetMover(it->second);
		if (!IsValidObj(pMoverVendor))
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Vendeur invalide.", 0xffffffff);
#else
			pUser->AddText("Invalid vendor.", 0xffffffff);
#endif // __ZCK_TRAD_FR
			return;
		}

		if (!pMoverVendor->m_vtInfo.IsVendorOpen())
			return;

		if (!pMoverVendor->m_vtInfo.GetItem(i))
		{
			pUser->AddVendorPreview(pMoverVendor);
			return;
		}

		// Remove from vendor, add to player
		pMoverVendor->m_vtInfo.VendorToPlayerSingle(pUser, i);

		// Save vendor, save player (TODO: delayed saving)
		g_dpDBClient.SendUpdateVendor(pMoverVendor);
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

		// Remove in clients side
		g_UserMng.AddPVendorItemNum((CUser*)pMoverVendor, i, 0, "");
		pUser->AddVendorPreview(pMoverVendor);
	}
}
void CDPSrvr::OnPVendorOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	if (uBufSize > 55)
		return;

	BOOL bOwnShop;
	DWORD dwObjId;

	ar >> bOwnShop;
	ar >> dwObjId;

	char szPVendor[MAX_VENDORNAME];
	ar.ReadString(szPVendor, MAX_VENDORNAME);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	if (ZckRefusStaff(pUser, "boutique personnelle"))
		return;
#else
#line 10371 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

	if (_tcslen(szPVendor) < 6 || _tcslen(szPVendor) > 32)
	{
		pUser->AddDefinedText(TID_DIAG_0011);
		return;
	}

	if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
		ParsingEffect(szPVendor, strlen(szPVendor));

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld || pWorld->GetID() != WI_WORLD_MADRIGAL)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Vous ne pouvez ouvrir une boutique priv\351e qu'\340 Madrigal !", 0xffffffff);
#else
		pUser->AddText("You can open private shop only in Madrigal!", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}

	/*	const BYTE nCont = CContinent::GetInstance()->GetContinent(pUser);
		if (nCont != CONT_SAINTMORNING)
		{
			pUser->AddText("You can open private shop only in Saint Morning!", 0xffffffff);
			return;
		}*/

	if (pUser->m_vtInfo.GetOther() || pUser->m_vtInfo.IsVendorOpen())
		return;

	if (!pUser->m_vtInfo.VendorIsVendor())
		return;

	if (pUser->IsAttackMode() || pUser->m_pActMover->IsFly())
		return;

#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
	{
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT_NOT_USE);
		return;
	}
#endif

	if (pUser->IsChaotic())
	{
		CHAO_PROPENSITY Propensity = prj.GetPropensityPenalty(pUser->GetPKPropensity());
		if (!Propensity.nVendor)
		{
			pUser->AddDefinedText(TID_GAME_CHAOTIC_NOT_VENDOR);
			return;
		}
	}

#ifdef __S_SERVER_UNIFY
	if (pUser->m_bAllAction == FALSE)
		return;
#endif // 

	if (bOwnShop) // Own private shop
	{
		pUser->m_vtInfo.SetTitle(szPVendor);
		g_UserMng.AddPVendorOpen(pUser);

#ifdef __FL_SHOP_SEARCH
		prj.AddToShopSearch(pUser->GetId());
#endif
		// Chat
		g_ChattingMng.NewChattingRoom(pUser->m_idPlayer);
		CChatting* pChatting = g_ChattingMng.GetChttingRoom(pUser->m_idPlayer);
		if (pChatting)
		{
			pChatting->m_bState = TRUE;
			if (pChatting->AddChattingMember(pUser->m_idPlayer))
				pUser->m_idChatting = pUser->m_idPlayer;
			pUser->AddNewChatting(pChatting);
		}
		pUser->m_dwHonorCheckTime = GetTickCount();
	}
	else // Own private vendor
	{
		if (dwObjId == NULL_ID)
			return;

		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwObjId);
		if (!IsUsableItem(pItemElem))
		{
			pUser->AddDefinedText(TID_GAME_HOUSING_ADDITION_FAIL);
			return;
		}

		ItemProp* pProp = pItemElem->GetProp();
		if (!pProp || pProp->dwItemKind3 != IK3_VENDOR)
			return;

		DWORD dwSkillTime = pItemElem->m_dwKeepTime ? pItemElem->m_dwKeepTime : pProp->dwSkillTime;
		if (dwSkillTime == NULL || dwSkillTime == NULL_ID)
			return;

		if (g_uIdofMulti != __FL_VENDORS)
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Les vendeurs hors ligne ne sont pas autoris\351s sur ce canal.", 0xffffffff);
#else
			pUser->AddText("Offline Vendors not allowed at this channel.", 0xffffffff);
#endif // __ZCK_TRAD_FR
			return;
		}

		auto it = prj.m_mapPlayerShops.find(pUser->m_idPlayer);
		if (it != prj.m_mapPlayerShops.end())
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Vous avez d\351j\340 un vendeur.", 0xffffffff);
#else
			pUser->AddText("You already have vendor.", 0xffffffff);
#endif // __ZCK_TRAD_FR
			return;
		}

		CMover* pMoverVendor = NULL;

		PLAYER_COPY tmpStruc;
		tmpStruc.idPlayer = pUser->m_idPlayer;
		tmpStruc.strName = pUser->GetName();
		tmpStruc.nJob = pUser->GetJob();
		tmpStruc.nLevel = pUser->GetLevel();
		tmpStruc.dwHairId = pUser->m_dwHairMesh;
		tmpStruc.dwHairColor = pUser->m_dwHairColor;
		tmpStruc.dwHeadId = pUser->m_dwHeadMesh;
		tmpStruc.vPos = pUser->GetPos();
		tmpStruc.dwWorld = pUser->GetWorld()->GetID();
		tmpStruc.fAngle = pUser->GetAngle();

		if (pProp->dwAbilityMin != NULL_ID)
		{
			MoverProp* pMoverProp = prj.GetMoverProp(pProp->dwAbilityMin);
			if (!pMoverProp)
				return;

			tmpStruc.dwIndex = pMoverProp->dwID;
			tmpStruc.tmpInventoryOwner = NULL;
			pMoverVendor = g_GuildCombatMng.CreatePlayerCopy(NPC_TYPE_VENDOR_NPC, tmpStruc);
		}
		else
		{
			tmpStruc.dwIndex = pUser->GetSex() == SEX_MALE ? MI_MALE : MI_FEMALE;
			tmpStruc.tmpInventoryOwner = &pUser->m_Inventory;
#ifdef __FL_WARDROBE
			tmpStruc.wardrobe.Copy(pUser->m_Wardrobe, false);
#endif
			pMoverVendor = g_GuildCombatMng.CreatePlayerCopy(NPC_TYPE_VENDOR_HUMAN, tmpStruc);
		}

		if (!pMoverVendor)
			return;

		pMoverVendor->SetVendorTime(pItemElem->m_dwKeepTime ? pItemElem->m_dwKeepTime + time(0) : pProp->dwSkillTime * 60 + time(0));
		pMoverVendor->SetVendorItemId(pProp->dwID);
		pMoverVendor->m_Inventory.SetItemContainer(ITYPE_ITEM, MAX_VENDITEM);

		pMoverVendor->m_vtInfo.PlayerToVendorAll(pUser);
		pMoverVendor->m_vtInfo.SetTitle(szPVendor);
		g_UserMng.AddPVendorOpen((CUser*)pMoverVendor);

#ifdef __FL_SHOP_SEARCH
		prj.AddToShopSearch(pMoverVendor->GetId());
#endif
		pUser->RemoveItem((BYTE)dwObjId, 1);
		pUser->ActivateClientVendor();
		g_dpDBClient.SendAddVendor(pMoverVendor);
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
	}
}

void CDPSrvr::OnVendorAction(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	BYTE nAction;
	ar >> nAction;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	auto it = prj.m_mapPlayerShops.find(pUser->m_idPlayer);
	if (it == prj.m_mapPlayerShops.end())
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Vous n'avez pas activ\351 votre vendeur.", 0xffffffff);
#else
		pUser->AddText("You have not activated vendor.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}

	CMover* pMoverVendor = prj.GetMover(it->second);
	if (!IsValidObj(pMoverVendor))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Vendeur invalide.", 0xffffffff);
#else
		pUser->AddText("Invalid vendor.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}

	switch (nAction)
	{
	case 1: pMoverVendor->ShutdownVendor(); break;
	case 2: pUser->AddVendorPreview(pMoverVendor); break;
	default: return;
	}
}
#endif
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
// define retire : numeros de ligne retablis apres le bloc conditionnel ci-dessus
#else
#line 10586 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF

#ifdef __FL_CASH_SHOP
void CDPSrvr::OnGetCShopBalance(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	g_dpDBClient.SendGetCShopBalance(pUser->m_idPlayer, pUser->m_playAccount.lpszAccount);
}
void CDPSrvr::OnBuyCShopItem(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nItemUniqueID;
	int nItemAmount;
	BOOL bDonate;
	u_long idReceiver;

	ar >> nItemUniqueID >> nItemAmount >> bDonate;
	ar >> idReceiver;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	DWORD dwItemID = NULL_ID;
	int nItemNum = 0;
	__int64 n64TotalPrice = 0;

	for (auto& it : *CFlyFFShop::GetInstance()->GetItemVector())
	{
		if (nItemUniqueID != it.nItemIndex)
			continue;

		dwItemID = it.dwItemID;
		nItemNum = it.nAmount * nItemAmount;

		if (bDonate)
		{
			if (it.nPurchaseMethod == CS_METHOD_DP || it.nPurchaseMethod == CS_METHOD_BOTH)
				n64TotalPrice = it.nDonatePrice;
		}
		else
		{
			if (it.nPurchaseMethod == CS_METHOD_VP || it.nPurchaseMethod == CS_METHOD_BOTH)
				n64TotalPrice = it.nVotePrice;
		}

		break;
	}

	if (n64TotalPrice == 0)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Objet ou monnaie invalide.", 0xffffffff);
#else
		pUser->AddText("Invalid item or currency.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}

	if (nItemAmount < 1 || nItemAmount > 99)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Quantit\351 d'objets invalide.", 0xffffffff);
#else
		pUser->AddText("Invalid item amount.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}

	// FIX_031223 BEGIN
	if (nItemNum > SHRT_MAX)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Achat impossible. R\351duisez la quantit\351 et r\351essayez.", 0xffffffff);
#else
		pUser->AddText("Cannot buy. Decrease amount of items and try again.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}
	// FIX_031223 END

	ItemProp* pProp = prj.GetItemProp(dwItemID);
	if (!pProp)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Probl\350me inattendu avec l'objet. Achat impossible.", 0xffffffff);
#else
		pUser->AddText("Unexpected item problem. Unable to purchase.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		Error("CShop Error: itemprop is null [%d]", nItemUniqueID);
		return;
	}

	n64TotalPrice *= nItemAmount;
	if (n64TotalPrice < 1 || n64TotalPrice > INT_MAX)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Probl\350me inattendu de limite de prix. Achat impossible.", 0xffffffff);
#else
		pUser->AddText("Unexpected price limit problem. Unable to purchase.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		Error("CShop Error: price < 1 or > INT_MAX for item id [%d]", nItemUniqueID);
		return;
	}

	int nTotalPrice = static_cast<int>(n64TotalPrice);
	g_dpDBClient.SendBuyCShopItem(pUser->m_idPlayer, pUser->m_playAccount.lpszAccount, dwItemID, nItemNum, nTotalPrice, bDonate, idReceiver);
}
#endif

#ifdef __FL_NEW_BOXES
void CDPSrvr::OnNewBoxOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwObjId;
	int nCurSel;

	ar >> dwObjId >> nCurSel;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!pUser->IsPossibleUseItem())
		return;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwObjId);
	if (!IsUsableItem(pItemElem))
		return;

	ItemProp* pItemPropBox = pItemElem->GetProp();
	if (!pItemPropBox)
		return;

	if (pUser->IsUsing(pItemElem))
	{
		pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
		return;
	}

	if (pUser->m_Inventory.IsEquip(dwObjId))
	{
		pUser->AddDefinedText(TID_GAME_EQUIPTRADE, "");
		return;
	}

	auto vecItems = CNewBoxes::GetInstance()->GetBoxElements(pItemElem->m_dwItemId);
	if (vecItems == NULL)
		return;

	if (nCurSel < 0 || nCurSel >= vecItems->size())
		return;

	CItemElem itemElem;
	itemElem.m_dwItemId = vecItems->at(nCurSel).dwReward;
	itemElem.m_nItemNum = vecItems->at(nCurSel).nItemCount;
	if (vecItems->at(nCurSel).bBinded)
		itemElem.SetFlag(CItemElem::binds);

	ItemProp* pItemPropReward = itemElem.GetProp();
	if (!pItemPropReward)
		return;

	if (!pUser->CreateItem(&itemElem))
	{
		pUser->AddDefinedText(TID_GAME_LACKSPACE);
		return;
	}

	pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), 1);

	// TODO: Move text/sound/sfx to one separate packet and do it in client side instead
#ifdef __ZCK_TRAD_FR
	CString str; str.Format("Vous avez ouvert '%s' et re\347u '%s' (x%d) !", pItemPropBox->szName, pItemPropReward->szName, vecItems->at(nCurSel).nItemCount);
#else
	CString str; str.Format("You successfully opened '%s' and received '%s' (x%d)!", pItemPropBox->szName, pItemPropReward->szName, vecItems->at(nCurSel).nItemCount);
#endif // __ZCK_TRAD_FR
	pUser->AddText(str, 0xffffff00);
	if ((pUser->IsMode(TRANSPARENT_MODE)) == 0)
		g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
}
#endif

void CDPSrvr::OnUseTransy(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	DWORD dwObjId;
	int nSel;

	ar >> dwObjId >> nSel;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!pUser->IsPossibleUseItem())
		return;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwObjId);
	if (!IsUsableItem(pItemElem))
		return;

	ItemProp* pItemProp = pItemElem->GetProp();
	if (!pItemProp)
		return;

	if (pItemProp->dwID != II_CHR_SYS_SCR_TRANSY)
		return;

	if (pUser->IsUsing(pItemElem))
	{
		pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
		return;
	}

	if (!pUser->DoUseItemSexChange(nSel))
		return;

	if (pUser->HasBuffByIk3(IK3_TEXT_DISGUISE))
		pUser->RemoveIk3Buffs(IK3_TEXT_DISGUISE);

	pUser->RemoveItem((BYTE)(pItemElem->m_dwObjId), 1);
}

#ifdef __FL_PENYA_CONVERTER
void CDPSrvr::OnConvertPenya(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (pUser->IsDie())
		return;

	pUser->PenyaToPerins();
}
#endif

#ifdef __FL_SWITCH_EQ
void CDPSrvr::OnSwitchAdd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nSel;
	char lpszName[32] = { 0, };
	DWORD dwLooter, dwPet, dwRegen, dwNewPet;

	ar >> nSel;
	ar.ReadString(lpszName, 32);
	ar >> dwLooter;
	ar >> dwPet;
	ar >> dwRegen;
	ar >> dwNewPet;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (pUser->m_Switches.AddSwitch(nSel, lpszName, dwLooter, dwPet, dwRegen, dwNewPet, TRUE))
		pUser->AddSwitchAdd(nSel, lpszName, dwLooter, dwPet, dwRegen, dwNewPet);
}
void CDPSrvr::OnSwitchDelete(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nSel;
	ar >> nSel;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (pUser->m_Switches.DeleteSwitch(nSel))
		pUser->AddSwitchDelete(nSel);
}
void CDPSrvr::OnSwitchUse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	int nSel;
	ar >> nSel;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->m_Switches.UseSwitch(nSel);
}
#endif

#ifdef __FL_GUILD_FINDER
void CDPSrvr::OnGuildFinderRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->AddGuildFinder();
}
void CDPSrvr::OnGuildFinderJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	u_long idGuild;
	ar >> idGuild;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CGuild* pUserGuild = g_GuildMng.GetGuild(pUser->m_idGuild);
	if (pUserGuild && pUserGuild->IsMember(pUser->m_idPlayer))
		return;

	CGuild* pTargetGuild = g_GuildMng.GetGuild(idGuild);
	if (!pTargetGuild || !pTargetGuild->m_bFinder)
		return;

	if (pTargetGuild->GetSize() >= pTargetGuild->GetMaxMemberSize())
		return;

	if (!IsInviteAbleGuild(idGuild, NULL))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Vous ne pouvez pas rejoindre cette guilde pour le moment.", 0xffffffff);
#else
		pUser->AddText("You cannot join this guild right now.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return;
	}

	BEFORESENDDUAL(out, PACKETTYPE_ADD_GUILD_MEMBER, DPID_UNKNOWN, DPID_UNKNOWN);
	out << pUser->m_idPlayer << idGuild;
	SEND(out, &g_DPCoreClient, DPID_SERVERPLAYER);
}
void CDPSrvr::OnGuildFinderAddon(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	u_long idGuild;
	ar >> idGuild;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CGuild* pTargetGuild = g_GuildMng.GetGuild(idGuild);
	if (!pTargetGuild || !pTargetGuild->m_bFinder)
		return;

	pUser->AddGuildFinderAddon(pTargetGuild);
}
#endif

#ifdef __FL_PACKED_ITEMS
void CDPSrvr::OnPackageOpen(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	DWORD dwObjId;
	ar >> dwObjId;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwObjId);
	if (!IsUsableItem(pItemElem))
		return;

	if (pUser->IsUsing(pItemElem))
	{
		pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
		return;
	}

	if (!pItemElem->IsPackage())
		return;

	auto pVecItems = pItemElem->GetItemList();
	if (pVecItems->empty())
		return;

	if (pUser->m_Inventory.GetEmptyCount() < pVecItems->size())
	{
		pUser->AddText(prj.GetText(TID_GAME_LACKSPACE), 0xffffffff);
		return;
	}

	for (auto& it : *pVecItems)
		pUser->CreateItem(it);

	pItemElem->ClearPackedItems();
	pUser->AddPackageOpen(dwObjId);
}
void CDPSrvr::OnPackageAdd(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	DWORD dwPackObjId, dwItemObjId;
	ar >> dwPackObjId >> dwItemObjId;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	// Check package and item
	CItemElem* pPackageElem = pUser->m_Inventory.GetAtId(dwPackObjId);
	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwItemObjId);
	if (!IsUsableItem(pPackageElem) || !IsUsableItem(pItemElem))
		return;

	if (!pPackageElem->IsPackage() || pItemElem->IsPackage())
		return;

	if (pUser->IsUsing(pPackageElem) || pUser->IsUsing(pItemElem))
	{
		pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
		return;
	}

	// Check item
	if (pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
	{
		pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
		return;
	}

	if (pItemElem->IsFlag(CItemElem::expired) || pItemElem->IsQuest() || pItemElem->IsBinds())
		return;

	// Add
	if (pPackageElem->AddToPack(pItemElem))
	{
		pUser->AddPackageAdd(dwPackObjId, dwItemObjId);
		pUser->RemoveItem((BYTE)dwItemObjId, pItemElem->m_nItemNum);
	}
}
void CDPSrvr::OnPackageRestore(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	DWORD dwObjId;
	int nCurSel;

	ar >> dwObjId >> nCurSel;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwObjId);
	if (!IsUsableItem(pItemElem))
		return;

	if (pUser->IsUsing(pItemElem))
	{
		pUser->AddDefinedText(TID_GAME_CANNOT_DO_USINGITEM);
		return;
	}

	if (pUser->m_Inventory.GetEmptyCount() < 1)
	{
		pUser->AddText(prj.GetText(TID_GAME_LACKSPACE), 0xffffffff);
		return;
	}

	if (!pItemElem->IsPackage())
		return;

	auto pVecItems = pItemElem->GetItemList();
	if (nCurSel < 0 || nCurSel >= static_cast<int>(pVecItems->size()))
		return;

	CItemElem* pItemInside = pVecItems->at(nCurSel);

	CItemElem itemElem;
	itemElem = *pItemInside;

	if (pItemElem->DeleteFromPack(nCurSel))
	{
		pUser->CreateItem(&itemElem);
		pUser->AddPackageRestore(dwObjId, nCurSel);
	}
}
#endif

#ifdef __FL_WHEEL_OF_FORTUNE
void CDPSrvr::OnWofRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	DWORD dwVersion;
	ar >> dwVersion;

	if (dwVersion == CWheelOfFortune::GetInstance()->GetVersion())
		return;

	pUser->AddWof();
}
void CDPSrvr::OnWofStart(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	int nWheelIndex;
	ar >> nWheelIndex;

	CWheelOfFortune::GetInstance()->InitProcess(nWheelIndex, pUser);
}
void CDPSrvr::OnWofFinish(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CWheelOfFortune::GetInstance()->FinishProcess(pUser);
}
#endif

#ifdef __FL_RECORD_BOOK
void CDPSrvr::OnRecordBook(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	DWORD dwVersion;
	ar >> dwVersion;

	pUser->AddRecordBook(dwVersion == CRecordBook::GetInstance()->GetVersion());
}
#endif
#ifdef __FL_MONSTER_ALBUM
void CDPSrvr::OnMABossCardSlotRestore(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	DWORD dwKeyObjId;
	int nKeyLocation;
	int nSlot;

	ar >> dwKeyObjId >> nKeyLocation >> nSlot;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->m_MonsterAlbum.BossCardSlotRestore(dwKeyObjId, nKeyLocation, nSlot);
}
#endif
#ifdef __ZCK_ACHIEVEMENT
void CDPSrvr::OnZckAchievementClaim(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	int nAchievementId = 0;
	ar >> nAchievementId;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CZckAchievementManager::GetInstance()->ClaimReward(pUser, nAchievementId);
}
#endif
#ifdef __ZCK_QUEST
// Quetes : le paquet est lu en entier (contrat de _Common/ZckQuest.h), puis tout est juge
// par CZckQuestManager::Traiter : action, version du catalogue, horaire, niveau, prestige,
// etat de la quete, place, Penya, buffs. Le client ne designe jamais une recompense.
void CDPSrvr::OnZckQuest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	BYTE byAction = 0;
	int nId = 0;
	DWORD dwVersion = 0;
	DWORD dwFin = 0;
	ar >> byAction;
	ar >> nId;
	ar >> dwVersion;
	ar >> dwFin;
	if (dwFin != ZCK_QUEST_FIN)
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	BOOL bStaffBloque = FALSE;
#if defined(__ZCK_CUSTOM_UI_CORRECTIF)
	bStaffBloque = ZckStaffBloque(pUser);
#endif // ZckStaffBloque (__ZCK_CUSTOM_UI_CORRECTIF)
	CZckQuestManager::GetInstance()->Traiter(pUser, byAction, nId, dwVersion, bStaffBloque);
}
#endif // __ZCK_QUEST
#ifdef __ZCK_CLASSEMENT
void CDPSrvr::OnZckClassement(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	BYTE byCommand = 0;
	ar >> byCommand;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (byCommand != ZCK_CLASSEMENT_REQ_REFRESH)
		return;

	CZckClassementManager::GetInstance()->RequestBoards(pUser);
}
#endif // __ZCK_CLASSEMENT
#ifdef __ZCK_FENETRE_CHAT_MJ
void CDPSrvr::OnZckFenetreChatMj(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	BYTE byCommand = 0;
	ar >> byCommand;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	// L'autorisation n'est PAS testee ici : Subscribe la teste
	// lui-meme et refuse en silence. Un joueur ordinaire qui
	// forgerait ce paquet n'obtient rien et n'apprend rien.
	if (byCommand == ZCK_CHATMJ_REQ_SUBSCRIBE)
		CZckChatMjManager::GetInstance()->Subscribe(pUser);
	else if (byCommand == ZCK_CHATMJ_REQ_UNSUBSCRIBE)
		CZckChatMjManager::GetInstance()->Unsubscribe(pUser->m_idPlayer);
}
#endif // __ZCK_FENETRE_CHAT_MJ
#ifdef __ZCK_PRESTIGE
void CDPSrvr::OnZckPrestigeRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE /*lpBuf*/, u_long /*uBufSize*/)
{
	DWORD dwStoneObjId = NULL_ID;
	SERIALNUMBER nStoneSerial = 0;

	ar >> dwStoneObjId;
	ar >> nStoneSerial;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;

	pUser->ExecuteZckPrestige(dwStoneObjId, nStoneSerial);
}
#endif // __ZCK_PRESTIGE
#ifdef __ZCK_SYSTEME_EVEIL
static CItemElem* GetZckSystemeEveilScroll(
    CUser* pUser,
    DWORD dwItemId)
{
    if (!pUser)
        return NULL;

    const int nMax =
        pUser->m_Inventory.GetMax();

    for (int i = 0; i < nMax; ++i)
    {
        CItemElem* pItem =
            pUser->m_Inventory.GetAtId((DWORD)i);

        if (!pItem ||
            pItem->m_dwItemId != dwItemId)
        {
            continue;
        }

        if (!IsUsableItem(pItem))
            continue;

        if (pItem->m_nItemNum < 1 ||
            pItem->IsFlag(CItemElem::expired))
        {
            continue;
        }

        return pItem;
    }

    return NULL;
}

static void SendZckAwakeFailure(
    CUser* pUser,
    DWORD dwRequestId)
{
    if (!pUser)
        return;

    pUser->AddZckAwakeMasteryState(
        ZCK_AWAKE_RESULT_FAILED,
        ZCK_AWAKE_CATEGORY_INVALID,
        0,
        ZCK_AWAKE_QUALITY_NORMAL,
        ZCK_AWAKE_EVENT_NONE,
        dwRequestId);
}

void CDPSrvr::OnZckSystemeEveil(
    CAr& ar,
    DPID dpidCache,
    DPID dpidUser,
    LPBYTE,
    u_long)
{
    DWORD dwRequestId = 0;
    OBJID dwItemId = NULL_ID;
    SERIALNUMBER nItemSerial = 0;

    // ORDRE EXACT de Neuz/CDPClient::SendZckSystemeEveil().
    ar >> dwRequestId;
    ar >> dwItemId;
    ar >> nItemSerial;

    CUser* pUser =
        g_UserMng.GetUser(
            dpidCache,
            dpidUser);

    if (!IsValidObj(pUser) ||
        !pUser->GetWorld())
    {
        return;
    }

    // Le serveur refuse un requestId nul, ancien ou rejoué.
    if (!pUser->AcceptZckAwakeRequest(dwRequestId))
        return;

    if (!prj.m_ZckAwakeMasteryConfig.bEnabled)
    {
        pUser->AddText(
            "Le syst\350me de Ma\356trise d'\311veil est d\351sactiv\351 : configuration invalide.");

        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    if (!pUser->IsPossibleUseItem())
    {
        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    CItemElem* pItemElem =
        pUser->m_Inventory.GetAtId(
            dwItemId);

    if (!IsUsableItem(pItemElem) ||
        pItemElem->GetSerialNumber() != nItemSerial ||
        pItemElem->IsFlag(CItemElem::expired))
    {
        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    if (!pItemElem->GetProp())
    {
        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    if (pUser->m_Inventory.IsEquip(dwItemId))
    {
        pUser->AddDefinedText(
            TID_GAME_EQUIPPUT);

        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    if (pUser->IsUsing(pItemElem))
    {
        pUser->AddText(
            "Rangez cet objet avant de continuer.");

        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    // Liste blanche (revalidee ici, apres lecture complete du paquet, avec
    // la meme fonction que la fenetre et l'envoi client) : arme, armure,
    // familier, pet, fashion/costume. Tout le reste est refuse avant tout
    // cout, tout tirage et tout compteur, comme les autres refus de cette
    // fonction : message au demandeur, aucune ligne de journal (un client
    // modifie ne doit pas pouvoir remplir le journal a volonte).
    const BYTE byFamily =
        ZckAwakeGetFamily(
            pItemElem);

    if (byFamily >= ZCK_AWAKE_FAMILY_MAX)
    {
        pUser->AddText(
            "Cet objet n'est pas \351veillable : seuls les armes, les armures, "
            "les familiers, les pets, la fashion et les costumes le sont.");

        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    const int nKind =
        ZckAwakeGetFamilyRandomOptionKind(
            byFamily);

    // Une famille sans bloc dans randomoption.inc, ou une piece dont la
    // table d'extension (main, pied, casque) est vide, ne peut pas etre
    // eveillee.
    if (!g_xRandomOptionProperty->ZckHasRandomOptionTable(
            nKind,
            (int)pItemElem->GetProp()->dwParts))
    {
        pUser->AddText(
            "Cette famille n'a aucune table d'\351veil : \351veil impossible.");

        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    // Categorie de maitrise : arme et fashion/costume seulement. Familier
    // et pet s'eveillent sans maitrise (ZCK_AWAKE_CATEGORY_INVALID).
    const BYTE byCategory =
        ZckAwakeGetFamilyMasteryCategory(
            byFamily);

#ifdef __PROTECT_AWAKE
    // Ne jamais écraser un candidat Safe Awakening en attente.
    // Correctif 4 : le Safe Awakening n'est plus refuse ici. Il est
    // detecte plus bas et emprunte le chemin natif deja existant :
    // option generee a part, fenetre de choix ancien / nouveau.
#endif

    const int nCurrentOptionCount =
        g_xRandomOptionProperty->GetRandomOptionSize(
            pItemElem->GetRandomOptItemId());

    const BOOL bProtectionAlreadyStaged =
        pUser->IsZckAwakeProtectionStaged(
            pItemElem);

#ifdef __PROTECT_AWAKE
    // Drapeau deja pose sur l'objet par le parcours natif
    // (buff II_SYS_SYS_SCR_AWAKESAFE + parchemin d'annulation sur l'objet).
    // Liste blanche : le Safe Awakening natif ne concerne que le kind
    // eAwakening ; familier et pet n'y entrent jamais.
    const BOOL bZckSafeFlagOnItem =
        (nKind == CRandomOptionProperty::eAwakening &&
         g_xRandomOptionProperty->IsCheckedSafeFlag(
             pItemElem->GetRandomOptItemId())) ? TRUE : FALSE;

    // Correctif 4 : le buff seul suffit desormais depuis la fenetre.
    // Le parchemin d'annulation est deja facture par la regle de cout
    // quand l'objet porte des lignes : le total depense est identique
    // au parcours natif.
    const BOOL bZckSafeBuff =
        (nKind == CRandomOptionProperty::eAwakening &&
         !bZckSafeFlagOnItem &&
         nCurrentOptionCount > 0 &&
         pUser->HasBuff(
             BUFF_ITEM,
             II_SYS_SYS_SCR_AWAKESAFE) == TRUE) ? TRUE : FALSE;

    const BOOL bZckSafeAwake =
        (bZckSafeFlagOnItem || bZckSafeBuff) ? TRUE : FALSE;
#else
    const BOOL bZckSafeFlagOnItem = FALSE;
    const BOOL bZckSafeBuff = FALSE;
    const BOOL bZckSafeAwake = FALSE;
#endif

    // Un choix ancien / nouveau deja en attente doit etre tranche avant
    // toute nouvelle generation, sinon l'option precedente est detruite
    // en silence et un choix tardif ferait un OR sur une option peuplee.
    if (pItemElem->GetNewRandomOption() != 0)
    {
        pUser->AddText(
            "Choisissez d'abord entre l'ancien et le nouvel "
            "\351veil de cet objet.");

        SendZckAwakeFailure(
            pUser,
            dwRequestId);
        return;
    }

    const ZCK_AWAKE_MASTERY_CONFIG& zckCfg =
        prj.m_ZckAwakeMasteryConfig;

    const BOOL bZckNeedCancel =
        (nCurrentOptionCount > 0 &&
         !bProtectionAlreadyStaged);

    CItemElem* pAwakeScroll = NULL;
    CItemElem* pCancelScroll = NULL;

    int nAwakeScrollCount = 0;
    int nCancelScrollCount = 0;
    int nPenyaCost = 0;

    if (zckCfg.nCostMode == ZCK_AWAKE_COST_MODE_PENYA)
    {
        nPenyaCost =
            bZckNeedCancel
                ? zckCfg.nCostPenyaReawake
                : zckCfg.nCostPenyaBase;

        if (nPenyaCost < 0)
            nPenyaCost = 0;

        if (nPenyaCost > 0 &&
            pUser->GetGold() < nPenyaCost)
        {
            pUser->AddDefinedText(
                TID_GAME_LACKMONEY);

            SendZckAwakeFailure(
                pUser,
                dwRequestId);
            return;
        }
    }
    else
    {
        const DWORD dwAwakeItemId =
            zckCfg.nCostScrollAwakeItem > 0
                ? (DWORD)zckCfg.nCostScrollAwakeItem
                : (DWORD)II_SYS_SYS_SCR_AWAKE;

        nAwakeScrollCount =
            zckCfg.nCostScrollAwakeCount > 0
                ? zckCfg.nCostScrollAwakeCount
                : 1;

        pAwakeScroll =
            GetZckSystemeEveilScroll(
                pUser,
                dwAwakeItemId);

        if (!pAwakeScroll ||
            pAwakeScroll->m_nItemNum < nAwakeScrollCount)
        {
            pUser->AddText(
                "Vous n'avez pas le parchemin d'\351veil requis.");

            SendZckAwakeFailure(
                pUser,
                dwRequestId);
            return;
        }

        if (bZckNeedCancel)
        {
            const DWORD dwCancelItemId =
                zckCfg.nCostScrollCancelItem > 0
                    ? (DWORD)zckCfg.nCostScrollCancelItem
                    : (DWORD)II_SYS_SYS_SCR_AWAKECANCEL;

            nCancelScrollCount =
                zckCfg.nCostScrollCancelCount > 0
                    ? zckCfg.nCostScrollCancelCount
                    : 1;

            pCancelScroll =
                GetZckSystemeEveilScroll(
                    pUser,
                    dwCancelItemId);

            if (!pCancelScroll ||
                pCancelScroll->m_nItemNum < nCancelScrollCount)
            {
                pUser->AddText(
                    "Vous n'avez pas le parchemin d'annulation "
                    "d'\351veil requis.");

                SendZckAwakeFailure(
                    pUser,
                    dwRequestId);
                return;
            }
        }
    }

    __int64 nNewRandomOption = 0;

    ZCK_AWAKE_MASTERY_ROLL zckRoll;

    // AUCUNE donnée de résultat ne vient du client.
    // Le WorldServer choisit le nombre de lignes, DST et valeurs
    // à travers le RandomOption V18 déjà existant.
    if (bZckSafeAwake)
    {
        // Chemin natif Safe Awakening : la nouvelle option est generee
        // A PART, l'objet conserve la sienne, et le joueur tranche.
        if (bZckSafeFlagOnItem)
        {
            g_xRandomOptionProperty->ResetSafeFlag(
                pItemElem->GetRandomOptItemIdPtr());
        }

        if (!pUser->GenerateZckAwakeOption(
                pItemElem,
                pItemElem->GetNewRandomOptionPtr(),
                TRUE,
                FALSE,
                zckRoll))
        {
            pItemElem->ResetNewRandomOption();

            if (bZckSafeFlagOnItem)
            {
                g_xRandomOptionProperty->SetSafeFlag(
                    pItemElem->GetRandomOptItemIdPtr());
            }

            pUser->AddText(
                "La g\351n\351ration de l'\351veil a \351chou\351.");

            SendZckAwakeFailure(
                pUser,
                dwRequestId);
            return;
        }

        nNewRandomOption =
            pItemElem->GetNewRandomOption();
    }
    else
    {
        nNewRandomOption =
            pItemElem->GetRandomOptItemId();

        if (!pUser->GenerateZckAwakeOption(
                pItemElem,
                &nNewRandomOption,
                FALSE,
                TRUE,
                zckRoll))
        {
            pUser->AddText(
                "La g\351n\351ration de l'\351veil a \351chou\351.");

            SendZckAwakeFailure(
                pUser,
                dwRequestId);
            return;
        }
    }

    // Toutes les validations et toute la génération ont réussi.
    // La consommation n'arrive qu'à partir d'ici.
    if (zckCfg.nCostMode == ZCK_AWAKE_COST_MODE_PENYA)
    {
        if (nPenyaCost > 0)
        {
            pUser->AddGold(-nPenyaCost);

            PutPenyaLog(
                pUser,
                "z",
                "ZCK_SYSTEME_EVEIL",
                nPenyaCost);
        }
    }
    else
    {
        const OBJID dwAwakeScrollObjId =
            pAwakeScroll->m_dwObjId;

        const OBJID dwCancelScrollObjId =
            pCancelScroll ?
                pCancelScroll->m_dwObjId :
                NULL_ID;

        pUser->RemoveItem(
            (BYTE)dwAwakeScrollObjId,
            nAwakeScrollCount);

        if (pCancelScroll)
        {
            pUser->RemoveItem(
                (BYTE)dwCancelScrollObjId,
                nCancelScrollCount);
        }
    }

#ifdef __PROTECT_AWAKE
    // Buff a usage unique, comme dans le parcours natif.
    if (bZckSafeBuff)
    {
        pUser->RemoveBuff(
            BUFF_ITEM,
            II_SYS_SYS_SCR_AWAKESAFE);

        PutItemLog(
            pUser,
            "z",
            "USE_AWAKESAVE_ITEM",
            pItemElem,
            1);
    }
#endif

    if (bZckSafeAwake)
    {
        // L'objet garde son option actuelle. Le client recoit l'ancienne
        // et la nouvelle et ouvre CWndSelectAwakeCase : le bouton de
        // retour a l'amelioration precedente est de nouveau atteignable.
        pUser->SendNewRandomOption(
            (BYTE)pItemElem->m_dwObjId,
            (DWORD)pItemElem->GetSerialNumber(),
            pItemElem->GetNewRandomOption());
    }
    else
    {
#ifdef __ZCK_SYSTEME_EVEIL
        // Correctif 4 : l'option courante devient le point de retour
        // persiste, juste avant d'etre ecrasee. Elle est encore intacte
        // ici : GenerateZckAwakeOption a travaille sur une copie locale.
        // Liste blanche : perimetre d'origine du retour, kind eAwakening.
        if (nKind == CRandomOptionProperty::eAwakening)
        {
            pUser->ZckStorePreviousAwake(
                pItemElem,
                pItemElem->GetRandomOptItemId());
        }
#endif // __ZCK_SYSTEME_EVEIL

        *pItemElem->GetRandomOptItemIdPtr() =
            nNewRandomOption;
    }

    pUser->UpdateItemEx(
        (BYTE)pItemElem->m_dwObjId,
        UI_RANDOMOPTITEMID,
        pItemElem->GetRandomOptItemId());

    if (byCategory < ZCK_AWAKE_CATEGORY_MAX)
    {
        pUser->CommitZckAwakeMastery(
            pItemElem,
            nNewRandomOption,
            zckRoll,
            dwRequestId);
    }
    else
    {
        // Familier et pet : aucune maitrise. Le client attend tout de meme
        // la reponse liee a sa requete : succes, categorie invalide, gain 0.
        pUser->AddZckAwakeMasteryState(
            ZCK_AWAKE_RESULT_SUCCESS,
            ZCK_AWAKE_CATEGORY_INVALID,
            0,
            ZCK_AWAKE_QUALITY_NORMAL,
            ZCK_AWAKE_EVENT_NONE,
            dwRequestId);
    }

#ifdef __FL_RECORD_BOOK
    CRecordBook::GetInstance()->AddPlayerRecord(
        pUser,
        RecordType::AWAKES_COUNT,
        1,
        true);
#endif

    PutItemLog(
        pUser,
        "z",
        "ZCK_SYSTEME_EVEIL",
        pItemElem,
        1);

    pUser->AddPlaySound(
        SND_INF_UPGRADESUCCESS);

    if (pUser->IsMode(TRANSPARENT_MODE) == 0)
    {
        g_UserMng.AddCreateSfxObj(
            (CMover*)pUser,
            XI_INT_SUCCESS,
            pUser->GetPos().x,
            pUser->GetPos().y,
            pUser->GetPos().z);
    }
}
void CDPSrvr::OnZckAwakeAffinity(
    CAr& ar,
    DPID dpidCache,
    DPID dpidUser,
    LPBYTE,
    u_long)
{
    BYTE byCategory =
        ZCK_AWAKE_CATEGORY_INVALID;

    BYTE byAffinity =
        ZCK_AWAKE_AFFINITY_INVALID;

    BYTE bySelectedDst =
        ZCK_AWAKE_DST_NONE;

    // ORDRE EXACT de Neuz/CDPClient::SendZckAwakeAffinity().
    ar >> byCategory;
    ar >> byAffinity;
    ar >> bySelectedDst;

    CUser* pUser =
        g_UserMng.GetUser(
            dpidCache,
            dpidUser);

    if (!IsValidObj(pUser) ||
        !pUser->GetWorld())
    {
        return;
    }

    if (!pUser->IsPossibleUseItem())
    {
        pUser->AddZckAwakeMasteryState();
        return;
    }

    if (!prj.m_ZckAwakeMasteryConfig.bEnabled)
    {
        pUser->AddText(
            "Le syst\350me de Ma\356trise d'\311veil est d\351sactiv\351 : configuration invalide.");

        pUser->AddZckAwakeMasteryState();
        return;
    }

    BOOL bAccepted = FALSE;

    if (bySelectedDst != ZCK_AWAKE_DST_NONE)
    {
        // Pour une statistique precise, le serveur derive lui-meme
        // l'affinite depuis le vrai DST. La valeur d'affinite du packet
        // n'est jamais utilisee comme autorite.
        bAccepted =
            pUser->SetZckAwakeStat(
                byCategory,
                bySelectedDst);
    }
    else
    {
        bAccepted =
            pUser->SetZckAwakeAffinity(
                byCategory,
                byAffinity);
    }

    if (!bAccepted)
    {
        pUser->AddText(
            "S\351lection d'affinit\351 refus\351e par le serveur.");

        pUser->AddZckAwakeMasteryState();
    }
}
#endif // __ZCK_SYSTEME_EVEIL
#ifdef __FL_TDM
void CDPSrvr::OnRequestTDM(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->AddTDMData();
}
void CDPSrvr::OnRequestTDMRegister(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CTDMManager::GetInstance()->RegisterPlayer(pUser);
}
void CDPSrvr::OnRequestTDMJoin(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (!CTDMManager::GetInstance()->JoinTDMWorld(pUser))
		pUser->AddDefinedText(TID_GAME_GUILDCOMBAT1TO1_NOENTRANCETIME);
}
#endif
#ifdef __FL_BUYBACK
void CDPSrvr::OnBuyback(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nIndex;
	ar >> nIndex;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->m_Buyback.BuybackItem(nIndex);
}
void CDPSrvr::OnBuybackRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->AddBuyback();
}
#endif

#ifdef __FL_WIKI_HONORS
void	CDPSrvr::OnRequestHonors(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	pUser->AddHonorListAck();
}
#endif

#ifdef __FL_SEASON_PASS
void	CDPSrvr::OnSeasonPassUnlock(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	int nSeason;
	ar >> nSeason;

	bool bResult = pUser->m_SeasonPass.DoUnlockPaidList(nSeason);
	if (!bResult)
	{
		pUser->AddDefinedText(TID_GAME_SEASON_PASS_ERROR_CANT_UNLOCK);
		return;
	}
}
void	CDPSrvr::OnSeasonPassClaim(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	int nSeason;
	ar >> nSeason;

	bool bResult = pUser->m_SeasonPass.DoClaimRewards(nSeason);
}
#endif

#ifdef __FL_WARDROBE
void CDPSrvr::OnWardrobePresetCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	char szName[MAX_WARDROBE_PRESET_NAME] = { 0, };
	ar.ReadString(szName, MAX_WARDROBE_PRESET_NAME);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	bool bResult = pUser->m_Wardrobe.PresetCreate(szName);
	if (!bResult)
		return;

	g_UserMng.AddWardrobePresetCreate(pUser, szName);
}
void CDPSrvr::OnWardrobePresetDelete(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nIndex;
	ar >> nIndex;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	bool bResult = pUser->m_Wardrobe.PresetDelete(nIndex);
	if (!bResult)
		return;

	g_UserMng.AddWardrobePresetDelete(pUser, nIndex);
}
void CDPSrvr::OnWardrobePresetUse(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nIndex;
	ar >> nIndex;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	bool bResult = pUser->m_Wardrobe.PresetUse(nIndex);
	if (!bResult)
		return;

	g_UserMng.AddWardrobePresetUse(pUser, nIndex);
}
void CDPSrvr::OnWardrobeItemActivate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nPresetIndex;
	DWORD dwItemID;
	ar >> nPresetIndex >> dwItemID;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	bool bResult = pUser->m_Wardrobe.ItemActivate(nPresetIndex, dwItemID);
	if (!bResult)
		return;

	g_UserMng.AddWardrobeItemActivate(pUser, nPresetIndex, dwItemID);
}
void CDPSrvr::OnWardrobeItemDeactivate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nPresetIndex;
	size_t nType;
	ar >> nPresetIndex >> nType;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	bool bResult = pUser->m_Wardrobe.ItemDeactivate(nPresetIndex, nType);
	if (!bResult)
		return;

	g_UserMng.AddWardrobeItemDeactivate(pUser, nPresetIndex, nType);
}
void CDPSrvr::OnWardrobeItemUnlock(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	DWORD dwItemObjId;
	ar >> dwItemObjId;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	DWORD dwItemID = pUser->m_Wardrobe.DoUnlockItem(dwItemObjId);
	if (dwItemID == NULL_ID)
		return;

	pUser->AddWardrobeItemUnlock(dwItemID);
}
#endif

#ifdef __FL_ITEM_RUNE
BOOL CDPSrvr::DoUseItemTarget_FashRuneAdd(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget)
{
	if (!pTarget->IsAvailableForRune())
		return FALSE;

	if (pTarget->m_dwRune != NULL_ID)
		return FALSE;

	ItemProp* pRuneProp = pMaterial->GetProp();
	if (!pRuneProp || pRuneProp->dwItemKind3 != IK3_FASHION_RUNE)
		return FALSE;

	pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_FASH_RUNE, pRuneProp->dwID);

	return TRUE;
}
BOOL CDPSrvr::DoUseItemTarget_FashRuneRemove(CUser* pUser, CItemElem* pMaterial, CItemElem* pTarget, bool bRestore)
{
	const DWORD dwRune = pTarget->m_dwRune;
	if (dwRune == NULL_ID)
		return FALSE;

	if (bRestore)
	{
		CItemElem itemElem;
		itemElem.m_dwItemId = dwRune;
		itemElem.m_nItemNum = 1;
		itemElem.SetSerialNumber();

		if (!pUser->CreateItem(&itemElem))
		{
			pUser->AddDefinedText(TID_GAME_LACKSPACE);
			return FALSE;
		}
	}

	pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_FASH_RUNE, NULL_ID);

	return TRUE;
}
#endif

#ifdef __SIZED_SNAPSHOTS_V2
void CDPSrvr::OnSnapshotReport(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	WORD wSnapshot;
	CAr::GoToOffsetAnswer reason;

	ar >> wSnapshot;
	ar >> reason;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	static std::set<WORD> glitchedSnapshotsId;
	if (glitchedSnapshotsId.count(wSnapshot) == 0)
	{
		if (reason == CAr::GoToOffsetAnswer::TooFar)
			Error("Snapshot %x went too far (User %d)", wSnapshot, pUser->m_idPlayer);
		else
			Error("Snapshot %x not all consumed (User %d)", wSnapshot, pUser->m_idPlayer);
		glitchedSnapshotsId.emplace(wSnapshot);

	}
}
#endif

#ifdef __FL_WORLDBOSS
void CDPSrvr::OnWorldBossTeleport(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	CWorldBossManager::GetInstance()->TeleportUserToWorldBoss(pUser);
}
#endif

void CDPSrvr::OnExpUpStop(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->ChangeExpUpState();
}
#ifdef __ZCK_BURNOUT

// Burnout (Virtuos : CDPSrvr::OnActivateBurnout). Jauge pleine (200 x niveau) : un des 4 buffs
// SI_CHEER_BURNOUT* tire au hasard (rand() % 4, comme Virtuos), duree forcee a 12 minutes,
// puis la jauge repart de 0 avec l'effet XI_NPCMETEONYKER et le son SND_NPC_CLOCKWORKSATK4.
void CDPSrvr::OnZckBurnout(CAr&, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (pUser->m_nBurnoutExp >= (200 * pUser->m_nLevel))
	{
		static const DWORD s_adwZckBurnout[4][2] =
		{
			{ SI_CHEER_BURNOUT,	SA_BURNOUT_LV1 },
			{ SI_CHEER_BURNOUT1,	SA_BURNOUT1_LV1 },
			{ SI_CHEER_BURNOUT2,	SA_BURNOUT2_LV1 },
			{ SI_CHEER_BURNOUT3,	SA_BURNOUT3_LV1 },
		};
		const int nZckBurnout = rand() % 4;
		ItemProp* pSkillProp = prj.GetSkillProp(s_adwZckBurnout[nZckBurnout][0]);
		AddSkillProp* pAddSkillProp = prj.GetAddSkillProp(s_adwZckBurnout[nZckBurnout][1]);
		if (!pSkillProp || !pAddSkillProp)
		{
			Error("CDPSrvr::OnZckBurnout : skill %d ou %d absent de propSkill.csv / propSkillAdd.csv", (int)s_adwZckBurnout[nZckBurnout][0], (int)s_adwZckBurnout[nZckBurnout][1]);
			return;
		}
		// Comme Virtuos : la duree est ecrite dans la propriete chargee (200 s dans propSkillAdd.csv).
		pAddSkillProp->dwSkillTime = MIN(12);
		pUser->DoApplySkill(pUser, pSkillProp, pAddSkillProp);
		g_UserMng.AddDoApplySkill(pUser, pUser->GetId(), s_adwZckBurnout[nZckBurnout][0], 1);

		pUser->m_nBurnoutExp = 0;
		g_UserMng.AddCreateSfxObj(pUser, XI_NPCMETEONYKER);
		pUser->AddPlaySound(SND_NPC_CLOCKWORKSATK4);
	}
	else
		pUser->AddText("Ta jauge Burnout n'est pas encore pleine.");
}
#endif // __ZCK_BURNOUT

#ifdef __FL_AUTO_STAT
void CDPSrvr::OnAutoStat(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nAutoStat;
	ar >> nAutoStat;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->SetAutoStat(nAutoStat);
}
#endif

#ifdef __ZCK_UPGRADE
void CDPSrvr::OnUpgrade(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	DWORD dwItemId = 0;
	BYTE nElement = 0;
	short nElementLevel = 0;
	short nUpgradeLevel = 0;
	short nPiercing = 0;

	ar >> dwItemId;
	ar >> nElement;
	ar >> nElementLevel >> nUpgradeLevel >> nPiercing;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser) || !pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
		return;

	CItemElem* pItem = pUser->m_Inventory.GetAtId(dwItemId);
	if (!IsUsableItem(pItem) || pUser->IsUsing(pItem) || pUser->m_Inventory.IsEquip(dwItemId))
	{
		pUser->AddText(prj.GetText(TID_UPGRADE_CANCLE));
		return;
	}

	ItemProp* pProp = pItem->GetProp();
	if (!pProp)
		return;

	const BOOL bCanUpgrade = CItemElem::IsDiceRefineryAble(pProp) || pItem->IsAccessory() || pItem->IsCollector(TRUE);
	const BOOL bCanElement = pProp->IsEleRefineryAble();
	const BOOL bCanPiercing = pItem->IsPierceAble(NULL_ID, FALSE) &&
		(pProp->dwItemKind3 == IK3_SUIT ||
		 pProp->dwItemKind3 == IK3_SHIELD ||
		 pProp->dwItemKind2 == IK2_WEAPON_DIRECT ||
		 pProp->dwItemKind2 == IK2_WEAPON_MAGIC
#if __VER >= 16
		 || pProp->dwItemKind3 == IK3_MAGICBARUNA
		 || pProp->dwItemKind3 == IK3_ZEMBARUNA
#endif
		 );

	if (!bCanUpgrade && !bCanElement && !bCanPiercing)
		return;

	if (nElement > SAI79::EARTH || nElementLevel < 0 || nElementLevel > 20 ||
		nUpgradeLevel < 0 || nUpgradeLevel > 20 || nPiercing < 0)
		return;

	if (!bCanElement && (nElement != SAI79::NO_PROP || nElementLevel != 0))
		return;

	if (nElement == SAI79::NO_PROP && nElementLevel != 0)
		return;

	if (!bCanUpgrade && nUpgradeLevel != 0)
		return;

	const int nMaxUpgrade = pItem->IsCollector(TRUE) ? 5 : 20;
	if (nUpgradeLevel > nMaxUpgrade)
		return;

	const int nMaxPiercing = bCanPiercing ? (pProp->dwItemKind3 == IK3_SUIT ? MAX_PIERCING_SUIT : MAX_PIERCING_WEAPON) : 0;
	if ((!bCanPiercing && nPiercing != 0) || nPiercing > nMaxPiercing)
		return;

	BOOL bChanged = FALSE;

	if (bCanElement)
	{
		if (pItem->m_bItemResist != nElement)
		{
			pUser->UpdateItem((BYTE)pItem->m_dwObjId, UI_IR, nElement);
			bChanged = TRUE;
		}

		if (pItem->m_nResistAbilityOption != nElementLevel)
		{
			pUser->UpdateItem((BYTE)pItem->m_dwObjId, UI_RAO, nElementLevel);
			bChanged = TRUE;
		}
	}

	if (bCanUpgrade && pItem->GetAbilityOption() != nUpgradeLevel)
	{
		pUser->UpdateItem((BYTE)pItem->m_dwObjId, UI_AO, nUpgradeLevel);
		bChanged = TRUE;
	}

#if __VER >= 9 // __ULTIMATE
	if (bCanUpgrade && pProp->dwReferStat1 == WEAPON_ULTIMATE)
	{
		int nUltimateSlots = 0;
		if (nUpgradeLevel > 5)
		{
			nUltimateSlots = nUpgradeLevel - 5;
			if (nUltimateSlots > MAX_PIERCING_ULTIMATE)
				nUltimateSlots = MAX_PIERCING_ULTIMATE;
		}

		if (pItem->GetUltimatePiercingSize() != nUltimateSlots)
		{
			pUser->UpdateItem((BYTE)pItem->m_dwObjId, UI_ULTIMATE_PIERCING_SIZE, nUltimateSlots);
			bChanged = TRUE;
		}
	}
#endif // __ULTIMATE

	if (bCanPiercing && pItem->GetPiercingSize() != nPiercing)
	{
		pUser->UpdateItem((BYTE)pItem->m_dwObjId, UI_PIERCING_SIZE, nPiercing);
		bChanged = TRUE;
	}

	if (bChanged)
	{
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if (pUser->IsMode(TRANSPARENT_MODE) == 0)
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	}
}
#endif // __ZCK_UPGRADE

#ifdef __ZCK_RARE
void CDPSrvr::OnZckRare(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	DWORD dwItem1 = NULL_ID;
	DWORD dwItem2 = NULL_ID;
	DWORD dwScroll = NULL_ID;
	SERIALNUMBER nSerial1 = 0;
	SERIALNUMBER nSerial2 = 0;
	SERIALNUMBER nScrollSerial = 0;
	ar >> dwItem1 >> dwItem2 >> dwScroll >> nSerial1 >> nSerial2 >> nScrollSerial;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser) || !pUser->GetWorld() ||
		dwItem1 == NULL_ID || dwItem2 == NULL_ID || dwScroll == NULL_ID ||
		dwItem1 == dwItem2 || dwItem1 == dwScroll || dwItem2 == dwScroll)
		return;

	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_ZCK_RARE, pUser->GetWorld(), pUser->GetPos()))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Approchez-vous du PNJ d'ascension de raret\351.");
#else
		pUser->AddText("Approchez-vous du PNJ d'ascension de rarete.");
#endif // __ZCK_TRAD_FR
		return;
	}

	CItemElem* pItem1 = pUser->m_Inventory.GetAtId(dwItem1);
	CItemElem* pItem2 = pUser->m_Inventory.GetAtId(dwItem2);
	CItemElem* pScroll = pUser->m_Inventory.GetAtId(dwScroll);
	if (!IsUsableItem(pItem1) || !IsUsableItem(pItem2) || !IsUsableItem(pScroll) ||
		pItem1->GetSerialNumber() != nSerial1 || pItem2->GetSerialNumber() != nSerial2 || pScroll->GetSerialNumber() != nScrollSerial ||
		pItem1->m_nItemNum != 1 || pItem2->m_nItemNum != 1 || pScroll->m_nItemNum <= 0 ||
		pScroll->m_dwItemId != ZCK_RARE_SCROLL_ITEM_ID ||
		pUser->IsUsing(pItem1) || pUser->IsUsing(pItem2) || pUser->IsUsing(pScroll))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("La s\351lection d'ascension n'est plus disponible.");
#else
		pUser->AddText("La selection d'ascension n'est plus disponible.");
#endif // __ZCK_TRAD_FR
		return;
	}

	if (pUser->m_Inventory.IsEquip(dwItem1) || pUser->m_Inventory.IsEquip(dwItem2) || pUser->m_Inventory.IsEquip(dwScroll))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("D\351s\351quipez les objets avant l'ascension.");
#else
		pUser->AddText("Desequipez les objets avant l'ascension.");
#endif // __ZCK_TRAD_FR
		return;
	}

	ItemProp* pProp1 = pItem1->GetProp();
	ItemProp* pProp2 = pItem2->GetProp();
	if (!pProp1 || !pProp2 || !IsZckRareItem(pProp1->dwItemKind3) || !IsZckRareItem(pProp2->dwItemKind3))
		return;

	if (pItem1->m_dwItemId != pItem2->m_dwItemId || pItem1->GetZckRareLevel() != pItem2->GetZckRareLevel())
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Les deux objets doivent \352tre identiques et de m\352me raret\351.");
#else
		pUser->AddText("Les deux objets doivent etre identiques et de meme rarete.");
#endif // __ZCK_TRAD_FR
		return;
	}

	const int nCurrentRare = pItem1->GetZckRareLevel();
	const int nNextRare = nCurrentRare + 1;
	if (!prj.IsZckRareLevelValid(nCurrentRare) || !prj.IsZckRareLevelValid(nNextRare) ||
		nCurrentRare < 0 || nCurrentRare >= ZCK_RARE_MAX_LEVEL || nNextRare > ZCK_RARE_MAX_LEVEL)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Cet objet a d\351j\340 atteint la raret\351 maximale.");
#else
		pUser->AddText("Cet objet a deja atteint la rarete maximale.");
#endif // __ZCK_TRAD_FR
		return;
	}

	ZCK_RARE_DATA* pCurrentData = prj.GetZckRareData(nCurrentRare);
	if (!pCurrentData || pCurrentData->m_nUpgradeRate < 0 || pCurrentData->m_nUpgradeRate > 100)
		return;

	if (pItem1->m_dwObjId > 0xFF || pItem2->m_dwObjId > 0xFF || pScroll->m_dwObjId > 0xFF)
		return;

	pItem1 = pUser->m_Inventory.GetAtId(dwItem1);
	pItem2 = pUser->m_Inventory.GetAtId(dwItem2);
	pScroll = pUser->m_Inventory.GetAtId(dwScroll);
	if (!IsUsableItem(pItem1) || !IsUsableItem(pItem2) || !IsUsableItem(pScroll) ||
		pItem1->GetSerialNumber() != nSerial1 || pItem2->GetSerialNumber() != nSerial2 || pScroll->GetSerialNumber() != nScrollSerial ||
		pItem1->m_nItemNum != 1 || pItem2->m_nItemNum != 1 || pScroll->m_nItemNum <= 0 ||
		pUser->IsUsing(pItem1) || pUser->IsUsing(pItem2) || pUser->IsUsing(pScroll) ||
		pUser->m_Inventory.IsEquip(dwItem1) || pUser->m_Inventory.IsEquip(dwItem2) || pUser->m_Inventory.IsEquip(dwScroll) ||
		pItem1->m_dwItemId != pItem2->m_dwItemId ||
		pItem1->GetZckRareLevel() != nCurrentRare || pItem2->GetZckRareLevel() != nCurrentRare ||
		pScroll->m_dwItemId != ZCK_RARE_SCROLL_ITEM_ID)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("La s\351lection a chang\351. Recommencez l'ascension.");
#else
		pUser->AddText("La selection a change. Recommencez l'ascension.");
#endif // __ZCK_TRAD_FR
		return;
	}

	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_ZCK_RARE, pUser->GetWorld(), pUser->GetPos()))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Vous \352tes trop loin du PNJ d'ascension.");
#else
		pUser->AddText("Vous etes trop loin du PNJ d'ascension.");
#endif // __ZCK_TRAD_FR
		return;
	}

	const BYTE byItem1 = static_cast<BYTE>(pItem1->m_dwObjId);
	const BYTE byItem2 = static_cast<BYTE>(pItem2->m_dwObjId);
	const BYTE byScroll = static_cast<BYTE>(pScroll->m_dwObjId);
	const BOOL bSuccess = (xRandom(100) < pCurrentData->m_nUpgradeRate);

	pUser->RemoveItem(byScroll, 1);

	if (bSuccess)
	{
		pUser->RemoveItem(byItem2, 1);

		pItem1 = pUser->m_Inventory.GetAtId(byItem1);
		if (!pItem1 || !IsUsableItem(pItem1) || pItem1->m_nItemNum != 1)
			return;

		pUser->UpdateItem(byItem1, UI_ZCK_RARE, nNextRare);

		const BYTE byOldFlag = pItem1->m_byFlag;
		if (prj.HasZckRareReflect(nNextRare))
			pItem1->SetFlag(CItemElem::zckRareReflect);
		else
			pItem1->ResetFlag(CItemElem::zckRareReflect);

		if (byOldFlag != pItem1->m_byFlag)
			pUser->UpdateItem(byItem1, UI_FLAG, MAKELONG(pItem1->m_dwObjIndex, pItem1->m_byFlag));

#ifdef __ZCK_TRAD_FR
		pUser->AddText("Ascension de raret\351 r\351ussie.");
#else
		pUser->AddText("Ascension de rarete reussie.");
#endif // __ZCK_TRAD_FR
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if (pUser->IsMode(TRANSPARENT_MODE) == 0)
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
	}
	else
	{
		pUser->RemoveItem(byItem1, 1);
		pUser->RemoveItem(byItem2, 1);
#ifdef __ZCK_TRAD_FR
		pUser->AddText("\311chec de l'ascension de raret\351.");
#else
		pUser->AddText("Echec de l'ascension de rarete.");
#endif // __ZCK_TRAD_FR
		if (pUser->GetWorld())
			g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());
	}
}
#endif // __ZCK_RARE

#ifdef __ZCK_ARME_REBORN
// Arme Reborn : toute demande de la fenetre CWndZckArmeReborn passe ici.
// Chaque action revalide l'arme comme OnZckRare (existence, serie, seule
// dans sa pile, non equipee, ni en echange ni en vente, PNJ a portee), puis
// repond par CMover::UpdateItem : le client n'affiche que l'etat recu.
void CDPSrvr::OnZckArmeReborn(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	BYTE byAction = 0;
	DWORD dwArme = NULL_ID;
	SERIALNUMBER nArmeSerial = 0;
	BYTE bySlot = 0;
	DWORD dwPierre = NULL_ID;
	SERIALNUMBER nPierreSerial = 0;
	ar >> byAction >> dwArme >> nArmeSerial >> bySlot >> dwPierre >> nPierreSerial;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser) || !pUser->GetWorld() || dwArme == NULL_ID || dwArme > 0xFF)
		return;
	if (byAction != ZCK_AR_ACTION_PASSER && byAction != ZCK_AR_ACTION_POSER && byAction != ZCK_AR_ACTION_RETIRER)
		return;

	// IsCloseNpc et SavePlayer prennent une reference non constante : variable
	// locale plutot que la temporaire de GetPos() (extension MSVC utilisee ailleurs).
	D3DXVECTOR3 vZckPos = pUser->GetPos();
	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_ZCK_ARME_REBORN, pUser->GetWorld(), vZckPos))
	{
		pUser->AddText("Approchez-vous du PNJ de l'arme Reborn.");
		return;
	}

	CItemElem* pArme = pUser->m_Inventory.GetAtId(dwArme);
	if (!IsUsableItem(pArme) || pArme->GetSerialNumber() != nArmeSerial || pArme->m_nItemNum != 1 || pUser->IsUsing(pArme))
	{
		pUser->AddText("Cette arme n'est plus disponible.");
		return;
	}
	if (pUser->m_Inventory.IsEquip(dwArme))
	{
		pUser->AddText("D\351s\351quipez l'arme avant de la passer en Reborn ou d'en changer les pierres.");
		return;
	}
	if (!ZckArmeRebornEstArme(pArme->GetProp()))
	{
		pUser->AddText(ZckArmeRebornTexteRaison(ZCK_AR_RAISON_PAS_ARME));
		return;
	}

	const BYTE byArme = static_cast<BYTE>(pArme->m_dwObjId);
	LogItemInfo aLogItem;
	aLogItem.Action = "-";
	aLogItem.SendName = pUser->GetName();
	aLogItem.WorldId = pUser->GetWorld()->GetID();
	aLogItem.Gold = aLogItem.Gold2 = pUser->GetGold();

	if (byAction == ZCK_AR_ACTION_PASSER)
	{
		// Seule condition : rarete maximale, pas encore Reborn.
		const int nRaison = pArme->GetZckRebornRaison(ZckArmeRebornRareteRequise());
		if (nRaison != ZCK_AR_RAISON_OK)
		{
			pUser->AddText(ZckArmeRebornTexteRaison(nRaison));
			return;
		}

		// Transaction, dans l'ordre ou le client la recoit : drapeau Reborn, puis
		// upgrade, element et niveau d'element, percage, gemmes ultimes et
		// emplacements Reborn a zero. Rarete, eveil et niveau d'arme intacts.
		pArme->SetFlag(CItemElem::zckReborn);
		pUser->UpdateItem(byArme, UI_FLAG, MAKELONG(pArme->m_dwObjIndex, pArme->m_byFlag));
		if (pArme->GetAbilityOption() != 0)
			pUser->UpdateItem(byArme, UI_AO, 0);
		if (pArme->m_bItemResist != 0)
			pUser->UpdateItem(byArme, UI_IR, 0);
		if (pArme->m_nResistAbilityOption != 0)
			pUser->UpdateItem(byArme, UI_RAO, 0);
		if (pArme->GetPiercingSize() != 0)
			pUser->UpdateItem(byArme, UI_PIERCING_SIZE, 0);
		if (pArme->GetUltimatePiercingSize() != 0)
			pUser->UpdateItem(byArme, UI_ULTIMATE_PIERCING_SIZE, 0);
		for (int i = 0; i < ZCK_ARME_REBORN_SLOTS; ++i)
		{
			if (pArme->GetZckRebornPierre(i) != 0)
				pUser->UpdateItem(byArme, UI_ZCK_REBORN_PIERRE, MAKELONG(i, 0));
		}

		aLogItem.RecvName = "ZCK_ARME_REBORN_PASSAGE";
		OnLogItem(aLogItem, pArme, 1);

		pUser->AddText("Arme pass\351e en Reborn : l'upgrade, l'\351l\351ment et les pierres ont \351t\351 remis \340 z\351ro.");
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), vZckPos, pUser->GetLayer());
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if (pUser->IsMode(TRANSPARENT_MODE) == 0)
			g_UserMng.AddCreateSfxObj(pUser, XI_INT_SUCCESS, vZckPos.x, vZckPos.y, vZckPos.z);
		return;
	}

	// Pose ou retrait d'une pierre : l'arme doit deja etre Reborn.
	if (!pArme->IsZckReborn())
	{
		pUser->AddText("Cette arme n'est pas Reborn.");
		return;
	}
	if (bySlot >= ZCK_ARME_REBORN_SLOTS)
		return;

	if (byAction == ZCK_AR_ACTION_POSER)
	{
		if (dwPierre == NULL_ID || dwPierre > 0xFF || dwPierre == dwArme)
			return;
		if (pArme->GetZckRebornPierre(bySlot) != 0)
		{
			pUser->AddText("Cet emplacement est d\351j\340 occup\351.");
			return;
		}
		CItemElem* pPierre = pUser->m_Inventory.GetAtId(dwPierre);
		if (!IsUsableItem(pPierre) || pPierre->GetSerialNumber() != nPierreSerial || pPierre->m_nItemNum <= 0 ||
			pUser->IsUsing(pPierre) || pUser->m_Inventory.IsEquip(dwPierre) || !ZckArmeRebornEstPierre(pPierre->GetProp()))
		{
			pUser->AddText("Cet objet n'est pas une pierre Reborn disponible.");
			return;
		}

		const DWORD dwPierreId = pPierre->m_dwItemId;
		aLogItem.RecvName = "ZCK_ARME_REBORN_POSE";
		OnLogItem(aLogItem, pPierre, 1);
		pUser->RemoveItem(static_cast<BYTE>(dwPierre), 1);

		// L'arme est relue apres le retrait de la pierre : meme conteneur, meme serie.
		pArme = pUser->m_Inventory.GetAtId(dwArme);
		if (!pArme || pArme->IsEmpty() || pArme->GetSerialNumber() != nArmeSerial)
			return;
		pUser->UpdateItem(byArme, UI_ZCK_REBORN_PIERRE, MAKELONG(bySlot, dwPierreId));
		pUser->AddText("Pierre Reborn ins\351r\351e.");
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), vZckPos, pUser->GetLayer());
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		return;
	}

	// ZCK_AR_ACTION_RETIRER : la pierre revient dans l'inventaire, l'emplacement
	// n'est libere que si la restitution a reussi (jamais de perte ni de double).
	const DWORD dwPierreId = pArme->GetZckRebornPierre(bySlot);
	if (dwPierreId == 0)
		return;
	if (!ZckArmeRebornEstPierre(prj.GetItemProp((int)dwPierreId)))
	{
		// Ligne propItem disparue depuis la pose : emplacement libere, rien a rendre.
		pUser->UpdateItem(byArme, UI_ZCK_REBORN_PIERRE, MAKELONG(bySlot, 0));
		pUser->AddText("Pierre inconnue retir\351e de l'emplacement.");
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), vZckPos, pUser->GetLayer());
		return;
	}
	CItemElem itemPierre;
	itemPierre.m_dwItemId = dwPierreId;
	itemPierre.m_nItemNum = 1;
	if (!pUser->CreateItem(&itemPierre))
	{
		pUser->AddText("Inventaire plein : impossible de retirer la pierre.");
		return;
	}
	pArme = pUser->m_Inventory.GetAtId(dwArme);
	if (!pArme || pArme->IsEmpty() || pArme->GetSerialNumber() != nArmeSerial)
		return;
	pUser->UpdateItem(byArme, UI_ZCK_REBORN_PIERRE, MAKELONG(bySlot, 0));
	aLogItem.RecvName = "ZCK_ARME_REBORN_RETRAIT";
	OnLogItem(aLogItem, &itemPierre, 1);
	pUser->AddText("Pierre Reborn retir\351e : elle est revenue dans l'inventaire.");
	g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), vZckPos, pUser->GetLayer());
}
#endif // __ZCK_ARME_REBORN
#ifdef __ZCK_MINIJEU_PVP
void CDPSrvr::OnZckPvPMinigameCreate(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nGameID = 0;
	ar >> nGameID;

	if (!CZckPvPMinigamesMng::GetInstance()->IsValidMinigameID(nGameID))
		return;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CWorld* pWorld = pUser->GetWorld();
	if (!pWorld)
		return;

	if (CZckPvPMinigamesMng::GetInstance()->IsPlaying(pUser->m_idPlayer))
	{
		pUser->AddZckPvPMinigameRefresh();
		return;
	}

	if (pUser->m_nGuildCombatState != 0 || pWorld->GetID() == WI_WORLD_GUILDWAR || pUser->IsAttackMode())
	{
		pUser->AddText(_T("You cannot do this now."), ZCK_MINIGAME_COLOR_ERROR);
		return;
	}

	CZckPvPMinigamesMng::GetInstance()->StartMinigame(pUser, nGameID);
}

void CDPSrvr::OnZckPvPMinigameCommand(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	__MINIGAME_COMMAND command;
	ar >> command.dwCommandID;
	ar >> command.dwCommandValue;
	ar >> command.dwCommandValue2;

	char szName[MAX_NAME] = { 0, };
	if (command.dwCommandID == ZCK_MINIGAME_COMMAND_INVITE)
		ar.ReadString(szName, MAX_NAME);

	if (!command.IsValid())
		return;

	CZckPvPMinigamesMng::GetInstance()->OnPlayerCommand(pUser, command, szName);
}

void CDPSrvr::OnZckPvPMinigameChat(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	char szMessage[1024] = { 0, };
	ar.ReadString(szMessage, 1024);
	if (szMessage[0] == '\0')
		return;

	CZckPvPMinigamesMng::GetInstance()->OnPlayerChat(pUser, szMessage);
}

void CDPSrvr::OnZckPvPMinigameGetList(CAr&, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->AddZckPvPMinigameList();
}
#endif // __ZCK_MINIJEU_PVP

#ifdef __ZCK_DIFFICULTY
void CDPSrvr::OnDungeonDifficulty(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	DWORD dwRequestId = 0;
	int nDifficulty = -1;
	ar >> dwRequestId >> nDifficulty;

	CInstanceDungeonHelper::GetInstance()->ConfirmDungeonDifficulty(pUser, dwRequestId, nDifficulty);
}
#endif

#ifdef __FL_PLAYER_STATUE
void CDPSrvr::OnPlayerStatueBuffReceive(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	DWORD dwObjID;
	ar >> dwObjID;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CMover* pMoverStatue = prj.GetMover(dwObjID);
	if (IsInvalidObj(pMoverStatue))
		return;

	CPlayerStatueMng::GetInstance()->ReceiveBuff(pMoverStatue, pUser);
}
#endif

#ifdef __ZCK_ANARCHY
//////////////////////////////////////////////////////////////////////
// Comptage et debit d'un item de cout reparti sur PLUSIEURS piles.
//
// CItemContainer::GetAtItemId (Item.h 454-462) ne rend que la PREMIERE
// case portant l'identifiant ; GetAtItemNum (464-473) somme toutes les
// cases. Le client testait le total, le serveur une seule pile : un
// joueur ayant 4 + 4 Perin se voyait refuser un buff a 7.
//
// Ces deux fonctions n'utilisent que des accesseurs publics existants :
// GetMax(), GetSize() et GetAtId(). Le filtre m_dwObjIndex < GetSize()
// est celui qu'emploie deja GetEmptyCount (Item.h 346-355) pour dire
// "case visible de l'inventaire".
//////////////////////////////////////////////////////////////////////
static int ZckAnarchyCountCostItem(CUser* pUser, DWORD dwItemId)
{
	if (!pUser || dwItemId == 0)
		return 0;

	const DWORD dwMax  = (DWORD)pUser->m_Inventory.GetMax();
	const DWORD dwSize = (DWORD)pUser->m_Inventory.GetSize();

	int nTotal = 0;

	for (DWORD i = 0; i < dwMax; ++i)
	{
		CItemElem* pElem = pUser->m_Inventory.GetAtId(i);
		if (!pElem)
			continue;

		if (pElem->m_dwItemId != dwItemId)
			continue;

		if (pElem->m_dwObjIndex >= dwSize)
			continue;

		if (IsUsableItem(pElem) == FALSE)
			continue;

		// UpdateItem prend un index sur un octet : une case au-dela de 255
		// ne serait pas debitable, on ne la compte donc pas non plus.
		if (pElem->m_dwObjId > 0xFF)
			continue;

		if (pElem->m_nItemNum <= 0)
			continue;

		nTotal += (int)pElem->m_nItemNum;
	}

	return nTotal;
}

// Debite nCount unites reparties sur autant de piles que necessaire.
// Le comptage ci-dessus a deja garanti que le total est suffisant : cette
// fonction n'est appelee qu'apres lui, et rend FALSE si elle n'a pas pu
// aller au bout. UpdateItem avec 0 vide la case (MoverParam.cpp 3162-3163,
// RemoveAtId), la case suivante est donc atteinte au tour d'apres.
static BOOL ZckAnarchyConsumeCostItem(CUser* pUser, DWORD dwItemId, int nCount)
{
	if (!pUser || dwItemId == 0 || nCount <= 0)
		return FALSE;

	const DWORD dwMax  = (DWORD)pUser->m_Inventory.GetMax();
	const DWORD dwSize = (DWORD)pUser->m_Inventory.GetSize();

	int nRemain = nCount;

	for (DWORD i = 0; i < dwMax && nRemain > 0; ++i)
	{
		CItemElem* pElem = pUser->m_Inventory.GetAtId(i);
		if (!pElem)
			continue;

		if (pElem->m_dwItemId != dwItemId)
			continue;

		if (pElem->m_dwObjIndex >= dwSize)
			continue;

		if (IsUsableItem(pElem) == FALSE)
			continue;

		if (pElem->m_dwObjId > 0xFF)
			continue;

		if (pElem->m_nItemNum <= 0)
			continue;

		const int nTake = ((int)pElem->m_nItemNum <= nRemain)
			? (int)pElem->m_nItemNum : nRemain;

		pUser->UpdateItem((BYTE)(pElem->m_dwObjId), UI_NUM,
			(DWORD)((int)pElem->m_nItemNum - nTake));

		nRemain -= nTake;
	}

	return (nRemain == 0) ? TRUE : FALSE;
}

//////////////////////////////////////////////////////////////////////
// Demande d'activation d'un buff serveur.
//
// Le client n'envoie QUE l'index dans la table lue depuis ZckAnarchy.inc.
// Cout, quantite, recompense, duree, item de buff : tout est relu ici.
// Un client modifie ne peut ni choisir son prix, ni sa duree, ni sa
// recompense, ni activer un item qui n'est pas un buff anarchy declare.
//////////////////////////////////////////////////////////////////////
void CDPSrvr::OnZckAnarchy(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Sentinelle : un paquet tronque laisse la valeur a -1, rejetee par
	// GetBuff. L'ancien systeme s'appuyait deja sur ce mecanisme.
	int nIndex = ZCK_ANARCHY_INVALID;
	ar >> nIndex;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	// Joueur mort. CUserMng::GetUser ne filtre que m_bValid et m_idPlayer
	// (User.cpp lignes 2956 et 2959), et IsInvalidObj ne teste que IsDelete
	// (Obj.h lignes 315 a 323) : sans ce test, un joueur mort atteint le
	// corps de la fonction, paie, et declenche l'annonce serveur.
	//
	// Meme garde que les 29 autres handlers de ce fichier.
	if (pUser->IsDie() == TRUE)
		return;

#ifdef __ZCK_AUTH
	// Le Guide est le seul role du staff exclu de l'achat de buffs anarchy.
	if (pUser->m_dwAuthorization == AUTH_GUIDE)
		return;

#endif // __ZCK_AUTH
	CZckAnarchyManager* pMng = CZckAnarchyManager::GetInstance();

	// --- 1. Validation de la demande, sans aucun effet de bord ---------

	const ZCK_ANARCHY_BUFF* pBuff = pMng->GetBuff(nIndex);
	if (!pBuff)
		return;

	ItemProp* pBuffProp = prj.GetItemProp((DWORD)pBuff->nId);
	if (!pBuffProp)
		return;

	// Revalide ici et pas seulement dans CDPCoreClient : un .inc recharge
	// a chaud ne doit jamais laisser passer un item non anarchy.
	if (pBuffProp->dwItemKind3 != IK3_ANARCHY)
		return;

	const int nSlot = CZckAnarchyManager::GetSlotByItemId(pBuffProp->dwID);
	if (nSlot < 0 || nSlot >= ZCK_ANARCHY_COUNT)
		return;

	if (CZckAnarchyManager::GetSafeTime(pBuffProp->dwCircleTime) == 0)
		return;

	ItemProp* pCostProp = prj.GetItemProp((DWORD)pBuff->nCostItem);
	if (!pCostProp)
		return;

	ItemProp* pRewardProp = NULL;
	if (pBuff->nRewardItem != 0)
	{
		pRewardProp = prj.GetItemProp((DWORD)pBuff->nRewardItem);
		if (!pRewardProp)
			return;
	}

	// Echange ou vente en cours : l'item de cout pourrait etre engage.
	if (pUser->m_vtInfo.GetOther() || pUser->m_vtInfo.VendorIsVendor())
		return;

	// --- 2. Anti-spam --------------------------------------------------
	// Sans ce garde-fou, un client modifie declenche une annonce serveur
	// et une diffusion DPID_ALLPLAYERS a chaque paquet recu.
	if (!pMng->CheckAndConsumeCooldown(pUser->m_idPlayer))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Patientez un instant avant de r\351activer un buff serveur.", 0xffff0000);
#else
		pUser->AddText("Patientez un instant avant de reactiver un buff serveur.", 0xffff0000);
#endif // __ZCK_TRAD_FR
		return;
	}

	// --- 3. Verification de l'inventaire -------------------------------
	//
	// Le total est compte sur TOUTES les piles utilisables, comme le fait
	// deja le client avec GetAtItemNum (WndZckAnarchy.cpp ligne 1597).
	// GetAtItemId ne rendait que la premiere pile : un joueur ayant 4 + 4
	// Perin se voyait refuser un buff a 7 alors qu'il avait le compte.

	const int nOwnedCost =
		ZckAnarchyCountCostItem(pUser, (DWORD)pBuff->nCostItem);

	if (nOwnedCost <= 0)
	{
		CString str;
		str.Format("Vous n'avez pas de %s dans votre inventaire.", pCostProp->szName);
		pUser->AddText(str, 0xffff0000);
		return;
	}

	if (nOwnedCost < pBuff->nCostNum)
	{
		CString str;
		str.Format("Vous n'avez pas assez de %s.", pCostProp->szName);
		pUser->AddText(str, 0xffff0000);
		return;
	}

	// Place pour la recompense VERIFIEE AVANT le debit. L'ancien systeme
	// debitait puis se contentait d'un message si CreateItem echouait :
	// le joueur perdait son cout et n'avait rien.
	if (pRewardProp && pBuff->nRewardNum > 0)
	{
		const BOOL bHasStack = (pUser->m_Inventory.GetAtItemId((DWORD)pBuff->nRewardItem) != NULL);

		if (pUser->m_Inventory.GetEmptyCount() <= 0 && !bHasStack)
		{
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Votre inventaire est plein : lib\351rez une place avant d'activer ce buff.", 0xffff0000);
#else
			pUser->AddText("Votre inventaire est plein : liberez une place avant d'activer ce buff.", 0xffff0000);
#endif // __ZCK_TRAD_FR
			return;
		}
	}

	// --- 4. Debit, annonce, diffusion, recompense ----------------------

	// Debit reparti sur autant de piles que necessaire. Le comptage
	// ci-dessus a deja garanti le total ; si le debit echoue malgre tout,
	// on sort AVANT l'annonce et avant la recompense, pour ne jamais
	// donner un buff qui n'a pas ete paye.
	if (ZckAnarchyConsumeCostItem(pUser,
		(DWORD)pBuff->nCostItem, pBuff->nCostNum) == FALSE)
	{
		Error("[__ZCK_ANARCHY] debit incomplet de l'item %d (%s)",
			pBuff->nCostItem, pUser->GetName());
		return;
	}

	CString msg;
#ifdef __ZCK_TRAD_FR
	msg.Format("[Notice] %s a activ\351 le buff serveur Anarchy : %s !",
		pUser->GetName(), pBuffProp->szName);
#else
	msg.Format("[Notice] %s a active le buff serveur Anarchy : %s !",
		pUser->GetName(), pBuffProp->szName);
#endif // __ZCK_TRAD_FR

	g_DPCoreClient.SendSystem(msg.GetString());

	// Remontee au CoreServer, qui rediffusera a tous les WorldServers.
	//
	// Le montant joint au classement est nCostNum RELU dans ZckAnarchy.inc
	// juste au-dessus, jamais une valeur venue du client, et il n'est
	// compte que si le cout est paye en Perin : une entree du .inc payee
	// dans un autre item ne compte pas. On est ici APRES le debit, donc
	// aucun credit n'est possible sans paiement effectif.
	const int nRankPerin =
		(pBuff->nCostItem == II_SYS_SYS_SCR_PERIN) ? pBuff->nCostNum : 0;

	g_DPCoreClient.SendZckAnarchy(pBuffProp->dwID, pUser->m_idPlayer,
		pUser->GetName(), nRankPerin);

	if (pRewardProp && pBuff->nRewardNum > 0)
	{
		CItemElem itemElem;
		itemElem.m_dwItemId = (DWORD)pBuff->nRewardItem;
		itemElem.m_nItemNum = pBuff->nRewardNum;

		if (pUser->CreateItem(&itemElem, TYPE_INVENTORY))
		{
			// En mode egalise, CMover::CreateItem (Mover.cpp 2139-2148) envoie
			// l'item par courrier et rend TRUE sans rien poser dans
			// l'inventaire. Annoncer "vous avez recu" ferait croire a une perte.
			BOOL bByMail = FALSE;
#ifdef __FL_EQUALIZED_MODE
			if (pUser->bTmpMode && !pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
				bByMail = TRUE;
#endif // __FL_EQUALIZED_MODE

			CString str;

			if (bByMail)
#ifdef __ZCK_TRAD_FR
				str.Format("Vous avez activ\351 le buff serveur avec succ\350s ! %d %s vous attendent dans votre courrier.",
					pBuff->nRewardNum, pRewardProp->szName);
			else
				str.Format("Vous avez activ\351 le buff serveur avec succ\350s ! Vous avez re\347u %d %s.",
					pBuff->nRewardNum, pRewardProp->szName);
#else
				str.Format("Vous avez active le buff serveur avec succes ! %d %s vous attendent dans votre courrier.",
					pBuff->nRewardNum, pRewardProp->szName);
			else
				str.Format("Vous avez active le buff serveur avec succes ! Vous avez recu %d %s.",
					pBuff->nRewardNum, pRewardProp->szName);
#endif // __ZCK_TRAD_FR

			pUser->AddText(str, 0xffffffff);
		}
		else
		{
			// Filet de securite : la place a ete verifiee plus haut, on ne
			// devrait jamais passer ici.
#ifdef __ZCK_TRAD_FR
			pUser->AddText("Vous avez activ\351 le buff serveur avec succ\350s, mais votre r\351compense n'a pas pu \352tre ajout\351e.", 0xffff0000);
#else
			pUser->AddText("Vous avez active le buff serveur avec succes, mais votre recompense n'a pas pu etre ajoutee.", 0xffff0000);
#endif // __ZCK_TRAD_FR
		}
	}
	else
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Vous avez activ\351 le buff serveur avec succ\350s !", 0xffffffff);
#else
		pUser->AddText("Vous avez active le buff serveur avec succes !", 0xffffffff);
#endif // __ZCK_TRAD_FR
	}
}
#endif // __ZCK_ANARCHY

#ifdef __ZCK_INVASION
// Le client n'envoie aucun parametre : il demande simplement l'etat complet
// des invasions en cours. Rien de ce qu'il envoie n'est utilise.
void CDPSrvr::OnZckInvasion(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE lpBuf, u_long uBufSize)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->SendZckInvasionPacket(ZckInvasionPacket::PACKET_REFRESHALL, 0);
}
#endif // __ZCK_INVASION

#ifdef __ZCK_BADGE
#include "ZckBadge.h"

// Le client ne fait que proposer un identifiant. Existence et possession sont
// revalidees ici : rien de ce qu'il envoie n'est accepte tel quel.
void CDPSrvr::OnZckBadge(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nBadge = ZCK_BADGE_ID_NONE;
	ar >> nBadge;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (nBadge < ZCK_BADGE_ID_NONE)
		return;

	if (nBadge >= ZCK_BADGE_ID_FIRST)
	{
		const CZckBadge* pMng = CZckBadge::GetInstance();

		if (!pMng->GetBadge(nBadge))
			return;

		if (!pMng->IsOwned(static_cast<CMover*>(pUser), nBadge))
			return;
	}

	pUser->SetZckBadge(nBadge);
	g_UserMng.AddZckBadgeChange(pUser, nBadge);
}
#endif // __ZCK_BADGE

#ifdef __ZCK_AURA_SYSTEM
// Pierre d'aura designee par le client, revalidee integralement : objid,
// numero de serie, type, quantite, usage, equipement, echange, expiration.
static CItemElem* ZckAuraGetStone(CUser* pUser, DWORD dwStoneObjId, SERIALNUMBER nStoneSerial)
{
	if (!pUser || dwStoneObjId == NULL_ID)
		return NULL;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwStoneObjId);
	if (!IsUsableItem(pItemElem))
		return NULL;
	if (pItemElem->m_dwItemId != II_PIERRE_AURA_ZCK)
		return NULL;
	if (pItemElem->GetSerialNumber() != nStoneSerial)
		return NULL;
	if (pItemElem->m_nItemNum < 1)
		return NULL;
	if (pUser->IsUsing(pItemElem) || pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
		return NULL;
	if (pUser->m_vtInfo.IsTrading(pItemElem))
		return NULL;
	if (pItemElem->IsFlag(CItemElem::expired))
		return NULL;
	if (pItemElem->m_dwObjId > 0xFF)
		return NULL;

	return pItemElem;
}

// Le client ne fait que demander. Format de la couleur, pierre (une pierre
// consommee par changement) et delai anti-flood sont verifies ici.
// Toute demande recoit une reponse, sauf les repetitions d'un refus
// anti-flood dans la meme fenetre : diffusion en cas de succes, valeur
// autoritaire au seul demandeur sinon (son apercu est alors abandonne).
void CDPSrvr::OnZckAura(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckAura : DWORD, WORD, DWORD, SERIALNUMBER, BYTE.
	// Paquet lu en entier avant tout test.
	DWORD dwCode = ZCK_AURA_NONE;
	WORD wGeo = ZCK_SFX_GEO_NEUTRAL;
	DWORD dwStoneObjId = NULL_ID;
	SERIALNUMBER nStoneSerial = 0;
	BYTE byStyle = (BYTE)ZCK_AURA_STYLE_DEFAULT;
	ar >> dwCode;
	ar >> wGeo;
	ar >> dwStoneObjId;
	ar >> nStoneSerial;
	ar >> byStyle;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;

	const DWORD dwNow = GetTickCount();
	if (dwNow - pUser->m_dwZckAuraTick < (DWORD)ZCK_AURA_REQUEST_DELAY_MS)
	{
		// Une seule reponse par fenetre : un client modifie qui inonde n'obtient
		// ni texte ni snapshot supplementaires.
		if (!pUser->m_bZckAuraFloodReplied)
		{
			pUser->m_bZckAuraFloodReplied = TRUE;
			pUser->AddText("Aura : demande trop rapproch\351e, patientez un instant.");
			pUser->AddZckAura();
		}
		return;
	}
	pUser->m_dwZckAuraTick = dwNow;
	pUser->m_bZckAuraFloodReplied = FALSE;

	if (!ZckAuraIsValidCode(dwCode) || !ZckSfxGeoIsValid(wGeo) || !ZckAuraStyleIsValid(byStyle))
	{
		pUser->AddText("Aura : couleur invalide.");
		pUser->AddZckAura();
		return;
	}

	if (dwCode == pUser->GetZckAura() && wGeo == pUser->GetZckAuraGeo() && byStyle == pUser->GetZckAuraStyle())
	{
		pUser->AddText("Aura : cette couleur est d\351j\340 la v\364tre.");
		pUser->AddZckAura();
		return;
	}

	CItemElem* pStone = ZckAuraGetStone(pUser, dwStoneObjId, nStoneSerial);
	if (!pStone)
	{
		pUser->AddText("Aura : Pierre d'aura introuvable ou indisponible.");
		pUser->AddZckAura();
		return;
	}

	// Un seul debit, puis diffusion a tous ceux qui voient le personnage. Le
	// demandeur est dans FOR_VISIBILITYRANGE (m_2pc le contient) : il recoit
	// donc la valeur enregistree et abandonne son apercu, comme sur un refus.
	pUser->RemoveItem((BYTE)pStone->m_dwObjId, 1);
	pUser->SetZckAura(dwCode);
	pUser->SetZckAuraGeo(wGeo);
	pUser->SetZckAuraStyle(byStyle);
	g_UserMng.AddZckAura(pUser);
	pUser->AddText("Aura modifi\351e.");
}
#endif // __ZCK_AURA_SYSTEM

#ifdef __ZCK_PET_GLOW
// Lecture complete du paquet, puis traitement dans ZckPetGlow.cpp : couleur,
// familier concerne, pierre, anti-flood, application et diffusion.
void CDPSrvr::OnZckPetGlow(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckPetGlow : DWORD, WORD, DWORD, SERIALNUMBER,
	// DWORD, puis, sous __ZCK_PET_GLOW_STYLES, BYTE. Paquet lu en entier avant tout test.
	DWORD dwCode = ZCK_PET_GLOW_NONE;
	WORD wGeo = ZCK_SFX_GEO_NEUTRAL;
	DWORD dwStoneObjId = NULL_ID;
	SERIALNUMBER nStoneSerial = 0;
	DWORD dwPetItemObjId = NULL_ID;
#ifdef __ZCK_PET_GLOW_STYLES
	BYTE byStyle = (BYTE)ZCK_AURA_STYLE_DEFAULT;
#endif // __ZCK_PET_GLOW_STYLES
	ar >> dwCode;
	ar >> wGeo;
	ar >> dwStoneObjId;
	ar >> nStoneSerial;
	ar >> dwPetItemObjId;
#ifdef __ZCK_PET_GLOW_STYLES
	ar >> byStyle;
#endif // __ZCK_PET_GLOW_STYLES

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;

#ifdef __ZCK_PET_GLOW_STYLES
	CZckPetGlow::OnRequest(pUser, dwCode, wGeo, byStyle, dwStoneObjId, nStoneSerial, dwPetItemObjId);
#else
	CZckPetGlow::OnRequest(pUser, dwCode, wGeo, dwStoneObjId, nStoneSerial, dwPetItemObjId);
#endif // __ZCK_PET_GLOW_STYLES
}
#endif // __ZCK_PET_GLOW

#ifdef __ZCK_TRAILS
// Pierre de trails designee par le client, revalidee integralement : objid,
// numero de serie, type, quantite, usage, equipement, echange, expiration.
// Copie de ZckAuraGetStone pour II_PIERRE_AURA_ZCK_TRAILS (defineItem.h).
static CItemElem* ZckTrailsGetStone(CUser* pUser, DWORD dwStoneObjId, SERIALNUMBER nStoneSerial)
{
	if (!pUser || dwStoneObjId == NULL_ID)
		return NULL;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwStoneObjId);
	if (!IsUsableItem(pItemElem))
		return NULL;
	if (pItemElem->m_dwItemId != II_PIERRE_AURA_ZCK_TRAILS)
		return NULL;
	if (pItemElem->GetSerialNumber() != nStoneSerial)
		return NULL;
	if (pItemElem->m_nItemNum < 1)
		return NULL;
	if (pUser->IsUsing(pItemElem) || pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
		return NULL;
	if (pUser->m_vtInfo.IsTrading(pItemElem))
		return NULL;
	if (pItemElem->IsFlag(CItemElem::expired))
		return NULL;
	if (pItemElem->m_dwObjId > 0xFF)
		return NULL;

	return pItemElem;
}

// Le client ne fait que demander. Format du code et des reglages, pierre (une
// pierre consommee par changement, "aucun trail" compris, comme l'aura) et
// delai anti-flood sont verifies ici. Toute demande recoit une reponse, sauf
// les repetitions d'un refus anti-flood dans la meme fenetre : diffusion en
// cas de succes, valeur autoritaire au seul demandeur sinon (son apercu est
// alors abandonne).
void CDPSrvr::OnZckTrails(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckTrails : DWORD, DWORD, DWORD, SERIALNUMBER.
	// Paquet lu en entier avant tout test.
	DWORD dwCode = ZCK_TRAILS_NONE;
	DWORD dwParam = ZCK_TRAILS_PARAM_DEFAULT;
	DWORD dwStoneObjId = NULL_ID;
	SERIALNUMBER nStoneSerial = 0;
	ar >> dwCode;
	ar >> dwParam;
	ar >> dwStoneObjId;
	ar >> nStoneSerial;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;

	const DWORD dwNow = GetTickCount();
	if (dwNow - pUser->m_dwZckTrailsTick < (DWORD)ZCK_TRAILS_REQUEST_DELAY_MS)
	{
		// Une seule reponse par fenetre : un client modifie qui inonde n'obtient
		// ni texte ni snapshot supplementaires.
		if (!pUser->m_bZckTrailsFloodReplied)
		{
			pUser->m_bZckTrailsFloodReplied = TRUE;
			pUser->AddText("Trail : demande trop rapproch\351e, patientez un instant.");
			pUser->AddZckTrails();
		}
		return;
	}
	pUser->m_dwZckTrailsTick = dwNow;
	pUser->m_bZckTrailsFloodReplied = FALSE;

	if (!ZckTrailsIsValidCode(dwCode) || !ZckTrailsParamIsValid(dwParam))
	{
		pUser->AddText("Trail : valeur invalide.");
		pUser->AddZckTrails();
		return;
	}

	if (dwCode == pUser->GetZckTrails() && dwParam == pUser->GetZckTrailsParam())
	{
		pUser->AddText("Trail : ce trail est d\351j\340 le v\364tre.");
		pUser->AddZckTrails();
		return;
	}

	CItemElem* pStone = ZckTrailsGetStone(pUser, dwStoneObjId, nStoneSerial);
	if (!pStone)
	{
		pUser->AddText("Trail : Pierre de trails introuvable ou indisponible.");
		pUser->AddZckTrails();
		return;
	}

	// Un seul debit, puis diffusion a tous ceux qui voient le personnage. Le
	// demandeur est dans FOR_VISIBILITYRANGE (m_2pc le contient) : il recoit
	// donc la valeur enregistree et abandonne son apercu, comme sur un refus.
	pUser->RemoveItem((BYTE)pStone->m_dwObjId, 1);
	pUser->SetZckTrails(dwCode);
	pUser->SetZckTrailsParam(dwParam);
	g_UserMng.AddZckTrails(pUser);
	pUser->AddText("Trail modifi\351.");
}
#endif // __ZCK_TRAILS
#ifdef __ZCK_ELEMENT_RGB

#ifndef II_PIERRE_AURA_ELEMENT
#error "__ZCK_ELEMENT_RGB : defineItem.h (dossier Resource) sans II_PIERRE_AURA_ELEMENT, appliquer les ressources de ZCK_ELEMENT_RGB.md"
#endif // II_PIERRE_AURA_ELEMENT

// Pierre d'element RGB designee par le client, revalidee integralement :
// objid, numero de serie, type, quantite, usage, equipement, echange,
// expiration. Copie de ZckTrailsGetStone pour II_PIERRE_AURA_ELEMENT.
static CItemElem* ZckElementRgbGetStone(CUser* pUser, DWORD dwStoneObjId, SERIALNUMBER nStoneSerial)
{
	if (!pUser || dwStoneObjId == NULL_ID)
		return NULL;

	CItemElem* pItemElem = pUser->m_Inventory.GetAtId(dwStoneObjId);
	if (!IsUsableItem(pItemElem))
		return NULL;
	if (pItemElem->m_dwItemId != II_PIERRE_AURA_ELEMENT)
		return NULL;
	if (pItemElem->GetSerialNumber() != nStoneSerial)
		return NULL;
	if (pItemElem->m_nItemNum < 1)
		return NULL;
	if (pUser->IsUsing(pItemElem) || pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
		return NULL;
	if (pUser->m_vtInfo.IsTrading(pItemElem))
		return NULL;
	if (pItemElem->IsFlag(CItemElem::expired))
		return NULL;
	if (pItemElem->m_dwObjId > 0xFF)
		return NULL;

	return pItemElem;
}

// Le client ne fait que demander. Main, format du code, pierre (une pierre
// consommee par changement, "couleurs d'origine" compris, comme l'aura et les
// trails) et delai anti-flood sont verifies ici. Une couleur par main : seule
// la main demandee change. L'element des objets n'est ni lu ni touche : seule
// la couleur de ses SFX change. Toute demande recoit une reponse, sauf les
// repetitions d'un refus anti-flood dans la meme fenetre : diffusion en cas de
// succes, valeurs autoritaires au seul demandeur sinon (son apercu est alors
// abandonne).
void CDPSrvr::OnZckElementRgb(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckElementRgb : BYTE, DWORD, DWORD,
	// SERIALNUMBER. Paquet lu en entier avant tout test.
	BYTE byHand = 0;
	DWORD dwCode = ZCK_ELEMENT_RGB_NONE;
	DWORD dwStoneObjId = NULL_ID;
	SERIALNUMBER nStoneSerial = 0;
	ar >> byHand;
	ar >> dwCode;
	ar >> dwStoneObjId;
	ar >> nStoneSerial;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;

	const DWORD dwNow = GetTickCount();
	if (dwNow - pUser->m_dwZckElementRgbTick < (DWORD)ZCK_ELEMENT_RGB_REQUEST_DELAY_MS)
	{
		// Une seule reponse par fenetre : un client modifie qui inonde n'obtient
		// ni texte ni snapshot supplementaires.
		if (!pUser->m_bZckElementRgbFloodReplied)
		{
			pUser->m_bZckElementRgbFloodReplied = TRUE;
			pUser->AddText("\311l\351ment RGB : demande trop rapproch\351e, patientez un instant.");
			pUser->AddZckElementRgb();
		}
		return;
	}
	pUser->m_dwZckElementRgbTick = dwNow;
	pUser->m_bZckElementRgbFloodReplied = FALSE;

	const int nHand = (int)byHand;
	if (!ZckElementRgbIsValidHand(nHand) || !ZckElementRgbIsValidCode(dwCode))
	{
		pUser->AddText("\311l\351ment RGB : couleur invalide.");
		pUser->AddZckElementRgb();
		return;
	}

	if (dwCode == pUser->GetZckElementRgb(nHand))
	{
		pUser->AddText("\311l\351ment RGB : cette couleur est d\351j\340 celle de cette main.");
		pUser->AddZckElementRgb();
		return;
	}

	CItemElem* pStone = ZckElementRgbGetStone(pUser, dwStoneObjId, nStoneSerial);
	if (!pStone)
	{
		pUser->AddText("\311l\351ment RGB : pierre introuvable ou indisponible.");
		pUser->AddZckElementRgb();
		return;
	}

	// Un seul debit, puis diffusion a tous ceux qui voient le personnage. Le
	// demandeur est dans FOR_VISIBILITYRANGE (m_2pc le contient) : il recoit
	// donc les valeurs enregistrees et abandonne son apercu, comme sur un refus.
	pUser->RemoveItem((BYTE)pStone->m_dwObjId, 1);
	pUser->SetZckElementRgb(nHand, dwCode);
	g_UserMng.AddZckElementRgb(pUser);
	if (nHand == ZCK_ELEMENT_RGB_HAND_LEFT)
		pUser->AddText("Couleur d'\351l\351ment de la main gauche modifi\351e.");
	else
		pUser->AddText("Couleur d'\351l\351ment de la main droite modifi\351e.");
}
#endif // __ZCK_ELEMENT_RGB
#ifdef __ZCK_VOIR_INVENTAIRE_JOUEURS
// Voir l'inventaire d'un joueur (portage de Titanium __AEGON_VIEW_INV, lecture
// seule). Le client n'envoie qu'un nom et l'onglet voulu ; tout est juge ici,
// jamais sur la foi du client : droits du demandeur (AUTH_GAMEMASTER2 ; un non-MJ
// n'obtient aucune reponse), anti-flood, joueur vise connecte a ce WorldServer,
// identifiant coherent, pas soi-meme, rang du staff selon IsAuthHigher (avec
// __ZCK_AUTH, tous les grades MJ valent administrateur : aucun refus entre MJ,
// comme pour /kill), conteneurs alloues aux tailles de V18.2. La reponse ne part
// qu'au demandeur. Aucun objet n'est lu du client ni modifie : les commandes
// d'objets de Titanium (copier, supprimer, deplacer un objet du joueur consulte)
// ne sont pas portees.
void CDPSrvr::OnZckVoirInventaire(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckVoirInventaire : une chaine puis un BYTE,
	// lus en entier avant tout test. ReadString borne la longueur : trop longue ou
	// negative, la chaine reste vide et plus rien n'est lu (jamais de debordement).
	char szNom[MAX_PLAYER] = { 0, };
	ar.ReadString(szNom, MAX_PLAYER);
	BYTE byOnglet = ZCK_VOIR_INV_ONGLET_INVENTAIRE;
	ar >> byOnglet;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;
	if (!pUser->IsAuthHigher(AUTH_GAMEMASTER2))
		return;

	const DWORD dwNow = GetTickCount();
	if (dwNow - pUser->m_dwZckVoirInventaireTick < (DWORD)ZCK_VOIR_INV_DELAI_MS)
	{
		// Une seule reponse par fenetre : un client qui inonde n'obtient rien de plus.
		if (!pUser->m_bZckVoirInventaireFloodReplied)
		{
			pUser->m_bZckVoirInventaireFloodReplied = TRUE;
			pUser->AddText("Voir l'inventaire : demande trop rapproch\351e, patientez un instant.");
		}
		return;
	}
	pUser->m_dwZckVoirInventaireTick = dwNow;
	pUser->m_bZckVoirInventaireFloodReplied = FALSE;

	if (szNom[0] == '\0')
	{
		pUser->AddText("Voir l'inventaire : nom du joueur absent ou trop long.");
		return;
	}

	const u_long idCible = CPlayerDataCenter::GetInstance()->GetPlayerId(szNom);
	CUser* pCible = (idCible != 0) ? g_UserMng.GetUserByPlayerID(idCible) : NULL;
	if (!IsValidObj(pCible) || pCible->m_idPlayer != idCible)
	{
		CString strTexte;
		strTexte.Format("Voir l'inventaire : %s introuvable (hors ligne ou sur un autre canal).", szNom);
		pUser->AddText(strTexte);
		return;
	}
	if (pCible == pUser)
	{
		pUser->AddText("Voir l'inventaire : c'est votre propre personnage.");
		return;
	}
	if (!pUser->IsAuthHigher(pCible->m_dwAuthorization))
	{
		pUser->AddText("Voir l'inventaire : rang insuffisant pour ce personnage.");
		return;
	}
	if (!ZckVoirInventairePret(pCible))
	{
		pUser->AddText("Voir l'inventaire : inventaire de ce personnage indisponible.");
		return;
	}

	pUser->AddZckVoirInventaire(pCible, ZCK_VOIR_INV_ONGLET_VALIDE(byOnglet));
#ifdef __ZCK_SPD_LOG
	ZCK_LOG_INFO("[VoirInventaire] %s (id %lu) consulte l'inventaire de %s (id %lu).", pUser->GetName(), (unsigned long)pUser->m_idPlayer, pCible->GetName(), (unsigned long)pCible->m_idPlayer);
#endif // __ZCK_SPD_LOG
}
#endif // __ZCK_VOIR_INVENTAIRE_JOUEURS

#ifdef __ZCK_MOUNTURE_VOLANTE
// Monture volante : decollage ou atterrissage demande depuis l'inventaire
// (CDPClient::SendZckMontureVolante). Monture, etat, monde, zone, sol,
// deguisement, propension au chaos et delai anti-flood sont verifies ici ; le
// changement est applique puis diffuse a tous ceux qui voient le joueur, lui
// compris (familiers rappeles au decollage, comme pour un balai). Un refus
// recoit un texte, sauf les repetitions d'un refus anti-flood dans la meme
// fenetre.
void CDPSrvr::OnZckMontureVolante(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckMontureVolante : BYTE. Paquet lu en entier avant tout test.
	BYTE byAction = 0;
	ar >> byAction;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;

	if (byAction != ZCK_MV_ACTION_DECOLLER && byAction != ZCK_MV_ACTION_ATTERRIR)
		return;

	const DWORD dwNow = GetTickCount();
	if (dwNow - pUser->m_dwZckMvTick < (DWORD)ZCK_MV_DELAI_DEMANDE_MS)
	{
		// Une seule reponse par fenetre : un client modifie qui inonde n'obtient
		// pas de texte supplementaire.
		if (!pUser->m_bZckMvFloodReplied)
		{
			pUser->m_bZckMvFloodReplied = TRUE;
			pUser->AddText(ZckMvTexteRefus(ZCK_MV_REFUS_DELAI));
		}
		return;
	}
	pUser->m_dwZckMvTick = dwNow;
	pUser->m_bZckMvFloodReplied = FALSE;

	const int nRefus = (byAction == ZCK_MV_ACTION_DECOLLER) ? ZckMvVerifierDecollage(pUser) : ZckMvVerifierAtterrissage(pUser);
	if (nRefus != ZCK_MV_REFUS_AUCUN)
	{
		pUser->AddText(ZckMvTexteRefus(nRefus));
		return;
	}

	// Serveur d'abord (le Synchronizer refuse un etat de vol different du sien),
	// puis tous ceux qui voient le joueur : m_2pc contient le joueur lui-meme.
	if (byAction == ZCK_MV_ACTION_DECOLLER)
	{
		// Comme a l'equipement d'un balai (CMover::IsEquipAble) : aucun familier
		// en vol (ActivateSystemPet refuse deja d'en appeler un en vol).
		pUser->DisableAllPets();
		ZckMvDecoller(pUser);
	}
	else
		ZckMvAtterrir(pUser);

	g_UserMng.AddZckMontureVolante(pUser, byAction);
}
#endif // __ZCK_MOUNTURE_VOLANTE
#ifdef __ZCK_CHANGE_DST_NIVEAU
// Changement de la caracteristique du niveau d'arme. Le client ne fait que
// demander (objet designe par objid et numero de serie, indice de choix) :
// objet, proprietaire, etat du joueur, caracteristique et parchemin (choisi
// ici, jamais par le client) sont juges par ZckChangeDstNiveauJuger, le delai
// anti-flood ici. Toute demande recoit une reponse (snapshot au seul
// demandeur), sauf les repetitions d'un refus anti-flood dans la meme
// fenetre. Le parchemin n'est consomme qu'une fois la caracteristique
// enregistree.
void CDPSrvr::OnZckChangeDstNiveau(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckChangeDstNiveau : paquet lu en entier
	// avant tout test (ZckChangeDstNiveauLireDemande).
	ZCK_CDN_DEMANDE demande;
	ZckChangeDstNiveauLireDemande(ar, demande);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;

	const DWORD dwNow = GetTickCount();
	if (dwNow - pUser->m_dwZckChangeDstNiveauTick < (DWORD)ZCK_CDN_DELAI_MS)
	{
		// Une seule reponse par fenetre : un client modifie qui inonde n'obtient
		// pas de snapshot supplementaire.
		if (!pUser->m_bZckChangeDstNiveauFloodReplied)
		{
			pUser->m_bZckChangeDstNiveauFloodReplied = TRUE;
			pUser->AddZckChangeDstNiveau(ZCK_CDN_REFUS_DELAI, demande.dwObjId, 0);
		}
		return;
	}
	pUser->m_dwZckChangeDstNiveauTick = dwNow;
	pUser->m_bZckChangeDstNiveauFloodReplied = FALSE;

	BOOL bModeEgalise = FALSE;
#ifdef __FL_EQUALIZED_MODE
	bModeEgalise = pUser->bTmpMode ? TRUE : FALSE;
#endif // __FL_EQUALIZED_MODE

	CItemElem* pArme = NULL;
	CItemElem* pParchemin = NULL;
	DWORD dwNouvelle = 0;
	const BYTE byCode = ZckChangeDstNiveauJuger(pUser, demande, bModeEgalise, &pArme, &pParchemin, &dwNouvelle);
	if (byCode != ZCK_CDN_OK)
	{
		pUser->AddZckChangeDstNiveau(byCode, demande.dwObjId, pArme ? pArme->m_dwZckArmeNiveauStat : 0);
		return;
	}

#ifdef __ZCK_SPD_LOG
	const DWORD dwAncienne = pArme->m_dwZckArmeNiveauStat;
#endif // __ZCK_SPD_LOG

	// La caracteristique d'abord : si elle n'est pas enregistree, rien n'est
	// consomme.
	if (!ZckChangeDstNiveauAppliquer(pUser, pArme, dwNouvelle))
	{
		pUser->AddZckChangeDstNiveau(ZCK_CDN_REFUS_ECHEC, demande.dwObjId, pArme->m_dwZckArmeNiveauStat);
		return;
	}

	// Puis le parchemin choisi par le serveur : journal, puis un seul debit.
	PutItemLog(pUser, "u", "ZCK_CHANGE_DST_NIVEAU", pParchemin, 1);
	pUser->RemoveItem((BYTE)pParchemin->m_dwObjId, 1);

	pUser->AddZckChangeDstNiveau(ZCK_CDN_OK, demande.dwObjId, pArme->m_dwZckArmeNiveauStat);
	pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
	if (pUser->IsMode(TRANSPARENT_MODE) == 0)
		g_UserMng.AddCreateSfxObj(pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
#ifdef __ZCK_SPD_LOG
	ZCK_LOG_INFO("[ChangeDstNiveau] %s (id %lu) : objet %lu, caracteristique %lu -> %lu.", pUser->GetName(), (unsigned long)pUser->m_idPlayer, (unsigned long)demande.dwObjId, (unsigned long)dwAncienne, (unsigned long)dwNouvelle);
#endif // __ZCK_SPD_LOG

	// SavePlayer prend une reference non constante : variable locale plutot
	// que la temporaire de GetPos() (comme l'arme Reborn).
	D3DXVECTOR3 vZckPos = pUser->GetPos();
	g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), vZckPos, pUser->GetLayer());
}
#endif // __ZCK_CHANGE_DST_NIVEAU
#ifdef __ZCK_IA_FARM
void CDPSrvr::OnZckIaFarm(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckIaFarm (_Common/ZckIaFarmReseau.h) ; le
	// paquet est lu, borne et revalide en entier par RecevoirReglages, qui
	// repond par un snapshot SNAPSHOTTYPE_ZCK_IA_FARM (etat d'armement).
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;
	g_ZckIaFarmServeur.RecevoirReglages(pUser, ar);
}
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
void CDPSrvr::OnZckMondialBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckMondialBuff (_Common/ZckMondialBuffReseau.h).
	// Le client n'envoie qu'une action, un index et l'empreinte de son .inc :
	// cout, duree, plafond et cooldowns sont relus par le serveur.
	BYTE byAction = 0;
	BYTE byIndex = 0;
	DWORD dwEmpreinte = 0;
	ar >> byAction;
	ar >> byIndex;
	ar >> dwEmpreinte;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;
	CZckMondialBuffMng::GetInstance()->OnPaquet(pUser, byAction, byIndex, dwEmpreinte);
}
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
void CDPSrvr::OnZckPerinBuff(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckPerinBuff (_Common/ZckPerinBuffReseau.h).
	// Le client n'envoie qu'une action, une quantite et l'empreinte de son
	// .inc : objet investi, capacite, paliers et perte sont relus par le serveur.
	BYTE byAction = 0;
	WORD wQuantite = 0;
	DWORD dwEmpreinte = 0;
	ar >> byAction;
	ar >> wQuantite;
	ar >> dwEmpreinte;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;
	CZckPerinBuffMng::GetInstance()->OnPaquet(pUser, byAction, wQuantite, dwEmpreinte);
}
#endif // __ZCK_PERIN_BUFF
#ifdef __ZCK_AMELIORATION_TICKET
void CDPSrvr::OnZckTicketCarte(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	// Ordre exact de CDPClient::SendZckTicketCarte (_Common/ticket.h, contrat
	// reseau) : la demande est lue en entier avant tout controle ; ticket,
	// monde et canal sont revalides par CUser::ZckTicketDemandeCarte.
	ZCK_TICKET_DEMANDE_CARTE demande;
	ZckTicketLireDemandeCarte(ar, demande);

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser) || !pUser->GetWorld())
		return;
	pUser->ZckTicketDemandeCarte(demande.dwObjId, demande.dwMonde, demande.byCanal);
}
#endif // __ZCK_AMELIORATION_TICKET

#ifdef __ZCK_LISTE_JOUEURS
void CDPSrvr::OnPlayerListRequest(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	if (!pUser->AcceptPlayerListRequest())
	{
		pUser->AddText("Veuillez patienter avant d'actualiser la liste.", 0xFFFF0000);
		return;
	}

	BOOL bCheck[17] = { FALSE };
	for (int i = 0; i < 17; ++i)
		ar >> bCheck[i];

	int nMin = 1;
	int nMax = 300;
	ar >> nMin >> nMax;

	TCHAR szSearch[32] = { 0 };
	ar.ReadString(szSearch, 32);

	CString strSearch = szSearch;
	strSearch.MakeLower();

	int nTotal = 0;
	for (unordered_map<DWORD, CUser*>::const_iterator it = g_UserMng.m_users.begin(); it != g_UserMng.m_users.end(); ++it)
	{
		CUser* pListed = it->second;
		if (!IsValidObj(pListed))
			continue;

		const BOOL bGeneralPlayer = (pListed->m_dwAuthorization == AUTH_GENERAL);
		if (!bCheck[0] && bGeneralPlayer)
			continue;
		if (!bCheck[1] && !bGeneralPlayer)
			continue;

		const int nJob = pListed->GetJob();
		if (!bCheck[2] && nJob == JOB_MERCENARY)
			continue;
#ifdef __ZCK_4_CLASSES
		if (!bCheck[3] && (nJob == JOB_KNIGHT || nJob == JOB_KNIGHT_MASTER || nJob == JOB_KNIGHT_HERO || nJob == JOB_LORDTEMPLER_HERO || nJob == JOB_LORDTEMPLER_HERO_ULTIMATE))
#else
		if (!bCheck[3] && (nJob == JOB_KNIGHT || nJob == JOB_KNIGHT_MASTER || nJob == JOB_KNIGHT_HERO || nJob == JOB_LORDTEMPLER_HERO))
#endif // __ZCK_4_CLASSES
			continue;
#ifdef __ZCK_4_CLASSES
		if (!bCheck[4] && (nJob == JOB_BLADE || nJob == JOB_BLADE_MASTER || nJob == JOB_BLADE_HERO || nJob == JOB_STORMBLADE_HERO || nJob == JOB_STORMBLADE_HERO_ULTIMATE))
#else
		if (!bCheck[4] && (nJob == JOB_BLADE || nJob == JOB_BLADE_MASTER || nJob == JOB_BLADE_HERO || nJob == JOB_STORMBLADE_HERO))
#endif // __ZCK_4_CLASSES
			continue;
		if (!bCheck[5] && nJob == JOB_ACROBAT)
			continue;
#ifdef __ZCK_4_CLASSES
		if (!bCheck[6] && (nJob == JOB_JESTER || nJob == JOB_JESTER_MASTER || nJob == JOB_JESTER_HERO || nJob == JOB_WINDLURKER_HERO || nJob == JOB_WINDLURKER_HERO_ULTIMATE))
#else
		if (!bCheck[6] && (nJob == JOB_JESTER || nJob == JOB_JESTER_MASTER || nJob == JOB_JESTER_HERO || nJob == JOB_WINDLURKER_HERO))
#endif // __ZCK_4_CLASSES
			continue;
#ifdef __ZCK_4_CLASSES
		if (!bCheck[7] && (nJob == JOB_RANGER || nJob == JOB_RANGER_MASTER || nJob == JOB_RANGER_HERO || nJob == JOB_CRACKSHOOTER_HERO || nJob == JOB_CRACKSHOOTER_HERO_ULTIMATE))
#else
		if (!bCheck[7] && (nJob == JOB_RANGER || nJob == JOB_RANGER_MASTER || nJob == JOB_RANGER_HERO || nJob == JOB_CRACKSHOOTER_HERO))
#endif // __ZCK_4_CLASSES
			continue;
		if (!bCheck[8] && nJob == JOB_ASSIST)
			continue;
#ifdef __ZCK_4_CLASSES
		if (!bCheck[9] && (nJob == JOB_RINGMASTER || nJob == JOB_RINGMASTER_MASTER || nJob == JOB_RINGMASTER_HERO || nJob == JOB_FLORIST_HERO || nJob == JOB_FLORIST_HERO_ULTIMATE))
#else
		if (!bCheck[9] && (nJob == JOB_RINGMASTER || nJob == JOB_RINGMASTER_MASTER || nJob == JOB_RINGMASTER_HERO || nJob == JOB_FLORIST_HERO))
#endif // __ZCK_4_CLASSES
			continue;
#ifdef __ZCK_4_CLASSES
		if (!bCheck[10] && (nJob == JOB_BILLPOSTER || nJob == JOB_BILLPOSTER_MASTER || nJob == JOB_BILLPOSTER_HERO || nJob == JOB_FORCEMASTER_HERO || nJob == JOB_FORCEMASTER_HERO_ULTIMATE))
#else
		if (!bCheck[10] && (nJob == JOB_BILLPOSTER || nJob == JOB_BILLPOSTER_MASTER || nJob == JOB_BILLPOSTER_HERO || nJob == JOB_FORCEMASTER_HERO))
#endif // __ZCK_4_CLASSES
			continue;
		if (!bCheck[11] && nJob == JOB_MAGICIAN)
			continue;
#ifdef __ZCK_4_CLASSES
		if (!bCheck[12] && (nJob == JOB_PSYCHIKEEPER || nJob == JOB_PSYCHIKEEPER_MASTER || nJob == JOB_PSYCHIKEEPER_HERO || nJob == JOB_MENTALIST_HERO || nJob == JOB_MENTALIST_HERO_ULTIMATE))
#else
		if (!bCheck[12] && (nJob == JOB_PSYCHIKEEPER || nJob == JOB_PSYCHIKEEPER_MASTER || nJob == JOB_PSYCHIKEEPER_HERO || nJob == JOB_MENTALIST_HERO))
#endif // __ZCK_4_CLASSES
			continue;
#ifdef __ZCK_4_CLASSES
		if (!bCheck[13] && (nJob == JOB_ELEMENTOR || nJob == JOB_ELEMENTOR_MASTER || nJob == JOB_ELEMENTOR_HERO || nJob == JOB_ELEMENTORLORD_HERO || nJob == JOB_ELEMENTORLORD_HERO_ULTIMATE))
#else
		if (!bCheck[13] && (nJob == JOB_ELEMENTOR || nJob == JOB_ELEMENTOR_MASTER || nJob == JOB_ELEMENTOR_HERO || nJob == JOB_ELEMENTORLORD_HERO))
#endif // __ZCK_4_CLASSES
			continue;
		if (!bCheck[14] && pListed->GetSex() == SEX_MALE)
			continue;
		if (!bCheck[15] && pListed->GetSex() == SEX_FEMALE)
			continue;
		if (!bCheck[16] && nJob == JOB_VAGRANT)
			continue;

		if (pListed->GetLevel() < nMin || pListed->GetLevel() > nMax)
			continue;

		if (!pListed->GetName() || !pListed->GetName()[0])
			continue;

		if (!strSearch.IsEmpty())
		{
			CString strPlayerName = pListed->GetName();
			strPlayerName.MakeLower();
			if (strPlayerName.Find(strSearch) < 0)
				continue;
		}

		if (pListed->IsPLHided())
		{
			const BOOL bViewerAtLeastTarget = pUser->IsAuthHigher(pListed->m_dwAuthorization) ? TRUE : FALSE;
			const BOOL bTargetAtLeastViewer = pListed->IsAuthHigher(pUser->m_dwAuthorization) ? TRUE : FALSE;
			if (!(bViewerAtLeastTarget && !bTargetAtLeastViewer))
				continue;
		}

		PlayerList player = {};
		strncpy(player.szName, pListed->GetName(), sizeof(player.szName) - 1);
		player.szName[sizeof(player.szName) - 1] = '\0';
		player.szRank[0] = '\0';

		if (!bGeneralPlayer)
		{
			CString strRank;
#ifdef __ZCK_AUTH
			strRank = pListed->GetAuthString();
#else
			if (pListed->m_dwAuthorization == AUTH_ADMINISTRATOR)
				strRank = "Administrateur";
			else if (pListed->m_dwAuthorization == AUTH_GAMEMASTER2)
				strRank = "Maitre du jeu";
			else if (pListed->m_dwAuthorization == AUTH_GAMEMASTER)
				strRank = "Moderateur";
#endif // __ZCK_AUTH
			if (!strRank.IsEmpty())
			{
				CString strDisplayRank;
				strDisplayRank.Format(" [%s]", (LPCTSTR)strRank);
				strncpy(player.szRank, (LPCTSTR)strDisplayRank, sizeof(player.szRank) - 1);
				player.szRank[sizeof(player.szRank) - 1] = '\0';
			}
		}

		player.dwJob = pListed->GetJob();
		player.dwLevel = pListed->GetLevel();
		player.dwSex = pListed->GetSex();
		player.nID = nTotal;

		pUser->SendPlayerList(FALSE, player, TRUE, nTotal == 0 ? TRUE : FALSE);
		++nTotal;
	}

	if (nTotal == 0)
		pUser->SendPlayerList(TRUE);
}

void CDPSrvr::OnPlayerListUpdateMods(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (!IsValidObj(pUser))
		return;

	BOOL bHidden = FALSE;
	ar >> bHidden;

	if (bHidden)
		pUser->SetMode(PLAYER_LIST_HIDE_MODE);
	else
		pUser->SetNotMode(PLAYER_LIST_HIDE_MODE);

	g_UserMng.AddModifyMode(pUser);
}
#endif // __ZCK_LISTE_JOUEURS

#ifdef __ZCK_COMBAT_MC
void CDPSrvr::OnZckCombatMCRegisterWindow(CAr&, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->AddMonsterClashRegisterWindow();
}

void CDPSrvr::OnZckCombatMCRegisterMemberWindow(CAr&, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	pUser->AddMonsterClashRegisterMemberWindow();
}

void CDPSrvr::OnZckCombatMCRegister(CAr&, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	if (CMonsterClashMng::GetInstance()->RegisterGuild(pUser))
	{
		CGuild* pGuild = pUser->GetGuild();
		pUser->AddMonsterClashRegister(pUser->m_idGuild, pGuild ? pGuild->m_szGuild : _T("Inconnue"));
	}
}

void CDPSrvr::OnZckCombatMCRegisterMember(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	u_long idPlayer = 0;
	ar >> idPlayer;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CUser* pMember = g_UserMng.GetUserByPlayerID(idPlayer);
	if (IsInvalidObj(pMember))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText(_T("Ce membre de guilde n'est plus connect\351."), 0xFFFF0000);
#else
		pUser->AddText(_T("Ce membre de guilde n'est plus connecté."), 0xFFFF0000);
#endif // __ZCK_TRAD_FR
		return;
	}

	if (CMonsterClashMng::GetInstance()->RegisterGuildMember(pUser, pMember))
		pUser->AddMonsterClashRegisterMember(pMember->m_idPlayer, pMember->GetName());
}

void CDPSrvr::OnZckCombatMCUnregisterMember(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	u_long idPlayer = 0;
	ar >> idPlayer;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CUser* pMember = g_UserMng.GetUserByPlayerID(idPlayer);
	if (IsInvalidObj(pMember))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText(_T("Ce membre de guilde n'est plus connect\351."), 0xFFFF0000);
#else
		pUser->AddText(_T("Ce membre de guilde n'est plus connecté."), 0xFFFF0000);
#endif // __ZCK_TRAD_FR
		return;
	}

	if (CMonsterClashMng::GetInstance()->UnregisterGuildMember(pUser, pMember))
		pUser->AddMonsterClashUnregisterMember(pMember->m_idPlayer, pMember->GetName());
}
#endif // __ZCK_COMBAT_MC

#ifdef __ZCK_TOUR_INFINI
// Le client n'envoie que des intentions : entrer, quitter, demander le classement.
void CDPSrvr::OnZckTourInfiniEnter(CAr&, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser) || !pUser->GetWorld())
		return;

	// Meme validation serveur du menu PNJ que MMI_ZCK_RARE (plus haut dans ce fichier).
	if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_ZCK_TOUR_INFINI_ENTER, pUser->GetWorld(), pUser->GetPos()))
	{
		pUser->AddText("Approchez-vous du PNJ de la Tour infinie.");
		return;
	}

	CZckTourInfiniMng::GetInstance()->TryEnter(pUser);
}

void CDPSrvr::OnZckTourInfiniLeave(CAr&, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;

	CZckTourInfiniMng::GetInstance()->Leave(pUser);
}

void CDPSrvr::OnZckTourInfiniRanking(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	int nMode = 0;
	ar >> nMode;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser))
		return;
	if (nMode < 0 || nMode >= ZCK_TOUR_MODE_COUNT)
		return;

	CZckTourInfiniMng::GetInstance()->SendRanking(pUser, nMode);
}
#endif // __ZCK_TOUR_INFINI

#ifdef __ZCK_COLOSSEUM
// Portage de CDPSrvr::OnColosseum (donneur) : BYTE requete [+ BYTE difficulte + BYTE mode].
void CDPSrvr::OnZckColosseum(CAr& ar, DPID dpidCache, DPID dpidUser, LPBYTE, u_long)
{
	BYTE nState = 0;
	BYTE byDifficult = 0;
	BYTE byMenu = 0;
	ar >> nState;
	if (nState == ZCK_COLO_REQ_CREATE)
		ar >> byDifficult >> byMenu;

	CUser* pUser = g_UserMng.GetUser(dpidCache, dpidUser);
	if (IsInvalidObj(pUser) || !pUser->GetWorld())
		return;

	CColosseumMng* pMng = CColosseumMng::GetInstance();
	CParty* pParty = g_PartyMng.GetParty(pUser->GetPartyId());
	switch (nState)
	{
	case ZCK_COLO_REQ_CREATE:
		if (pParty && pParty->IsLeader(pUser->m_idPlayer))
		{
			// Meme validation serveur du menu PNJ que la Tour infinie (absente chez le donneur).
			D3DXVECTOR3 vPos = pUser->GetPos();
			if (!CNpcChecker::GetInstance()->IsCloseNpc(MMI_COLOSSEUM_COLOENTER01, pUser->GetWorld(), vPos))
			{
				pUser->AddText(_T("Colis\xE9") _T("e : approchez-vous du PNJ du Colis\xE9") _T("e."));
				break;
			}
			// Le chef doit pouvoir etre teleporte (instance, commerce, banque, zone...) :
			// verifie AVANT la creation, sinon le match existerait sans lui.
			if (!pMng->CanEnter(pUser))
				break;

			if (pMng->CreateNewMatch(pUser, byDifficult, byMenu))
			{
				CColosseumMatch* pMatch = pMng->GetMatchByParty(pParty);
				if (pMatch)
					pMatch->EnterRoom(pUser);
				// Donneur : ce texte part aussi apres une creation reussie (voir Points a confirmer).
				pUser->AddDefinedText(TID_COLOSSEUM_NOTENTERTIME01);
			}
			else
				pUser->AddDefinedText(TID_COLOSSEUM_NOTENTERTIME01);
		}
		else
			pUser->AddDefinedText(TID_COLOSSEUM_COLONOWPLAYING01);
		break;

	case ZCK_COLO_REQ_JOIN:
		if (pParty)
		{
			CColosseumMatch* pMatch = pMng->GetMatchByParty(pParty);
			if (pMatch && (pMatch->m_byMenu != ZCK_COLO_MENU_GUILD || pMatch->m_uGuildID == pUser->m_idGuild))
			{
				pMatch->EnterRoom(pUser);
				// Entree refusee pendant l'attente (regles d'entree) : le client a deja ferme
				// l'invitation, elle est renvoyee pour que le joueur puisse reessayer.
				if (pMatch->m_bWaitTime && !pMatch->IsTeleported(pUser->m_idPlayer))
					pUser->AddZckColosseumEnter();
			}
		}
		break;

	case ZCK_COLO_REQ_ENDWAIT:
		if (pParty && pParty->IsLeader(pUser->m_idPlayer))
		{
			CColosseumMatch* pMatch = pMng->GetMatchByParty(pParty);
			if (pMatch)
				pMatch->EndWaitTime();
		}
		break;

	default:
		break;
	}
}
#endif // __ZCK_COLOSSEUM