#include "stdafx.h"

#ifdef __ZCK_IMGUI

#include "ZckImGui.h"

#include "../ThirdParty/DearImGui/imgui.h"
#include "../ThirdParty/DearImGui/backends/imgui_impl_win32.h"
#include "../ThirdParty/DearImGui/backends/imgui_impl_dx9.h"

#ifdef __ZCK_SPD_LOG
#include "ZckSpdLog.h"
#endif // __ZCK_SPD_LOG

#ifdef __ZCK_RENDU
#include "ZckRendu.h"
extern CZckRendu g_ZckRendu;
#endif // __ZCK_RENDU

#ifdef __ZCK_CRYPT_CLIENT
#include "ZckCryptClient.h"
extern CZckCryptClient g_ZckCryptClient;
#endif // __ZCK_CRYPT_CLIENT

#ifdef __ZCK_IA_FARM
#include "ZckIaFarm.h"
extern CZckIaFarm g_ZckIaFarm;
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
#include "ZckMondialBuff.h"
extern CZckMondialBuffMng g_ZckMondialBuff;
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
#include "ZckPerinBuff.h"
extern CZckPerinBuffMng g_ZckPerinBuff;
#endif // __ZCK_PERIN_BUFF

// Declaration volontairement absente du header public officiel Dear ImGui.
// Le backend demande de la forward-declarer dans le .cpp utilisateur.
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam
);

extern int g_nOldVirtKey;

namespace
{
    enum ZckMouseButtonMask
    {
        ZCK_MOUSE_NONE   = 0,
        ZCK_MOUSE_LEFT   = 1 << 0,
        ZCK_MOUSE_RIGHT  = 1 << 1,
        ZCK_MOUSE_MIDDLE = 1 << 2,
        ZCK_MOUSE_X1     = 1 << 3,
        ZCK_MOUSE_X2     = 1 << 4
    };

    bool s_bInitialized = false;
    bool s_bWin32Initialized = false;
    bool s_bDX9Initialized = false;
    bool s_bVisible = false;

    bool s_bKeyboardCaptureActive = false;
    bool s_bMouseCaptureActive = false;

    BYTE s_bConsumeKeyUp[256] = { 0 };
    unsigned int s_uFlyffMouseButtonsDown = ZCK_MOUSE_NONE;
    unsigned int s_uImGuiMouseButtonsDown = ZCK_MOUSE_NONE;

    bool IsKeyboardDownMessage(UINT msg)
    {
        return msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN;
    }

    bool IsKeyboardUpMessage(UINT msg)
    {
        return msg == WM_KEYUP || msg == WM_SYSKEYUP;
    }

    bool IsCharacterMessage(UINT msg)
    {
        return msg == WM_CHAR || msg == WM_SYSCHAR;
    }

    bool IsImeMessage(UINT msg)
    {
        return msg >= WM_IME_SETCONTEXT && msg <= WM_IME_KEYUP;
    }

    unsigned int GetMouseButtonMask(UINT msg, WPARAM wParam)
    {
        switch (msg)
        {
        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_LBUTTONDBLCLK:
            return ZCK_MOUSE_LEFT;

        case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:
        case WM_RBUTTONDBLCLK:
            return ZCK_MOUSE_RIGHT;

        case WM_MBUTTONDOWN:
        case WM_MBUTTONUP:
        case WM_MBUTTONDBLCLK:
            return ZCK_MOUSE_MIDDLE;

        case WM_XBUTTONDOWN:
        case WM_XBUTTONUP:
        case WM_XBUTTONDBLCLK:
            return HIWORD(wParam) == XBUTTON1 ? ZCK_MOUSE_X1 : ZCK_MOUSE_X2;
        }

        return ZCK_MOUSE_NONE;
    }

    bool IsMouseButtonDownMessage(UINT msg)
    {
        switch (msg)
        {
        case WM_LBUTTONDOWN:
        case WM_LBUTTONDBLCLK:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONDBLCLK:
        case WM_MBUTTONDOWN:
        case WM_MBUTTONDBLCLK:
        case WM_XBUTTONDOWN:
        case WM_XBUTTONDBLCLK:
            return true;
        }

        return false;
    }

    bool IsMouseButtonUpMessage(UINT msg)
    {
        switch (msg)
        {
        case WM_LBUTTONUP:
        case WM_RBUTTONUP:
        case WM_MBUTTONUP:
        case WM_XBUTTONUP:
            return true;
        }

        return false;
    }

    bool WantsKeyboardCapture(UINT msg)
    {
        if (!s_bVisible)
            return false;

        const ImGuiIO& io = ImGui::GetIO();

        if (IsCharacterMessage(msg))
            return io.WantCaptureKeyboard || io.WantTextInput;

        return io.WantCaptureKeyboard;
    }

    bool WantsMouseCapture()
    {
        return s_bVisible && ImGui::GetIO().WantCaptureMouse;
    }

    void ClearOwnershipTracking()
    {
        ZeroMemory(s_bConsumeKeyUp, sizeof(s_bConsumeKeyUp));
        s_uFlyffMouseButtonsDown = ZCK_MOUSE_NONE;
        s_uImGuiMouseButtonsDown = ZCK_MOUSE_NONE;
        s_bKeyboardCaptureActive = false;
        s_bMouseCaptureActive = false;
    }

    void CancelFlyffKeyboardStateForCapture()
    {
        for (int i = 0; i < 256; ++i)
        {
            if (g_bKeyTable[i])
                s_bConsumeKeyUp[i] = TRUE;
        }

        if (g_nOldVirtKey >= 0 && g_nOldVirtKey < 256 && g_nOldVirtKey != 0)
            s_bConsumeKeyUp[g_nOldVirtKey] = TRUE;

        if (g_WndMng.m_pWndWorld)
        {
            if (g_WndMng.m_pWndWorld->m_bCtrlPushed)
                s_bConsumeKeyUp[VK_CONTROL] = TRUE;
            if (g_WndMng.m_pWndWorld->m_bShiftPushed)
                s_bConsumeKeyUp[VK_SHIFT] = TRUE;
        }

        ZeroMemory(g_bKeyTable, sizeof(g_bKeyTable));
        ZeroMemory(g_bSlotSwitchAboutEquipItem, sizeof(g_bSlotSwitchAboutEquipItem));
        g_nOldVirtKey = 0;

        if (g_WndMng.m_pWndWorld)
        {
            g_WndMng.m_pWndWorld->m_bCtrlPushed = FALSE;
            g_WndMng.m_pWndWorld->m_bShiftPushed = FALSE;
        }
    }

    void UpdateCaptureTransitions()
    {
        ImGuiIO& io = ImGui::GetIO();

        const bool bKeyboardCapture = s_bVisible && (io.WantCaptureKeyboard || io.WantTextInput);
        if (bKeyboardCapture && !s_bKeyboardCaptureActive)
            CancelFlyffKeyboardStateForCapture();
        s_bKeyboardCaptureActive = bKeyboardCapture;

        // Ne considere pas ImGui proprietaire tant qu'un geste FlyFF commence auparavant
        // est encore actif. Le controle FlyFF doit pouvoir finir son drag jusqu'au BUTTONUP.
        const bool bMouseCapture = s_bVisible && io.WantCaptureMouse &&
            (s_uFlyffMouseButtonsDown == ZCK_MOUSE_NONE);
        if (bMouseCapture && !s_bMouseCaptureActive)
        {
            // Annule uniquement le drag d'icone global qui pourrait sinon etre depose
            // dans l'interface FlyFF derriere ImGui. Ne libere PAS m_pWndCapture ici :
            // le controle FlyFF ayant commence un drag doit recevoir son vrai BUTTONUP.
            CWndBase::m_GlobalShortcut.Empty();

            // CWndWorld peut masquer le curseur Direct3D lors d'un drag camera.
            // En entrant dans ImGui, on garantit un curseur visible et neutre.
            if (g_Neuz.m_pd3dDevice)
                g_Neuz.m_pd3dDevice->ShowCursor(TRUE);
            SetMouseCursor(CUR_BASE);
        }
        s_bMouseCaptureActive = bMouseCapture;
    }

    //==================================================================
    //  Developer Tools : helpers de lecture
    //  Lecture seule. Aucune ecriture gameplay, aucun paquet, aucun
    //  scan global, aucune allocation par frame.
    //==================================================================

    // Le projet est MultiByte : les chaines FlyFF sont en CP_ACP alors que
    // Dear ImGui attend de l'UTF-8. Quatre emplacements statiques permettent
    // d'utiliser jusqu'a quatre conversions dans un meme appel Text().
    const char* ZckToUtf8(const char* szAnsi, int nSlot)
    {
        static char  s_szUtf8[4][512];
        static WCHAR s_szWide[512];

        if (nSlot < 0 || nSlot >= 4)
            nSlot = 0;

        char* pOut = s_szUtf8[nSlot];
        pOut[0] = '\0';

        if (szAnsi == NULL || szAnsi[0] == '\0')
            return pOut;

        const int nWide = MultiByteToWideChar(CP_ACP, 0, szAnsi, -1, s_szWide, 512);
        if (nWide <= 0)
            return pOut;

        // CP_UTF8 exige lpDefaultChar et lpUsedDefaultChar a NULL.
        if (WideCharToMultiByte(CP_UTF8, 0, s_szWide, -1, pOut, 512, NULL, NULL) <= 0)
            pOut[0] = '\0';

        return pOut;
    }

    // g_pPlayer peut etre NULL (login, Character Select) ou marque delete
    // pendant un changement de monde.
    CMover* ZckGetPlayer()
    {
        CMover* pPlayer = g_pPlayer;

        if (pPlayer == NULL)
            return NULL;

        if (IsInvalidObj(pPlayer))
            return NULL;

        if (!pPlayer->IsPlayer())
            return NULL;

        return pPlayer;
    }

    // m_nJob vaut -1 tant que le personnage n'est pas charge. Six getters
    // deferencent prj.GetJobProp(GetJob()) avec un simple ASSERT(), neutralise
    // en Release : sans ce bornage, DEF, HP/MP/FP max et ATK plantent.
    bool ZckIsJobValid(CMover* pMover)
    {
        if (pMover == NULL)
            return false;

        const int nJob = pMover->GetJob();
        if (nJob < 0 || nJob >= MAX_JOB)
            return false;

        return prj.GetJobProp(nJob) != NULL;
    }

    // Vrai quand les getters "max" sont surs sur ce mover : branche joueur
    // -> job valide, branche monstre -> MoverProp present.
    bool ZckCanReadMaxPoints(CMover* pMover)
    {
        if (pMover == NULL)
            return false;

        if (pMover->IsPlayer())
            return ZckIsJobValid(pMover);

        return pMover->GetProp() != NULL;
    }

    // La cible du client est l'objet focus du monde courant. Ce n'est ni
    // g_pTarget ni GetTarget() : voir CWndWorld et CWndWorldControlPlayer,
    // qui lisent tous deux GetObjFocus(). Peut etre un OT_ITEM au sol :
    // le type est verifie avant tout cast.
    CMover* ZckGetTargetMover()
    {
        CWorld* pWorld = g_WorldMng.Get();
        if (pWorld == NULL)
            return NULL;

        CObj* pObj = pWorld->GetObjFocus();
        if (pObj == NULL || IsInvalidObj(pObj))
            return NULL;

        if (pObj->GetType() != OT_MOVER)
            return NULL;

        return (CMover*)pObj;
    }

    const char* ZckBuffTypeName(WORD wType)
    {
        switch (wType)
        {
        case BUFF_ITEM:  return "ITEM";
        case BUFF_SKILL: return "SKILL";
        case BUFF_PET:   return "PET";
        case BUFF_ITEM2: return "ITEM2";
        case BUFF_EQUIP: return "EQUIP";
        }

        return "INCONNU";
    }

    // Compteurs de performance. Mis a jour a chaque frame par
    // ZckUpdatePerfCounters(), lus seulement quand l'onglet est ouvert.
    DWORD s_tmDevToolsStart = 0;
    float s_fFrameMsLast    = 0.0f;
    float s_fFrameMsMin     = 0.0f;
    float s_fFrameMsMax     = 0.0f;
    double s_dFrameMsSum    = 0.0;
    unsigned int s_uFrameCount = 0;

    void ZckUpdatePerfCounters()
    {
        const ImGuiIO& io = ImGui::GetIO();

        if (s_tmDevToolsStart == 0)
            s_tmDevToolsStart = timeGetTime();

        const float fMs = io.DeltaTime * 1000.0f;
        if (fMs <= 0.0f)
            return;

        s_fFrameMsLast = fMs;

        if (s_uFrameCount == 0 || fMs < s_fFrameMsMin)
            s_fFrameMsMin = fMs;
        if (s_uFrameCount == 0 || fMs > s_fFrameMsMax)
            s_fFrameMsMax = fMs;

        s_dFrameMsSum += (double)fMs;
        ++s_uFrameCount;
    }

    // Affiche HP courant / HP max en respectant la signature reelle.
    void ZckTextHitPoints(CMover* pMover)
    {
        const bool bMaxOk = ZckCanReadMaxPoints(pMover);

#ifdef __ZCK_HP_AUCUNE_LIMITE
        const __int64 nHp = pMover->GetHitPoint();
        if (bMaxOk)
            ImGui::Text("HP  : %I64d / %I64d", nHp, pMover->GetMaxHitPoint());
        else
            ImGui::Text("HP  : %I64d / (max indisponible, job %d)", nHp, pMover->GetJob());
#else
        const int nHp = pMover->GetHitPoint();
        if (bMaxOk)
            ImGui::Text("HP  : %d / %d", nHp, pMover->GetMaxHitPoint());
        else
            ImGui::Text("HP  : %d / (max indisponible, job %d)", nHp, pMover->GetJob());
#endif
    }

    void ZckTextPosition(const char* szPrefix, const D3DXVECTOR3& vPos)
    {
        ImGui::Text("%s X %.2f   Y %.2f   Z %.2f", szPrefix, vPos.x, vPos.y, vPos.z);
    }

    // Un slot de bonus inutilise vaut NULL_ID, pas 0. References :
    // Mover.cpp 829 / 882 / 9520 / 9796, et le "case NULL_ID: break;" de
    // CMover::ApplyParam dans MoverActEvent.cpp. defineAttribute.h ne
    // definit aucun DST de valeur 0 : le filtre ne porte donc que sur
    // NULL_ID, exactement comme le moteur.
    // Aucune indexation de tableau ici : une valeur de la zone virtuelle
    // (DST_RESIST_ALL 10002 et suivants) s'affiche sans risque.
    void ZckTextDestParam(DWORD dwDestParam, int nValue)
    {
        if (dwDestParam == NULL_ID)
            return;

        ImGui::Text("    DST %u = %d", (unsigned)dwDestParam, nValue);
    }

    //==================================================================
    //  Onglets
    //==================================================================

    void DrawGeneralTab()
    {
        const ImGuiIO& io = ImGui::GetIO();
        const float fFrameTimeMs = (io.Framerate > 0.0f) ? (1000.0f / io.Framerate) : 0.0f;

        ImGui::TextUnformatted("Dear ImGui OK");
        ImGui::Separator();
        ImGui::Text("FPS        : %.1f", io.Framerate);
        ImGui::Text("Frame time : %.3f ms", fFrameTimeMs);
        ImGui::Separator();

        CMover* pPlayer = ZckGetPlayer();
        CWorld* pWorld  = g_WorldMng.Get();

        ImGui::Text("Joueur : %s", pPlayer != NULL ? "pret" : "indisponible");
        ImGui::Text("Monde  : %s", pWorld  != NULL ? "charge" : "non charge");
        ImGui::Text("Cible  : %s", ZckGetTargetMover() != NULL ? "selectionnee" : "aucune");
    }

    void DrawPlayerTab()
    {
        CMover* pPlayer = ZckGetPlayer();
        if (pPlayer == NULL)
        {
            ImGui::TextUnformatted("Joueur indisponible (login, selection de personnage ou chargement).");
            return;
        }

        const bool bJobOk = ZckIsJobValid(pPlayer);

        ImGui::Text("Nom    : %s", ZckToUtf8(pPlayer->GetName(), 0));
        ImGui::Text("Niveau : %d", pPlayer->GetLevel());

        if (bJobOk)
            ImGui::Text("Classe : %s (job %d)", ZckToUtf8(pPlayer->GetJobString(), 0), pPlayer->GetJob());
        else
            ImGui::Text("Classe : (job %d non valide)", pPlayer->GetJob());

        ImGui::Separator();

        ZckTextHitPoints(pPlayer);

        if (bJobOk)
        {
            ImGui::Text("MP  : %d / %d", pPlayer->GetManaPoint(), pPlayer->GetMaxManaPoint());
            ImGui::Text("FP  : %d / %d", pPlayer->GetFatiguePoint(), pPlayer->GetMaxFatiguePoint());
        }
        else
        {
            ImGui::Text("MP  : %d / (max indisponible)", pPlayer->GetManaPoint());
            ImGui::Text("FP  : %d / (max indisponible)", pPlayer->GetFatiguePoint());
        }

        ImGui::Separator();

        ZckTextPosition("Position :", pPlayer->GetPos());

        CWorld* pWorld = pPlayer->GetWorld();
        if (pWorld != NULL)
            ImGui::Text("World ID : %u", (unsigned)pWorld->GetID());
        else
            ImGui::TextUnformatted("World ID : non disponible (changement de monde)");
    }

    void DrawTargetTab()
    {
        CMover* pTarget = ZckGetTargetMover();
        if (pTarget == NULL)
        {
            ImGui::TextUnformatted("Aucune cible de type mover selectionnee.");
            return;
        }

        ImGui::Text("Nom       : %s", ZckToUtf8(pTarget->GetName(), 0));
        ImGui::Text("Object ID : %u", (unsigned)pTarget->GetId());
        ImGui::Text("Type      : %s", pTarget->IsPlayer() ? "joueur" : "monstre / PNJ");
        ImGui::Text("Index     : %u", (unsigned)pTarget->GetIndex());
        ImGui::Text("Niveau    : %d", pTarget->GetLevel());

        if (pTarget->IsPlayer())
        {
            if (ZckIsJobValid(pTarget))
                ImGui::Text("Classe    : %s (job %d)", ZckToUtf8(pTarget->GetJobString(), 0), pTarget->GetJob());
            else
                ImGui::Text("Classe    : (job %d non valide)", pTarget->GetJob());
        }
        else
        {
            MoverProp* pProp = pTarget->GetProp();
            if (pProp != NULL)
                ImGui::Text("Prop      : %s (ID %u, classe %u)",
                    ZckToUtf8(pProp->szName, 0), (unsigned)pProp->dwID, (unsigned)pProp->dwClass);
            else
                ImGui::TextUnformatted("Prop      : non disponible");
        }

        ImGui::Separator();

        ZckTextHitPoints(pTarget);

        if (pTarget->m_pActMover != NULL)
            ImGui::Text("Etat      : %s", pTarget->IsLive() ? "vivant" : "mort");
        else
            ImGui::TextUnformatted("Etat      : non disponible (ActionMover absent)");

        ImGui::Separator();

        const D3DXVECTOR3 vTarget = pTarget->GetPos();
        ZckTextPosition("Position :", vTarget);

        CWorld* pTargetWorld = pTarget->GetWorld();
        if (pTargetWorld != NULL)
            ImGui::Text("World ID : %u", (unsigned)pTargetWorld->GetID());

        CMover* pPlayer = ZckGetPlayer();
        if (pPlayer != NULL)
        {
            D3DXVECTOR3 vDelta = vTarget - pPlayer->GetPos();
            ImGui::Text("Distance : %.2f m", D3DXVec3Length(&vDelta));
        }
    }

    void DrawStatsTab()
    {
        CMover* pPlayer = ZckGetPlayer();
        if (pPlayer == NULL)
        {
            ImGui::TextUnformatted("Joueur indisponible.");
            return;
        }

        const bool bJobOk = ZckIsJobValid(pPlayer);

        ImGui::TextUnformatted("Statistiques de base (finale / de base)");
        ImGui::Separator();
        ImGui::Text("STR : %d / %d", pPlayer->GetStr(), (int)pPlayer->m_nStr);
        ImGui::Text("STA : %d / %d", pPlayer->GetSta(), (int)pPlayer->m_nSta);
        ImGui::Text("DEX : %d / %d", pPlayer->GetDex(), (int)pPlayer->m_nDex);
        ImGui::Text("INT : %d / %d", pPlayer->GetInt(), (int)pPlayer->m_nInt);

        ImGui::Separator();
        ImGui::TextUnformatted("Combat");
        ImGui::Separator();

        // GetHitMinMax -> GetWeaponATK -> GetJobPropFactor -> prj.GetJobProp(),
        // deference apres un simple ASSERT() : interdit si le job est invalide.
        if (bJobOk)
        {
            int nAtkMin = 0;
            int nAtkMax = 0;
            pPlayer->GetHitMinMax(&nAtkMin, &nAtkMax);
            ImGui::Text("ATK arme         : %d - %d", nAtkMin, nAtkMax);
        }
        else
        {
            ImGui::TextUnformatted("ATK arme         : indisponible (job non valide)");
        }

        ImGui::Text("DST_ATKPOWER     : %d", pPlayer->GetParam(DST_ATKPOWER, 0));
        ImGui::Text("DST_ATKPOWER_RATE: %d %%", pPlayer->GetParam(DST_ATKPOWER_RATE, 0));

        // GetShowDefense -> CalcDefenseCore -> prj.GetJobProp(), meme piege.
        if (bJobOk)
            ImGui::Text("DEF              : %d", pPlayer->GetShowDefense(FALSE));
        else
            ImGui::TextUnformatted("DEF              : indisponible (job non valide)");

        // GetAttackSpeed teste lui-meme pProperty == NULL : sans garde ici.
        const float fAtkSpeed = pPlayer->GetAttackSpeed();
        ImGui::Text("Vitesse d'attaque: %.3f  (affichage fenetre : %d %%)",
            fAtkSpeed, (int)(fAtkSpeed * 100.0f) / 2);

        ImGui::Separator();
        ImGui::TextUnformatted("Valeurs finales du moteur");
        ImGui::Separator();
        ImGui::Text("Critique (bonus) : %d %%", pPlayer->GetCriticalRate());
        ImGui::Text("Hit rate         : %d %%", pPlayer->GetHitRate());
        ImGui::Text("Esquive / parade : %d %%", pPlayer->GetDodgeRate());
        ImGui::Text("Blocage melee    : %d %%", pPlayer->GetBlockMelee());
        ImGui::Text("Blocage distance : %d %%", pPlayer->GetBlockRange());
        ImGui::Text("Vitesse course   : %d", pPlayer->GetSpeedRun());
        ImGui::Text("Vitesse de sort  : %d %%", pPlayer->GetSpellCastSpeed());
        ImGui::Text("Degats JcJ       : %d %%", pPlayer->GetPvpDamage());

        ImGui::Separator();
        ImGui::TextUnformatted("Resistances");
        ImGui::Separator();

        // GetResistMagic est un GetParam(DST_RESIST_MAGIC, 0) nu : sans garde.
        ImGui::Text("Resist magie     : %d", pPlayer->GetResistMagic());
        ImGui::Text("Resist magie taux: %d %%", pPlayer->GetParam(DST_RESIST_MAGIC_RATE, 0));

        // PIEGE : CMover::GetResistSpell journalise un Error() quand MoverProp
        // est NULL, mais NE SORT PAS, puis deference pProp. Le test est donc
        // fait ici, avant l'appel.
        if (pPlayer->GetProp() != NULL)
        {
            ImGui::Text("Resist feu       : %d", pPlayer->GetResistSpell(DST_RESIST_FIRE));
            ImGui::Text("Resist eau       : %d", pPlayer->GetResistSpell(DST_RESIST_WATER));
            ImGui::Text("Resist terre     : %d", pPlayer->GetResistSpell(DST_RESIST_EARTH));
            ImGui::Text("Resist vent      : %d", pPlayer->GetResistSpell(DST_RESIST_WIND));
            ImGui::Text("Resist electric. : %d", pPlayer->GetResistSpell(DST_RESIST_ELECTRICITY));
        }
        else
        {
            ImGui::TextUnformatted("Resistances elementaires : MoverProp absent");
        }

        // DST_RESIST_ALL vaut 10002, soit au-dessus de MAX_ADJPARAMARY (95) :
        // GetParam renverrait toujours la valeur de repli. Non affiche.

        ImGui::Separator();
        ImGui::TextUnformatted("Bonus bruts (GetAdjParam)");
        ImGui::Separator();
        ImGui::Text("Bonus HP max : %d", pPlayer->GetAdjParam(DST_HP_MAX));
        ImGui::Text("Bonus MP max : %d", pPlayer->GetAdjParam(DST_MP_MAX));
        ImGui::Text("Bonus FP max : %d", pPlayer->GetAdjParam(DST_FP_MAX));

        ImGui::Separator();
        ImGui::TextUnformatted("Note : GetCriticalProb() n'est volontairement pas appele ici.");
        ImGui::TextUnformatted("Ce getter efface MVRF_CRITICAL dans m_dwFlag : le lire chaque");
        ImGui::TextUnformatted("frame consommerait le bonus critique de groupe.");
    }

    void DrawBuffsTab()
    {
        CMover* pPlayer = ZckGetPlayer();
        if (pPlayer == NULL)
        {
            ImGui::TextUnformatted("Joueur indisponible.");
            return;
        }

        MAPBUFF& mapBuffs = pPlayer->m_buffs.m_mapBuffs;

        ImGui::Text("Buffs actifs : %d", (int)mapBuffs.size());
        ImGui::Separator();

        for (MAPBUFF::iterator it = mapBuffs.begin(); it != mapBuffs.end(); ++it)
        {
            IBuff* pBuff = it->second;
            if (pBuff == NULL)
                continue;

            const WORD  wType   = pBuff->GetType();
            const WORD  wId     = pBuff->GetId();
            const DWORD dwLevel = pBuff->GetLevel();

            // GetProp() est virtuel : ItemProp pour ITEM / ITEM2, SkillProp
            // pour SKILL, NULL pour PET et EQUIP.
            ItemProp* pProp = pBuff->GetProp();

            if (pProp != NULL)
                ImGui::Text("[%s] %s", ZckBuffTypeName(wType), ZckToUtf8(pProp->szName, 0));
            else
                ImGui::Text("[%s] (propriete absente)", ZckBuffTypeName(wType));

            ImGui::Text("    ID %u   niveau %u", (unsigned)wId, (unsigned)dwLevel);
            ImGui::Text("    restant %u ms / total %u ms",
                (unsigned)pBuff->GetRemain(), (unsigned)pBuff->GetTotal());

            const OBJID idAttacker = pBuff->GetAttacker();
            if (idAttacker != NULL_ID && idAttacker != 0)
                ImGui::Text("    lanceur (OBJID) : %u", (unsigned)idAttacker);

            if (wType == BUFF_SKILL && pProp != NULL)
            {
                // prj.GetAddSkillProp est appele directement plutot que
                // CMover::GetSkillProp : ce dernier journalise un Error()
                // a chaque echec, ce qui inonderait le log par frame.
                AddSkillProp* pAdd = prj.GetAddSkillProp(pProp->dwSubDefine, dwLevel);
                if (pAdd != NULL)
                {
                    // AddSkillProp ne porte que deux emplacements de bonus.
                    for (int i = 0; i < 2; ++i)
                        ZckTextDestParam(pAdd->dwDestParam[i], (int)pAdd->nAdjParamVal[i]);
                }
            }
            else if (pProp != NULL)
            {
                for (int i = 0; i < PROP_BONUSES; ++i)
                    ZckTextDestParam(pProp->dwDestParam[i], (int)pProp->nAdjParamVal[i]);
            }

            ImGui::Separator();
        }
    }

    void DrawWorldTab()
    {
        CWorld* pWorld = g_WorldMng.Get();
        if (pWorld == NULL)
        {
            ImGui::TextUnformatted("Monde non charge (login, selection ou changement de monde).");
            return;
        }

        const DWORD dwWorldId = pWorld->GetID();

        ImGui::Text("World ID  : %u", (unsigned)dwWorldId);
        ImGui::Text("Nom       : %s", ZckToUtf8(pWorld->m_szWorldName, 0));
        ImGui::Text("Fichier   : %s", ZckToUtf8(pWorld->m_szFileName, 0));

        // CFixedArray::GetAt est borne et renvoie NULL hors plage.
        LPWORLD pWorldStruct = g_WorldMng.GetWorldStruct(dwWorldId);
        if (pWorldStruct != NULL && pWorldStruct->IsValid())
            ImGui::Text("Script    : %s", ZckToUtf8(pWorldStruct->m_szWorldName, 0));

        ImGui::Separator();
        ImGui::Text("Interieur : %s", pWorld->m_bIsIndoor ? "oui" : "non");
        ImGui::Text("Vol       : %s", pWorld->m_bFly ? "autorise" : "non");
        ImGui::Text("Mode PK   : %d", pWorld->m_nPKMode);
        ImGui::Text("Donjon instancie : %s", pWorld->IsWorldInstanceDungeon() ? "oui" : "non");

        ImGui::Separator();
        ImGui::Text("Meteo     : %d", CSkyBox::GetInstance()->GetWeather());
        ImGui::Text("Heure monde : jour %d, %02d:%02d",
            g_GameTimer.m_nDay, g_GameTimer.m_nHour, g_GameTimer.m_nMin);

        CMover* pPlayer = ZckGetPlayer();
        if (pPlayer != NULL)
        {
            ImGui::Separator();
            ZckTextPosition("Joueur :", pPlayer->GetPos());
        }

        ImGui::Separator();
        ImGui::TextUnformatted("Aucun compteur direct d'objets ou de movers n'existe");
        ImGui::TextUnformatted("cote client : il n'est donc pas affiche.");
    }

    void DrawEquipmentTab()
    {
        CMover* pPlayer = ZckGetPlayer();
        if (pPlayer == NULL)
        {
            ImGui::TextUnformatted("Joueur indisponible.");
            return;
        }

        int nEquipped = 0;

        // Meme bornage que CMover::SetDestParamSetItem. CItemContainer::GetEquip
        // est lui-meme borne et renvoie NULL hors plage.
        for (int nParts = 0; nParts < MAX_HUMAN_PARTS; ++nParts)
        {
            CItemElem* pItem = pPlayer->GetEquipItem(nParts);
            if (pItem == NULL || pItem->IsEmpty())
                continue;

            ++nEquipped;

            ItemProp* pProp = pItem->GetProp();

            if (pProp != NULL)
                ImGui::Text("Slot %2d : %s", nParts, ZckToUtf8(pProp->szName, 0));
            else
                ImGui::Text("Slot %2d : (propriete absente)", nParts);

            ImGui::Text("    Item ID %u", (unsigned)pItem->m_dwItemId);

            if (pProp != NULL)
                ImGui::Text("    Niveau item %u", (unsigned)pProp->dwItemLV);

            ImGui::Text("    Upgrade +%d", pItem->GetAbilityOption());
            ImGui::Text("    Element %d, niveau %d",
                pItem->GetItemResist(), pItem->GetResistAbilityOption());

            const int nPiercing = pItem->GetPiercingSize();
            if (nPiercing > 0)
            {
                ImGui::Text("    Piercing : %d emplacement(s)", nPiercing);
                for (int p = 0; p < nPiercing; ++p)
                {
                    const DWORD dwPierce = pItem->GetPiercingItem(p);
                    if (dwPierce != 0 && dwPierce != NULL_ID)
                        ImGui::Text("        [%d] item %u", p, (unsigned)dwPierce);
                }
            }

            ImGui::Text("    Eveil (RandomOptItemId) : %I64d", pItem->GetRandomOptItemId());

#ifdef __ZCK_RARE
            ImGui::Text("    Rarete : %d", pItem->GetZckRareLevel());
#endif // __ZCK_RARE

#ifdef __ZCK_NIVEAU_ARME
            ImGui::Text("    Niveau d'arme : %d (exp %u)",
                pItem->m_nZckArmeNiveau, (unsigned)pItem->m_dwZckArmeNiveauExp);
#endif // __ZCK_NIVEAU_ARME

            ImGui::Text("    Durabilite : %d", pItem->m_nHitPoint);

            if (pItem->m_dwKeepTime != 0)
                ImGui::Text("    KeepTime : %u", (unsigned)pItem->m_dwKeepTime);

            if (pItem->IsFlag(CItemElem::expired))
                ImGui::TextUnformatted("    EXPIRE");

            if (pProp != NULL)
            {
                for (int i = 0; i < PROP_BONUSES; ++i)
                    ZckTextDestParam(pProp->dwDestParam[i], (int)pProp->nAdjParamVal[i]);
            }

            ImGui::Separator();
        }

        if (nEquipped == 0)
            ImGui::TextUnformatted("Aucun equipement porte.");
    }

    void DrawPerformanceTab()
    {
        const ImGuiIO& io = ImGui::GetIO();

        ImGui::Text("FPS               : %.1f", io.Framerate);
        ImGui::Text("Frame time        : %.3f ms", s_fFrameMsLast);

        if (s_uFrameCount > 0)
        {
            ImGui::Text("Frame time moyen  : %.3f ms",
                (float)(s_dFrameMsSum / (double)s_uFrameCount));
            ImGui::Text("Frame time min    : %.3f ms", s_fFrameMsMin);
            ImGui::Text("Frame time max    : %.3f ms", s_fFrameMsMax);
        }

        ImGui::Separator();

        // Soustraction DWORD : correcte meme au rebouclage de timeGetTime().
        const DWORD tmElapsed = (s_tmDevToolsStart != 0)
            ? (timeGetTime() - s_tmDevToolsStart)
            : 0;

        ImGui::Text("Temps depuis lancement : %u s (%u frames)",
            (unsigned)(tmElapsed / 1000), s_uFrameCount);
    }

    void DrawDefinesTab()
    {
        ImGui::TextUnformatted("Systemes compiles dans ce Neuz :");
        ImGui::Separator();

        // Seuls les defines reellement presents dans CustomCommon.h sont
        // listes. __ZCK_DST et __ZCK_4_CLASSE n'existent nulle part dans ces
        // sources, defineAttribute.h compris : ils ne sont pas affiches.
#ifdef __ZCK_INTERFACE_V19
        ImGui::TextUnformatted("__ZCK_INTERFACE_V19      : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_INTERFACE_V19      : INACTIF");
#endif
#ifdef __ZCK_LANG_FR
        ImGui::TextUnformatted("__ZCK_LANG_FR            : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_LANG_FR            : INACTIF");
#endif
#ifdef __ZCK_PRESTIGE
        ImGui::TextUnformatted("__ZCK_PRESTIGE           : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_PRESTIGE           : INACTIF");
#endif
#ifdef __ZCK_SYSTEME_EVEIL
        ImGui::TextUnformatted("__ZCK_SYSTEME_EVEIL      : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_SYSTEME_EVEIL      : INACTIF");
#endif
#ifdef __ZCK_ACHIEVEMENT
        ImGui::TextUnformatted("__ZCK_ACHIEVEMENT        : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_ACHIEVEMENT        : INACTIF");
#endif
#ifdef __ZCK_QUEST
        ImGui::TextUnformatted("__ZCK_QUEST              : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_QUEST              : INACTIF");
#endif
#ifdef __ZCK_HP_AUCUNE_LIMITE
        ImGui::TextUnformatted("__ZCK_HP_AUCUNE_LIMITE   : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_HP_AUCUNE_LIMITE   : INACTIF");
#endif
#ifdef __ZCK_BUFF_CLASSE
        ImGui::TextUnformatted("__ZCK_BUFF_CLASSE        : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_BUFF_CLASSE        : INACTIF");
#endif
#ifdef __ZCK_BUFF_GROUPE
        ImGui::TextUnformatted("__ZCK_BUFF_GROUPE        : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_BUFF_GROUPE        : INACTIF");
#endif
#ifdef __ZCK_RARE
        ImGui::TextUnformatted("__ZCK_RARE               : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_RARE               : INACTIF");
#endif
#ifdef __ZCK_NIVEAU_ARME
        ImGui::TextUnformatted("__ZCK_NIVEAU_ARME        : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_NIVEAU_ARME        : INACTIF");
#endif
#ifdef __ZCK_ANTICHEAT
        ImGui::TextUnformatted("__ZCK_ANTICHEAT          : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_ANTICHEAT          : INACTIF");
#endif
#ifdef __ZCK_ANARCHY
        ImGui::TextUnformatted("__ZCK_ANARCHY            : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_ANARCHY            : INACTIF");
#endif
#ifdef __ZCK_AUTH
        ImGui::TextUnformatted("__ZCK_AUTH               : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_AUTH               : INACTIF");
#endif
#ifdef __ZCK_BADGE
        ImGui::TextUnformatted("__ZCK_BADGE              : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_BADGE              : INACTIF");
#endif
#ifdef __ZCK_APNG
        ImGui::TextUnformatted("__ZCK_APNG               : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_APNG               : INACTIF");
#endif
#ifdef __ZCK_PROGRESSION
        ImGui::TextUnformatted("__ZCK_PROGRESSION        : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_PROGRESSION        : INACTIF");
#endif
#ifdef __ZCK_CLASSEMENT
        ImGui::TextUnformatted("__ZCK_CLASSEMENT         : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_CLASSEMENT         : INACTIF");
#endif
#ifdef __ZCK_CUBE
        ImGui::TextUnformatted("__ZCK_CUBE               : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_CUBE               : INACTIF");
#endif
#ifdef __ZCK_SHOP
        ImGui::TextUnformatted("__ZCK_SHOP               : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_SHOP               : INACTIF");
#endif
#ifdef __ZCK_DIFFICULTY
        ImGui::TextUnformatted("__ZCK_DIFFICULTY         : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_DIFFICULTY         : INACTIF");
#endif
#ifdef __ZCK_POSITION_H
        ImGui::TextUnformatted("__ZCK_POSITION_H         : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_POSITION_H         : INACTIF");
#endif
#ifdef __ZCK_SPD_LOG
        ImGui::TextUnformatted("__ZCK_SPD_LOG            : ACTIF");
#else
        ImGui::TextUnformatted("__ZCK_SPD_LOG            : INACTIF");
#endif
#ifdef __ZCK_RENDU
        ImGui::TextUnformatted("__ZCK_RENDU              : ACTIF");
#endif // __ZCK_RENDU
#ifdef __ZCK_CRYPT_CLIENT
        ImGui::TextUnformatted("__ZCK_CRYPT_CLIENT       : ACTIF");
#endif // __ZCK_CRYPT_CLIENT
#ifdef __ZCK_IA_FARM
        ImGui::TextUnformatted("__ZCK_IA_FARM            : ACTIF");
#endif // __ZCK_IA_FARM

        ImGui::Separator();
        ImGui::TextUnformatted("__ZCK_IMGUI est forcement ACTIF : ce panneau est");
        ImGui::TextUnformatted("entierement compile sous sa garde.");
    }

    void DrawSessionTab()
    {
        const DWORD tmElapsed = (s_tmDevToolsStart != 0)
            ? (timeGetTime() - s_tmDevToolsStart)
            : 0;

        const unsigned uSeconds = (unsigned)(tmElapsed / 1000);

        ImGui::Text("Session : %02u:%02u:%02u",
            uSeconds / 3600, (uSeconds / 60) % 60, uSeconds % 60);

        ImGui::Separator();

        CMover* pPlayer = ZckGetPlayer();
        if (pPlayer == NULL)
        {
            ImGui::TextUnformatted("Aucun personnage en jeu.");
            return;
        }

        ImGui::Text("Personnage : %s", ZckToUtf8(pPlayer->GetName(), 0));
        ImGui::Text("Niveau     : %d", pPlayer->GetLevel());

        if (ZckIsJobValid(pPlayer))
            ImGui::Text("Classe     : %s", ZckToUtf8(pPlayer->GetJobString(), 0));
        else
            ImGui::Text("Classe     : (job %d non valide)", pPlayer->GetJob());

        CWorld* pWorld = pPlayer->GetWorld();
        if (pWorld != NULL)
            ImGui::Text("World ID   : %u", (unsigned)pWorld->GetID());

        ZckTextPosition("Position :", pPlayer->GetPos());
    }

    void DrawCameraTab()
    {
        // La camera du jeu est g_Neuz.m_camera (CBackCamera), membre direct
        // de CNeuzApp, branchee sur le monde par CWorld::SetCamera dans
        // CWndWorld et CDPClient. Ce n'est pas un pointeur : jamais NULL.
        const CBackCamera& cam = g_Neuz.m_camera;

        ZckTextPosition("Position :", cam.m_vPos);
        ZckTextPosition("LookAt   :", cam.m_vLookAt);

        ImGui::Separator();
        ImGui::Text("Zoom        : %.3f", cam.m_fZoom);
        ImGui::Text("Longueur 1  : %.3f", cam.m_fLength1);
        ImGui::Text("Longueur 2  : %.3f", cam.m_fLength2);

        D3DXVECTOR3 vDelta = cam.m_vLookAt - cam.m_vPos;
        ImGui::Text("Distance    : %.3f", D3DXVec3Length(&vDelta));

        ImGui::Separator();
        ImGui::Text("Rot X / Y   : %.3f / %.3f", cam.m_fRotx, cam.m_fRoty);
        ImGui::Text("Rot courante: %.3f / %.3f", cam.m_fCurRotx, cam.m_fCurRoty);
        ImGui::Text("Style       : %u", (unsigned)cam.m_dwCamStyle);

#if __VER >= 13 // __HOUSING
        ImGui::Text("Mode        : %d", cam.m_nCamMode);
#endif // __HOUSING

        ImGui::Separator();
        ImGui::TextUnformatted("Le FOV n'est stocke ni dans CCamera ni dans CBackCamera :");
        ImGui::TextUnformatted("il n'est donc pas affiche.");
    }

#ifdef __ZCK_SPD_LOG
    //==================================================================
    //  Onglet Logs : lecture du snapshot borne de CZckSpdLog.
    //  Aucune lecture disque, aucune allocation par frame : la copie ne se
    //  fait que si de nouveaux evenements existent, au plus 4 fois/seconde.
    //  Le logger ne connait pas ImGui ; c'est l'UI qui vient lire.
    //==================================================================

    CZckSpdLog::RecentEntry s_aLogCache[CZckSpdLog::RECENT_CAPACITY];
    unsigned int    s_nLogCacheCount    = 0;
    unsigned int    s_uLogCacheSequence = 0;
    DWORD           s_tmLogLastCopy     = 0;
    bool            s_bLogAutoScroll    = true;
    bool            s_abLogLevelShown[CZckSpdLog::LEVEL_COUNT] = { true, true, true, true, true };
    ImGuiTextFilter s_LogFilter;

    const char* ZckLogLevelLabel(int nLevel)
    {
        switch (nLevel)
        {
        case CZckSpdLog::LEVEL_DEBUG:    return "DEBUG";
        case CZckSpdLog::LEVEL_INFO:     return "INFO";
        case CZckSpdLog::LEVEL_WARNING:  return "WARN";
        case CZckSpdLog::LEVEL_ERROR:    return "ERROR";
        case CZckSpdLog::LEVEL_CRITICAL: return "CRIT";
        }
        return "?";
    }

    ImVec4 ZckLogLevelColor(int nLevel)
    {
        switch (nLevel)
        {
        case CZckSpdLog::LEVEL_DEBUG:    return ImVec4(0.60f, 0.60f, 0.60f, 1.0f);
        case CZckSpdLog::LEVEL_WARNING:  return ImVec4(1.00f, 0.80f, 0.20f, 1.0f);
        case CZckSpdLog::LEVEL_ERROR:    return ImVec4(1.00f, 0.40f, 0.40f, 1.0f);
        case CZckSpdLog::LEVEL_CRITICAL: return ImVec4(1.00f, 0.20f, 0.60f, 1.0f);
        }
        return ImVec4(0.85f, 0.85f, 0.85f, 1.0f);
    }

    void DrawLogsTab()
    {
        ImGui::Text("Logger : %s", CZckSpdLog::IsInitialized() ? "actif" : "inactif");

        char szPath[CZckSpdLog::PATH_UTF8_SIZE];
        if (CZckSpdLog::GetLogFilePathUtf8(szPath, (unsigned int)sizeof(szPath)))
            ImGui::TextWrapped("Fichier : %s", szPath);
        else
            ImGui::TextUnformatted("Fichier : (non disponible)");

        // Etat "en jeu" : g_pPlayer est remis a NULL par OpenTitle() et OnReplace(), il est fiable.
        // Les drapeaux m_fConn de CDPCertified / CDPLoginClient ne sont pas remis a FALSE par
        // DeleteDPObject() (retour volontaire a l'ecran de connexion) : ils ne sont pas affiches.
        ImGui::Text("Personnage en jeu : %s", ZckGetPlayer() != NULL ? "oui" : "non");

        unsigned int auCount[CZckSpdLog::LEVEL_COUNT] = { 0 };
        CZckSpdLog::GetLevelCounters(auCount, (unsigned int)CZckSpdLog::LEVEL_COUNT);
        ImGui::Text("Total : DEBUG %u  INFO %u  WARN %u  ERROR %u  CRIT %u",
            auCount[CZckSpdLog::LEVEL_DEBUG], auCount[CZckSpdLog::LEVEL_INFO],
            auCount[CZckSpdLog::LEVEL_WARNING], auCount[CZckSpdLog::LEVEL_ERROR],
            auCount[CZckSpdLog::LEVEL_CRITICAL]);

        ImGui::Separator();

        // Rafraichissement : seulement si le logger a produit du nouveau, au plus toutes les 250 ms.
        const unsigned int uSequence = CZckSpdLog::GetRecentSequence();
        const DWORD tmNow = timeGetTime();
        if (uSequence != s_uLogCacheSequence && (tmNow - s_tmLogLastCopy) >= 250)
        {
            s_nLogCacheCount    = CZckSpdLog::CopyRecent(s_aLogCache, (unsigned int)CZckSpdLog::RECENT_CAPACITY);
            s_uLogCacheSequence = uSequence;
            s_tmLogLastCopy     = tmNow;
        }

        s_LogFilter.Draw("Filtre", 180.0f);
        ImGui::SameLine();
        ImGui::Checkbox("INFO",  &s_abLogLevelShown[CZckSpdLog::LEVEL_INFO]);
        ImGui::SameLine();
        ImGui::Checkbox("WARN",  &s_abLogLevelShown[CZckSpdLog::LEVEL_WARNING]);
        ImGui::SameLine();
        ImGui::Checkbox("ERROR", &s_abLogLevelShown[CZckSpdLog::LEVEL_ERROR]);
        ImGui::SameLine();
        ImGui::Checkbox("CRIT",  &s_abLogLevelShown[CZckSpdLog::LEVEL_CRITICAL]);
#ifdef _DEBUG
        ImGui::SameLine();
        ImGui::Checkbox("DEBUG", &s_abLogLevelShown[CZckSpdLog::LEVEL_DEBUG]);
#endif
        ImGui::SameLine();
        ImGui::Checkbox("Auto-scroll", &s_bLogAutoScroll);

        ImGui::Text("%u evenement(s) conserve(s) sur %u", s_nLogCacheCount, (unsigned int)CZckSpdLog::RECENT_CAPACITY);

        // Zone defilante sur tout le reste de l'onglet : suit le redimensionnement de la fenetre.
        // EndChild() est appele inconditionnellement : c'est le contrat de l'API.
        if (ImGui::BeginChild("ZckLogsScroll", ImVec2(0.0f, 0.0f), ImGuiChildFlags_Borders, ImGuiWindowFlags_HorizontalScrollbar))
        {
            for (unsigned int i = 0; i < s_nLogCacheCount; ++i)
            {
                const CZckSpdLog::RecentEntry& e = s_aLogCache[i];

                if (e.nLevel >= 0 && e.nLevel < CZckSpdLog::LEVEL_COUNT && !s_abLogLevelShown[e.nLevel])
                    continue;
                if (!s_LogFilter.PassFilter(e.szText))
                    continue;

                ImGui::TextColored(ZckLogLevelColor(e.nLevel), "%02u:%02u:%02u.%03u [%-5s] %s",
                    (unsigned int)e.wHour, (unsigned int)e.wMinute, (unsigned int)e.wSecond, (unsigned int)e.wMilliseconds,
                    ZckLogLevelLabel(e.nLevel), e.szText);
            }

            if (s_bLogAutoScroll && ImGui::GetScrollY() >= ImGui::GetScrollMaxY())
                ImGui::SetScrollHereY(1.0f);
        }
        ImGui::EndChild();
    }
#endif // __ZCK_SPD_LOG

    //==================================================================
    //  Fenetre principale
    //==================================================================

    void DrawDeveloperTools()
    {
        ZckUpdatePerfCounters();

        if (!s_bVisible)
            return;

        ImGui::SetNextWindowSize(ImVec2(520.0f, 460.0f), ImGuiCond_FirstUseEver);

        bool bVisible = s_bVisible;

        // ImGui::End() est appele inconditionnellement, meme quand Begin()
        // renvoie false : c'est le contrat de l'API.
        if (ImGui::Begin("Reborn-MMO Developer Tools", &bVisible))
        {
            // Libelles en echappements UTF-8 explicites : le fichier est en
            // utf-8-sig, et sans /utf-8 MSVC convertirait un accent ecrit
            // tel quel vers la page ANSI, que Dear ImGui ne sait pas lire.
            if (ImGui::BeginTabBar("ZckDevToolsTabs", ImGuiTabBarFlags_None))
            {
                if (ImGui::BeginTabItem("G\xC3\xA9n\xC3\xA9ral"))
                {
                    DrawGeneralTab();
                    ImGui::EndTabItem();
                }

#ifdef __ZCK_SPD_LOG
                if (ImGui::BeginTabItem("Logs"))
                {
                    DrawLogsTab();
                    ImGui::EndTabItem();
                }
#endif // __ZCK_SPD_LOG

#ifdef __ZCK_RENDU
                if (ImGui::BeginTabItem("Rendu"))
                {
                    g_ZckRendu.DessinerOnglet();
                    ImGui::EndTabItem();
                }
#endif // __ZCK_RENDU

#ifdef __ZCK_CRYPT_CLIENT
                if (ImGui::BeginTabItem("Fichiers"))
                {
                    g_ZckCryptClient.DessinerOnglet();
                    ImGui::EndTabItem();
                }
#endif // __ZCK_CRYPT_CLIENT

#ifdef __ZCK_IA_FARM
                if (ImGui::BeginTabItem("IA Farm"))
                {
                    g_ZckIaFarm.DessinerOnglet();
                    ImGui::EndTabItem();
                }
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
                if (ImGui::BeginTabItem("Buff mondial"))
                {
                    g_ZckMondialBuff.DessinerOnglet();
                    ImGui::EndTabItem();
                }
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
                if (ImGui::BeginTabItem("Buffs Perin"))
                {
                    g_ZckPerinBuff.DessinerOnglet();
                    ImGui::EndTabItem();
                }
#endif // __ZCK_PERIN_BUFF
                if (ImGui::BeginTabItem("Joueur"))
                {
                    DrawPlayerTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Cible"))
                {
                    DrawTargetTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Stats"))
                {
                    DrawStatsTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Buffs"))
                {
                    DrawBuffsTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Monde"))
                {
                    DrawWorldTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("\xC3\x89quipement"))
                {
                    DrawEquipmentTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Performance"))
                {
                    DrawPerformanceTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Defines"))
                {
                    DrawDefinesTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Session"))
                {
                    DrawSessionTab();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Cam\xC3\xA9ra"))
                {
                    DrawCameraTab();
                    ImGui::EndTabItem();
                }

                ImGui::EndTabBar();
            }
        }
        ImGui::End();

        s_bVisible = bVisible;
    }
}

namespace ZckImGui
{
    bool Initialize(HWND hWnd, LPDIRECT3DDEVICE9 pDevice)
    {
        if (s_bInitialized)
            return true;

        if (hWnd == NULL || pDevice == NULL)
            return false;

        // Un contexte residuel ne devrait jamais exister ici. Le detruire silencieusement
        // masquerait un double-lifetime ; on prefere echouer proprement.
        if (ImGui::GetCurrentContext() != NULL)
            return false;

        ClearOwnershipTracking();

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();

        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
        io.IniFilename = NULL;
        io.LogFilename = NULL;

        ImGui::StyleColorsDark();

        if (!ImGui_ImplWin32_Init(hWnd))
        {
            ImGui::DestroyContext();
            return false;
        }
        s_bWin32Initialized = true;

        if (!ImGui_ImplDX9_Init(pDevice))
        {
            ImGui_ImplWin32_Shutdown();
            s_bWin32Initialized = false;
            ImGui::DestroyContext();
            return false;
        }

        s_bDX9Initialized = true;
        s_bInitialized = true;
        s_bVisible = false;

        return true;
    }

    void Shutdown()
    {
        if (s_bDX9Initialized)
        {
            ImGui_ImplDX9_Shutdown();
            s_bDX9Initialized = false;
        }

        if (s_bWin32Initialized)
        {
            ImGui_ImplWin32_Shutdown();
            s_bWin32Initialized = false;
        }

        // Ne detruit que le contexte dont ce wrapper a effectivement pris possession.
        // Si Initialize() a refuse un contexte residuel/etranger, Shutdown() ne doit pas
        // le detruire par effet de bord.
        if (s_bInitialized && ImGui::GetCurrentContext() != NULL)
            ImGui::DestroyContext();

        s_bVisible = false;
        s_bInitialized = false;
        ClearOwnershipTracking();
    }

    void NewFrame()
    {
        if (!s_bInitialized)
            return;

        ImGui_ImplDX9_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        DrawDeveloperTools();
        UpdateCaptureTransitions();
    }

    void Render()
    {
        if (!s_bInitialized)
            return;

        ImGui::Render();
        ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
    }

    void OnLostDevice()
    {
        if (s_bDX9Initialized)
            ImGui_ImplDX9_InvalidateDeviceObjects();
    }

    bool OnResetDevice()
    {
        if (!s_bDX9Initialized)
            return true;

        return ImGui_ImplDX9_CreateDeviceObjects();
    }

    bool HandleWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        if (!s_bInitialized)
            return false;

        // Cas particulier IME :
        // le backend Win32 v1.92.9b appelle lui-meme DefWindowProcW() pour
        // WM_IME_COMPOSITION. Quand ImGui ne possede pas la saisie texte,
        // on laisse donc le pipeline IME historique de FlyFF totalement intact
        // et on ne transmet pas cette plage au backend.
        const bool bImeMessage = IsImeMessage(msg);
        const bool bImGuiTextInput = s_bVisible && ImGui::GetIO().WantTextInput;

        if (!bImeMessage || bImGuiTextInput)
            ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam);

        // Le focus et les messages systeme restent obligatoirement traites par FlyFF/base.
        if (msg == WM_KILLFOCUS)
        {
            ClearOwnershipTracking();
            return false;
        }

        // F10 avant GuildDeploy/CWndEdit. Bit 30 = auto-repeat deja enfonce.
        if (IsKeyboardDownMessage(msg) && wParam == VK_F10)
        {
            const bool bWasAlreadyDown = (lParam & (1L << 30)) != 0;
            if (!bWasAlreadyDown)
                Toggle();
            return true;
        }

        if (IsKeyboardUpMessage(msg) && wParam == VK_F10)
            return true;

        if (IsKeyboardUpMessage(msg))
        {
            const unsigned int nKey = (unsigned int)wParam;
            if (nKey < 256 && s_bConsumeKeyUp[nKey])
            {
                s_bConsumeKeyUp[nKey] = FALSE;
                return true;
            }

            return WantsKeyboardCapture(msg);
        }

        if (IsKeyboardDownMessage(msg))
        {
            if (!WantsKeyboardCapture(msg))
                return false;

            const unsigned int nKey = (unsigned int)wParam;
            if (nKey < 256)
                s_bConsumeKeyUp[nKey] = TRUE;
            return true;
        }

        if (IsCharacterMessage(msg))
            return WantsKeyboardCapture(msg);

        // CWndEdit traite plusieurs messages IME.
        // Si ImGui attend reellement du texte, ces messages ne doivent pas traverser
        // CWndEdit. Neuz.cpp distinguera ensuite les messages deja finalises par
        // le backend (COMPOSITION/IME_CHAR) de ceux qui doivent encore aller au
        // MsgProc de base/DefWindowProc.
        if (bImeMessage && bImGuiTextInput)
            return true;

        const unsigned int uButtonMask = GetMouseButtonMask(msg, wParam);

        if (IsMouseButtonUpMessage(msg))
        {
            // Un DOWN deja livre a FlyFF doit recevoir son UP FlyFF, meme si ImGui
            // demande maintenant la souris. C'est ce qui evite scrollbar/drag/camera bloques.
            if (uButtonMask != ZCK_MOUSE_NONE && (s_uFlyffMouseButtonsDown & uButtonMask))
            {
                s_uFlyffMouseButtonsDown &= ~uButtonMask;
                return false;
            }

            // A l'inverse, un DOWN appartenant a ImGui ne doit pas produire un UP orphelin
            // dans FlyFF si la fenetre a ete fermee entre les deux.
            if (uButtonMask != ZCK_MOUSE_NONE && (s_uImGuiMouseButtonsDown & uButtonMask))
            {
                s_uImGuiMouseButtonsDown &= ~uButtonMask;
                return true;
            }

            return WantsMouseCapture();
        }

        if (IsMouseButtonDownMessage(msg))
        {
            // Une interaction souris est possedee du DOWN jusqu'au UP correspondant.
            // On ne change jamais de proprietaire au milieu d'un drag.
            if (s_uFlyffMouseButtonsDown != ZCK_MOUSE_NONE)
            {
                s_uFlyffMouseButtonsDown |= uButtonMask;
                return false;
            }

            if (s_uImGuiMouseButtonsDown != ZCK_MOUSE_NONE || WantsMouseCapture())
            {
                s_uImGuiMouseButtonsDown |= uButtonMask;
                return true;
            }

            s_uFlyffMouseButtonsDown |= uButtonMask;
            return false;
        }

        if (msg == WM_MOUSEMOVE)
        {
            if (s_uFlyffMouseButtonsDown != ZCK_MOUSE_NONE)
                return false;
            if (s_uImGuiMouseButtonsDown != ZCK_MOUSE_NONE)
                return true;
            return WantsMouseCapture();
        }

        if (msg == WM_MOUSEWHEEL || msg == WM_MOUSEHWHEEL)
        {
            if (s_uFlyffMouseButtonsDown != ZCK_MOUSE_NONE)
                return false;
            if (s_uImGuiMouseButtonsDown != ZCK_MOUSE_NONE)
                return true;
            return WantsMouseCapture();
        }

        // Evite que le curseur d'un controle FlyFF situe derriere la fenetre ImGui
        // remplace le curseur neutre. Le moteur de base traitera quand meme WM_SETCURSOR.
        if (msg == WM_SETCURSOR && LOWORD(lParam) == HTCLIENT)
        {
            if (s_uFlyffMouseButtonsDown != ZCK_MOUSE_NONE)
                return false;
            if (s_uImGuiMouseButtonsDown != ZCK_MOUSE_NONE)
                return true;
            return WantsMouseCapture();
        }

        return false;
    }

    void Toggle()
    {
        if (!s_bInitialized)
            return;

        // Ne purge pas arbitrairement les inputs FlyFF au simple affichage du menu.
        // La purge clavier n'arrive que lorsqu'ImGui reclame effectivement le clavier.
        s_bVisible = !s_bVisible;
    }

    bool IsVisible()
    {
        return s_bVisible;
    }

    bool IsInitialized()
    {
        return s_bInitialized;
    }
}

#endif // __ZCK_IMGUI