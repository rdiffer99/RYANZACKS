#include "StdAfx.h"
#include "defineObj.h"
#include "dbmanager.h"
#include "dploginsrvr.h"
#include "dpcoresrvr.h"
#include "dptrans.h"
#include "..\_Network\Objects\Obj.h"
#include "misc.h"
#include "mytrace.h"
#ifdef __ZCK_CRAFT_LOAD_TEX
#include "ZckCraftLoadTexBase.h"
#else
#line 9 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX

#include "party.h"
#include "guild.h"
extern	CGuildMng	g_GuildMng;
#include "guildwar.h"

#ifdef __FL_RECORD_BOOK
#include "RecordParameters.h"
#endif

#ifdef __ZCK_ACHIEVEMENT
// Taille max d'une entree "%d,%I64d,%u;" :
//   nId    (int, valide > 0)      : 10 caracteres
//   nProgress (__int64, valide >= 0) : 19 caracteres
//   byClaimed (0 ou 1)            :  1 caractere
//   2 virgules + 1 point-virgule  :  3 caracteres
// soit 33, arrondi a 35 pour marge. Plus 2 octets pour le '$' final et le '\0'.
//
// QUERY_COLUMN_SIZE vaut 51000 avec __INVENTORY_168_SLOTS, 8192 sans (_Database/Query.h).
// La capacite Achievement depend donc d'un define d'inventaire sans rapport :
// cette assertion casse la compilation plutot que de laisser des personnages
// cesser silencieusement d'etre sauvegardes.
#define ZCK_ACHIEVEMENT_DB_ENTRY_MAX_LEN 35

static_assert(
    ZCK_ACHIEVEMENT_MAX_COUNT * ZCK_ACHIEVEMENT_DB_ENTRY_MAX_LEN + 2 <= QUERY_COLUMN_SIZE,
    "ZCK_ACHIEVEMENT_MAX_COUNT depasse la capacite de m_szZckAchievement : "
    "reduire ZCK_ACHIEVEMENT_MAX_COUNT ou augmenter QUERY_COLUMN_SIZE.");
#endif

#ifdef __ZCK_QUEST
// m_szZckQuest est relue par GetBaseCharacter dans un tampon de QUERY_COLUMN_SIZE
// octets (CQuery::GetStr) : la colonne ecrite ne doit jamais le depasser.
static_assert(
    ZCK_QUEST_DB_COLONNE <= QUERY_COLUMN_SIZE,
    "ZCK_QUEST_MAX depasse la capacite de m_szZckQuest : "
    "reduire ZCK_QUEST_MAX ou augmenter QUERY_COLUMN_SIZE.");
#endif // __ZCK_QUEST

// ---------------------------------------------------------------------------
// Canal unique de persistance des champs custom d'objet.
//
// Les trois systemes custom ecrivaient leurs champs a la fin de
// l'enregistrement szItem. Le plafond de szItem en banque est
// BANK_TBL.m_Bank varchar(4290) pour MAX_BANK = 42 emplacements, soit 102
// octets par emplacement ; l'enregistrement de base en consomme deja 75 et le
// trio jusqu'a 49. La chaine debordait, l'affectation au parametre T-SQL
// @im_Bank VARCHAR(4290) tronquait SANS erreur (8152 ne se leve que sur une
// colonne), le '$' final disparaissait, et VerifyString faisait refuser le
// conteneur ENTIER au chargement suivant : les 42 objets disparaissaient.
//
// Les champs sont desormais ecrits a la fin de l'enregistrement szPiercing,
// dont le plafond en banque est 7800 octets pour les memes 42 emplacements.
// Un champ custom supplementaire se greffe ici et dans LoadPiercingInfo, sans
// autre reflexion : la famille de lecteurs ...PaFromStr (_Network/CmnHdr.h
// l.114 et l.145) rend la valeur par defaut SANS avancer quand le champ est
// absent, ce qui rend les lignes deja en base relisibles telles quelles.
//
// Le bloc n'est ecrit QUE s'il porte une valeur non nulle. Ce n'est pas une
// optimisation : c'est ce qui garantit qu'un vis-pet perce 9 (pire
// enregistrement szPiercing, 173 octets) ne paie pas le bloc, et donc que le
// majorant du conteneur reste 42 * 173 + 1 = 7267 <= 7800.
// ---------------------------------------------------------------------------
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)

// Majorant du bloc : ",10" + ",99,4294967295,4294967295" + ",2305843009213693696"
// = 3 + 26 + 20 = 49 octets, plus le '\0'. 80 laisse 30 octets de marge.
#define ZCK_DB_EXTRA_BUF 80

static BOOL ZckHasDbExtra(CItemElem* pItemElem)
{
	if (pItemElem == NULL)
		return FALSE;
#ifdef __ZCK_RARE
	if (pItemElem->GetZckRareLevel() != 0)
		return TRUE;
#endif
#ifdef __ZCK_NIVEAU_ARME
	if (pItemElem->m_nZckArmeNiveau != 0
		|| pItemElem->m_dwZckArmeNiveauExp != 0
		|| pItemElem->m_dwZckArmeNiveauStat != 0)
		return TRUE;
#endif
#ifdef __ZCK_SYSTEME_EVEIL
	if (pItemElem->GetZckPrevRandomOpt() != 0)
		return TRUE;
#endif
#ifdef __ZCK_ARME_REBORN
	if (pItemElem->GetZckRebornNbPierres() > 0)
		return TRUE;
#endif // __ZCK_ARME_REBORN
	return FALSE;
}

static void ZckFormatDbExtra(char* szDst, CItemElem* pItemElem)
{
	szDst[0] = '\0';
	if (ZckHasDbExtra(pItemElem) == FALSE)
		return;

	sprintf(szDst
#ifdef __ZCK_RARE
		, ",%d"
#endif
#ifdef __ZCK_NIVEAU_ARME
		",%d,%u,%u"
#endif
#ifdef __ZCK_SYSTEME_EVEIL
		",%I64d"
#endif
#ifdef __ZCK_RARE
		, pItemElem->GetZckRareLevel()
#endif
#ifdef __ZCK_NIVEAU_ARME
		, pItemElem->m_nZckArmeNiveau
		, static_cast<unsigned int>(pItemElem->m_dwZckArmeNiveauExp)
		, static_cast<unsigned int>(pItemElem->m_dwZckArmeNiveauStat)
#endif
#ifdef __ZCK_SYSTEME_EVEIL
		, pItemElem->GetZckPrevRandomOpt()
#endif
	);
}

// Garde-fou : une troncature SQL future ne doit plus jamais vider un conteneur
// en silence. CQuery::Exec (_Database/Query.cpp l.173-180) classe
// SQL_SUCCESS_WITH_INFO en succes et ne trace le diagnostic que sous _DEBUG :
// l'avertissement 01004 n'apparait nulle part en production. Ce controle-ci
// hurle AVANT l'ecriture, en nommant le conteneur, le proprietaire et la
// longueur atteinte.
static void ZckCheckDbLen(const char* lpszChain, size_t uCap, const char* lpszWhat, u_long idOwner)
{
	if (lpszChain == NULL)
		return;

	const size_t uLen = strlen(lpszChain);
	if (uLen >= uCap)
		Error("ZCK PERSIST OVERFLOW: %s owner=%07u len=%u cap=%u last='%c' "
			"-- la chaine va etre TRONQUEE par SQL et le conteneur sera REFUSE au chargement",
			lpszWhat, idOwner, (unsigned)uLen, (unsigned)uCap,
			uLen ? lpszChain[uLen - 1] : '?');
}

#endif // __ZCK_RARE || __ZCK_NIVEAU_ARME || __ZCK_SYSTEME_EVEIL

extern const int MAX_TASKBAR;
extern const int MAX_APPLETTASKBAR;
extern const int MAX_ITEMTASKBAR;
extern const char NullStr[2];

#if __VER >= 13
#include "honor.h"
#endif

#if defined( __VERIFY_PLAYER ) || defined( __PROVIDE ) || defined( __S0707_ITEM_CONV ) || defined(__RECOVER0816)
#define	MAX_QUERY_SIZE	1024 * 64
#include "resource.h"
BOOL	CALLBACK	VerifyPlayerDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam);
#endif	// __VERIFY_PLAYER OR __PROVIDE

extern  CDPCoreSrvr			g_dpCoreSrvr;
extern	CDPLoginSrvr		g_dpLoginSrvr;
extern	CProject			prj;
extern	APP_INFO			g_appInfo;
extern	CMyTrace			g_MyTrace;

#define	VERIFYSTRING( lpString, lpszPlayer )	\
	if( FALSE == VerifyString( lpString, __FILE__, __LINE__, lpszPlayer, lpDbOverlappedPlus ) )		return;

#define	VERIFY_GUILD_STRING( lpString, lpszGuild )	\
	if( FALSE == VerifyString( lpString, __FILE__, __LINE__, lpszGuild ) )		return;

void CDbManager::SavePlayer(CQuery* qry, CQuery* pQueryLog, CMover* pMover, char* szQuery)
{
	szQuery[0] = '\0';

	///////// actMover
	char cActMover[50] = { 0, };
	sprintf(cActMover, "%d,%d", pMover->m_pActMover->m_dwState, pMover->m_pActMover->m_dwStateFlag);

	///////// Skill
	char JobSkill[1024] = { 0, };
	char LicenseSkill[1024] = { 0, };

	///////// JobLv
	char JobLv[500] = { 0, };
	SaveJobLv(pMover, JobLv);

	///////// Quest
	char QuestCnt[3072] = { 0, };
	char m_aCompleteQuest[1024] = { 0, };
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	char CheckedQuest[100] = { 0, };
	SaveQuest(pMover, QuestCnt, m_aCompleteQuest, CheckedQuest);
#else // __IMPROVE_QUEST_INTERFACE
	SaveQuest(pMover, QuestCnt, m_aCompleteQuest);
#endif // __IMPROVE_QUEST_INTERFACE

	///////// Inventory
	ItemContainerStruct	icsInventory, icsBank[3];
	SaveContainer(&pMover->m_Inventory, &icsInventory);
	for (int k = 0; k < 3; ++k)
		SaveContainer(&pMover->m_Bank[k], &icsBank[k]);

	///////// CardCube
	char Card[2] = "$";
	char sCardIndex[2] = "$";
	char sCardObjIndex[2] = "$";
	char Cube[2] = "$";
	char sCubeIndex[2] = "$";
	char sCubeObjIndex[2] = "$";

	///////// TaskBar
	char AppletTaskBar[MAX_APPLETTASKBAR] = { 0, };
	char ItemTaskBar[MAX_ITEMTASKBAR] = { 0, };

	char SkillTaskBar[2048] = { 0, };

	SaveTaskBar(pMover, AppletTaskBar, ItemTaskBar, SkillTaskBar);


	char szSMTime[3072] = { 0, };
	SaveSMCode(pMover, szSMTime);

	char szSkillInfluence[7500] = { 0, };
	SaveSkillInfluence(pMover, szSkillInfluence);

#ifdef __ZCK_ACHIEVEMENT
    vector<char> vecZckAchievement(QUERY_COLUMN_SIZE, 0);
    if (!pMover->m_ZckAchievement.SerializeDbText(&vecZckAchievement[0], vecZckAchievement.size()))
    {
        Error("SavePlayer(%s) - serialisation Achievement impossible, payload neutralise",
            pMover->m_szName);

        vecZckAchievement[0] = '$';
        vecZckAchievement[1] = '\0';
    }
#endif

#ifdef __ZCK_CLASSEMENT
    vector<char> vecZckClassement(ZCK_CLASSEMENT_DB_COLUMN_SIZE, 0);
    if (!pMover->m_ZckClassement.SerializeDbText(&vecZckClassement[0], vecZckClassement.size()))
    {
        Error("SavePlayer(%s) - serialisation Classement impossible, payload neutralise",
            pMover->m_szName);

        vecZckClassement[0] = '$';
        vecZckClassement[1] = '\0';
    }
#endif

#ifdef __ZCK_QUEST
    // Etat non charge (colonne absente de la branche S8) ou illisible : le
    // parametre part a NULL et la branche U1 garde la valeur en base
    // (ISNULL(@im_szZckQuest, ...)). Indicateur propre : cbLen est partage
    // par toutes les chaines de la requete.
    vector<char> vecZckQuest(ZCK_QUEST_DB_COLONNE, 0);
    SQLINTEGER cbZckQuest = SQL_NTS;
    if (!pMover->m_ZckQuest.IsBaseOk())
    {
        vecZckQuest[0] = '\0';
        cbZckQuest = SQL_NULL_DATA;
    }
    else if (!pMover->m_ZckQuest.SerializeDbText(&vecZckQuest[0], vecZckQuest.size()))
    {
        Error("SavePlayer(%s) - serialisation des quetes impossible, colonne m_szZckQuest gardee en l'etat",
            pMover->m_szName);
        vecZckQuest[0] = '\0';
        cbZckQuest = SQL_NULL_DATA;
    }
#endif // __ZCK_QUEST

#ifdef __ZCK_SYSTEME_EVEIL
    pMover->m_ZckAwakeMastery.Normalize(ZCK_AWAKE_MASTERY_STORAGE_MAX);

    __int64 nZckAwakeWeaponState =
        ZckAwakePackDbState(pMover->m_ZckAwakeMastery.aCategory[ZCK_AWAKE_CATEGORY_WEAPON]);

    __int64 nZckAwakeArmorState =
        ZckAwakePackDbState(pMover->m_ZckAwakeMastery.aCategory[ZCK_AWAKE_CATEGORY_ARMOR]);

    __int64 nZckAwakeJewelryState =
        ZckAwakePackDbState(pMover->m_ZckAwakeMastery.aCategory[ZCK_AWAKE_CATEGORY_JEWELRY]);

    __int64 nZckAwakeAccessoryState =
        ZckAwakePackDbState(pMover->m_ZckAwakeMastery.aCategory[ZCK_AWAKE_CATEGORY_ACCESSORY]);
#endif

	PutExpLog(pQueryLog, pMover, (pMover->m_dwPeriodicTick == 0 ? 'O' : 'P'));


	sprintf(szQuery, "{call CHARACTER_STR('U1','%07d','%02d','',"
		"?,?,?,?,?,?,?,?,?,?,?,"		// 1
		"?,?,?,?,?,?,?,?,?,?,?,"		// 2
		"?,?,?,?,?,?,?,?,?,?,"			// 3
		"?,?,?,?,?,?,?,?,?,?,?,"		// 4
		"?,?,?,?,?,?,"		// 5
		"?,?,?,?,?,?,?,?,?,?,"		// 6
		"?,?,?,?,?,?,?,?,?,?,?,"		// 7
//					  "?,?,?,?,?,?,?,?,?,?,?,"		// 8
"?,?,?,?,?,?,?,%7.0f,%7.0f,"		// 8
"%7.0f,?,?"
",?,?,?"
#if __VER >= 13
",?"
#endif
#ifdef __LAYER_1015
",?"
#endif	// __LAYER_1015
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
",?"
#endif // __IMPROVE_QUEST_INTERFACE
#ifdef __FL_BATTLE_PASS
",?"
",?"
",?"
#endif
",?"
",?,?,?,?,?,?,?"
#ifdef __ZCK_SYSTEME_EVEIL
",?,?,?,?"
#endif
#ifdef __FL_AUTO_STAT
",?"
#endif
#ifdef __ZCK_PRESTIGE
",?,?,?"
#endif
#ifdef __ZCK_ACHIEVEMENT
",?"
#endif
#ifdef __ZCK_CLASSEMENT
",?"
#endif
#ifdef __ZCK_AURA_SYSTEM
",?"		// @im_nZckAura : TOUJOURS le dernier parametre de CHARACTER_STR
#endif // __ZCK_AURA_SYSTEM
#ifdef __ZCK_PET_GLOW
",?"		// @im_nZckPetGlow : TOUJOURS le dernier parametre de CHARACTER_STR
#endif // __ZCK_PET_GLOW
#ifdef __ZCK_TRAILS
",?,?"		// @im_nZckTrails, @im_nZckTrailsParam : desormais les deux derniers parametres de CHARACTER_STR
#endif // __ZCK_TRAILS
#ifdef __ZCK_ELEMENT_RGB
",?"		// @im_nZckElementRgb : desormais le dernier parametre de CHARACTER_STR
#endif // __ZCK_ELEMENT_RGB
#ifdef __ZCK_QUEST
",?"		// @im_szZckQuest : desormais le dernier parametre de CHARACTER_STR
#endif // __ZCK_QUEST

")}", pMover->m_idPlayer, g_appInfo.dwSys, pMover->m_vReturnPos.x, pMover->m_vReturnPos.y, pMover->m_vReturnPos.z);		// +3

	char szAuthority[2] = "F";
	int nSlot = 0;
	int nSex = pMover->GetSex();
	int nExpertLv = 0;
	int nRemainLP = 0;
#if defined(__ZCK_AURA_SYSTEM) || defined(__ZCK_PET_GLOW)
	// Colonne CHARACTER_TBL.m_dwExpertLv reutilisee (ZckSfxTint.h, section 3) :
	// elle recevait la constante 0 et n'etait relue nulle part. Elle porte
	// desormais la geometrie des deux systemes (0 si les deux sont neutres :
	// aucune difference pour un joueur qui ne touche a rien). Meme parametre
	// @im_dwExpertLv, meme liaison SQL_C_LONG plus bas, ni requete ni nombre de
	// parametres changes.
	nExpertLv = (int)pMover->GetZckSfxGeoStored();
#endif // __ZCK_AURA_SYSTEM || __ZCK_PET_GLOW
#ifdef __ZCK_AURA_SYSTEM
	// Colonne CHARACTER_TBL.m_nRemainLP reutilisee (ZckAura.h, "STYLE DE L'AURA") :
	// elle recevait la constante 0 et n'etait relue nulle part. Elle porte
	// desormais le style de l'aura (0 pour le style 0 : aucune difference pour
	// un joueur qui ne touche a rien). Meme parametre @im_nRemainLP, meme
	// liaison SQL_C_LONG plus bas, ni requete ni nombre de parametres changes.
#if defined(__ZCK_PET_GLOW) && defined(__ZCK_PET_GLOW_STYLES)
	// Et, sous __ZCK_PET_GLOW_STYLES, le style du glow du familier dans ses bits
	// 5..3 (ZckPetGlow.h) : les deux membres composent la colonne, chacun
	// conserve les bits de l'autre. Style de familier 0 : valeur identique a
	// ZckAuraStyleToStored, bit pour bit.
	nRemainLP = (int)ZckPetGlowStyleComposeStored(pMover->GetZckAuraStyle(), pMover->GetZckPetGlowStyle());
#else
	nRemainLP = (int)ZckAuraStyleToStored(pMover->GetZckAuraStyle());
#endif // __ZCK_PET_GLOW && __ZCK_PET_GLOW_STYLES
#endif // __ZCK_AURA_SYSTEM
	int nTotalPlayTime = 0;
	DWORD dwGold = pMover->GetGold();
	int i = 0;
	int j = -1;
	__int64 nExp2 = 0;
	DWORD dwSkillPoint = 0;
	int nSkillPoint = 0;
	int nSkillLevel = 0;
	DWORD dwRideItemId = 0;
#ifdef __ZCK_PET_SELECTION
	// Colonne CHARACTER_TBL.m_dwRideItemIdx reutilisee (ZckPetGlow.h, "FAMILIER A
	// L'ECRAN DE SELECTION") : elle recevait la constante 0 et n'etait relue
	// nulle part. Elle porte desormais le familier a montrer a l'ecran de
	// selection (0 sans familier). Meme parametre @im_dwRideItemIdx, meme
	// liaison SQL_C_LONG plus bas, ni requete ni nombre de parametres changes.
	dwRideItemId = pMover->GetZckPetSelection();
#endif // __ZCK_PET_SELECTION
#ifdef __ZCK_ELEMENT_RGB
	// Colonne CHARACTER_TBL.m_SkillPoint reutilisee (ZckElementRgb.h) : elle
	// recevait la constante 0 et n'etait relue nulle part. Elle porte desormais
	// la couleur des SFX d'element de la main gauche (arme de gauche ou
	// bouclier ; 0 = couleurs d'origine : aucune difference pour un joueur qui
	// ne touche a rien). Code valide positif (au plus 0x71FFFFFF). Meme
	// parametre @im_SkillPoint, meme liaison SQL_C_LONG plus bas, ni requete ni
	// nombre de parametres changes.
	nSkillPoint = (int)ZckElementRgbToStored(pMover->GetZckElementRgb(ZCK_ELEMENT_RGB_HAND_LEFT));
#endif // __ZCK_ELEMENT_RGB

	////////////////////////////////////////////////////////////////////////////////
	int MAX_SAVEPARAM = 76;
	MAX_SAVEPARAM += 3;
#if __VER >= 8 // __S8_PK
	MAX_SAVEPARAM += 1;
#endif // __VER >= 8 // __S8_PK
#if __VER >= 8 // __CSC_VER8_5
	MAX_SAVEPARAM += 2;
#endif // __CSC_VER8_5

	MAX_SAVEPARAM += 3;

#if __VER >= 13
	MAX_SAVEPARAM += 1;
#endif
#ifdef __LAYER_1015
	MAX_SAVEPARAM += 1;	// m_nLayer
#endif	// __LAYER_1015
#if __VER >= 15 // __IMPROVE_QUEST_INTERFACE
	MAX_SAVEPARAM += 1;	// m_aCheckedQuest
#endif // __IMPROVE_QUEST_INTERFACE
#ifdef __FL_BATTLE_PASS
	MAX_SAVEPARAM += 3;
#endif
	MAX_SAVEPARAM += 1;
	MAX_SAVEPARAM += 7;
#ifdef __ZCK_SYSTEME_EVEIL
	MAX_SAVEPARAM += 4;
#endif
#ifdef __FL_AUTO_STAT
	MAX_SAVEPARAM += 1;
#endif
#ifdef __ZCK_PRESTIGE
	MAX_SAVEPARAM += 3;
#endif
#ifdef __ZCK_ACHIEVEMENT
    MAX_SAVEPARAM += 1;
#endif
#ifdef __ZCK_CLASSEMENT
    MAX_SAVEPARAM += 1;
#endif
#ifdef __ZCK_AURA_SYSTEM
    MAX_SAVEPARAM += 1;
#endif // __ZCK_AURA_SYSTEM
#ifdef __ZCK_PET_GLOW
    MAX_SAVEPARAM += 1;
#endif // __ZCK_PET_GLOW
#ifdef __ZCK_TRAILS
	MAX_SAVEPARAM += 2;
#endif // __ZCK_TRAILS
#ifdef __ZCK_ELEMENT_RGB
	MAX_SAVEPARAM += 1;
#endif // __ZCK_ELEMENT_RGB
#ifdef __ZCK_QUEST
	MAX_SAVEPARAM += 1;
#endif // __ZCK_QUEST
	int nNumSkill = 0;
	int nSlaughter = 0;
#ifdef __ZCK_HP_AUCUNE_LIMITE
	LONG nHitPointDb = 0;
if (pMover->m_nHitPoint > INT_MAX)
	nHitPointDb = INT_MAX;
else if (pMover->m_nHitPoint > 0)
	nHitPointDb = static_cast<LONG>(pMover->m_nHitPoint);
#endif
	SQLINTEGER cbLen = SQL_NTS;
	BOOL* bOK = new BOOL[MAX_SAVEPARAM];

	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 32, 0, pMover->m_szName, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nSlot, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwWorldID, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwIndex, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &pMover->m_vPos.x, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &pMover->m_vPos.y, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &pMover->m_vPos.z, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 32, 0, pMover->m_szCharacterKey, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwSkinSet, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwHairMesh, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwHairColor, 0, 0);
	// 1
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwHeadMesh, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nSex, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &pMover->m_vScale.x, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwMotion, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &pMover->m_fAngle, 0, 0);
#ifdef __ZCK_HP_AUCUNE_LIMITE
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nHitPointDb, 0, 0);
#else
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nHitPoint, 0, 0);
#endif
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nManaPoint, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nFatiguePoint, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &dwRideItemId, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &dwGold, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nJob, 0, 0);
	// 2
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 50, 0, cActMover, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nStr, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nSta, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nDex, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nInt, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nLevel, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_SBIGINT, SQL_BIGINT, 0, 0, &pMover->m_nExp1, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_SBIGINT, SQL_BIGINT, 0, 0, &nExp2, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 500, 0, JobSkill, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 500, 0, LicenseSkill, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 500, 0, JobLv, 0, &cbLen);
	// 3
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nExpertLv, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_idMarkingWorld, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &pMover->m_vMarkingPos.x, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &pMover->m_vMarkingPos.y, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_FLOAT, SQL_REAL, 0, 0, &pMover->m_vMarkingPos.z, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nRemainGP, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nRemainLP, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nFxp, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nFxp, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 3072, 0, QuestCnt, 0, &cbLen);
	// 4
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_CHAR, 1, 0, szAuthority, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwMode, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_idparty, 0, 0);

#ifdef __JEFF_9_20
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwMute, 0, 0);
#else	// __JEFF_9_20
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwFlyTime, 0, 0);
#endif	// __JEFF_9_20
	DWORD dwState = pMover->m_RTMessenger.GetState();
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &dwState, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nTotalPlayTime, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 1980, 0, Card, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 215, 0, sCardIndex, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 215, 0, sCardObjIndex, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 1980, 0, Cube, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 215, 0, sCubeIndex, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 215, 0, sCubeObjIndex, 0, &cbLen);
#ifndef __INVENTORY_168_SLOTS
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 6940, 0, icsInventory.szItem, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 345, 0, icsInventory.szIndex, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 345, 0, icsInventory.szObjIndex, 0, &cbLen);
#else
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 0, 0, icsInventory.szItem, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 1000, 0, icsInventory.szIndex, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 1000, 0, icsInventory.szObjIndex, 0, &cbLen);
#endif
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 3100, 0, AppletTaskBar, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 6885, 0, ItemTaskBar, 0, &cbLen);

	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2048, 0, SkillTaskBar, 0, &cbLen);

	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_SHORT, SQL_SMALLINT, 0, 0, &pMover->m_UserTaskBar.m_nActionPoint, 0, 0);
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
	// Plafonds effectifs : le plus petit des trois (colonne, parametre de
	// procedure, liaison ODBC). szIndex/szObjIndex de l'inventaire sont lies a
	// 1000 alors que la colonne fait 2048 : c'est la liaison qui commande.
	ZckCheckDbLen(icsInventory.szIndex, 1000, "INVENTORY_TBL.m_apIndex", pMover->m_idPlayer);
	ZckCheckDbLen(icsInventory.szObjIndex, 1000, "INVENTORY_TBL.m_dwObjIndex", pMover->m_idPlayer);
	ZckCheckDbLen(icsInventory.szExt, 8000, "INVENTORY_EXT_TBL.m_extInventory", pMover->m_idPlayer);
	ZckCheckDbLen(icsBank[pMover->m_nSlot].szItem, 4290, "BANK_TBL.m_Bank", pMover->m_idPlayer);
	ZckCheckDbLen(icsBank[pMover->m_nSlot].szExt, 1296, "BANK_EXT_TBL.m_extBank", pMover->m_idPlayer);
	ZckCheckDbLen(icsBank[pMover->m_nSlot].szPiercing, 7800, "BANK_EXT_TBL.m_BankPiercing", pMover->m_idPlayer);
	ZckCheckDbLen(icsBank[pMover->m_nSlot].szPet, 4200, "BANK_EXT_TBL.szBankPet", pMover->m_idPlayer);
#endif
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 4290, 0, icsBank[pMover->m_nSlot].szItem, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 215, 0, icsBank[pMover->m_nSlot].szIndex, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 215, 0, icsBank[pMover->m_nSlot].szObjIndex, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwGoldBank[pMover->m_nSlot], 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nFuel, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_tmAccFuel, 0, 0);
	// 7
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2560, 0, szSMTime, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 7500, 0, szSkillInfluence, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &dwSkillPoint, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 1024, 0, m_aCompleteQuest, 0, &cbLen);
#ifndef __INVENTORY_168_SLOTS
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2000, 0, icsInventory.szExt, 0, &cbLen);
#else
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 0, 0, icsInventory.szExt, 0, &cbLen);
#endif
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2000, 0, icsBank[pMover->m_nSlot].szExt, 0, &cbLen);
#ifndef __INVENTORY_168_SLOTS
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 7800, 0, icsInventory.szPiercing, 0, &cbLen);
#else
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 0, 0, icsInventory.szPiercing, 0, &cbLen);
#endif
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 7800, 0, icsBank[pMover->m_nSlot].szPiercing, 0, &cbLen);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwReturnWorldID, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nSkillPoint, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nSkillLevel, 0, 0);
#ifndef __INVENTORY_168_SLOTS
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2000, 0, icsInventory.szPet, 0, &cbLen);
#else
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 0, 0, icsInventory.szPet, 0, &cbLen);
#endif
	// 4200 = BANK_EXT_TBL.szBankPet varchar(4200) et @iszBankPet varchar(4200).
	// La liaison etait le seul des trois plafonds a valoir 2000 : elle tronquait
	// des 23 familiers dans un onglet (87 octets par enregistrement).
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 4200, 0, icsBank[pMover->m_nSlot].szPet, 0, &cbLen);
	DWORD dwPetId = pMover->GetPetId();
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &dwPetId, 0, 0);

	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nHonor, 0, 0);
#ifdef __LAYER_1015
	int nLayer = pMover->GetLayer();
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nLayer, 0, 0);
#endif	// 
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 100, 0, CheckedQuest, 0, &cbLen);

#ifdef __FL_BATTLE_PASS
	int m_nLastBattlePassID = pMover->GetLastBattlePassID();
	int m_nBattlePassLevel = pMover->GetBattlePassLevel();
	int m_nBattlePassExp = pMover->GetBattlePassExp();

	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &m_nLastBattlePassID, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &m_nBattlePassLevel, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &m_nBattlePassExp, 0, 0);
#endif
	int nHideCoat = 0;
	for (int z = 0; z < hft_MAX_HIDEFASHION_TYPES; ++z)
	{
		int c = (pMover->m_bHideFashion[z] ? 1 : 0);
		nHideCoat |= (c << z);
	}
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nHideCoat, 0, 0);

	// pk
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nPKValue, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwPKPropensity, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_dwPKExp, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_SBIGINT, SQL_BIGINT, 0, 0, &pMover->m_nAngelExp, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nAngelLevel, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_idMurderer, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nFame, 0, 0);

#ifdef __ZCK_SYSTEME_EVEIL
    bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_SBIGINT, SQL_BIGINT, 0, 0, &nZckAwakeWeaponState, 0, 0);
    bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_SBIGINT, SQL_BIGINT, 0, 0, &nZckAwakeArmorState, 0, 0);
    bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_SBIGINT, SQL_BIGINT, 0, 0, &nZckAwakeJewelryState, 0, 0);
    bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_SBIGINT, SQL_BIGINT, 0, 0, &nZckAwakeAccessoryState, 0, 0);
#endif

#ifdef __FL_AUTO_STAT
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &pMover->m_nAutoStat, 0, 0);
#endif

#ifdef __ZCK_PRESTIGE
    int nZckPrestige = (int)pMover->GetZckPrestige();
    int nZckPendingCommit = pMover->IsZckPrestigePending() ? 1 : 0;
    int nZckPendingPrestige = (int)pMover->GetZckPrestigePending();

    bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nZckPrestige, 0, 0);
    bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nZckPendingCommit, 0, 0);
    bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nZckPendingPrestige, 0, 0);
#endif
#ifdef __ZCK_ACHIEVEMENT
    bOK[++j] = qry->BindParameter(
        ++i,
        SQL_PARAM_INPUT,
        SQL_C_CHAR,
        SQL_LONGVARCHAR,
        static_cast<SQLUINTEGER>(vecZckAchievement.size() - 1),
        0,
        &vecZckAchievement[0],
        static_cast<SQLINTEGER>(vecZckAchievement.size()),
        &cbLen);
#endif
#ifdef __ZCK_CLASSEMENT
    bOK[++j] = qry->BindParameter(
        ++i,
        SQL_PARAM_INPUT,
        SQL_C_CHAR,
        SQL_LONGVARCHAR,
        static_cast<SQLUINTEGER>(vecZckClassement.size() - 1),
        0,
        &vecZckClassement[0],
        static_cast<SQLINTEGER>(vecZckClassement.size()),
        &cbLen);
#endif
#ifdef __ZCK_AURA_SYSTEM
	// Variable locale de la fonction : ODBC lit l'adresse liee au moment d'Exec.
	// Code compact positif (0, ou 0x01RRGGBB plus les bits de reglage 25..30,
	// bit 31 toujours a zero : au plus 0x7FFFFFFF) : int SQL.
	// Ni la requete ni le nombre de parametres ne changent.
	int nZckAura = (int)pMover->GetZckAura();
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nZckAura, 0, 0);
#endif // __ZCK_AURA_SYSTEM
#ifdef __ZCK_PET_GLOW
	// Meme regle que l'aura : variable locale de la fonction (ODBC lit l'adresse
	// liee au moment d'Exec). Code compact positif (0, ou 0x01RRGGBB plus les
	// bits de reglage 25..30, bit 31 toujours a zero) : int SQL.
	int nZckPetGlow = (int)pMover->GetZckPetGlow();
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nZckPetGlow, 0, 0);
#endif // __ZCK_PET_GLOW
#ifdef __ZCK_TRAILS
	// Meme regle : variables locales de la fonction (ODBC lit l'adresse liee au
	// moment d'Exec). Valeurs canoniques positives (0, ou signature bit 30 +
	// champs, bit 31 toujours a zero : au plus 0x7FFFFFFF) : int SQL. Les deux
	// derniers parametres de CHARACTER_STR, dans cet ordre (code, reglages).
	int nZckTrails = (int)ZckTrailsToStored(pMover->GetZckTrails());
	int nZckTrailsParam = (int)ZckTrailsParamToStored(pMover->GetZckTrailsParam());
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nZckTrails, 0, 0);
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nZckTrailsParam, 0, 0);
#endif // __ZCK_TRAILS
#ifdef __ZCK_ELEMENT_RGB
	// Meme regle : variable locale de la fonction (ODBC lit l'adresse liee au
	// moment d'Exec). Code valide positif de la main droite (0, ou 0x01RRGGBB
	// plus l'eclat, bit 31 toujours a zero : au plus 0x71FFFFFF) : int SQL.
	// Dernier parametre de CHARACTER_STR. La main gauche passe par
	// @im_SkillPoint (plus haut).
	int nZckElementRgb = (int)ZckElementRgbToStored(pMover->GetZckElementRgb(ZCK_ELEMENT_RGB_HAND_RIGHT));
	bOK[++j] = qry->BindParameter(++i, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &nZckElementRgb, 0, 0);
#endif // __ZCK_ELEMENT_RGB
#ifdef __ZCK_QUEST
	// Dernier parametre de CHARACTER_STR (@im_szZckQuest VARCHAR(MAX) = NULL).
	// Meme liaison que m_szZckAchievement, avec son propre indicateur.
	bOK[++j] = qry->BindParameter(
		++i,
		SQL_PARAM_INPUT,
		SQL_C_CHAR,
		SQL_LONGVARCHAR,
		static_cast<SQLUINTEGER>(vecZckQuest.size() - 1),
		0,
		&vecZckQuest[0],
		static_cast<SQLINTEGER>(vecZckQuest.size()),
		&cbZckQuest);
#endif // __ZCK_QUEST
		for (i = 0; i <= j; ++i) //__ZCK_ACHIEVEMENT
	{
		if (bOK[i] == FALSE)
		{
			char szBuffer[128];
			sprintf(szBuffer, "SavePlayer(%s) - %dth bindparam error - %d", pMover->m_szName, i + 1, ::GetCurrentThreadId());
			WriteLog(szBuffer);


			WriteLog("try DB Reconnect... - ThreadId : %d", ::GetCurrentThreadId());
			qry->DisConnect();
			if (qry->Connect(3, qry->DBName, qry->DBId, qry->DBPass))
				WriteLog("DB Reconnect Success! - ThreadId : %d", ::GetCurrentThreadId());
			else
				WriteLog("DB Reconnect Failed! - ThreadId : %d", ::GetCurrentThreadId());
			qry->Clear();


			SAFE_DELETE_ARRAY(bOK);
			return;
		}
	}

	if (qry->Exec(szQuery) == FALSE)
	{
		WriteLog("SavePlayer(%s) - Exec RETURN FALSE, ThreadID : %d", pMover->m_szName, ::GetCurrentThreadId());
		SAFE_DELETE_ARRAY(bOK);
		return;
	}

	if (qry->Fetch())
	{
		int nError = qry->GetInt("fError");
		if (nError != 1)
		{
			WriteLog("SavePlayer(%s) - fError:%d", pMover->m_szName, nError);
			SAFE_DELETE_ARRAY(bOK);
			return;
		}
	}
	SaveHonor(qry, pMover->m_idPlayer, pMover->m_aHonorTitle, szQuery);
	SaveSkill(qry, pMover->m_idPlayer, pMover->m_aJobSkill, pMover->m_abUpdateSkill, szQuery);
#ifdef __FL_CONSUMABLES_STORAGE
#ifndef __FL_PACKED_ITEMS
	SaveChest(pMover, qry);
#else
	if (SaveChest(pMover, qry))
		SavePackages(qry, &pMover->m_Chest, pMover->m_idPlayer, PRT_CHEST);
#endif
#endif

#ifdef __FL_SWITCH_EQ
	SaveSwitches(pMover, qry);
#endif

#ifdef __FL_RECORD_BOOK
	SaveRecords(pMover, qry);
#endif

#ifdef __FL_MONSTER_ALBUM
	SaveMonsterAlbum(pMover, qry);
#endif
#ifdef __FL_SEASON_PASS
	SaveSeasonPass(pMover, qry);
#endif
#ifdef __FL_WARDROBE
	SaveWardrobe(pMover, qry);
#endif
#ifdef __FL_PET_FILTER
	SavePetFilter(pMover, qry);
#endif
#ifdef __ZCK_BADGE
	SaveZckBadge(pMover, qry);
#endif // __ZCK_BADGE

#ifdef __ZCK_CRAFT_LOAD_TEX
	// Experience d'artisanat : rien n'est ecrit si elle n'a pas ete chargee (une valeur
	// en base n'est jamais ecrasee) ou si la table n'existe pas encore.
	ZckCraftSauverExp(pMover, qry, g_appInfo.dwSys);
#else
#line 771 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#ifdef __FL_PACKED_ITEMS
	SavePackages(qry, &pMover->m_Inventory, pMover->m_idPlayer, PRT_INVENTORY);
	SavePackages(qry, &pMover->m_Bank[pMover->m_nSlot], pMover->m_idPlayer, PRT_BANK);
#endif

	for (i = 0; i < 3; ++i)
	{
		if (pMover->m_idPlayerBank[i] != 0 && i != pMover->m_nSlot)
		{
			ADDBANK_QUERYINFO info("U1");
			info.idPlayer = pMover->m_idPlayerBank[i];
			info.dwGoldBank = pMover->m_dwGoldBank[i];
			info.pszBank = icsBank[i].szItem;
			info.pszBankIndex = icsBank[i].szIndex;
			info.pszObjIndexBank = icsBank[i].szObjIndex;
			info.pszExtBank = icsBank[i].szExt;
			info.pszPirecingBank = icsBank[i].szPiercing;
			info.pszBankPet = icsBank[i].szPet;

			DBQryAddBankSave(szQuery, info);

			{
				SQLINTEGER cbLen = SQL_NTS;
				BOOL bOK[7];
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
				ZckCheckDbLen(info.pszBank, 4290, "BANK_TBL.m_Bank (onglet non courant)", info.idPlayer);
				ZckCheckDbLen(info.pszExtBank, 1296, "BANK_EXT_TBL.m_extBank (onglet non courant)", info.idPlayer);
				ZckCheckDbLen(info.pszPirecingBank, 7800, "BANK_EXT_TBL.m_BankPiercing (onglet non courant)", info.idPlayer);
				ZckCheckDbLen(info.pszBankPet, 4200, "BANK_EXT_TBL.szBankPet (onglet non courant)", info.idPlayer);
#endif
				bOK[0] = qry->BindParameter(1, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 4290, 0, (char*)info.pszBank, 0, &cbLen);
				bOK[1] = qry->BindParameter(2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 215, 0, (char*)info.pszBankIndex, 0, &cbLen);
				bOK[2] = qry->BindParameter(3, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 215, 0, (char*)info.pszObjIndexBank, 0, &cbLen);
				bOK[3] = qry->BindParameter(4, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, &info.dwGoldBank, 0, 0);
				bOK[4] = qry->BindParameter(5, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2000, 0, (char*)info.pszExtBank, 0, &cbLen);
#if __VER >= 15 // __PETVIS
				bOK[5] = qry->BindParameter(6, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 7800, 0, (char*)info.pszPirecingBank, 0, &cbLen);
#else // __PETVIS
				bOK[5] = qry->BindParameter(6, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2000, 0, (char*)info.pszPirecingBank, 0, &cbLen);
#endif // __PETVIS
				// 2689 -> 4200 : aligne sur la colonne et sur le parametre de
				// procedure, et sur la liaison de l'onglet courant (l.394).
				bOK[6] = qry->BindParameter(7, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 4200, 0, (char*)info.pszBankPet, 0, &cbLen);
			}

			if (FALSE == qry->Exec(szQuery))
			{
				SAFE_DELETE_ARRAY(bOK);
				return;
			}

#ifdef __FL_PACKED_ITEMS
			SavePackages(qry, &pMover->m_Bank[i], pMover->m_idPlayerBank[i], PRT_BANK);
#endif
		}
	}

	SAFE_DELETE_ARRAY(bOK);
}

void CDbManager::UpdateGuildBankUpdate(CQuery* pQuery, CQuery* pQueryLog, LPDB_OVERLAPPED_PLUS lpDbOverlappedPlus)
{
	CAr							ar(lpDbOverlappedPlus->lpBuf, lpDbOverlappedPlus->uBufSize);
	CItemContainer<CItemElem>	GuildBank;
	int							nGoldGuild;
	int							nGuildId = 0;
	BYTE						cbUpdateContribution;
	u_long						idPlayer, idLogPlayer;
	int							nMode;		// GUILD_PUT_ITEM, GUILD_GET_ITEM, GUILD_PUT_PENYA, GUILD_GET_PENYA, GUILD_CLOAK
	DWORD						dwItemId;
	short						nItemCount;
	int							nAbilityOption;
	SERIALNUMBER	iSerialNumber;
	DWORD						dwPenya;
	GuildBank.SetItemContainer(ITYPE_ITEM, MAX_GUILDBANK);

	ar >> nGuildId;
	ar >> nGoldGuild;
	GuildBank.Serialize(ar);
	ar >> cbUpdateContribution;
	ar >> idPlayer;
	ar >> nMode;
	ar >> dwItemId;
	ar >> nAbilityOption;
	ar >> iSerialNumber;
	ar >> nItemCount;
	ar >> dwPenya;

	idLogPlayer = idPlayer;
	if (cbUpdateContribution != 1)
		idPlayer = 0;

	ItemContainerStruct icsGuildBank;
	SaveContainer(&GuildBank, &icsGuildBank);

#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
	// Seul conteneur restant en litteral T-SQL. Un litteral non-Unicode ne peut
	// pas etre type plus large que varchar(8000) : c'est le plafond reel de
	// szItem ici, quel que soit le TEXT de la colonne. Pire cas mesure : 3151.
	ZckCheckDbLen(icsGuildBank.szItem, 8000, "GUILD_BANK_TBL.m_GuildBank", (u_long)nGuildId);
	ZckCheckDbLen(icsGuildBank.szExt, 1296, "GUILD_BANK_EXT_TBL.m_extGuildBank", (u_long)nGuildId);
	ZckCheckDbLen(icsGuildBank.szPiercing, 8000, "GUILD_BANK_EXT_TBL.m_GuildBankPiercing", (u_long)nGuildId);
	ZckCheckDbLen(icsGuildBank.szPet, 4200, "GUILD_BANK_EXT_TBL.szGuildBankPet", (u_long)nGuildId);
#endif
	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery,
		"GUILD_BANK_STR 'U1','%06d','%02d','%d','%s','%s','%s','%07d','%s','%s','%s'",
		nGuildId, g_appInfo.dwSys, nGoldGuild, icsGuildBank.szIndex, icsGuildBank.szObjIndex, icsGuildBank.szItem, idPlayer, icsGuildBank.szExt, icsGuildBank.szPiercing, icsGuildBank.szPet);

	if (FALSE == pQuery->Exec(szQuery))
	{
		Error("update guild bank:%s ", szQuery);
		return;
	}

#ifdef __FL_PACKED_ITEMS
	SavePackages(pQuery, &GuildBank, nGuildId, PRT_GUILDBANK);
#endif

#ifndef __NOLOG
	GUILDLOG_QUERYINFO qi("L2");
	qi.idGuild = nGuildId;
	qi.idPlayer = idLogPlayer;
	qi.nGuildGold = nGoldGuild;

	switch (nMode)
	{
	case GUILD_PUT_ITEM:
		qi.pszState = "A";
		qi.nItem = dwItemId;
		qi.nAbilityOption = nAbilityOption;
		qi.iUniqueNo = iSerialNumber;
		qi.nItem_count = nItemCount;
		break;
	case GUILD_GET_ITEM:
		qi.pszState = "D";
		qi.nItem = dwItemId;
		qi.nAbilityOption = nAbilityOption;
		qi.iUniqueNo = iSerialNumber;
		qi.nItem_count = nItemCount;
		break;
	case GUILD_CLOAK:
		qi.pszState = "C";
		qi.nItem = dwItemId;
		qi.nAbilityOption = nAbilityOption;
		qi.iUniqueNo = iSerialNumber;
		qi.nItem_count = nItemCount;
		break;
	case GUILD_GET_PENYA:
		qi.pszState = "O";
		qi.nItem = dwPenya;
		break;
	case GUILD_QUERY_REMOVE_GUILD_BANK:
		qi.pszState = "R";
		break;
	}

	qi.pszGuildBank = icsGuildBank.szItem;

	DBQryGuildLog(szQuery, qi);
	if (FALSE == pQueryLog->Exec(szQuery))
	{

		return;
	}
#endif // __NOLOG

}


#if __VER >= 13
void	CDbManager::SaveHonor(CQuery* qry, u_long uidPlayer, int* aHonor, char* szQuery)
{
	int	aHonorEtc[50] = { 0, };
	int	aHonorItem[50] = { 0, };
	int	aHonorMonster[50] = { 0, };

	int nEtc = 0, nItem = 0, nMonster = 0;
	int nType = 0;
	int nCurrentTitleCount = CTitleManager::Instance()->m_nCurrentTitleCount;
	for (int i = 0; i < nCurrentTitleCount; i++)
	{
		nType = CTitleManager::Instance()->GetIdxType(i);
		if (nType == HI_HUNT_MONSTER)
		{
			aHonorMonster[nMonster] = aHonor[i];
			nMonster++;
		}
		else if (nType == HI_USE_ITEM)
		{
			aHonorItem[nItem] = aHonor[i];
			nItem++;
		}
		else
		{
			aHonorEtc[nEtc] = aHonor[i];
			nEtc++;
		}
	}

	sprintf(szQuery,
		"usp_Master_Update @serverindex='%02d',@m_idPlayer='%07d',@sec=%d,@c01=%d,@c02=%d,@c03=%d,@c04=%d,@c05=%d,@c06=%d,@c07=%d,@c08=%d,@c09=%d,@c10=%d,@c11=%d,@c12=%d,@c13=%d,@c14=%d,@c15=%d,@c16=%d,@c17=%d,@c18=%d,@c19=%d,@c20=%d,@c21=%d,@c22=%d,@c23=%d,@c24=%d,@c25=%d,@c26=%d,@c27=%d,@c28=%d,@c29=%d,@c30=%d,@c31=%d,@c32=%d,@c33=%d,@c34=%d,@c35=%d,@c36=%d,@c37=%d,@c38=%d,@c39=%d,@c40=%d,@c41=%d,@c42=%d,@c43=%d,@c44=%d,@c45=%d,@c46=%d,@c47=%d,@c48=%d,@c49=%d,@c50=%d",
		g_appInfo.dwSys, uidPlayer, 1,
		aHonorEtc[0], aHonorEtc[1], aHonorEtc[2], aHonorEtc[3], aHonorEtc[4], aHonorEtc[5], aHonorEtc[6], aHonorEtc[7], aHonorEtc[8], aHonorEtc[9],
		aHonorEtc[10], aHonorEtc[11], aHonorEtc[12], aHonorEtc[13], aHonorEtc[14], aHonorEtc[15], aHonorEtc[16], aHonorEtc[17], aHonorEtc[18], aHonorEtc[19],
		aHonorEtc[20], aHonorEtc[21], aHonorEtc[22], aHonorEtc[23], aHonorEtc[24], aHonorEtc[25], aHonorEtc[26], aHonorEtc[27], aHonorEtc[28], aHonorEtc[29],
		aHonorEtc[30], aHonorEtc[31], aHonorEtc[32], aHonorEtc[33], aHonorEtc[34], aHonorEtc[35], aHonorEtc[36], aHonorEtc[37], aHonorEtc[38], aHonorEtc[39],
		aHonorEtc[40], aHonorEtc[41], aHonorEtc[42], aHonorEtc[43], aHonorEtc[44], aHonorEtc[45], aHonorEtc[46], aHonorEtc[47], aHonorEtc[48], aHonorEtc[49]);

	if (FALSE == qry->Exec(szQuery))
	{
		WriteLog("%s, %d\t%s", __FILE__, __LINE__, szQuery);
		return;
	}

	sprintf(szQuery,
		"usp_Master_Update @serverindex='%02d',@m_idPlayer='%07d',@sec=%d,@c01=%d,@c02=%d,@c03=%d,@c04=%d,@c05=%d,@c06=%d,@c07=%d,@c08=%d,@c09=%d,@c10=%d,@c11=%d,@c12=%d,@c13=%d,@c14=%d,@c15=%d,@c16=%d,@c17=%d,@c18=%d,@c19=%d,@c20=%d,@c21=%d,@c22=%d,@c23=%d,@c24=%d,@c25=%d,@c26=%d,@c27=%d,@c28=%d,@c29=%d,@c30=%d,@c31=%d,@c32=%d,@c33=%d,@c34=%d,@c35=%d,@c36=%d,@c37=%d,@c38=%d,@c39=%d,@c40=%d,@c41=%d,@c42=%d,@c43=%d,@c44=%d,@c45=%d,@c46=%d,@c47=%d,@c48=%d,@c49=%d,@c50=%d",
		g_appInfo.dwSys, uidPlayer, 2,
		aHonorItem[0], aHonorItem[1], aHonorItem[2], aHonorItem[3], aHonorItem[4], aHonorItem[5], aHonorItem[6], aHonorItem[7], aHonorItem[8], aHonorItem[9],
		aHonorItem[10], aHonorItem[11], aHonorItem[12], aHonorItem[13], aHonorItem[14], aHonorItem[15], aHonorItem[16], aHonorItem[17], aHonorItem[18], aHonorItem[19],
		aHonorItem[20], aHonorItem[21], aHonorItem[22], aHonorItem[23], aHonorItem[24], aHonorItem[25], aHonorItem[26], aHonorItem[27], aHonorItem[28], aHonorItem[29],
		aHonorItem[30], aHonorItem[31], aHonorItem[32], aHonorItem[33], aHonorItem[34], aHonorItem[35], aHonorItem[36], aHonorItem[37], aHonorItem[38], aHonorItem[39],
		aHonorItem[40], aHonorItem[41], aHonorItem[42], aHonorItem[43], aHonorItem[44], aHonorItem[45], aHonorItem[46], aHonorItem[47], aHonorItem[48], aHonorItem[49]);

	if (FALSE == qry->Exec(szQuery))
	{
		WriteLog("%s, %d\t%s", __FILE__, __LINE__, szQuery);
		return;
	}

	sprintf(szQuery,
		"usp_Master_Update @serverindex='%02d',@m_idPlayer='%07d',@sec=%d,@c01=%d,@c02=%d,@c03=%d,@c04=%d,@c05=%d,@c06=%d,@c07=%d,@c08=%d,@c09=%d,@c10=%d,@c11=%d,@c12=%d,@c13=%d,@c14=%d,@c15=%d,@c16=%d,@c17=%d,@c18=%d,@c19=%d,@c20=%d,@c21=%d,@c22=%d,@c23=%d,@c24=%d,@c25=%d,@c26=%d,@c27=%d,@c28=%d,@c29=%d,@c30=%d,@c31=%d,@c32=%d,@c33=%d,@c34=%d,@c35=%d,@c36=%d,@c37=%d,@c38=%d,@c39=%d,@c40=%d,@c41=%d,@c42=%d,@c43=%d,@c44=%d,@c45=%d,@c46=%d,@c47=%d,@c48=%d,@c49=%d,@c50=%d",
		g_appInfo.dwSys, uidPlayer, 3,
		aHonorMonster[0], aHonorMonster[1], aHonorMonster[2], aHonorMonster[3], aHonorMonster[4], aHonorMonster[5], aHonorMonster[6], aHonorMonster[7], aHonorMonster[8], aHonorMonster[9],
		aHonorMonster[10], aHonorMonster[11], aHonorMonster[12], aHonorMonster[13], aHonorMonster[14], aHonorMonster[15], aHonorMonster[16], aHonorMonster[17], aHonorMonster[18], aHonorMonster[19],
		aHonorMonster[20], aHonorMonster[21], aHonorMonster[22], aHonorMonster[23], aHonorMonster[24], aHonorMonster[25], aHonorMonster[26], aHonorMonster[27], aHonorMonster[28], aHonorMonster[29],
		aHonorMonster[30], aHonorMonster[31], aHonorMonster[32], aHonorMonster[33], aHonorMonster[34], aHonorMonster[35], aHonorMonster[36], aHonorMonster[37], aHonorMonster[38], aHonorMonster[39],
		aHonorMonster[40], aHonorMonster[41], aHonorMonster[42], aHonorMonster[43], aHonorMonster[44], aHonorMonster[45], aHonorMonster[46], aHonorMonster[47], aHonorMonster[48], aHonorMonster[49]);

	if (FALSE == qry->Exec(szQuery))
	{
		WriteLog("%s, %d\t%s", __FILE__, __LINE__, szQuery);
		return;
	}


}

#endif

void CDbManager::SaveSkill(CQuery* qry, u_long uidPlayer, LPSKILL aJobSkill, LPBYTE abUpdateSkill, char* szQuery)
{
	for (int i = 0; i < MAX_SKILL_JOB; i++)
	{
		if (abUpdateSkill[i] == 0)
			continue;

		sprintf(szQuery,
			"uspLearnSkill @serverindex='%02d',@pPlayerID='%07d',@pSkillID=%d,@pSkillLv=%d,@pSkillPosition=%d",
			g_appInfo.dwSys, uidPlayer, aJobSkill[i].dwSkill, aJobSkill[i].dwLevel, i);

		if (FALSE == qry->Exec(szQuery))
		{
			WriteLog("%s, %d\t%s", __FILE__, __LINE__, szQuery);
			return;
		}
	}
}

void CDbManager::SaveJobLv(CMover* pMover, char* szJobLv)
{
	char OneJobLv[16] = { 0, };
	for (int i = 0; i < MAX_JOB; i++)
	{
		sprintf(OneJobLv, "%d/", 0);
		strncat(szJobLv, OneJobLv, sizeof(OneJobLv));
	}
	strncat(szJobLv, NullStr, sizeof(NullStr));
}

void CDbManager::SaveQuest(CMover* pMover, char* szQuestCnt, char* szm_aCompleteQuest, char* szCheckedQuest)
{
	char sPerQuest[128];
	char OneCompleteQuest[20] = { 0, };
	char OneCheckedQuest[20] = { 0, };

	for (int i = 0; i < pMover->m_nQuestSize; i++)
	{
		sprintf(sPerQuest, "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d/",
			pMover->m_aQuest[i].m_wId, pMover->m_aQuest[i].m_nState, pMover->m_aQuest[i].m_wTime,
			pMover->m_aQuest[i].m_nKillNPCNum[0], pMover->m_aQuest[i].m_nKillNPCNum[1],
			pMover->m_aQuest[i].m_bPatrol, pMover->m_aQuest[i].m_bReserve2, pMover->m_aQuest[i].m_bReserve3, pMover->m_aQuest[i].m_bReserve4,
			pMover->m_aQuest[i].m_bReserve5, pMover->m_aQuest[i].m_bReserve6, pMover->m_aQuest[i].m_bReserve7, pMover->m_aQuest[i].m_bReserve8
		);
		strncat(szQuestCnt, sPerQuest, sizeof(sPerQuest));
	}

	for (int i = 0; i < pMover->m_nCompleteQuestSize; i++)
	{
		sprintf(OneCompleteQuest, "%d/", pMover->m_aCompleteQuest[i]);
		strncat(szm_aCompleteQuest, OneCompleteQuest, sizeof(OneCompleteQuest));
	}

	strcat(szQuestCnt, NullStr);
	strcat(szm_aCompleteQuest, NullStr);

	for (int i = 0; i < pMover->m_nCheckedQuestSize; ++i)
	{
		sprintf(OneCheckedQuest, "%d/", pMover->m_aCheckedQuest[i]);
		strncat(szCheckedQuest, OneCheckedQuest, sizeof(OneCheckedQuest));
	}
	strcat(szCheckedQuest, NullStr);
}

#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
// Le strncat d'origine bornait la SOURCE, jamais la destination : avec 168 ou
// 200 emplacements, les chaines pouvaient depasser ItemContainerStruct et
// ecrire dans la trame de pile de SavePlayer (icsInventory et icsBank[3] sont
// des variables locales, l.94). Ici on reserve 2 octets pour le '$' final et
// le '\0', et on refuse l'ajout plutot que de deborder.
//
// Consequence voulue : une chaine saturee est tronquee A UNE FRONTIERE
// D'ENREGISTREMENT et reste terminee par '$' (l.879-890, inchangees). Une fois
// qu'un ajout echoue sur une chaine, l'appelant cesse d'y ajouter : le resultat
// est un PREFIXE, jamais un trou, donc aucune desynchronisation du parseur
// positionnel. Une saturation de szExt, szPiercing ou szPet coute donc des
// attributs sur les derniers emplacements -- jamais un objet.
static BOOL ZckAppendChain(char* szDst, size_t uCap, const char* szSrc, DWORD dwItemMax, const char* lpszWhat)
{
	const size_t uLen = strlen(szDst);
	const size_t uAdd = strlen(szSrc);
	if (uLen + uAdd + 2 > uCap)
	{
		Error("ZCK PERSIST OVERFLOW: tampon C++ %s sature (cap=%u len=%u ajout=%u conteneur=%u emplacements)",
			lpszWhat, (unsigned)uCap, (unsigned)uLen, (unsigned)uAdd, (unsigned)dwItemMax);
		return FALSE;
	}
	memcpy(szDst + uLen, szSrc, uAdd + 1);
	return TRUE;
}
#endif

void CDbManager::SaveContainer(CItemContainer<CItemElem  >* pContainer, ItemContainerStruct* pStruct)
{
	ItemStruct	is;
	char Onem_apIndex[10] = { 0, };
	char sPerObjIndex[16] = { 0, };
	BOOL bExtInven = FALSE;
	BOOL bPirecingInven = FALSE;
	BOOL bPet = FALSE;
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
	BOOL bFitItem = TRUE, bFitExt = TRUE, bFitPiercing = TRUE;
	BOOL bFitIndex = TRUE, bFitObjIndex = TRUE, bFitPet = TRUE;
#endif

	for (DWORD ch = 0; ch < pContainer->m_dwItemMax; ch++)
	{
		SaveOneItem(&pContainer->m_apItem[ch], &is);
		sprintf(Onem_apIndex, "%d/", pContainer->m_apIndex[ch]);
		sprintf(sPerObjIndex, "%d/", pContainer->m_apItem[ch].m_dwObjIndex);
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
		if (bFitItem)
			bFitItem = ZckAppendChain(pStruct->szItem, sizeof(pStruct->szItem), is.szItem, pContainer->m_dwItemMax, "szItem");
		if (bFitExt)
			bFitExt = ZckAppendChain(pStruct->szExt, sizeof(pStruct->szExt), is.szExt, pContainer->m_dwItemMax, "szExt");
		if (bFitPiercing)
			bFitPiercing = ZckAppendChain(pStruct->szPiercing, sizeof(pStruct->szPiercing), is.szPiercing, pContainer->m_dwItemMax, "szPiercing");
		if (bFitIndex)
			bFitIndex = ZckAppendChain(pStruct->szIndex, sizeof(pStruct->szIndex), Onem_apIndex, pContainer->m_dwItemMax, "szIndex");
		if (bFitObjIndex)
			bFitObjIndex = ZckAppendChain(pStruct->szObjIndex, sizeof(pStruct->szObjIndex), sPerObjIndex, pContainer->m_dwItemMax, "szObjIndex");
		if (bFitPet)
			bFitPet = ZckAppendChain(pStruct->szPet, sizeof(pStruct->szPet), is.szPet, pContainer->m_dwItemMax, "szPet");
#else
		strncat(pStruct->szItem, is.szItem, sizeof(is.szItem));
		strncat(pStruct->szExt, is.szExt, sizeof(is.szExt));
		strncat(pStruct->szPiercing, is.szPiercing, sizeof(is.szPiercing));
		strncat(pStruct->szIndex, Onem_apIndex, sizeof(Onem_apIndex));
		strcat(pStruct->szObjIndex, sPerObjIndex);
		strncat(pStruct->szPet, is.szPet, sizeof(is.szPet));
#endif

		if (0 < pContainer->m_apItem[ch].m_dwKeepTime
			|| 0 != pContainer->m_apItem[ch].GetRandomOptItemId()
			|| FALSE != pContainer->m_apItem[ch].m_bTranformVisPet
			)
			bExtInven = TRUE;
		if (pContainer->m_apItem[ch].IsPiercedItem())
			bPirecingInven = TRUE;
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
		// szPiercing porte desormais les champs custom. Sans ce drapeau, le
		// test l.884-885 plus bas effacerait la chaine entiere et perdrait les
		// valeurs de TOUS les objets du conteneur, en silence, des que le
		// conteneur ne contient aucun objet perce. Meme predicat que
		// l'ecriture, pour qu'ils ne puissent pas diverger.
		if (ZckHasDbExtra(&pContainer->m_apItem[ch]))
			bPirecingInven = TRUE;
#endif
		if (pContainer->m_apItem[ch].m_pPet)
			bPet = TRUE;
	}

	strncat(pStruct->szItem, NullStr, sizeof(NullStr));
	strncat(pStruct->szIndex, NullStr, sizeof(NullStr));
	strcat(pStruct->szObjIndex, NullStr);
	if (bExtInven == FALSE)
		*pStruct->szExt = '\0';
	if (bPirecingInven == FALSE)
		*pStruct->szPiercing = '\0';
	if (bPet == FALSE)
		*pStruct->szPet = '\0';
	strcat(pStruct->szExt, NullStr);
	strcat(pStruct->szPiercing, NullStr);
	strcat(pStruct->szPet, NullStr);
}


void CDbManager::SaveTaskBar(CMover* pMover, char* szAppletTaskBar, char* szItemTaskBar, char* szSkillTaskBar)
{
	char OneAppletTaskBar[MAX_TASKBAR] = { 0, };
	char OneItemTaskBar[MAX_TASKBAR] = { 0, };
	char OneSkillTaskBar[256] = { 0, };
	for (int ch = 0; ch < MAX_SLOT_APPLET; ch++)
	{
		if (pMover->m_UserTaskBar.m_aSlotApplet[ch].m_dwShortcut != SHORTCUT_NONE)
		{
			sprintf(OneAppletTaskBar, "%d,%d,%d,%d,%d,%d,%d,%d", ch,
				pMover->m_UserTaskBar.m_aSlotApplet[ch].m_dwShortcut, pMover->m_UserTaskBar.m_aSlotApplet[ch].m_dwId, pMover->m_UserTaskBar.m_aSlotApplet[ch].m_dwType,
				pMover->m_UserTaskBar.m_aSlotApplet[ch].m_dwIndex, pMover->m_UserTaskBar.m_aSlotApplet[ch].m_dwUserId, pMover->m_UserTaskBar.m_aSlotApplet[ch].m_dwData,
				pMover->m_UserTaskBar.m_aSlotApplet[ch].m_nLocation
			);

			if (pMover->m_UserTaskBar.m_aSlotApplet[ch].m_dwShortcut == SHORTCUT_CHAT)
				SetStrDBFormat(OneAppletTaskBar, pMover->m_UserTaskBar.m_aSlotApplet[ch].m_szString);

			strncat(szAppletTaskBar, OneAppletTaskBar, sizeof(OneAppletTaskBar));
			strcat(szAppletTaskBar, "/");
		}
	}
	strcat(szAppletTaskBar, NullStr);

	for (int ch = 0; ch < MAX_SLOT_ITEM_COUNT; ch++)
	{
		for (int j = 0; j < MAX_SLOT_ITEM; j++)
		{
			if (pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_dwShortcut != SHORTCUT_NONE)
			{
				sprintf(OneItemTaskBar, "%d,%d,%d,%d,%d,%d,%d,%d,%d", ch, j,
					pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_dwShortcut, pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_dwId, pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_dwType,
					pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_dwIndex, pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_dwUserId, pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_dwData,
					pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_nLocation
				);
				if (pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_dwShortcut == SHORTCUT_CHAT)
					SetStrDBFormat(OneItemTaskBar, pMover->m_UserTaskBar.m_aSlotItem[ch][j].m_szString);

				strncat(szItemTaskBar, OneItemTaskBar, sizeof(OneItemTaskBar));
				strcat(szItemTaskBar, "/");
			}
		}
	}
	strcat(szItemTaskBar, NullStr);

	for (int ch = 0; ch < MAX_SLOT_QUEUE_COUNT; ch++)
	{
		for (int i = 0; i < MAX_SLOT_QUEUE; i++)
		{
			if (pMover->m_UserTaskBar.m_aSlotQueue[ch][i].m_dwShortcut != SHORTCUT_NONE)
			{
				sprintf(OneSkillTaskBar, "%d,%d,%d,%d,%d,%d,%d,%d,%d/", ch, i,
					pMover->m_UserTaskBar.m_aSlotQueue[ch][i].m_dwShortcut, pMover->m_UserTaskBar.m_aSlotQueue[ch][i].m_dwId, pMover->m_UserTaskBar.m_aSlotQueue[ch][i].m_dwType,
					pMover->m_UserTaskBar.m_aSlotQueue[ch][i].m_dwIndex, pMover->m_UserTaskBar.m_aSlotQueue[ch][i].m_dwUserId, pMover->m_UserTaskBar.m_aSlotQueue[ch][i].m_dwData,
					pMover->m_UserTaskBar.m_aSlotQueue[ch][i].m_nLocation
				);
				strncat(szSkillTaskBar, OneSkillTaskBar, sizeof(OneSkillTaskBar));
			}
		}
	}

	strcat(szSkillTaskBar, NullStr);
}

void CDbManager::SaveSMCode(CMover* pMover, char* szszSMTime)
{
	BOOL bSMSave = FALSE;
	for (int ch = 0; ch < SM_MAX; ++ch)
	{
		if (0 < pMover->m_dwSMTime[ch])
		{
			bSMSave = TRUE;
		}
		char OneSMTime[256] = { 0, };
		if (ch == SM_MAX_HP50)
			sprintf(OneSMTime, "%d,%d,", pMover->m_dwSMTime[ch], pMover->m_nPlusMaxHitPoint);
		else
			sprintf(OneSMTime, "%d,", pMover->m_dwSMTime[ch]);

		strcat(szszSMTime, OneSMTime);
	}
	strcat(szszSMTime, NullStr);

	if (bSMSave == FALSE)
	{
		memset(szszSMTime, 0, sizeof(szszSMTime));
	}
}

void CDbManager::SaveSkillInfluence(CMover* pMover, char* szszSkillInfluence)
{
#ifdef __BUFF_1107
	pMover->m_buffs.ToString(szszSkillInfluence);
#else	// __BUFF_1107
	char OneSkillInfluence[256] = { 0, };
	for (int ch = 0; ch < MAX_SKILLINFLUENCE; ++ch)
	{
		SKILLINFLUENCE* pSkillInfluenece = &pMover->m_SkillState.m_aSkillInfluence[ch];
		if (pSkillInfluenece->wType == BUFF_EQUIP)
			continue;
#if __VER >= 13 // __HOUSING
		if (pSkillInfluenece->wType == 0 && pSkillInfluenece->wID == 0
			&& pSkillInfluenece->dwLevel == 0 && pSkillInfluenece->tmCount == 0)
			break;
#endif // __HOUSING
		sprintf(OneSkillInfluence, "%d,%d,%d,%d/",
			pSkillInfluenece->wType, pSkillInfluenece->wID,
			pSkillInfluenece->dwLevel, pSkillInfluenece->tmCount);
		strcat(szszSkillInfluence, OneSkillInfluence);
	}
	strcat(szszSkillInfluence, NullStr);
#endif	// __BUFF_1107
}

void CDbManager::SavePlayTime(CQuery* qry, LPDB_OVERLAPPED_PLUS lpDbOverlappedPlus)
{
	CAr arRead(lpDbOverlappedPlus->lpBuf, lpDbOverlappedPlus->uBufSize);

	DWORD dwTime;
	arRead.ReadString(lpDbOverlappedPlus->AccountInfo.szAccount, MAX_ACCOUNT);
	u_long idPlayer;
	arRead >> idPlayer;
	arRead >> dwTime;
	dwTime /= 1000;

	char szQuery[QUERY_SIZE] = { 0, };
	DBQryCharacter(szQuery, "U3", idPlayer, g_appInfo.dwSys, '\0', "", dwTime);

	if (FALSE == qry->Exec(szQuery))
	{
		WriteLog("%s, %d\t%s\r\n\t%s", __FILE__, __LINE__, szQuery, lpDbOverlappedPlus->AccountInfo.szPlayer);
	}
}

void CDbManager::DBQryAddBankSave(char* szSql, const ADDBANK_QUERYINFO& info)
{
	sprintf(szSql, "{call ADD_BANK_STR('U1','%07d','%02d', ?, ?, ?, ?, ?, ?, ?)}", info.idPlayer, g_appInfo.dwSys);
}

void CDbManager::SaveOneItem(CItemElem* pItemElem, ItemStruct* pItemStruct)
{
	char szPiercing[32] = { 0, };

	if (pItemElem->IsEmpty() == FALSE)
	{
		sprintf(pItemStruct->szItem, "%d,%d,%s,%d,%d,%d,%d,%d,%d,%d"
#ifdef __FL_CATCH_THE_PET // todo: create separate column as it's done for szPet / m_pPet
			",%d,%d,%d,%d,%d,%d"
#endif
#ifdef __FL_ITEM_RUNE
			",%d"
#endif // 
#ifdef __FL_GUARANTEED_UPGRADE
			",%d"
			",%d"
			",%d"
#endif
			// __ZCK_RARE, __ZCK_NIVEAU_ARME et __ZCK_SYSTEME_EVEIL ont quitte
			// szItem : budget banque 4290 / 42 emplacements = 102 octets, dont
			// 75 pour l'enregistrement de base. Ils sont ecrits en fin
			// d'enregistrement szPiercing, plus bas dans cette fonction.
			// GetOneItem continue de les RELIRE pour les lignes deja en base :
			// les lecteurs ...PaFromStr rendent 0 sans avancer quand le champ
			// est absent, donc la boucle reste alignee dans les deux cas.
			"/",
			pItemElem->m_dwObjId, pItemElem->m_dwItemId,
			pItemElem->m_szItemText,
			pItemElem->m_nItemNum,
			pItemElem->m_nHitPoint,
			pItemElem->m_byFlag,
			pItemElem->GetSerialNumber(), pItemElem->GetOption(),
			pItemElem->m_bItemResist, pItemElem->m_nResistAbilityOption
#ifdef __FL_CATCH_THE_PET
			, pItemElem->m_pCatchedPet ? TRUE : FALSE
			, pItemElem->m_pCatchedPet ? pItemElem->m_pCatchedPet->GetMonsterID() : NULL_ID
			, pItemElem->m_pCatchedPet ? pItemElem->m_pCatchedPet->GetLevel() : 0
			, pItemElem->m_pCatchedPet ? pItemElem->m_pCatchedPet->GetExp() : 0
			, pItemElem->m_pCatchedPet ? pItemElem->m_pCatchedPet->GetRandomDST().at(0) : NULL_ID
			, pItemElem->m_pCatchedPet ? pItemElem->m_pCatchedPet->GetRandomDST().at(1) : NULL_ID
#endif
#ifdef __FL_ITEM_RUNE
			, pItemElem->m_dwRune
#endif
#ifdef __FL_GUARANTEED_UPGRADE
			, pItemElem->m_nGuaranteedUpgrade
			, pItemElem->m_nGuaranteedPiercing
			, pItemElem->m_nGuaranteedElement
#endif
		);

		sprintf(pItemStruct->szExt, "%d,%I64d"
			",%d"
			"/", pItemElem->m_dwKeepTime, pItemElem->GetRandomOptItemId()
			, static_cast<int>(pItemElem->m_bTranformVisPet)
		);

		ItemProp* itemProp = prj.GetItemProp(pItemElem->m_dwItemId);
		if (itemProp && itemProp->IsUltimate())
		{
			sprintf(pItemStruct->szPiercing, "%d", pItemElem->GetUltimatePiercingSize());
			for (int nPirecing = 0; nPirecing < pItemElem->GetUltimatePiercingSize(); ++nPirecing)
			{
				sprintf(szPiercing, ",%d", pItemElem->GetUltimatePiercingItem(nPirecing));
				strncat(pItemStruct->szPiercing, szPiercing, sizeof(szPiercing));
			}

			sprintf(szPiercing, ",%d", pItemElem->GetPiercingSize());
			strncat(pItemStruct->szPiercing, szPiercing, sizeof(szPiercing));

		}
		else
			sprintf(pItemStruct->szPiercing, "%d", pItemElem->GetPiercingSize());

		for (int nPirecing = 0; nPirecing < pItemElem->GetPiercingSize(); ++nPirecing)
		{
			sprintf(szPiercing, ",%d", pItemElem->GetPiercingItem(nPirecing));
			strncat(pItemStruct->szPiercing, szPiercing, sizeof(szPiercing));
		}
		if (pItemElem->IsVisPet())
		{
			for (int nPirecing = 0; nPirecing < pItemElem->GetPiercingSize(); ++nPirecing)
			{
				sprintf(szPiercing, ",%d", pItemElem->GetVisKeepTime(nPirecing));
				strncat(pItemStruct->szPiercing, szPiercing, sizeof(szPiercing));
			}
		}
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
		// Canal unique des champs custom, EN DERNIER dans l'enregistrement,
		// juste avant le '/'. Relu par LoadPiercingInfo (DbManagerFun.cpp
		// l.370). Rien n'est ecrit si l'objet ne porte aucune valeur : un
		// vis-pet, pire enregistrement szPiercing, ne paie donc rien.
		{
			char szZckExtra[ZCK_DB_EXTRA_BUF] = { 0, };
			ZckFormatDbExtra(szZckExtra, pItemElem);
			if (szZckExtra[0] != '\0')
				strncat(pItemStruct->szPiercing, szZckExtra, sizeof(szZckExtra));
		}
#ifdef __ZCK_ARME_REBORN
		// Emplacements de pierres Reborn : DERNIER champ du bloc custom, jeton
		// base 62 de ZCK_ARME_REBORN_JETON_LONG caracteres (ZckArmeReborn.h),
		// ecrit seulement si une pierre est posee. Relu par LoadPiercingInfo.
		// Cout maximal : 31 octets ; pire enregistrement d'arme = 144 + 31 = 175
		// octets (szPiercing fait 512), soit 42 * 175 + 1 = 7351 <= 7800 en
		// banque (voir ZCK_ARME_REBORN.md).
		if (pItemElem->GetZckRebornNbPierres() > 0)
		{
			char szZckJeton[ZCK_ARME_REBORN_JETON_TAILLE + 1] = { 0, };
			szZckJeton[0] = ',';
			pItemElem->GetZckRebornJeton(szZckJeton + 1);
			strcat(pItemStruct->szPiercing, szZckJeton);
		}
#endif // __ZCK_ARME_REBORN
#endif
		strcat(pItemStruct->szPiercing, "/");

		// pet
		if (pItemElem->m_pPet)
		{
			sprintf(pItemStruct->szPet, "1,%d,%d,%d,%d,%d",
				pItemElem->m_pPet->GetKind(), pItemElem->m_pPet->GetLevel(),
				pItemElem->m_pPet->GetExp(), pItemElem->m_pPet->GetEnergy(),
				pItemElem->m_pPet->GetLife());
			for (int i = PL_D; i <= pItemElem->m_pPet->GetLevel(); i++)
			{
				char szAvailLevel[16] = { 0, };
				sprintf(szAvailLevel, ",%d", pItemElem->m_pPet->GetAvailLevel(i));
				strcat(pItemStruct->szPet, szAvailLevel);
			}
#ifdef __PET_1024
			char szTemp[MAX_PET_NAME_FMT + 1] = { 0, };
			char szFmt[MAX_PET_NAME_FMT] = { 0, };
			SetDBFormatStr(szFmt, MAX_PET_NAME_FMT, pItemElem->m_pPet->GetName());
			sprintf(szTemp, ",%s", szFmt);
			strcat(pItemStruct->szPet, szTemp);
#endif
			strcat(pItemStruct->szPet, "/");
		}
		else
		{
			sprintf(pItemStruct->szPet, "0/");
		}
	}
	else
	{
		// item
		ZeroMemory(pItemStruct->szItem, sizeof(pItemStruct->szItem));
		// ext
		sprintf(pItemStruct->szExt, "%d,%d,%d/", 0, 0, 0);
		// piercing
		sprintf(pItemStruct->szPiercing, "%d/", 0);
		// pet
		sprintf(pItemStruct->szPet, "0/");
	}
}

#ifdef __FL_CONSUMABLES_STORAGE
bool CDbManager::SaveChest(CMover* pMover, CQuery* qry)
{
	ItemContainerStruct icsChest;
	SaveContainer(&pMover->m_Chest, &icsChest);

	// Le coffre est le plus gros conteneur du jeu : MAX_CHEST = 168
	// emplacements (_Common/ProjectCmn.h l.57). Ses six chaines etaient
	// assemblees en LITTERAL dans un tampon de PILE de QUERY_SIZE octets
	// (_Database/DbManager.h l.25). Pire cas mesure : 46542 contre 40960. Un
	// depassement la n'etait pas une troncature, c'etait un ecrasement de pile.
	//
	// Elles passent desormais en parametres lies, sur la MEME procedure et les
	// MEMES colonnes. Trois plafonds tombent d'un seul geste :
	//   - le tampon de pile : la requete fait 47 octets, quel que soit le coffre ;
	//   - le plafond du litteral T-SQL non-Unicode (un litteral ne peut pas etre
	//     type plus large que varchar(8000), meme affecte a un varchar(MAX)) ;
	//   - l'apostrophe dans un texte d'objet, qui casserait le litteral.
	//
	// Motif identique a DBQryAddBankSave (l.1030) : literaux pour les deux
	// premiers parametres, '?' pour les six chaines, liaison juste avant Exec.
	// SQL_VARCHAR avec ColumnSize 0 pour les varchar(MAX), comme l.353.
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME) || defined(__ZCK_SYSTEME_EVEIL)
	ZckCheckDbLen(icsChest.szIndex, 2048, "CHEST_TBL.m_apIndexChest", pMover->m_idPlayer);
	ZckCheckDbLen(icsChest.szObjIndex, 2048, "CHEST_TBL.m_dwObjIndexChest", pMover->m_idPlayer);
	ZckCheckDbLen(icsChest.szExt, 8000, "CHEST_TBL.m_extChest", pMover->m_idPlayer);
#endif
	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "{call uspChestSave('%07d','%02d',?,?,?,?,?,?)}",
		pMover->m_idPlayer, g_appInfo.dwSys);

	SQLINTEGER cbLen = SQL_NTS;
	qry->BindParameter(1, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 0, 0, icsChest.szItem, 0, &cbLen);
	qry->BindParameter(2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2048, 0, icsChest.szIndex, 0, &cbLen);
	qry->BindParameter(3, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 2048, 0, icsChest.szObjIndex, 0, &cbLen);
	qry->BindParameter(4, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 8000, 0, icsChest.szExt, 0, &cbLen);
	qry->BindParameter(5, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 0, 0, icsChest.szPiercing, 0, &cbLen);
	qry->BindParameter(6, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 0, 0, icsChest.szPet, 0, &cbLen);

	if (!qry->Exec(szQuery))
	{
		Error("CDbManager::uspChestSave[Line:%u] Failed Exec, Query: %s", __LINE__, szQuery);
		return false;
	}

	return true;
}
#endif

#ifdef __FL_EQUALIZED_MODE
void CDbManager::SaveTemporalEquipment(CQuery* pQueryChar, LPDB_OVERLAPPED_PLUS lpDbOverlappedPlus)
{
	CAr ar(lpDbOverlappedPlus->lpBuf, lpDbOverlappedPlus->uBufSize);

	DWORD dwWorldID;
	DWORD dwSex;
	int nJob;
	CItemContainer<CItemElem>tmpInventory;

	ar >> dwWorldID >> dwSex >> nJob;
	tmpInventory.SetItemContainer(ITYPE_ITEM, MAX_INVENTORY, MAX_HUMAN_PARTS);
	tmpInventory.Serialize(ar);

	ItemContainerStruct icsTemporal;
	SaveContainer(&tmpInventory, &icsTemporal);

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "uspTemporalPresetsSave %d, %d, %d, '%s', '%s', '%s', '%s', '%s', '%s'",
		dwWorldID, dwSex, nJob, icsTemporal.szItem, icsTemporal.szPet, icsTemporal.szExt, icsTemporal.szPiercing, icsTemporal.szIndex, icsTemporal.szObjIndex);

	if (!pQueryChar->Exec(szQuery))
	{
		Error("CDbManager::uspTemporalPresetsSave[Line:%u] Failed Exec, Query: %s", __LINE__, szQuery);
		return;
	}
}
#endif

#ifdef __FL_VENDORS
void CDbManager::AddVendor(CQuery* pQueryChar, LPDB_OVERLAPPED_PLUS lpDbOverlappedPlus)
{
	CAr ar(lpDbOverlappedPlus->lpBuf, lpDbOverlappedPlus->uBufSize);

	// Receive data begin
	u_long idPlayer;
	DWORD dwWorldId;
	D3DXVECTOR3 vecPos;
	float fAngle;
	char szShopName[64] = { 0, };
	time_t dwVendorTime;
	DWORD dwVendorItem;
	CItemContainer<CItemElem>tmpInventory;
	tmpInventory.SetItemContainer(ITYPE_ITEM, MAX_VENDITEM);

	int nCost[MAX_VENDITEM] = { };
	int nPerinCost[MAX_VENDITEM] = { };

	ar >> idPlayer >> dwWorldId >> vecPos >> fAngle;
	ar >> dwVendorTime;
	ar >> dwVendorItem;
	ar.ReadString(szShopName, 64);
	tmpInventory.Serialize(ar);

	// Serialize prices
	int nItemsCount;
	ar >> nItemsCount;

	for (int i = 0; i < nItemsCount; i++)
	{
		BYTE nIndex;
		ar >> nIndex;

		ar >> nCost[nIndex];
		ar >> nPerinCost[nIndex];
	}

	CString strShopName = szShopName;
	strShopName.Replace("--", "");
	strShopName.Replace("'", "");
	strShopName.Replace("/*", "");
	strShopName.Replace("*/", "");
	strShopName.Replace(";", "");
	if (strShopName.IsEmpty())
		strShopName.Format("Vendor Shop");
	// Receive data end

	ItemContainerStruct icsInventory;
	SaveContainer(&tmpInventory, &icsInventory);

	char szPrice[1024] = { 0, };
	char szOneItemPrice[128] = { 0, };

	for (int i = 0; i < MAX_VENDITEM; i++)
	{
		sprintf(szOneItemPrice, "%d,%d/", nCost[i], nPerinCost[i]);
		strcat(szPrice, szOneItemPrice);
	}
	strcat(szPrice, NullStr);


	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "uspOfflineVendorSave '%07d', '%02d', %d, %1.2f, %1.2f, %1.2f, %1.2f, %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'",
		idPlayer, g_appInfo.dwSys, dwWorldId, vecPos.x, vecPos.y, vecPos.z, fAngle, dwVendorTime, dwVendorItem, strShopName,
		icsInventory.szItem, icsInventory.szPet, icsInventory.szExt, icsInventory.szPiercing, icsInventory.szIndex, icsInventory.szObjIndex, szPrice);

	if (!pQueryChar->Exec(szQuery))
	{
		Error("CDbManager::uspOfflineVendorSave[Line:%u] Failed Exec, Query: %s", __LINE__, szQuery);
		return;
	}

#ifdef __FL_PACKED_ITEMS
	SavePackages(pQueryChar, &tmpInventory, idPlayer, PRT_VENDORS);
#endif
}
void CDbManager::UpdateVendor(CQuery* pQueryChar, LPDB_OVERLAPPED_PLUS lpDbOverlappedPlus)
{
	CAr ar(lpDbOverlappedPlus->lpBuf, lpDbOverlappedPlus->uBufSize);

	// Receive data begin
	u_long idPlayer;
	CItemContainer<CItemElem>tmpInventory;
	tmpInventory.SetItemContainer(ITYPE_ITEM, MAX_VENDITEM);

	int nCost[MAX_VENDITEM] = { };
	int nPerinCost[MAX_VENDITEM] = { };

	ar >> idPlayer;
	tmpInventory.Serialize(ar);

	// Serialize prices
	int nItemsCount;
	ar >> nItemsCount;

	for (int i = 0; i < nItemsCount; i++)
	{
		BYTE nIndex;
		ar >> nIndex;

		ar >> nCost[nIndex];
		ar >> nPerinCost[nIndex];
	}
	// Receive data end

	ItemContainerStruct icsInventory;
	SaveContainer(&tmpInventory, &icsInventory);

	char szPrice[1024] = { 0, };
	char szOneItemPrice[128] = { 0, };

	for (int i = 0; i < MAX_VENDITEM; i++)
	{
		sprintf(szOneItemPrice, "%d,%d/", nCost[i], nPerinCost[i]);
		strcat(szPrice, szOneItemPrice);
	}
	strcat(szPrice, NullStr);

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "uspOfflineVendorUpdate '%07d', '%02d', '%s', '%s', '%s', '%s', '%s', '%s', '%s'",
		idPlayer, g_appInfo.dwSys, icsInventory.szItem, icsInventory.szPet, icsInventory.szExt, icsInventory.szPiercing, icsInventory.szIndex, icsInventory.szObjIndex, szPrice);

	if (!pQueryChar->Exec(szQuery))
	{
		Error("CDbManager::uspOfflineVendorUpdate[Line:%u] Failed Exec, Query: %s", __LINE__, szQuery);
		return;
	}

#ifdef __FL_PACKED_ITEMS
	SavePackages(pQueryChar, &tmpInventory, idPlayer, PRT_VENDORS);
#endif
}
void CDbManager::DeleteVendor(CQuery* pQueryChar, LPDB_OVERLAPPED_PLUS lpDbOverlappedPlus)
{
	CAr ar(lpDbOverlappedPlus->lpBuf, lpDbOverlappedPlus->uBufSize);

	u_long idPlayer;
	ar >> idPlayer;

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "uspOfflineVendorDelete '%07d', '%02d'", idPlayer, g_appInfo.dwSys);
	if (!pQueryChar->Exec(szQuery))
	{
		Error("CDbManager::uspOfflineVendorDelete[Line:%u] Failed, Query: %s", __LINE__, szQuery);
		return;
	}

#ifdef __FL_PACKED_ITEMS
	SavePackages(pQueryChar, nullptr, idPlayer, PRT_VENDORS);
#endif
}
#endif

#ifdef __FL_SWITCH_EQ
void CDbManager::SaveSwitches(CMover* pMover, CQuery* qry)
{
	auto vecSwitches = pMover->m_Switches.GetSwitches();

	char SwitchesNames[2048] = { 0, };
	char SwitchesParts[2048] = { 0, };
	char SwitchesOther[2048] = { 0, };

	char szTmp[65] = { 0, };

	for (auto& it : *vecSwitches)
	{
		SetDBFormatStr(szTmp, 65, it.szSwitchName);
		sprintf(szTmp, "%s/", szTmp);
		strcat(SwitchesNames, szTmp);

		for (int i = 0; i < MAX_HUMAN_PARTS; i++)
		{
			sprintf(szTmp, "%d,", it.dwItem[i]);
			strncat(SwitchesParts, szTmp, sizeof(SwitchesParts));
		}

		sprintf(szTmp, "%d,", it.dwLooterPet);
		strncat(SwitchesOther, szTmp, sizeof(SwitchesOther));

		sprintf(szTmp, "%d,", it.dwPet);
		strncat(SwitchesOther, szTmp, sizeof(SwitchesOther));

		sprintf(szTmp, "%d,", it.dwRegen);
		strncat(SwitchesOther, szTmp, sizeof(SwitchesOther));

		sprintf(szTmp, "%d,", it.dwNewPet);
		strncat(SwitchesOther, szTmp, sizeof(SwitchesOther));

		SwitchesParts[strlen(SwitchesParts) - 1] = '/';
		SwitchesOther[strlen(SwitchesOther) - 1] = '/';
	}

	strcat(SwitchesNames, NullStr);
	strcat(SwitchesParts, NullStr);
	strcat(SwitchesOther, NullStr);

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "uspSwitchesSave '%07d', '%02d', '%s', '%s', '%s'",
		pMover->m_idPlayer, g_appInfo.dwSys, SwitchesNames, SwitchesParts, SwitchesOther);

	if (!qry->Exec(szQuery))
	{
		Error("CDbManager::uspSwitchesSave[Line:%u] Failed Exec, Query: %s", __LINE__, szQuery);
		return;
	}
}
#endif

#ifdef __FL_RECORD_BOOK
void CDbManager::SaveRecords(CMover* pMover, CQuery* qry)
{
	CString strQuery;
	strQuery.Format("uspRecordsSave @iserverindex='%02d', @im_idPlayer='%07d'", g_appInfo.dwSys, pMover->m_idPlayer);

	CString strParams;
	strParams.Preallocate(64 * RecordType::MAX_RECORDTYPE);

	for (int i = 0; i < RecordType::MAX_RECORDTYPE; i++)
		strParams.AppendFormat(", @irc_%d='%d,%d,%I64d,%d'", i, pMover->m_arrayRecords[i].nLevel, pMover->m_arrayRecords[i].nJob, pMover->m_arrayRecords[i].n64Value, pMover->m_arrayRecords[i].tmRecord);

	strQuery += strParams;

	if (!qry->Exec(strQuery))
	{
		Error("Cannot execute %s", strQuery);
		return;
	}
}
#endif

#ifdef __FL_MONSTER_ALBUM
void CDbManager::SaveMonsterAlbum(CMover* pMover, CQuery* qry)
{
	auto pMapMonsters = pMover->m_MonsterAlbum.GetMonsterProgress();
	auto pBossCards = pMover->m_MonsterAlbum.GetBossCards();

	char stringMonsters[2048] = { 0, };
	char stringBossCards[256] = { 0, };
	char szTmp[65] = { 0, };

	for (auto& it : *pMapMonsters)
	{
		sprintf(szTmp, "%d,%d,", it.first, it.second);
		strncat(stringMonsters, szTmp, sizeof(stringMonsters));

		stringMonsters[strlen(stringMonsters) - 1] = '/';
	}

	for (auto& it : *pBossCards)
	{
		sprintf(szTmp, "%d,", it);
		strncat(stringBossCards, szTmp, sizeof(stringBossCards));

		stringBossCards[strlen(stringBossCards) - 1] = '/';
	}

	strcat(stringMonsters, NullStr);
	strcat(stringBossCards, NullStr);

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "uspMonsterAlbumSave '%07d', '%02d', '%s', '%s'",
		pMover->m_idPlayer, g_appInfo.dwSys, stringMonsters, stringBossCards);

	if (!qry->Exec(szQuery))
	{
		Error("Cannot execute %s", szQuery);
		return;
	}
}
#endif

#ifdef __FL_SEASON_PASS
void CDbManager::SaveSeasonPass(CMover* pMover, CQuery* qry)
{
	auto& refSeasonPasses = pMover->m_SeasonPass.GetSeasonPasses();

	char szSeasonPasses[2048] = { 0, };
	char szSeasonPass[64] = { 0, };

	for (auto& it : refSeasonPasses)
	{
		sprintf(szSeasonPass, "%d,%d,%d,%d,%d/", it.first, it.second.nCurrentLevel, it.second.nCurrentExp, it.second.nLastPickedLevel, it.second.bUnlockedPaidList);
		strncat(szSeasonPasses, szSeasonPass, sizeof(szSeasonPasses));
	}

	strcat(szSeasonPasses, NullStr);

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "usp_SeasonPass_Update '%07d', '%02d', '%s'", pMover->m_idPlayer, g_appInfo.dwSys, szSeasonPasses);

	if (!qry->Exec(szQuery))
	{
		Error("Cannot execute %s", szQuery);
		return;
	}
}
#endif

#ifdef __FL_WARDROBE
void CDbManager::SaveWardrobe(CMover* pMover, CQuery* qry)
{
	auto& refUnlockedItems = pMover->m_Wardrobe.GetUnlockedItems();
	auto& refPresets = pMover->m_Wardrobe.GetPresets();

	char szUnlockedItems[4096] = { 0, };
	char szPresets[1024] = { 0, };

	char szTmp[65] = { 0, };
	for (auto& it : refUnlockedItems)
	{
		sprintf(szTmp, "%d,", it);
		strncat(szUnlockedItems, szTmp, sizeof(szUnlockedItems));

		szUnlockedItems[strlen(szUnlockedItems) - 1] = '/';
	}

	char szTmpPreset[256] = { 0, };
	for (auto& it : refPresets)
	{
		SetDBFormatStr(szTmp, 65, it.szPresetName);
		sprintf(szTmpPreset, "%s,", szTmp);

		for (size_t i = 0; i < wdb_MAX_WARDROBE_TYPES; i++)
		{
			sprintf(szTmp, "%d,", it.arrayItemID.at(i));
			strncat(szTmpPreset, szTmp, sizeof(szTmpPreset));
		}

		strncat(szPresets, szTmpPreset, sizeof(szPresets));

		szPresets[strlen(szPresets) - 1] = '/';
	}

	strcat(szUnlockedItems, NullStr);
	strcat(szPresets, NullStr);

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "uspWardrobeSave '%07d', '%02d', '%s', '%s', %d",
		pMover->m_idPlayer, g_appInfo.dwSys, szUnlockedItems, szPresets, pMover->m_Wardrobe.GetSelectedPreset());

	if (!qry->Exec(szQuery))
	{
		Error("Cannot execute %s", szQuery);
		return;
	}
}
#endif

#ifdef __FL_PET_FILTER
void CDbManager::SavePetFilter(CMover* pMover, CQuery* qry)
{
	char stringBlack[512] = { 0, };
	char stringWhite[512] = { 0, };

	char szTmp[16] = { 0, };
	for (auto& it : pMover->m_setPetfilterBlackList)
	{
		sprintf(szTmp, "%d,", it);
		strncat(stringBlack, szTmp, sizeof(stringBlack));

		stringBlack[strlen(stringBlack) - 1] = '/';
	}

	for (auto& it : pMover->m_setPetfilterWhiteList)
	{
		sprintf(szTmp, "%d,", it);
		strncat(stringWhite, szTmp, sizeof(stringWhite));

		stringWhite[strlen(stringWhite) - 1] = '/';
	}

	strcat(stringBlack, NullStr);
	strcat(stringWhite, NullStr);

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "uspPetFilterSave '%07d', '%02d', '%s', '%s'",
		pMover->m_idPlayer, g_appInfo.dwSys, stringBlack, stringWhite);

	if (!qry->Exec(szQuery))
	{
		Error("Cannot execute %s", szQuery);
		return;
	}
}
#endif

#ifdef __ZCK_BADGE
#include "..\\_Common\\ZckBadge.h"

// La colonne BADGES_TBL.m_Badges est un varchar(3096) : casse la compilation
// plutot que de laisser des personnages cesser silencieusement d'etre
// sauvegardes si ZCK_BADGE_MAX_OWNED augmente.
static_assert(
	ZCK_BADGE_DB_STRING_LEN <= 3096,
	"ZCK_BADGE_MAX_OWNED depasse la capacite de BADGES_TBL.m_Badges : "
	"reduire ZCK_BADGE_MAX_OWNED ou elargir la colonne.");

void CDbManager::SaveZckBadge(CMover* pMover, CQuery* qry)
{
	if (!pMover || !qry)
		return;

	vector<int> vecSafe;
	ZckBadgeBuildSafeList(pMover->GetZckOwnedBadges(), vecSafe);

	if (vecSafe != pMover->GetZckOwnedBadges())
		pMover->GetZckOwnedBadges() = vecSafe;

	const int nSelected = ZckBadgeSanitizeSelected(pMover->GetZckBadge(), vecSafe);
	if (nSelected != pMover->GetZckBadge())
		pMover->SetZckBadge(nSelected);

	CString strBadges;
	for (vector<int>::const_iterator it = vecSafe.begin(); it != vecSafe.end(); ++it)
	{
		CString strOne;
		strOne.Format("%d/", *it);
		strBadges += strOne;
	}
	strBadges += NullStr;

	char szQuery[QUERY_SIZE] = { 0, };
	sprintf(szQuery, "{ CALL SAVE_BADGES('%07d', '%02d', '%d', '%s') }",
		pMover->m_idPlayer, g_appInfo.dwSys, nSelected, static_cast<LPCTSTR>(strBadges));

	if (!qry->Exec(szQuery))
	{
		WriteLog("%s - %07d, %02d, %d, %s", __FUNCTION__,
			pMover->m_idPlayer, g_appInfo.dwSys, nSelected, static_cast<LPCTSTR>(strBadges));
	}
}
#endif // __ZCK_BADGE