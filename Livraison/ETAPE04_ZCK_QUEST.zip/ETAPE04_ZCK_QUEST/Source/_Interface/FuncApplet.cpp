#include "stdafx.h"
#include "defineText.h"
#include "AppDefine.h"
#include "WndParty.h"
#include "WndNotice.h"
#include "WndMessenger.h"
#include "WndBank.h"
#include "WndDebugInfo.h"
#include "WndHelp.h"
#include "WndWebBox.h"
#include "WndVendor.h"
#include "WndCommItem.h"
#include "WndQuest.h"
#include "WndMotion.h"
#include "WndPvp.h"
#ifdef __ZCK_FENETRE_CHAT_MJ
#include "WndZckFenetreChatMj.h"
#endif
#include "WndMapEx.h"
#include "WndBagEx.h"

#if __VER >= 8 //__CSC_VER8_2
#include "WndPartyQuick.h"
#endif //__CSC_VER8_2
#if __VER >= 13 // __HOUSING
#include "WndHousing.h"
#endif // __HOUSING

#if __VER >= 15 // __GUILD_HOUSE
#include "WndGuildHouse.h"
#endif

#ifdef __FL_CASH_SHOP
#include "FlyFFShop.h"
#endif

#ifdef __WIKI_ITEMS_V2
#include "WndWikiItems.h"
#endif

#ifdef __ZCK_INTERFACE_GLOBAL
#include "WndZckInterfaceGlobal.h"
#endif

#ifdef __ZCK_ACHIEVEMENT
#include "WndZckAchievement.h"
#endif

#ifdef __ZCK_QUEST
#include "WndZckQuest.h"
#endif // __ZCK_QUEST

#ifdef __ZCK_CLASSEMENT
#include "WndZckClassementDonjon.h"
#endif

#ifdef __ZCK_PRESTIGE
#include "WndZckPrestige.h"
#endif

#ifdef __ZCK_SYSTEME_EVEIL
#include "WndZckSystemeEveil.h"
#endif

#ifdef __ZCK_MINIJEU_PVP
#include "WndZckPvPMinigames.h"
#endif

#ifdef __ZCK_ANARCHY
#include "WndZckAnarchy.h"
#endif

#ifdef __ZCK_WIKI_MONSTRES
#include "WndZckWikiMonstres.h"
#endif

#ifdef __ZCK_IA_FARM
#include "WndZckIaFarm.h"
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
#include "WndZckMondialBuff.h"
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
#include "WndZckPerinBuff.h"
#endif // __ZCK_PERIN_BUFF
#ifdef __ZCK_ARME_REBORN
#include "WndZckArmeReborn.h"
#endif // __ZCK_ARME_REBORN

#ifdef __ZCK_CRAFT_LOAD_TEX
#include "DPClient.h"
extern CDPClient g_DPlay;
#include "WndZckCraftLoadTex.h"
#else
#line 85 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#include "WndNavigator.h"

#ifdef __FL_TELEPORT
#include "Teleporter.h"
#endif

#ifdef __MODEL_VIEW
#include "WndModelView.h"
#endif

DECLAREAPPLET(AppMain_WndNavigator, new CWndNavigator);
DECLAREAPPLET(AppMain_WndCharacter, new CWndCharacter);
DECLAREAPPLET(AppMain_WndSkill2, new CWndSkill_16);
DECLAREAPPLET(AppMain_WndEmotion, new CWndEmotion);
DECLAREAPPLET(AppMain_WndMotion, new CWndMotion);
DECLAREAPPLET(AppMain_WndTrade, new CWndTrade);
DECLAREAPPLET(AppMain_WndVendor, new CWndVendor);
DECLAREAPPLET(AppMain_WndQuest, new CWndQuest);
DECLAREAPPLET(AppMain_WndInventory, new CWndInventory);
DECLAREAPPLET(AppMain_WndParty, new CWndParty);
DECLAREAPPLET(AppMain_WndGuild, new CWndGuild);
DECLAREAPPLET(AppMain_WndCommItem, new CWndCommItem);
DECLAREAPPLET(AppMain_WndUpgradeBase, new CWndUpgradeBase);
DECLAREAPPLET(AppMain_WndChat, new CWndChat);
#if __VER >= 11 // __CSC_VER11_4
DECLAREAPPLET(AppMain_WndMessenger, new CWndMessengerEx);
#else //__CSC_VER11_4
DECLAREAPPLET(AppMain_WndMessenger, new CWndMessenger);
#endif //__CSC_VER11_4
DECLAREAPPLET(AppMain_WndOptSound, new CWndOptSound);
DECLAREAPPLET(AppMain_WndOptWindow, new CWndOptWindow);
DECLAREAPPLET(AppMain_WndOptMyInfo, new CWndOptMyInfo);
DECLAREAPPLET(AppMain_WndOption, new CWndTotalOption);
DECLAREAPPLET(AppMain_WndInfoNotice, new CWndInfoNotice);
DECLAREAPPLET(AppMain_WndHelpHelp, new CWndHelp);
DECLAREAPPLET(AppMain_WndHelpTip, new CWndHelpTip);
DECLAREAPPLET(AppMain_WndHelpFAQ, new CWndHelpFAQ);
DECLAREAPPLET(AppMain_WndLogOut, new CWndLogOut);
DECLAREAPPLET(AppMain_WndQuit, new CWndQuit);
DECLAREAPPLET(AppMain_WndWorld, new CWndWorld);
DECLAREAPPLET(AppMain_WndDebugInfo, new CWndDebugInfo);
DECLAREAPPLET(AppMain_WndStatus, new CWndStatus);
DECLAREAPPLET(AppMain_WndLogin, new CWndLogin);
DECLAREAPPLET(AppMain_WndSelectServer, new CWndSelectServer);
DECLAREAPPLET(AppMain_WndCreateChar, new CWndCreateChar);
DECLAREAPPLET(AppMain_WndSelectChar, new CWndSelectChar);
DECLAREAPPLET(AppMain_WndMap, new CWndMapEx);
DECLAREAPPLET(AppMain_LordSkill, new CWndLordSkill);
DECLAREAPPLET(AppMain_WndPartyQuick, new CWndPartyQuick);
DECLAREAPPLET(AppMain_WndBuffStatus, new CWndBuffStatus);
DECLAREAPPLET(AppMain_WndInvenRemoveItem, new CWndInvenRemoveItem);
DECLAREAPPLET(AppMain_Housing, new CWndHousing);
DECLAREAPPLET(AppMain_GuildHousing, new CWndGuildHousing);
DECLAREAPPLET(AppMain_Couple, new CWndCoupleManager);

#ifdef __WIKI_ITEMS_V2
DECLAREAPPLET(AppMain_WikiItems, new CWndWikiItems);
#endif

#ifdef __FL_BATTLE_PASS
DECLAREAPPLET(AppMain_BattlePass, new CWndBattlePass);
#endif

#ifdef __FL_CONSUMABLES_STORAGE
DECLAREAPPLET(AppMain_Chest, new CWndChest);
#endif

#ifdef __FL_FAST_ELEMENT
DECLAREAPPLET(AppMain_ElementChanger, new CWndChangeAttributeNew);
#endif

#ifdef __FL_SHOP_SEARCH
DECLAREAPPLET(AppMain_ShopSearch, new CWndShopSearch);
#endif

#ifdef __FL_PET_FILTER
DECLAREAPPLET(AppMain_PetFilter, new CWndPetLootOption);
#endif

DECLAREAPPLET(AppMain_CollectInfo, new CWndCollectingItems);

#ifdef __FL_FFA
DECLAREAPPLET(AppMain_FFAResult, new CWndFFAResult);
#endif

#ifdef __FL_DAILY_REWARDS
DECLAREAPPLET(AppMain_DailyGift, new CWndDailyGift);
#endif

#ifdef __FL_TELEPORT
DECLAREAPPLET(AppMain_Teleport, new CWndTeleport);
#endif

#ifdef __FL_RECYCLE
DECLAREAPPLET(AppMain_Recycle, new CWndRecycle);
#endif

#ifdef __JOB_CHANGE
DECLAREAPPLET(AppMain_WndNewChangeJob, new CWndNewChangeJob);
DECLAREAPPLET(AppMain_WndNewChangeJob2, new CWndNewChangeJob2);
DECLAREAPPLET(AppMain_WndNewChangeJob3, new CWndNewChangeJob3);
#endif

#ifdef __MODEL_VIEW
DECLAREAPPLET(AppMain_ModelView, new CWndModelView);
#endif

#ifdef __FL_PARTY_FINDER
DECLAREAPPLET(AppMain_PartyFinder, new CWndPartyFinder);
#endif

#ifdef __FL_VENDORS
DECLAREAPPLET(AppMain_VendorManagement, new CWndVendorManagement);
DECLAREAPPLET(AppMain_VendorPreview, new CWndVendorPreview);
#endif

#ifdef __FL_CASH_SHOP
DECLAREAPPLET(AppMain_FlyFFShop, new CWndFlyFFShop);
#endif

#ifdef __FL_SWITCH_EQ
DECLAREAPPLET(AppMain_SwitchEq, new CWndSwitchEquip);
#endif

#ifdef __FL_GUILD_FINDER
DECLAREAPPLET(AppMain_GuildFinder, new CWndGuildFinder);
#endif

#ifdef __FL_FARM_DISPLAY
DECLAREAPPLET(AppMain_FarmDisplay, new CWndFarmDisplay);
#endif

#ifdef __FL_PACKED_ITEMS
DECLAREAPPLET(AppMain_PackedItems, new CWndPackedItems);
#endif

#ifdef __FL_WHEEL_OF_FORTUNE
DECLAREAPPLET(AppMain_Wof, new CWndWof);
#endif

#ifdef __FL_RECORD_BOOK
DECLAREAPPLET(AppMain_RecordBook, new CWndRecordBook);
#endif

#ifdef __FL_MONSTER_ALBUM
DECLAREAPPLET(AppMain_MonsterAlbum, new CWndMonsterAlbum);
#endif

#ifdef __FL_TDM
DECLAREAPPLET(AppMain_Activities, new CWndActivities);
DECLAREAPPLET(AppMain_TDMResult, new CWndTDMResult);
#endif

#ifdef __FL_DPS_UI
DECLAREAPPLET(AppMain_Dps, new CWndDPS);
#endif

#ifdef __AI_SYSTEM
DECLAREAPPLET(AppMain_WndRefresher, new CWndRefresher);
#endif

#ifdef __FL_WIKI_HONORS
DECLAREAPPLET(AppMain_WikiHonor, new CWndWikiHonor);
#endif
#ifdef __FL_SEASON_PASS
DECLAREAPPLET(AppMain_SeasonPass, new CWndSeasonPass);
#endif
#ifdef __FL_WARDROBE
DECLAREAPPLET(AppMain_Wardrobe, new CWndWardrobe);
#endif
#ifdef __FL_BOXES_V2
DECLAREAPPLET(AppMain_BoxInfo, new CWndBoxInformation);
#endif
#ifdef __FL_BUYBACK
DECLAREAPPLET(AppMain_BuyBack, new CWndBuyback);
#endif
#ifdef __FL_AUTO_POWERUPS
DECLAREAPPLET(AppMain_AutoPowerUps, new CWndAutoPowerUps);
#endif
#ifdef __FL_WIKI_UPGRADE
DECLAREAPPLET(AppMain_WikiUpgrade, new CWndWikiUpgrade);
#endif
#ifdef __FL_WIKI_AWAKENING
DECLAREAPPLET(AppMain_WikiAwakening, new CWndWikiAwakening);
#endif
#ifdef __FL_WORLDBOSS
DECLAREAPPLET(AppMain_WorldBoss, new CWndWorldBoss);
#endif
#ifdef __exchanges_ui
DECLAREAPPLET(AppMain_Exchanges, new CWndExchanges);
#endif
#ifdef __FL_PANG_HELPER
DECLAREAPPLET(AppMain_PangHelper, new CWndPangHelper);
#endif
#ifdef __ZCK_INTERFACE_GLOBAL
DECLAREAPPLET(AppMain_ZckInterfaceGlobal, new CWndZckInterfaceGlobal);
#endif
#ifdef __ZCK_UPGRADE
DECLAREAPPLET(AppMain_WndUpgrade, new CWndUpgrade);
#endif
#ifdef __ZCK_RARE
DECLAREAPPLET(AppMain_ZckArmeRare, new CWndZckArmeRare);
#endif
#ifdef __ZCK_ARME_REBORN
DECLAREAPPLET(AppMain_ZckArmeReborn, new CWndZckArmeReborn);
#endif // __ZCK_ARME_REBORN
#ifdef __ZCK_DIFFICULTY
DECLAREAPPLET(AppMain_WndDungeonDifficulty, new CWndDungeonDifficulty);
#endif
#ifdef __ZCK_PROGRESSION
DECLAREAPPLET(AppMain_ZckProgression, new CWndZckProgression);
#endif
#ifdef __ZCK_ACHIEVEMENT
DECLAREAPPLET(AppMain_ZckAchievement, new CWndZckAchievement);
#endif
#ifdef __ZCK_CLASSEMENT
DECLAREAPPLET(AppMain_ZckClassementDonjon, new CWndZckClassementDonjon);
#endif
#ifdef __ZCK_FENETRE_CHAT_MJ
DECLAREAPPLET(AppMain_ZckFenetreChatMj, new CWndZckFenetreChatMj);
#endif
#ifdef __ZCK_PRESTIGE
DECLAREAPPLET(AppMain_ZckPrestige, new CWndZckPrestige);
#endif
#ifdef __ZCK_SYSTEME_EVEIL
DECLAREAPPLET(AppMain_ZckSystemeEveil, new CWndZckSystemeEveil);
#endif
#ifdef __ZCK_MINIJEU_PVP
DECLAREAPPLET(AppMain_WndZckPvPMinigamesCreate, new CWndZckPvPGameCreate);
DECLAREAPPLET(AppMain_WndZckPvPMinigamesFinder, new CWndZckPvPGameFinder);
#endif
#ifdef __ZCK_ANARCHY
DECLAREAPPLET(AppMain_ZckAnarchy, new CWndZckAnarchy);
#endif // __ZCK_ANARCHY
#ifdef __ZCK_WIKI_MONSTRES
DECLAREAPPLET(AppMain_ZckWikiMonstres, new CWndZckWikiMonstres);
#endif // __ZCK_WIKI_MONSTRES
#ifdef __ZCK_LISTE_JOUEURS
DECLAREAPPLET(AppMain_WndPlayerList, new CWndPlayerList);
#endif // __ZCK_LISTE_JOUEURS
#ifdef __ZCK_IA_FARM
DECLAREAPPLET(AppMain_ZckIaFarm, new CWndZckIaFarm);
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
DECLAREAPPLET(AppMain_ZckMondialBuff, new CWndZckMondialBuff);
DECLAREAPPLET(AppMain_ZckMondialBuffConfirm, new CWndZckMondialBuffConfirm);
DECLAREAPPLET(AppMain_ZckMondialBuffHud, new CWndZckMondialBuffHud);
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
DECLAREAPPLET(AppMain_ZckPerinBuff, new CWndZckPerinBuff);
DECLAREAPPLET(AppMain_ZckPerinBuffConfirm, new CWndZckPerinBuffConfirm);
DECLAREAPPLET(AppMain_ZckPerinBuffHud, new CWndZckPerinBuffHud);
#endif // __ZCK_PERIN_BUFF
#ifdef __ZCK_CRAFT_LOAD_TEX
DECLAREAPPLET(AppMain_ZckCraft, new CWndZckCraftLoadTex);
#else
#line 338 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#ifdef __ZCK_QUEST
DECLAREAPPLET(AppMain_ZckQuest, new CWndZckQuest);
DECLAREAPPLET(AppMain_ZckQuestSuivi, new CWndZckQuestSuivi);
#endif // __ZCK_QUEST
void CWndMgr::AddAllApplet()
{
#ifdef __ZCK_CRAFT_LOAD_TEX
	AddAppletFunc(AppMain_ZckCraft, APP_ZCK_CRAFT, "WndZckCraftLoadTex", "Icon_Applet.dds", "Artisanat", 0);
#else
#line 340 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#ifdef __ZCK_UPGRADE
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_WndUpgrade, APP_UPGRADE, "WndUpgrade", "Icon_Applet.dds", "Am\351lioration Admin", 0);
#else
	AddAppletFunc(AppMain_WndUpgrade, APP_UPGRADE, "WndUpgrade", "Icon_Applet.dds", "Amelioration Admin", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __ZCK_RARE
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_ZckArmeRare, APP_ZCK_ARME_RARE, "WndZckArmeRare", "Icon_Applet.dds", "Ascension de raret\351", 0);
#else
	AddAppletFunc(AppMain_ZckArmeRare, APP_ZCK_ARME_RARE, "WndZckArmeRare", "Icon_Applet.dds", "Ascension de rarete", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __ZCK_ARME_REBORN
	AddAppletFunc(AppMain_ZckArmeReborn, APP_ZCK_ARME_REBORN, "WndZckArmeReborn", "Icon_Applet.dds", "Arme Reborn", 0);
#endif // __ZCK_ARME_REBORN
#ifdef __ZCK_PROGRESSION
	AddAppletFunc(AppMain_ZckProgression, APP_ZCK_PROGRESSION, "WndZckProgression", "Icon_Applet.dds", "Progression du donjon", 0);
#endif
#ifdef __ZCK_DIFFICULTY
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_WndDungeonDifficulty, APP_DUNGEON_DIFFICULTY, "WndDungeonDifficulty", "Icon_Applet.dds", "Choisir la difficult\351", 0);
#else
	AddAppletFunc(AppMain_WndDungeonDifficulty, APP_DUNGEON_DIFFICULTY, "WndDungeonDifficulty", "Icon_Applet.dds", "Choisir la difficulte", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __ZCK_INTERFACE_GLOBAL
	AddAppletFunc(AppMain_ZckInterfaceGlobal, APP_ZCK_INTERFACE_GLOBAL, "WndZckInterfaceGlobal", "Icon_Applet.dds", GETTEXT(TID_ZCK_INTERFACE_GLOBAL), 0);
#endif
#ifdef __ZCK_ACHIEVEMENT
	AddAppletFunc(AppMain_ZckAchievement, APP_ZCK_ACHIEVEMENT, "WndZckAchievement", "Icon_Applet.dds", "Achievements", 0);
#endif
#ifdef __ZCK_QUEST
	AddAppletFunc(AppMain_ZckQuest, APP_ZCK_QUEST, "WndZckQuest", "Icon_Applet.dds", "Qu\352tes", 0);
	AddAppletFunc(AppMain_ZckQuestSuivi, APP_ZCK_QUEST_SUIVI, "WndZckQuestSuivi", NULL, "Suivi des qu\352tes", 0);
#endif // __ZCK_QUEST
#ifdef __ZCK_CLASSEMENT
	AddAppletFunc(AppMain_ZckClassementDonjon, APP_ZCK_CLASSEMENT_DONJON, "WndZckClassementDonjon", "Icon_Applet.dds", "Livre des Records", 0);
#endif
#ifdef __ZCK_FENETRE_CHAT_MJ
	AddAppletFunc(AppMain_ZckFenetreChatMj, APP_ZCK_FENETRE_CHAT_MJ, "WndZckFenetreChatMj", "Icon_Applet.dds", "Supervision des communications", 0);
#endif
#ifdef __ZCK_PRESTIGE
	AddAppletFunc(AppMain_ZckPrestige, APP_ZCK_PRESTIGE, "WndZckPrestige", "Icon_Applet.dds", "Prestige", 0);
#endif
#ifdef __ZCK_SYSTEME_EVEIL
#ifdef __ZCK_TRAD_FR
    AddAppletFunc(AppMain_ZckSystemeEveil, APP_ZCK_SYSTEME_EVEIL, "WndZckSystemeEveil", "Icon_Applet.dds", "Syst\350me d'\351veil", 0);
#else
    AddAppletFunc(AppMain_ZckSystemeEveil, APP_ZCK_SYSTEME_EVEIL, "WndZckSystemeEveil", "Icon_Applet.dds", "Systeme d'eveil", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __ZCK_MINIJEU_PVP
	AddAppletFunc(AppMain_WndZckPvPMinigamesCreate, APP_PVP_MINIGAME_CREATE, "WndMinigameCreate", "Icon_Infopang.dds", "Create Minigame", 0);
	AddAppletFunc(AppMain_WndZckPvPMinigamesFinder, APP_PVP_MINIGAME_FINDER, "WndMinigameFinder", "Icon_Infopang.dds", "Find Minigame", 0);
#endif
#ifdef __ZCK_ANARCHY
	AddAppletFunc(AppMain_ZckAnarchy, APP_ANARCHY_SKILL, "WndZckAnarchy", "Icon_Applet.dds", "Buffs serveur", 0);
#endif // __ZCK_ANARCHY
#ifdef __ZCK_WIKI_MONSTRES
	AddAppletFunc(AppMain_ZckWikiMonstres, APP_ZCK_WIKI_MONSTRES, "WndZckWikiMonstres", "Icon_Applet.dds", "Wikipedia - Monstres", 0);
#endif // __ZCK_WIKI_MONSTRES
#ifdef __ZCK_LISTE_JOUEURS
	AddAppletFunc(AppMain_WndPlayerList, APP_ZCK_LISTE, "WndPlayerList", "Icon_Applet.dds", "Liste des joueurs", 0);
#endif // __ZCK_LISTE_JOUEURS
#ifdef __ZCK_IA_FARM
	AddAppletFunc(AppMain_ZckIaFarm, APP_BOTSYSTEMZCK, "WndZckIaFarm", "Icon_Applet.dds", "IA Farm", 0);
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
	AddAppletFunc(AppMain_ZckMondialBuff, APP_ZCK_MONDIAL_BUFF, "WndZckMondialBuff", "Icon_Applet.dds", "Buffs mondiaux", 0);
	AddAppletFunc(AppMain_ZckMondialBuffConfirm, APP_ZCK_MONDIAL_BUFF_CONFIRM, "WndZckMondialBuffConfirm", NULL, "Offrande de buff mondial", 0);
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_ZckMondialBuffHud, APP_ZCK_MONDIAL_BUFF_HUD, "WndZckMondialBuffHud", NULL, "Ic\364ne des buffs mondiaux", 0);
#else
	AddAppletFunc(AppMain_ZckMondialBuffHud, APP_ZCK_MONDIAL_BUFF_HUD, "WndZckMondialBuffHud", NULL, "Icone des buffs mondiaux", 0);
#endif // __ZCK_TRAD_FR
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
	AddAppletFunc(AppMain_ZckPerinBuff, APP_ZCK_PERIN_BUFF, "WndZckPerinBuff", "Icon_Applet.dds", "Buffs Perin", 0);
	AddAppletFunc(AppMain_ZckPerinBuffConfirm, APP_ZCK_PERIN_BUFF_CONFIRM, "WndZckPerinBuffConfirm", NULL, "Investissement de Perins", 0);
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_ZckPerinBuffHud, APP_ZCK_PERIN_BUFF_HUD, "WndZckPerinBuffHud", NULL, "Ic\364ne des buffs Perin", 0);
#else
	AddAppletFunc(AppMain_ZckPerinBuffHud, APP_ZCK_PERIN_BUFF_HUD, "WndZckPerinBuffHud", NULL, "Icone des buffs Perin", 0);
#endif // __ZCK_TRAD_FR
#endif // __ZCK_PERIN_BUFF
#ifdef __FL_PANG_HELPER
	AddAppletFunc(AppMain_PangHelper, APP_PANG_HELPER, "WndPangHelper", "Icon_Applet.dds", "Pang Helper", 0);
#endif
#ifdef __exchanges_ui
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_Exchanges, APP_EXCHANGES_UI, "WndExchanges", "Icon_Applet.dds", "\311changes", 0);
#else
	AddAppletFunc(AppMain_Exchanges, APP_EXCHANGES_UI, "WndExchanges", "Icon_Applet.dds", "Exchanges", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_WORLDBOSS
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_WorldBoss, APP_WORLD_BOSS, "WndWorldBoss", "Icon_Applet.dds", "Classement du boss mondial", 0);
#else
	AddAppletFunc(AppMain_WorldBoss, APP_WORLD_BOSS, "WndWorldBoss", "Icon_Applet.dds", "World Boss Rank", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_WIKI_UPGRADE
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_WikiUpgrade, APP_WIKI_UPGRADE, "WndWikiUpgrade", "Icon_Applet.dds", "Wiki am\351lioration", 0);
#else
	AddAppletFunc(AppMain_WikiUpgrade, APP_WIKI_UPGRADE, "WndWikiUpgrade", "Icon_Applet.dds", "Wiki Upgrade", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_WIKI_AWAKENING
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_WikiAwakening, APP_WIKI_AWAKENING, "WndWikiAwakening", "Icon_Applet.dds", "Wiki \351veil", 0);
#else
	AddAppletFunc(AppMain_WikiAwakening, APP_WIKI_AWAKENING, "WndWikiAwakening", "Icon_Applet.dds", "Wiki Awakening", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_AUTO_POWERUPS
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_AutoPowerUps, APP_AUTO_POWERUPS, "WndAutoPowerUps", "Icon_Applet.dds", "Boosts automatiques", 0);
#else
	AddAppletFunc(AppMain_AutoPowerUps, APP_AUTO_POWERUPS, "WndAutoPowerUps", "Icon_Applet.dds", "Auto Power-Ups", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_BUYBACK
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_BuyBack, APP_BUYBACK, "WndBuyback", "Icon_Applet.dds", "Rachat", 0);
#else
	AddAppletFunc(AppMain_BuyBack, APP_BUYBACK, "WndBuyback", "Icon_Applet.dds", "Buyback", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_BOXES_V2
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_BoxInfo, APP_BOX_INFO, "WndBoxInformation", "Icon_Applet.dds", "Contenu de la bo\356te", 0);
#else
	AddAppletFunc(AppMain_BoxInfo, APP_BOX_INFO, "WndBoxInformation", "Icon_Applet.dds", "Box Information", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_WARDROBE
	AddAppletFunc(AppMain_Wardrobe, APP_WARDROBE, "WndWardrobe", "Icon_Applet.dds", "Garde-robe", 0);
#endif
#ifdef __FL_SEASON_PASS
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_SeasonPass, APP_SEASON_PASS, "WndSeasonPass", "Icon_Applet.dds", "Pass de saison", 0);
#else
	AddAppletFunc(AppMain_SeasonPass, APP_SEASON_PASS, "WndSeasonPass", "Icon_Applet.dds", "Season Pass", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_WIKI_HONORS
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_WikiHonor, APP_WIKI_HONOR, "WndWikiHonor", "Icon_Applet.dds", "Wiki des honneurs", 0);
#else
	AddAppletFunc(AppMain_WikiHonor, APP_WIKI_HONOR, "WndWikiHonor", "Icon_Applet.dds", "Wiki Honors", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_DPS_UI
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_Dps, APP_DPS_UI, _T("WndDPS"), _T("Icon_Applet.dds"), "Analyse DPS", 0);
#else
	AddAppletFunc(AppMain_Dps, APP_DPS_UI, _T("WndDPS"), _T("Icon_Applet.dds"), "DPS UI", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_TDM
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_TDMResult, APP_TDM_RESULT, "WndTDMResult", "Icon_Hunter_FFA.tga", "R\351sultats TDM", 0);
	AddAppletFunc(AppMain_Activities, APP_PVP_ACTIVITIES, "WndActivities", "Icon_Hunter_FFA.tga", "Activit\351s PvP / PvE", 0);
#else
	AddAppletFunc(AppMain_TDMResult, APP_TDM_RESULT, "WndTDMResult", "Icon_Hunter_FFA.tga", "TDM Result", 0);
	AddAppletFunc(AppMain_Activities, APP_PVP_ACTIVITIES, "WndActivities", "Icon_Hunter_FFA.tga", "PvP & PvE Activities", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_MONSTER_ALBUM
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_MonsterAlbum, APP_MONSTER_ALBUM, "WndMonsterAlbum", "Icon_Applet.dds", "Album des monstres", 0);
#else
	AddAppletFunc(AppMain_MonsterAlbum, APP_MONSTER_ALBUM, "WndMonsterAlbum", "Icon_Applet.dds", "Monster Album", 0);
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_RECORD_BOOK
	AddAppletFunc(AppMain_RecordBook, APP_RECORD_BOOK, "WndRecordBook", "Icon_Applet.dds", "Livre des records", 0);
#endif
#ifdef __FL_WHEEL_OF_FORTUNE
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_Wof, APP_WOF, "WndWof", "Icon_Applet.dds", "Roue de la fortune", 0);
#else
	AddAppletFunc(AppMain_Wof, APP_WOF, "WndWof", "Icon_Applet.dds", "Wheel of Fortune", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_PACKED_ITEMS
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_PackedItems, APP_PACKED_ITEMS, "WndPackedItems", "Icon_Applet.dds", "Aper\347u des packs", 0);
#else
	AddAppletFunc(AppMain_PackedItems, APP_PACKED_ITEMS, "WndPackedItems", "Icon_Applet.dds", "Preview Custom Package", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_FARM_DISPLAY
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_FarmDisplay, APP_FARM_DISPLAY, "WndFarmDisplay", "Icon_Applet.dds", "Suivi du farm", 0);
#else
	AddAppletFunc(AppMain_FarmDisplay, APP_FARM_DISPLAY, "WndFarmDisplay", "Icon_Applet.dds", "Farm Display", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_GUILD_FINDER
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_GuildFinder, APP_GUILD_FINDER, "WndGuildFinder", "Icon_Applet.dds", "Recherche de guilde", 0);
#else
	AddAppletFunc(AppMain_GuildFinder, APP_GUILD_FINDER, "WndGuildFinder", "Icon_Applet.dds", "Guild-Finder", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __AI_SYSTEM
	AddAppletFunc(AppMain_WndRefresher, APP_REFRESHER, _T("WndRefresher"), _T("Icon_Motion.dds"), ("AI System"), 0);
#endif

#ifdef __FL_SWITCH_EQ
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_SwitchEq, APP_EQ_SWITCH, "WndSwitchEquip", "Icon_Applet.dds", "Changer d'\351quipement", 0);
#else
	AddAppletFunc(AppMain_SwitchEq, APP_EQ_SWITCH, "WndSwitchEquip", "Icon_Applet.dds", "Switch Equipment", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_CASH_SHOP
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_FlyFFShop, APP_CASH_SHOP, "WndFlyFFShop", "Icon_Applet.dds", "Boutique FlyFF", 0);
#else
	AddAppletFunc(AppMain_FlyFFShop, APP_CASH_SHOP, "WndFlyFFShop", "Icon_Applet.dds", "FlyFF Cash Shop", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_VENDORS
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_VendorManagement, APP_VENDOR_MANAGE, "WndVendorManagement", "Icon_Applet.dds", "Gestion des vendeurs", 0);
	AddAppletFunc(AppMain_VendorPreview, APP_VENDOR_PREVIEW, "WndVendorPreview", "Icon_Applet.dds", "Aper\347u du vendeur hors ligne", 0);
#else
	AddAppletFunc(AppMain_VendorManagement, APP_VENDOR_MANAGE, "WndVendorManagement", "Icon_Applet.dds", "Offline Vendor Menu", 0);
	AddAppletFunc(AppMain_VendorPreview, APP_VENDOR_PREVIEW, "WndVendorPreview", "Icon_Applet.dds", "Offline Vendor Preview", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_PARTY_FINDER
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_PartyFinder, APP_PARTY_FINDER, "WndPartyFinder", "Icon_Hunter_Partyfinder.tga", "Recherche de groupe", 'L');
#else
	AddAppletFunc(AppMain_PartyFinder, APP_PARTY_FINDER, "WndPartyFinder", "Icon_Hunter_Partyfinder.tga", "Party-Finder", 'L');
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_RECYCLE
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_Recycle, APP_RECYCLE, "WndRecycle", "Icon_Hunter_Recycle.tga", "Recycler", 0);
#else
	AddAppletFunc(AppMain_Recycle, APP_RECYCLE, "WndRecycle", "Icon_Hunter_Recycle.tga", "Recycle", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __MODEL_VIEW
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_ModelView, APP_MODEL_VIEW, "WndModelView", "Icon_Applet.dds", "Visionneuse de mod\350les", 0);
#else
	AddAppletFunc(AppMain_ModelView, APP_MODEL_VIEW, "WndModelView", "Icon_Applet.dds", "ModelView", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __JOB_CHANGE
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_WndNewChangeJob, APP_CHANGE_JOB_01, _T("WndNewChangeJob"), _T("Icon_Applet.dds"), "Changement de classe", 0);
	AddAppletFunc(AppMain_WndNewChangeJob2, APP_CHANGE_JOB_02, _T("WndNewChangeJob2"), _T("Icon_Applet.dds"), "Changement de classe", 0);
	AddAppletFunc(AppMain_WndNewChangeJob3, APP_CHANGE_JOB_03, _T("WndNewChangeJob3"), _T("Icon_Applet.dds"), "Changement de classe", 0);
#else
	AddAppletFunc(AppMain_WndNewChangeJob, APP_CHANGE_JOB_01, _T("WndNewChangeJob"), _T("Icon_Applet.dds"), "Job Changer", 0);
	AddAppletFunc(AppMain_WndNewChangeJob2, APP_CHANGE_JOB_02, _T("WndNewChangeJob2"), _T("Icon_Applet.dds"), "Job Changer", 0);
	AddAppletFunc(AppMain_WndNewChangeJob3, APP_CHANGE_JOB_03, _T("WndNewChangeJob3"), _T("Icon_Applet.dds"), "Job Changer", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_TELEPORT
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_Teleport, APP_TELEPORT, "WndTeleport", "Icon_Hunter_Teleporter.tga", "T\351l\351porteur", 'V');
#else
	AddAppletFunc(AppMain_Teleport, APP_TELEPORT, "WndTeleport", "Icon_Hunter_Teleporter.tga", "Teleporter", 'V');
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_DAILY_REWARDS
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_DailyGift, APP_DAILY_REWARD, "WndDailyGift", "Icon_Applet.dds", "R\351compense quotidienne", 0);
#else
	AddAppletFunc(AppMain_DailyGift, APP_DAILY_REWARD, "WndDailyGift", "Icon_Applet.dds", "Daily Reward", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_FFA
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_FFAResult, APP_FFA_RESULT, "WndFFAResult", "Icon_Hunter_FFA.tga", "R\351sultats FFA", 0);
#else
	AddAppletFunc(AppMain_FFAResult, APP_FFA_RESULT, "WndFFAResult", "Icon_Hunter_FFA.tga", "FFA Result", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_CollectInfo, APP_COLLECTING_INFO, "WndCollectingItems", "Icon_Applet.dds", "Informations du collecteur", 0);
#else
	AddAppletFunc(AppMain_CollectInfo, APP_COLLECTING_INFO, "WndCollectingItems", "Icon_Applet.dds", "Collector Info", 0);
#endif // __ZCK_TRAD_FR

#ifdef __FL_PET_FILTER
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_PetFilter, APP_PET_LOOT_OPTION, "WndPetLootOption", "Icon_Hunter_PetFilter.tga", "Filtre familier", 'U');
#else
	AddAppletFunc(AppMain_PetFilter, APP_PET_LOOT_OPTION, "WndPetLootOption", "Icon_Hunter_PetFilter.tga", "Pet Filter", 'U');
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_SHOP_SEARCH
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_ShopSearch, APP_SHOP_SEARCH, "WndShopSearch", "Icon_Hunter_ShopSearch.tga", "Recherche boutique", 0);
#else
	AddAppletFunc(AppMain_ShopSearch, APP_SHOP_SEARCH, "WndShopSearch", "Icon_Hunter_ShopSearch.tga", "Shop Search", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_FAST_ELEMENT
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_ElementChanger, APP_FAST_ELEMENT, "WndChangeAttributeNew", "Icon_Hunter_ElementChanger.tga", "Changer d'\351l\351ment", 'R');
#else
	AddAppletFunc(AppMain_ElementChanger, APP_FAST_ELEMENT, "WndChangeAttributeNew", "Icon_Hunter_ElementChanger.tga", "Element Changer", 'R');
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_CONSUMABLES_STORAGE
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_Chest, APP_CHEST, _T("WndChest"), _T("Icon_Hunter_Chest.tga"), "Coffre", 'B');
#else
	AddAppletFunc(AppMain_Chest, APP_CHEST, _T("WndChest"), _T("Icon_Hunter_Chest.tga"), "Chest", 'B');
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_BATTLE_PASS
#ifdef __ZCK_TRAD_FR
	AddAppletFunc(AppMain_BattlePass, APP_BATTLE_PASS, "WndBattlePass", "Icon_Hunter_BattlePass.tga", "Pass de combat", 0);
#else
	AddAppletFunc(AppMain_BattlePass, APP_BATTLE_PASS, "WndBattlePass", "Icon_Hunter_BattlePass.tga", "Battle Pass", 0);
#endif // __ZCK_TRAD_FR
#endif

#ifdef __WIKI_ITEMS_V2
	AddAppletFunc(AppMain_WikiItems, APP_WIKI_ITEMS, "WndWikiItems", "Icon_Hunter_Wiki.tga", "Wiki des objets", 0);
#endif

	AddAppletFunc(AppMain_WndNavigator, APP_NAVIGATOR, _T("WndNavigator"), _T("Icon_Navigator.dds"), GETTEXT(TID_TIP_NAVIGATOR), 'N');
	AddAppletFunc(AppMain_WndStatus, APP_STATUS1, _T("WndStatus"), _T("Icon_Status.dds"), GETTEXT(TID_TIP_STATUS), 'T');
	AddAppletFunc(AppMain_WndMap, APP_MAP_EX, _T("WndMap"), _T("Icon_Applet.dds"), GETTEXT(TID_TIP_MAP), 'M');
	AddAppletFunc(AppMain_LordSkill, APP_LORD_SKILL, _T("WndLordSkill"), _T("Icon_Infopang.dds"), GETTEXT(TID_TIP_INFOPANG), 0);
	AddAppletFunc(AppMain_Housing, APP_HOUSING, _T("WndHousing"), _T("Icon_Housing.dds"), GETTEXT(TID_GAME_HOUSING_BOX), 'Y');
	AddAppletFunc(AppMain_GuildHousing, APP_GH_FURNITURE_STORAGE, _T("WndGuildHousing"), _T("Icon_Housing.dds"), GETTEXT(TID_GAME_HOUSING_BOX), 0);
	AddAppletFunc(AppMain_WndCharacter, APP_CHARACTER3, _T("WndCharacter"), _T("Icon_Character.dds"), GETTEXT(TID_TIP_CHARACTER), 'H');
	AddAppletFunc(AppMain_WndInventory, APP_INVENTORY, _T("WndInventory"), _T("Icon_Inventory.dds"), GETTEXT(TID_TIP_INVENTORY), 'I');
	AddAppletFunc(AppMain_WndSkill2, APP_SKILL4, _T("WndSkill"), _T("Icon_Skill.dds"), GETTEXT(TID_TIP_SKILL), 'K');
	AddAppletFunc(AppMain_WndMotion, APP_MOTION, _T("WndMotion"), _T("Icon_Motion.dds"), GETTEXT(TID_TIP_MOTION), 'O');
	AddAppletFunc(AppMain_WndTrade, APP_TRADE, _T("WndTrade"), _T("Icon_Trade.dds"), GETTEXT(TID_TIP_TRADE), 0);
	AddAppletFunc(AppMain_WndVendor, APP_VENDOR_REVISION, _T("WndVendor"), _T("Icon_Hunter_PrivateShop.tga"), GETTEXT(TID_TIP_VENDOR), 0);
	AddAppletFunc(AppMain_WndQuest, APP_QUEST_EX_LIST, _T("WndQuest"), _T("Icon_Quest.dds"), GETTEXT(TID_TIP_QUEST), g_Neuz.Key.chQuest);
	AddAppletFunc(AppMain_WndParty, APP_PARTY, _T("WndParty"), _T("Icon_Troupe.dds"), GETTEXT(TID_TIP_PARTY), 'P');
	AddAppletFunc(AppMain_WndGuild, APP_GUILD, _T("WndGuild"), _T("Icon_Troupe.dds"), GETTEXT(TID_TIP_COMPANY), 'G');
	AddAppletFunc(AppMain_WndCommItem, APP_COMM_ITEM, _T("WndCommItem"), _T("Icon_CItemTime.dds"), GETTEXT(TID_TIP_ITEMTIME), 'J');
	AddAppletFunc(AppMain_WndUpgradeBase, APP_TEST, _T("WndUpgradeBase"), _T("Icon_Troupe.dds"), GETTEXT(TID_TIP_PARTY), 0);
	AddAppletFunc(AppMain_WndChat, APP_COMMUNICATION_CHAT, _T("WndChat"), _T("Icon_Chat.dds"), GETTEXT(TID_TIP_COMMUNICATION_CHAT), 0);
	AddAppletFunc(AppMain_WndMessenger, APP_MESSENGER_, _T("WndMessenger"), _T("Icon_Messenger.dds"), GETTEXT(TID_TIP_MESSENGER), 'E');
	AddAppletFunc(AppMain_WndOptSound, APP_OPTION_SOUND, _T("WndOptSound"), _T("Icon_Hunter_Settings.tga"), GETTEXT(TID_TIP_OPTION_SOUND), 0);
	AddAppletFunc(AppMain_WndOptWindow, APP_OPTION_WINDOW, _T("WndOptWindow"), _T("Icon_Hunter_Settings.tga"), GETTEXT(TID_TIP_OPTION_WINDOW), 0);
	AddAppletFunc(AppMain_WndOptMyInfo, APP_OPTION_MYINFO, _T("WndOptMyInfo"), _T("Icon_Hunter_Settings.tga"), GETTEXT(TID_TIP_OPTION_MYINFO), 0);
	AddAppletFunc(AppMain_WndOption, APP_OPTIONEX, _T("WndOption"), _T("Icon_Hunter_Settings.tga"), GETTEXT(TID_APP_OPTION), 0);
	AddAppletFunc(AppMain_WndInfoNotice, APP_INFO_NOTICE, _T("WndInfoNotice"), _T("Icon_Applet.dds"), GETTEXT(TID_TIP_INFO_NOTICE), 0);
	AddAppletFunc(AppMain_WndHelpHelp, APP_HELPER_HELP, _T("WndHelpHelp"), _T("Icon_HelperHelp.dds"), GETTEXT(TID_TIP_HELPER_HELP), 0);
	AddAppletFunc(AppMain_WndHelpTip, APP_HELPER_TIP, _T("WndHelpTip"), _T("Icon_HelperTip.dds"), GETTEXT(TID_TIP_HELPER_TIP), 0);
	AddAppletFunc(AppMain_WndHelpFAQ, APP_HELPER_FAQ, _T("WndHelpFAQ"), _T("Icon_HelperFAQ.dds"), GETTEXT(TID_TIP_HELPER_FAQ), 0);
	AddAppletFunc(AppMain_WndLogOut, APP_LOGOUT, _T("WndLogout"), _T("Icon_Logout.dds"), GETTEXT(TID_TIP_LOGOUT), 0);
	AddAppletFunc(AppMain_WndQuit, APP_QUIT, _T("WndQuit"), _T("Icon_Quit.dds"), GETTEXT(TID_TIP_QUIT), 0);
	AddAppletFunc(AppMain_WndWorld, APP_WORLD, _T("WndWorld"), _T("Icon_Applet.dds"), GETTEXT(TID_TIP_WORLD), 0);
	AddAppletFunc(AppMain_WndDebugInfo, APP_DEBUGINFO, _T("WndDebugInfo"), _T("Icon_Hunter_Debug.tga"), GETTEXT(TID_TIP_DEBUGINFO), 0);
	AddAppletFunc(AppMain_WndLogin, APP_LOGIN, _T("WndLogin"), _T("Icon_Login.dds"), GETTEXT(TID_TIP_APPLET), 0);
	AddAppletFunc(AppMain_WndSelectServer, APP_SELECT_SERVER, _T("WndSelectServer"), _T("Icon_SelectServer.dds"), GETTEXT(TID_TIP_WORLD), 0);
	AddAppletFunc(AppMain_WndCreateChar, APP_CREATE_CHAR, _T("WndCreateChar"), _T("Icon_CreateChar.dds"), GETTEXT(TID_TIP_WORLD), 0);
	AddAppletFunc(AppMain_WndSelectChar, APP_SELECT_CHAR, _T("WndSelectChar"), _T("Icon_SelectChar.dds"), GETTEXT(TID_TIP_DIALOG), 0);
	AddAppletFunc(AppMain_WndPartyQuick, APP_PARTY_QUICK, _T("WndPartyQuick"), NULL, GETTEXT(TID_TIP_DIALOG), 0);
	AddAppletFunc(AppMain_WndBuffStatus, APP_BUFF_STATUS, _T("WndBuffStatus"), NULL, GETTEXT(TID_TIP_DIALOG), 0);
	AddAppletFunc(AppMain_Couple, APP_COUPLE_MAIN, _T("WndCoupleManager"), _T("Icon_Couple.dds"), GETTEXT(TID_GAME_COUPLE), 'F');
}
