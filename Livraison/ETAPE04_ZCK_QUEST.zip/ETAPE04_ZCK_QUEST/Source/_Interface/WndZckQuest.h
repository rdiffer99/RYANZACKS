#ifndef __WND_ZCK_QUEST_H__
#define __WND_ZCK_QUEST_H__

#ifdef __ZCK_QUEST

#include "ZckQuest.h"

class CModelObject;

//////////////////////////////////////////////////////////////////////
// __ZCK_QUEST : fenetres du client (etape 04).
//
// CWndZckQuest       APP_ZCK_QUEST : journal des quetes de chasse.
//   Tout est dessine par le code, comme les achievements, sur une grille
//   calculee depuis la zone client : la fenetre se redimensionne par ses
//   bords (WBS_THICKFRAME) de ZCK_QU_FENETRE_L_MIN x ZCK_QU_FENETRE_H_MIN
//   jusqu'a l'ecran entier, et le bouton Agrandir la passe a la taille
//   de l'ecran (puis Restaurer) :
//     bandeau      heure du serveur, compteurs, Suivi, Agrandir ;
//     onglets      Toutes, Disponibles, En cours, A recuperer, Accomplies ;
//     liste        quetes de l'onglet : statut, horaire, progression ;
//     detail       statut, description, conditions, objectif et temps,
//                  monstres (clic : apercu), recompenses ;
//     monstre      apercu 3D (glisser : tourner, molette : zoom, fleches :
//                  monstre suivant) et fiche complete (PV, attaque, defense,
//                  resistances, element, EXP, comportement, rang...) ;
//     pied         etat, Accepter / Recommencer / Abandonner / Recuperer,
//                  Fermer.
//
// CWndZckQuestSuivi  APP_ZCK_QUEST_SUIVI : suivi a l'ecran (HUD).
//   Petite fenetre sans cadre, deplacable par sa barre de titre et
//   redimensionnable par ses bords : quetes en cours, terminees et echouees
//   (encore ouvertes), progression et temps restant. Reductible a sa barre
//   (neuz.ini ZckQueteSuiviReduit) et masquable (neuz.ini ZckQueteSuivi) :
//   bouton x, /quete suivi ou bouton Suivi du journal. Ouverte d'elle-meme
//   quand une quete est a suivre et l'option active, fermee quand il n'y a
//   plus rien a suivre. Exclue de CWndBase::GetWndBase : Echap ne la ferme
//   pas.
//
// Aucune logique de jeu : definitions (catalogue), etat et heure viennent du
// WorldServer (SNAPSHOTTYPE_ZCK_QUEST, CWndZckQuest::Recevoir) ; un bouton
// envoie CDPClient::SendZckQuest, que le serveur revalide en entier.
//////////////////////////////////////////////////////////////////////
class CWndZckQuest : public CWndNeuz
{
public:
	CWndZckQuest();
	virtual ~CWndZckQuest();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD dwWndId = 0);
	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual BOOL Process();
	virtual void OnDestroy();
	virtual HRESULT InvalidateDeviceObjects();
	virtual void SetWndRect(CRect rectWnd, BOOL bOnSize = TRUE);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	virtual void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	virtual void OnMouseWndSurface(CPoint point);

	// SNAPSHOTTYPE_ZCK_QUEST (CDPClient::OnZckQuest) : lu en entier ici,
	// puis les fenetres ouvertes sont rafraichies.
	static void Recevoir(CAr& ar);
	// Journal ouvert (ou ramene) sur une quete (clic dans le suivi).
	static void Ouvrir(int nId);

	void Rafraichir();
	void FinDemande(BYTE byAction, BYTE byCode, int nId);

private:
	enum
	{
		ZCK_QU_ONGLET_TOUTES = 0,
		ZCK_QU_ONGLET_DISPONIBLES,
		ZCK_QU_ONGLET_EN_COURS,
		ZCK_QU_ONGLET_A_RECUPERER,
		ZCK_QU_ONGLET_ACCOMPLIES,
		ZCK_QU_NB_ONGLETS
	};
	enum
	{
		ZCK_QU_MONSTRES_ZONES_MAX = ZCK_QUEST_MONSTRES_MAX,
		ZCK_QU_BULLES_MAX = 96
	};

	// Donnees
	const ZCK_QUEST_DEFINITION* GetSelection() const;
	BOOL DansOnglet(int nOnglet, int nStatut) const;
	int CompterOnglet(int nOnglet) const;
	void RebuildList();
	void SelectOnglet(int nOnglet);
	void SelectQuete(int nId);
	void SelectIndex(int nIndex);
	void ScrollTo(int nIndex);
	int GetVisibleRows();
	void Agir();
	BOOL ActionPossible(const ZCK_QUEST_DEFINITION& def, BYTE& byAction, CString& strBouton, CString& strRaison) const;
	BOOL EstAgrandie();
	void Agrandir();
	void Appuyer(CPoint point);

	// Monstre montre dans l'apercu
	DWORD GetViewMonsterId() const;
	CModelObject* GetMonsterModel(DWORD dwMonsterId);
	void ReleaseMonsterModel();
	void ChangerMonstre(int nSens);
	float AngleVue() const;
	void FinTourner();

	// Geometrie (coordonnees client)
	CRect RectBandeau();
	CRect RectSuivi();
	CRect RectAgrandir();
	CRect RectOnglet(int nOnglet);
	int GetCorpsHaut() const;
	int GetCorpsBas();
	CRect RectListe();
	CRect RectLigne(int nIndex);
	CRect RectPiste();
	CRect RectColonneMonstre();
	CRect RectDetail();
	CRect RectRecompenses();
	CRect RectSlot(int nSlot);
	CRect RectFiche();
	CRect RectApercu();
	CRect RectVue();
	CRect RectFleche(int nSens);
	CRect RectAction();
	CRect RectFermer();

	// Dessin
	void DessinerBandeau(C2DRender* p2DRender);
	void DessinerOnglets(C2DRender* p2DRender);
	void DessinerListe(C2DRender* p2DRender);
	void DessinerDetail(C2DRender* p2DRender);
	int DessinerConditions(C2DRender* p2DRender, const ZCK_QUEST_DEFINITION& def, int y, int yMax);
	int DessinerObjectif(C2DRender* p2DRender, const ZCK_QUEST_DEFINITION& def, int y, int yMax);
	void DessinerRecompenses(C2DRender* p2DRender);
	void DessinerApercu(C2DRender* p2DRender);
	void DessinerModele(C2DRender* p2DRender, const CRect& rectVue);
	void DessinerFiche(C2DRender* p2DRender);
	void DessinerPied(C2DRender* p2DRender);
	void DessinerVide(C2DRender* p2DRender, LPCTSTR lpszTitre, LPCTSTR lpszTexte);
	void AjouterBulle(const CRect& rect, LPCTSTR lpszTitre, LPCTSTR lpszTexte);
	void InfoBulle(DWORD dwId, CEditString& strEdit, CRect rect, CPoint point);

	int m_nOnglet;						// onglet affiche
	int m_anCompte[ZCK_QU_NB_ONGLETS];	// quetes par onglet (bandeau, onglets)
	vector<int> m_vecList;				// quetes de l'onglet, dans l'ordre des Id
	int m_nSelectedId;					// quete detaillee, 0 si aucune (gardee hors de l'onglet)
	int m_nScroll;						// premiere ligne visible de la liste
	DWORD m_dwTickListe;				// dernier calcul de la liste (les statuts suivent l'heure)
	DWORD m_dwTickEnvoi;				// demande envoyee au serveur (0 = aucune)
	int m_nEnvoiId;						// quete de la demande en cours
	DWORD m_dwTickConfirmer;			// premier clic sur Abandonner (0 = aucun)
	int m_nConfirmerId;
	CPoint m_ptSurvol;					// souris sur la fenetre, (-1, -1) sinon
	BOOL m_bAppui;						// bouton gauche enfonce dans la zone client (clic a venir)
	BOOL m_bRestaurable;				// m_rectRestauree garde le rectangle d'avant Agrandir
	CRect m_rectRestauree;				// rectangle rendu par Restaurer
	BOOL m_bPlace;						// position controlee une fois a l'ouverture

	// Apercu du monstre
	int m_nViewMonster;					// index dans vecMonstres de la quete detaillee
	CModelObject* m_pMonsterModel;
	DWORD m_dwViewportMonsterId;
	DWORD m_dwNextFrameMove;
	BOOL m_bTourne;						// glisser en cours dans la vue
	BOOL m_bRotationLibre;				// angle choisi a la souris (sinon balancement)
	float m_fRotation;					// degres, autour de Y
	float m_fZoom;
	CPoint m_ptTourne;

	// Zones cliquables (monstres de l'objectif) et infobulles du dernier dessin.
	int m_nZonesMonstres;
	CRect m_arectMonstre[ZCK_QU_MONSTRES_ZONES_MAX];
	int m_anMonstre[ZCK_QU_MONSTRES_ZONES_MAX];		// index dans vecMonstres
	int m_nBulles;
	CRect m_arectBulle[ZCK_QU_BULLES_MAX];
	CString m_astrBulleTitre[ZCK_QU_BULLES_MAX];
	CString m_astrBulle[ZCK_QU_BULLES_MAX];
};

class CWndZckQuestSuivi : public CWndNeuz
{
public:
	CWndZckQuestSuivi();
	virtual ~CWndZckQuestSuivi();

	virtual BOOL Initialize(CWndBase* pWndParent = NULL, DWORD dwWndId = 0);
	virtual void OnInitialUpdate();
	virtual void OnDraw(C2DRender* p2DRender);
	virtual BOOL Process();
	virtual void PaintFrame(C2DRender* p2DRender);
	virtual BOOL OnEraseBkgnd(C2DRender* p2DRender);
	virtual void SetWndRect(CRect rectWnd, BOOL bOnSize = TRUE);
	virtual BOOL IsPickupSpace(CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnMouseWndSurface(CPoint point);

	// Ouvre le suivi s'il y a une quete a suivre et l'option active.
	static void Actualiser();
	// /quete suivi, bouton Suivi du journal : option inversee, message.
	static void Basculer();
	// Au moins une quete en cours, terminee, ou echouee encore ouverte.
	static BOOL QueteASuivre();

private:
	enum
	{
		ZCK_QU_SUIVI_LIGNES_MAX = ZCK_QUEST_MAX
	};

	void Masquer();
	void Reduire(BOOL bReduit);
	int HauteurReduite() const;
	void ListerQuetes();
	CRect RectTete();
	CRect RectReduire();
	CRect RectMasquer();
	CRect RectEntree(int nRang);
	int GetEntreesVisibles();

	vector<int> m_vecQuetes;			// quetes suivies, dans l'ordre d'affichage
	DWORD m_dwTickListe;
	DWORD m_dwTickVide;					// rien a suivre depuis (0 = quelque chose a suivre)
	BOOL m_bReduit;
	int m_nHauteurDepliee;				// hauteur de la fenetre avant Reduire
	BOOL m_bPlace;						// position controlee une fois a l'ouverture
	BOOL m_bAppui;						// bouton gauche enfonce dans la zone client (clic a venir)
	CPoint m_ptSurvol;
	int m_nAlphaFond;					// fond plus marque sous la souris (0 a 255)
};

#endif // __ZCK_QUEST

#endif // __WND_ZCK_QUEST_H__
