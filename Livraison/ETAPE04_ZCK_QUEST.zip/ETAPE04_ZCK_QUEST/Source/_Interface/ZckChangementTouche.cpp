#include "stdafx.h"

#ifdef __ZCK_CHANGEMENT_TOUCHE

#include <algorithm>
#include <string>
#include <string.h>
#include "ZckChangementTouche.h"
#include "AppDefine.h"
#include "resdata.h"
#include "defineText.h"
#ifdef __ZCK_SPD_LOG
#include "ZckSpdLog.h"
#endif // __ZCK_SPD_LOG

//------------------------------------------------------------------------
// Objet global (convention : l'en-tete declare la classe, le .cpp definit
// l'objet, chaque .cpp utilisateur pose son propre extern).
//------------------------------------------------------------------------
CZckChangementTouche	g_ZckChangementTouche;

//------------------------------------------------------------------------
// Fenetres proposees dans l'onglet Touches, dans l'ordre d'affichage.
// Memes fenetres et memes conditions que le menu de la barre des taches
// (CWndTaskMenu::OnInitialUpdate) puis le Centre des systemes
// (CWndZckInterfaceGlobal::RefreshCategory). Les autres fenetres enregistrees
// avec une touche d'origine suivent, par identifiant croissant.
// Ce tableau ne decide pas des conflits : voir Initialiser (m_vecOrdre).
// dwTid = 0 : le libelle est celui de l'enregistrement (m_pAppletDesc).
//------------------------------------------------------------------------
struct ZCK_TOUCHE_FENETRE
{
	DWORD	dwApplet;
	DWORD	dwTid;
	DWORD	dwAutorisation;
};

static const ZCK_TOUCHE_FENETRE s_aZckToucheFenetres[] =
{
	// Applets
	{ APP_STATUS1,					TID_APP_STATUS,					0 },
	{ APP_NAVIGATOR,				TID_APP_NAVIGATOR,				0 },
	{ APP_CHARACTER3,				TID_APP_CHARACTER,				0 },
	{ APP_INVENTORY,				TID_APP_INVENTORY,				0 },
	{ APP_HOUSING,					TID_GAME_HOUSING_BOX,			0 },
	{ APP_SKILL4,					TID_APP_SKILL,					0 },
	{ APP_QUEST_EX_LIST,			TID_APP_QUEST,					0 },
	{ APP_MOTION,					TID_APP_MOTION,					0 },
	{ APP_MAP_EX,					TID_APP_MAP,					0 },
	// Communication
	{ APP_COMMUNICATION_CHAT,		TID_APP_COMMUNICATION_CHAT,		0 },
	{ APP_MESSENGER_,				TID_APP_MESSENGER,				0 },
	{ APP_COUPLE_MAIN,				TID_GAME_COUPLE,				0 },
	{ APP_PARTY,					TID_APP_PARTY,					0 },
	{ APP_GUILD,					TID_APP_COMPANY,				0 },
	// Aide
	{ APP_HELPER_HELP,				TID_APP_HELPER_HELP,			0 },
	{ APP_HELPER_TIP,				TID_APP_HELPER_TIP,				0 },
	{ APP_HELPER_FAQ,				TID_APP_HELPER_FAQ,				0 },
	{ APP_INFO_NOTICE,				TID_APP_INFO_NOTICE,			0 },
	{ APP_COMM_ITEM,				TID_APP_ITEMTIME,				0 },
#ifdef __FL_PANG_HELPER
	{ APP_PANG_HELPER,				0,								0 },
#endif // __FL_PANG_HELPER
	// Contenu personnalise du menu
#ifdef __ZCK_INTERFACE_GLOBAL
	{ APP_ZCK_INTERFACE_GLOBAL,		TID_ZCK_INTERFACE_GLOBAL,		0 },
#endif // __ZCK_INTERFACE_GLOBAL
#ifdef __ZCK_IA_FARM
	{ APP_BOTSYSTEMZCK,				0,								0 },
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
	{ APP_ZCK_MONDIAL_BUFF,			0,								0 },
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
	{ APP_ZCK_PERIN_BUFF,			0,								0 },
#endif // __ZCK_PERIN_BUFF
#ifdef __ZCK_LISTE_JOUEURS
	{ APP_ZCK_LISTE,				0,								0 },
#endif // __ZCK_LISTE_JOUEURS
#ifdef __ZCK_CRAFT_LOAD_TEX
	{ APP_ZCK_CRAFT,					0,								0 },
#else
#line 80 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#ifdef __ZCK_QUEST
	{ APP_ZCK_QUEST,				0,								0 },
#endif // __ZCK_QUEST
	{ APP_VENDOR_REVISION,			TID_APP_VENDOR,					0 },
	{ APP_OPTIONEX,					TID_APP_OPTION,					0 },
	{ APP_DEBUGINFO,				TID_APP_DEBUGINFO,				AUTH_GAMEMASTER },
	// Centre des systemes : services
#ifdef __FL_TELEPORT
	{ APP_TELEPORT,					0,								0 },
#endif // __FL_TELEPORT
#ifdef __FL_SHOP_SEARCH
	{ APP_SHOP_SEARCH,				0,								0 },
#endif // __FL_SHOP_SEARCH
#ifdef __FL_CONSUMABLES_STORAGE
	{ APP_CHEST,					0,								0 },
#endif // __FL_CONSUMABLES_STORAGE
#ifdef __FL_PET_FILTER
	{ APP_PET_LOOT_OPTION,			0,								0 },
#endif // __FL_PET_FILTER
#ifdef __FL_CASH_SHOP
	{ APP_CASH_SHOP,				0,								0 },
#endif // __FL_CASH_SHOP
#ifdef __FL_AUTO_POWERUPS
	{ APP_AUTO_POWERUPS,			0,								0 },
#endif // __FL_AUTO_POWERUPS
	// Centre des systemes : progression
#ifdef __FL_BATTLE_PASS
	{ APP_BATTLE_PASS,				0,								0 },
#endif // __FL_BATTLE_PASS
#ifdef __FL_SEASON_PASS
	{ APP_SEASON_PASS,				0,								0 },
#endif // __FL_SEASON_PASS
#ifdef __FL_RECORD_BOOK
	{ APP_RECORD_BOOK,				0,								0 },
#endif // __FL_RECORD_BOOK
#ifdef __FL_DPS_UI
	{ APP_DPS_UI,					0,								0 },
#endif // __FL_DPS_UI
#ifdef __FL_FARM_DISPLAY
	{ APP_FARM_DISPLAY,				0,								0 },
#endif // __FL_FARM_DISPLAY
#ifdef __FL_TDM
	{ APP_PVP_ACTIVITIES,			0,								0 },
#endif // __FL_TDM
#ifdef __ZCK_ACHIEVEMENT
	{ APP_ZCK_ACHIEVEMENT,			0,								0 },
#endif // __ZCK_ACHIEVEMENT
#ifdef __ZCK_CLASSEMENT
	{ APP_ZCK_CLASSEMENT_DONJON,	0,								0 },
#endif // __ZCK_CLASSEMENT
#ifdef __ZCK_PRESTIGE
	{ APP_ZCK_PRESTIGE,				0,								0 },
#endif // __ZCK_PRESTIGE
	// Centre des systemes : equipement
#ifdef __FL_FAST_ELEMENT
	{ APP_FAST_ELEMENT,				0,								0 },
#endif // __FL_FAST_ELEMENT
#ifdef __FL_RECYCLE
	{ APP_RECYCLE,					0,								0 },
#endif // __FL_RECYCLE
#ifdef __FL_SWITCH_EQ
	{ APP_EQ_SWITCH,				0,								0 },
#endif // __FL_SWITCH_EQ
#ifdef __FL_WARDROBE
	{ APP_WARDROBE,					0,								0 },
#endif // __FL_WARDROBE
#ifdef __FL_PACKED_ITEMS
	{ APP_PACKED_ITEMS,				0,								0 },
#endif // __FL_PACKED_ITEMS
#ifdef __exchanges_ui
	{ APP_EXCHANGES_UI,				0,								0 },
#endif // __exchanges_ui
	// Centre des systemes : wiki
#ifdef __WIKI_ITEMS_V2
	{ APP_WIKI_ITEMS,				0,								0 },
#endif // __WIKI_ITEMS_V2
#ifdef __FL_WIKI_HONORS
	{ APP_WIKI_HONOR,				0,								0 },
#endif // __FL_WIKI_HONORS
#ifdef __FL_WIKI_UPGRADE
	{ APP_WIKI_UPGRADE,				0,								0 },
#endif // __FL_WIKI_UPGRADE
#ifdef __FL_WIKI_AWAKENING
	{ APP_WIKI_AWAKENING,			0,								0 },
#endif // __FL_WIKI_AWAKENING
#ifdef __FL_MONSTER_ALBUM
	{ APP_MONSTER_ALBUM,			0,								0 },
#endif // __FL_MONSTER_ALBUM
#ifdef __ZCK_WIKI_MONSTRES
	{ APP_ZCK_WIKI_MONSTRES,		0,								0 },
#endif // __ZCK_WIKI_MONSTRES
	// Centre des systemes : social
#ifdef __FL_PARTY_FINDER
	{ APP_PARTY_FINDER,				0,								0 },
#endif // __FL_PARTY_FINDER
#ifdef __FL_GUILD_FINDER
	{ APP_GUILD_FINDER,				0,								0 },
#endif // __FL_GUILD_FINDER
#ifdef __FL_VENDORS
	{ APP_VENDOR_MANAGE,			0,								0 },
#endif // __FL_VENDORS
};

static const int s_nZckToucheFenetres = (int)(sizeof(s_aZckToucheFenetres) / sizeof(s_aZckToucheFenetres[0]));

// Actions systeme : cle dans ZckTouches.ini et libelle affiche, dans l'ordre de l'enum.
static const char* const s_apszZckToucheCleSysteme[ZCK_TOUCHE_NB_SYSTEME] =
{
	"Avancer",
	"Reculer",
	"Gauche",
	"Droite",
	"Marcher",
	"Suivre"
};

static const char* const s_apszZckToucheLibelleSysteme[ZCK_TOUCHE_NB_SYSTEME] =
{
	"Avancer",
	"Reculer",
	"Tourner \340 gauche",
	"Tourner \340 droite",
	"Marcher / Courir",
	"Suivre la cible"
};

//------------------------------------------------------------------------
// Menu de la barre des taches : touche et infobulle des fenetres, refaites
// apres un changement (le menu est construit une fois, a sa premiere ouverture).
//------------------------------------------------------------------------
static void ZckToucheRafraichirMenu(CWndMenu* pMenu, int nProfondeur)
{
	if (pMenu == NULL || nProfondeur > 8)
		return;

	for (int i = 0; i < pMenu->m_awndMenuItem.GetSize(); ++i)
	{
		CWndButton* pBouton = pMenu->GetMenuItem(i);
		if (pBouton == NULL)
			continue;

		AppletFunc* pApplet = g_WndMng.GetAppletFunc(pBouton->GetWndId());
		if (pApplet && pBouton->m_shortcut.m_dwShortcut == SHORTCUT_APPLET)
		{
			pBouton->m_cHotkey = pApplet->m_cHotkey;
			CZckChangementTouche::InfobulleFenetre(pApplet, pBouton->m_strToolTip);
		}

		if (pBouton->m_pWndMenu && pBouton->m_pWndMenu != pMenu)
			ZckToucheRafraichirMenu(pBouton->m_pWndMenu, nProfondeur + 1);
	}
}

//------------------------------------------------------------------------
// Ecriture sure d'un fichier : texte complet dans <fichier>.tmp, vide sur le
// disque (FlushFileBuffers), puis remplacement du fichier en une operation
// (MoveFileExA). Une coupure ou un plantage pendant l'ecriture laisse l'ancien
// fichier intact ; en cas d'echec, le fichier temporaire est supprime.
//------------------------------------------------------------------------
static BOOL ZckToucheEcrireFichier(LPCTSTR pszChemin, const std::string& strTexte)
{
	char szTemporaire[MAX_PATH];
	const int nEcrit = snprintf(szTemporaire, MAX_PATH, "%s%s", pszChemin, ZCK_TOUCHE_FICHIER_TEMPORAIRE);
	if (nEcrit < 0 || nEcrit >= MAX_PATH)
		return FALSE;

	HANDLE hFichier = CreateFileA(szTemporaire, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFichier == INVALID_HANDLE_VALUE)
		return FALSE;

	DWORD dwEcrits = 0;
	BOOL bReussi = WriteFile(hFichier, strTexte.data(), (DWORD)strTexte.size(), &dwEcrits, NULL);
	if (bReussi && dwEcrits != (DWORD)strTexte.size())
		bReussi = FALSE;
	if (bReussi)
		bReussi = FlushFileBuffers(hFichier);
	CloseHandle(hFichier);

	if (bReussi)
		bReussi = MoveFileExA(szTemporaire, pszChemin, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH);
	if (bReussi == FALSE)
		DeleteFileA(szTemporaire);
	return bReussi;
}

CZckChangementTouche::CZckChangementTouche()
{
	m_bInitialise = FALSE;
	m_nActionEcoutee = -1;
	m_pDemandeur = NULL;
	m_byAvalee = 0;
	m_bAvalerCaractere = FALSE;
	m_szCompte[0] = '\0';
	m_szDossier[0] = '\0';
	m_szCheminIni[0] = '\0';
}

CZckChangementTouche::~CZckChangementTouche()
{
}

//------------------------------------------------------------------------
// Fichier du compte en jeu : <dossier de Neuz.exe>\ZckTouches\compte_<nom>.ini,
// Win32 pur (comme ZckRendu.ini). Dossier de Neuz.exe introuvable ou trop long :
// dossier relatif .\ZckTouches. Sans compte : chemins vides.
//------------------------------------------------------------------------
void CZckChangementTouche::ConstruireCheminIni()
{
	m_szDossier[0] = '\0';
	m_szCheminIni[0] = '\0';

	CString strNom;
	NomFichierCompte(m_szCompte, strNom);
	if (strNom.IsEmpty())
		return;

	char szModule[MAX_PATH];
	char* pszDernier = NULL;
	const DWORD dwLongueur = GetModuleFileNameA(NULL, szModule, MAX_PATH);
	if (dwLongueur > 0 && dwLongueur < MAX_PATH)
	{
		szModule[dwLongueur] = '\0';
		pszDernier = strrchr(szModule, '\\');
	}

	// Le chemin doit tenir avec l'extension du fichier temporaire.
	const int nReserve = (int)strlen(ZCK_TOUCHE_FICHIER_TEMPORAIRE);
	int nEcrit = -1;
	if (pszDernier != NULL)
	{
		pszDernier[1] = '\0';
		nEcrit = snprintf(m_szDossier, MAX_PATH, "%s%s", szModule, ZCK_TOUCHE_DOSSIER);
		if (nEcrit >= 0 && nEcrit < MAX_PATH)
			nEcrit = snprintf(m_szCheminIni, MAX_PATH, "%s\\%s", m_szDossier, (LPCTSTR)strNom);
	}
	if (nEcrit < 0 || nEcrit + nReserve >= MAX_PATH)
	{
		nEcrit = snprintf(m_szDossier, MAX_PATH, "%s", ZCK_TOUCHE_DOSSIER_REPLI);
		if (nEcrit >= 0 && nEcrit < MAX_PATH)
			nEcrit = snprintf(m_szCheminIni, MAX_PATH, "%s\\%s", m_szDossier, (LPCTSTR)strNom);
	}
	if (nEcrit < 0 || nEcrit + nReserve >= MAX_PATH)
	{
		m_szDossier[0] = '\0';
		m_szCheminIni[0] = '\0';
	}
}

void CZckChangementTouche::NomFichierCompte(LPCTSTR pszCompte, CString& strNom)
{
	strNom.Empty();
	if (pszCompte == NULL || pszCompte[0] == '\0' || strlen(pszCompte) >= ZCK_TOUCHE_COMPTE_TAILLE)
		return;

	static const char s_szHexa[] = "0123456789abcdef";
	char szCode[ZCK_TOUCHE_COMPTE_TAILLE * 3];
	size_t n = 0;
	for (const char* p = pszCompte; *p; ++p)
	{
		unsigned char c = (unsigned char)*p;
		if (c >= 'A' && c <= 'Z')
			c = (unsigned char)(c - 'A' + 'a');			// comptes sans casse : Zacks et zacks, un seul fichier
		if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9'))
			szCode[n++] = (char)c;
		else
		{
			szCode[n++] = '_';
			szCode[n++] = s_szHexa[c >> 4];
			szCode[n++] = s_szHexa[c & 0x0F];
		}
	}
	szCode[n] = '\0';
	strNom.Format("%s%s%s", ZCK_TOUCHE_FICHIER_PREFIXE, szCode, ZCK_TOUCHE_FICHIER_EXTENSION);
}

void CZckChangementTouche::AjouterAction(int nType, DWORD dwId, DWORD dwTid, DWORD dwAutorisation, BYTE byDefaut)
{
	ZCK_TOUCHE_ACTION action;
	action.nType = nType;
	action.dwId = dwId;
	action.dwTid = dwTid;
	action.dwAutorisation = dwAutorisation;
	action.byDefaut = byDefaut;
	m_vecActions.push_back(action);
}

int CZckChangementTouche::TrouverFenetre(DWORD dwApplet) const
{
	for (size_t i = 0; i < m_vecActions.size(); ++i)
	{
		if (m_vecActions[i].nType == ZCK_TOUCHE_TYPE_FENETRE && m_vecActions[i].dwId == dwApplet)
			return (int)i;
	}
	return -1;
}

char* CZckChangementTouche::ToucheSysteme(DWORD dwId)
{
	switch (dwId)
	{
	case ZCK_TOUCHE_AVANCER:	return &g_Neuz.Key.chUp;
	case ZCK_TOUCHE_RECULER:	return &g_Neuz.Key.chBack;
	case ZCK_TOUCHE_GAUCHE:		return &g_Neuz.Key.chLeft;
	case ZCK_TOUCHE_DROITE:		return &g_Neuz.Key.chRight;
	case ZCK_TOUCHE_MARCHER:	return &g_Neuz.Key.chWalk;
	case ZCK_TOUCHE_SUIVRE:		return &g_Neuz.Key.chTrace;
	}
	return NULL;
}

// Touche d'origine d'une action deja relevee par un appel precedent
// d'Initialiser (peripherique recree), sinon la touche actuelle.
static BYTE ZckToucheDefautConnu(const std::vector<ZCK_TOUCHE_ACTION>& vecAnciennes, int nType, DWORD dwId, BYTE byActuelle)
{
	for (size_t i = 0; i < vecAnciennes.size(); ++i)
	{
		if (vecAnciennes[i].nType == nType && vecAnciennes[i].dwId == dwId)
			return vecAnciennes[i].byDefaut;
	}
	return byActuelle;
}

void CZckChangementTouche::Initialiser()
{
	// Un second appel ne doit pas prendre les touches du joueur pour celles d'origine.
	std::vector<ZCK_TOUCHE_ACTION> vecAnciennes;
	vecAnciennes.swap(m_vecActions);
	m_nActionEcoutee = -1;
	m_pDemandeur = NULL;
	m_byAvalee = 0;
	m_bAvalerCaractere = FALSE;
	ConstruireCheminIni();

	// 1. Actions systeme, touches posees par InitGlobalVars (AZERTY : Z Q S D W F).
	for (DWORD dwId = 0; dwId < ZCK_TOUCHE_NB_SYSTEME; ++dwId)
	{
		const char* pchTouche = ToucheSysteme(dwId);
		const BYTE byActuelle = pchTouche ? (BYTE)*pchTouche : 0;
		AjouterAction(ZCK_TOUCHE_TYPE_SYSTEME, dwId, 0, 0, ZckToucheDefautConnu(vecAnciennes, ZCK_TOUCHE_TYPE_SYSTEME, dwId, byActuelle));
	}

	// 2. Fenetres du tableau, si elles sont enregistrees dans cette compilation.
	for (int i = 0; i < s_nZckToucheFenetres; ++i)
	{
		const ZCK_TOUCHE_FENETRE& fenetre = s_aZckToucheFenetres[i];
		AppletFunc* pApplet = g_WndMng.GetAppletFunc(fenetre.dwApplet);
		if (pApplet == NULL || TrouverFenetre(fenetre.dwApplet) >= 0)
			continue;
		const BYTE byDefaut = ZckToucheDefautConnu(vecAnciennes, ZCK_TOUCHE_TYPE_FENETRE, fenetre.dwApplet, (BYTE)pApplet->m_cHotkey);
		AjouterAction(ZCK_TOUCHE_TYPE_FENETRE, fenetre.dwApplet, fenetre.dwTid, fenetre.dwAutorisation, byDefaut);
	}

	// 3. Toute autre fenetre enregistree avec une touche d'origine : ajoutee a la
	// fin, par identifiant croissant, pour qu'aucune touche n'echappe a l'unicite.
	std::vector<DWORD> vecAutres;
	POSITION pos = g_WndMng.m_mapAppletFunc.GetStartPosition();
	while (pos)
	{
		DWORD dwIdApplet = 0;
		AppletFunc* pApplet = NULL;
		g_WndMng.m_mapAppletFunc.GetNextAssoc(pos, dwIdApplet, (void*&)pApplet);
		if (pApplet == NULL || TrouverFenetre(dwIdApplet) >= 0)
			continue;
		if (ZckToucheDefautConnu(vecAnciennes, ZCK_TOUCHE_TYPE_FENETRE, dwIdApplet, (BYTE)pApplet->m_cHotkey) != 0)
			vecAutres.push_back(dwIdApplet);
	}
	std::sort(vecAutres.begin(), vecAutres.end());
	for (size_t i = 0; i < vecAutres.size(); ++i)
	{
		AppletFunc* pApplet = g_WndMng.GetAppletFunc(vecAutres[i]);
		if (pApplet)
			AjouterAction(ZCK_TOUCHE_TYPE_FENETRE, vecAutres[i], 0, 0,
				ZckToucheDefautConnu(vecAnciennes, ZCK_TOUCHE_TYPE_FENETRE, vecAutres[i], (BYTE)pApplet->m_cHotkey));
	}

	// 4. Priorite d'attribution : actions systeme, puis fenetres dans l'ordre de
	// parcours de m_mapAppletFunc, celui de la boucle d'ouverture de
	// CWndTaskBar::Process. A touche d'origine egale, la fenetre que le jeu
	// ouvrait deja garde sa touche (AZERTY : L reste a la Recherche de groupe).
	m_vecOrdre.clear();
	for (int i = 0; i < GetNbActions(); ++i)
	{
		if (m_vecActions[i].nType == ZCK_TOUCHE_TYPE_SYSTEME)
			m_vecOrdre.push_back(i);
	}
	pos = g_WndMng.m_mapAppletFunc.GetStartPosition();
	while (pos)
	{
		DWORD dwIdApplet = 0;
		AppletFunc* pApplet = NULL;
		g_WndMng.m_mapAppletFunc.GetNextAssoc(pos, dwIdApplet, (void*&)pApplet);
		const int nAction = TrouverFenetre(dwIdApplet);
		if (nAction >= 0)
			m_vecOrdre.push_back(nAction);
	}

	// 5. Touches du compte en jeu (peripherique recree en cours de partie : AddAllApplet
	// vient de remettre les touches d'origine des fenetres), sinon touches d'origine ;
	// puis attribution : une touche = une action.
	std::vector<BYTE> vecSouhait;
	Charger(vecSouhait);
	Attribuer(vecSouhait);

	m_bInitialise = TRUE;
}

//------------------------------------------------------------------------
// Compte en jeu
//------------------------------------------------------------------------
void CZckChangementTouche::ChargerCompte(LPCTSTR pszCompte)
{
	AnnulerEcoute();

	m_szCompte[0] = '\0';
	if (pszCompte != NULL && strlen(pszCompte) < ZCK_TOUCHE_COMPTE_TAILLE)
	{
		strncpy(m_szCompte, pszCompte, ZCK_TOUCHE_COMPTE_TAILLE - 1);
		m_szCompte[ZCK_TOUCHE_COMPTE_TAILLE - 1] = '\0';
	}
	ConstruireCheminIni();
	if (m_szCheminIni[0] == '\0')
		m_szCompte[0] = '\0';				// nom vide ou chemin impossible : pas de compte, rien de modifiable

	if (m_bInitialise == FALSE)
		return;

	std::vector<BYTE> vecSouhait;
	const int nLues = Charger(vecSouhait);
	Attribuer(vecSouhait);
	Rafraichir();
#ifdef __ZCK_SPD_LOG
	if (EstCompteCharge())
		ZCK_LOG_INFO("ZckChangementTouche : entree en jeu, %d touche(s) lue(s) dans le fichier du compte.", nLues);
	else
		ZCK_LOG_WARNING("ZckChangementTouche : entree en jeu sans compte utilisable, touches d'origine.");
#else
	(void)nLues;
#endif // __ZCK_SPD_LOG
}

void CZckChangementTouche::QuitterCompte()
{
	AnnulerEcoute();

	m_szCompte[0] = '\0';
	ConstruireCheminIni();

	if (m_bInitialise == FALSE)
		return;

	std::vector<BYTE> vecSouhait;
	Charger(vecSouhait);					// sans compte : touches d'origine
	Attribuer(vecSouhait);
	Rafraichir();
}

BYTE CZckChangementTouche::GetTouche(int nAction) const
{
	if (nAction < 0 || nAction >= GetNbActions())
		return 0;

	const ZCK_TOUCHE_ACTION& action = m_vecActions[nAction];
	if (action.nType == ZCK_TOUCHE_TYPE_SYSTEME)
	{
		const char* pchTouche = ToucheSysteme(action.dwId);
		return pchTouche ? (BYTE)*pchTouche : 0;
	}

	AppletFunc* pApplet = g_WndMng.GetAppletFunc(action.dwId);
	return pApplet ? (BYTE)pApplet->m_cHotkey : 0;
}

void CZckChangementTouche::SetTouche(int nAction, BYTE byTouche)
{
	if (nAction < 0 || nAction >= GetNbActions())
		return;

	const ZCK_TOUCHE_ACTION& action = m_vecActions[nAction];
	if (action.nType == ZCK_TOUCHE_TYPE_SYSTEME)
	{
		char* pchTouche = ToucheSysteme(action.dwId);
		if (pchTouche)
			*pchTouche = (char)byTouche;
		return;
	}

	AppletFunc* pApplet = g_WndMng.GetAppletFunc(action.dwId);
	if (pApplet)
		pApplet->m_cHotkey = (CHAR)byTouche;
}

BOOL CZckChangementTouche::EstSysteme(int nAction) const
{
	if (nAction < 0 || nAction >= GetNbActions())
		return FALSE;
	return m_vecActions[nAction].nType == ZCK_TOUCHE_TYPE_SYSTEME;
}

// Avancer, reculer et tourner gardent toujours une touche : sans elles,
// plus aucun deplacement au clavier.
BOOL CZckChangementTouche::EstObligatoire(int nAction) const
{
	if (EstSysteme(nAction) == FALSE)
		return FALSE;
	return m_vecActions[nAction].dwId <= ZCK_TOUCHE_DROITE;
}

BOOL CZckChangementTouche::EstVisible(int nAction) const
{
	if (nAction < 0 || nAction >= GetNbActions())
		return FALSE;

	const DWORD dwAutorisation = m_vecActions[nAction].dwAutorisation;
	if (dwAutorisation == 0)
		return TRUE;

	return g_pPlayer && g_pPlayer->IsAuthHigher(dwAutorisation);
}

void CZckChangementTouche::GetLibelle(int nAction, CString& strLibelle) const
{
	strLibelle.Empty();
	if (nAction < 0 || nAction >= GetNbActions())
		return;

	const ZCK_TOUCHE_ACTION& action = m_vecActions[nAction];
	if (action.nType == ZCK_TOUCHE_TYPE_SYSTEME)
	{
		if (action.dwId < ZCK_TOUCHE_NB_SYSTEME)
			strLibelle = s_apszZckToucheLibelleSysteme[action.dwId];
		return;
	}

	if (action.dwTid != 0)
	{
		LPCTSTR pszTexte = prj.GetText(action.dwTid);
		if (pszTexte && pszTexte[0])
		{
			strLibelle = pszTexte;
			return;
		}
	}

	AppletFunc* pApplet = g_WndMng.GetAppletFunc(action.dwId);
	if (pApplet && pApplet->m_pAppletDesc && pApplet->m_pAppletDesc[0])
		strLibelle = pApplet->m_pAppletDesc;
	else
		strLibelle.Format("Fen\352tre %lu", (unsigned long)action.dwId);
}

// Cle de la ligne dans ZckTouches.ini : nom fixe pour le systeme, nom interne
// de l'applet pour une fenetre ("WndInventory"), ou "Fenetre<id>" a defaut.
void CZckChangementTouche::GetCleIni(int nAction, CString& strCle) const
{
	strCle.Empty();
	if (nAction < 0 || nAction >= GetNbActions())
		return;

	const ZCK_TOUCHE_ACTION& action = m_vecActions[nAction];
	if (action.nType == ZCK_TOUCHE_TYPE_SYSTEME)
	{
		if (action.dwId < ZCK_TOUCHE_NB_SYSTEME)
			strCle = s_apszZckToucheCleSysteme[action.dwId];
		return;
	}

	AppletFunc* pApplet = g_WndMng.GetAppletFunc(action.dwId);
	BOOL bNomValide = (pApplet && pApplet->m_pAppletName && pApplet->m_pAppletName[0]) ? TRUE : FALSE;
	if (bNomValide)
	{
		for (const char* p = pApplet->m_pAppletName; *p; ++p)
		{
			const char c = *p;
			if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_'))
			{
				bNomValide = FALSE;
				break;
			}
		}
	}

	if (bNomValide)
		strCle = pApplet->m_pAppletName;
	else
		strCle.Format("Fenetre%lu", (unsigned long)action.dwId);
}

int CZckChangementTouche::TrouverAction(BYTE byTouche) const
{
	if (byTouche == 0)
		return -1;

	for (int i = 0; i < GetNbActions(); ++i)
	{
		if (GetTouche(i) == byTouche)
			return i;
	}
	return -1;
}

//------------------------------------------------------------------------
// Touches souhaitees : touche d'origine, remplacee par le fichier du compte
// quand la ligne existe et que sa valeur est acceptable pour cette action.
// Sans compte : touches d'origine, aucun fichier lu. Renvoie le nombre de
// lignes trouvees dans le fichier.
//------------------------------------------------------------------------
int CZckChangementTouche::Charger(std::vector<BYTE>& vecSouhait) const
{
	const int nNbActions = GetNbActions();
	vecSouhait.assign(nNbActions, 0);
	for (int i = 0; i < nNbActions; ++i)
		vecSouhait[i] = m_vecActions[i].byDefaut;

	if (m_szCheminIni[0] == '\0')
		return 0;

	int nLues = 0;
	char szValeur[32];
	CString strCle;
	for (int i = 0; i < nNbActions; ++i)
	{
		GetCleIni(i, strCle);
		if (strCle.IsEmpty())
			continue;

		szValeur[0] = '\0';
		const DWORD dwLu = GetPrivateProfileStringA(ZCK_TOUCHE_INI_SECTION, strCle, "", szValeur, sizeof(szValeur), m_szCheminIni);
		if (dwLu == 0)
			continue;						// ligne absente : touche d'origine
		szValeur[sizeof(szValeur) - 1] = '\0';
		++nLues;

		BYTE byTouche = 0;
		if (LireNomTouche(szValeur, &byTouche) == FALSE)
			continue;						// valeur illisible : touche d'origine

		if (byTouche == 0)
		{
			if (EstObligatoire(i) == FALSE)
				vecSouhait[i] = 0;			// "Aucune"
			continue;
		}

		if (EstToucheAutorisee(byTouche, EstSysteme(i), NULL) == FALSE)
			continue;						// touche refusee : touche d'origine

		vecSouhait[i] = byTouche;
	}
	return nLues;
}

//------------------------------------------------------------------------
// Une touche = une action. Dans l'ordre de priorite (m_vecOrdre) : la touche
// souhaitee si elle est libre, sinon la touche d'origine si elle est libre,
// sinon aucune. Une action obligatoire sans touche libre recoit la premiere
// lettre libre.
//------------------------------------------------------------------------
void CZckChangementTouche::Attribuer(const std::vector<BYTE>& vecSouhait)
{
	BYTE abyPrise[256];
	memset(abyPrise, 0, sizeof(abyPrise));

	const int nNbActions = GetNbActions();
	if ((int)m_vecOrdre.size() != nNbActions)
	{
		m_vecOrdre.clear();					// liste incoherente : ordre d'affichage
		for (int i = 0; i < nNbActions; ++i)
			m_vecOrdre.push_back(i);
	}

	for (int k = 0; k < nNbActions; ++k)
	{
		const int i = m_vecOrdre[k];
		BYTE byTouche = (i < (int)vecSouhait.size()) ? vecSouhait[i] : m_vecActions[i].byDefaut;

		if (byTouche != 0 && abyPrise[byTouche])
			byTouche = m_vecActions[i].byDefaut;
		if (byTouche != 0 && abyPrise[byTouche])
			byTouche = 0;
		if (byTouche == 0 && EstObligatoire(i))
			byTouche = LettreLibre(abyPrise);

		SetTouche(i, byTouche);
		if (byTouche != 0)
			abyPrise[byTouche] = 1;
	}
}

BYTE CZckChangementTouche::LettreLibre(const BYTE* pbyPrise)
{
	for (BYTE byLettre = 'A'; byLettre <= 'Z'; ++byLettre)
	{
		if (byLettre != ZCK_TOUCHE_RESERVEE_ACTION && pbyPrise[byLettre] == 0)
			return byLettre;
	}
	return 0;
}

// Fichier du compte reecrit en entier : [Touches], Version, une ligne par action.
BOOL CZckChangementTouche::Sauvegarder()
{
	if (m_szCheminIni[0] == '\0')
		return FALSE;						// sans compte : rien n'est modifiable, rien a ecrire

	std::string strTexte;
	strTexte.reserve(4096);

	CString strLigne;
	strLigne.Format("[%s]\r\n%s=%d\r\n", ZCK_TOUCHE_INI_SECTION, ZCK_TOUCHE_INI_CLE_VERSION, ZCK_TOUCHE_INI_VERSION);
	strTexte += (LPCTSTR)strLigne;

	CString strCle, strNom;
	for (int i = 0; i < GetNbActions(); ++i)
	{
		GetCleIni(i, strCle);
		if (strCle.IsEmpty())
			continue;

		const BYTE byTouche = GetTouche(i);
		if (byTouche == 0)
			strNom = ZCK_TOUCHE_INI_AUCUNE;
		else if (EstNommable(byTouche))
			NomTouche(byTouche, strNom);
		else
			continue;						// touche d'origine sans nom ecrivable : rien a sauver

		strLigne.Format("%s=%s\r\n", (LPCTSTR)strCle, (LPCTSTR)strNom);
		strTexte += (LPCTSTR)strLigne;
	}

	CreateDirectoryA(m_szDossier, NULL);	// deja present : sans effet
	if (ZckToucheEcrireFichier(m_szCheminIni, strTexte) == FALSE)
	{
#ifdef __ZCK_SPD_LOG
		ZCK_LOG_WARNING("ZckChangementTouche : ecriture du fichier du compte impossible (erreur Windows %lu).", (unsigned long)GetLastError());
#endif // __ZCK_SPD_LOG
		Message("ZckTouches : \351criture impossible, les touches ne sont pas sauvegard\351es.", ZCK_TOUCHE_COULEUR_REFUS);
		return FALSE;
	}
	return TRUE;
}

void CZckChangementTouche::Rafraichir()
{
	if (g_WndMng.m_pWndMenu)
		ZckToucheRafraichirMenu(g_WndMng.m_pWndMenu, 0);
}

void CZckChangementTouche::Message(LPCTSTR pszMessage, DWORD dwCouleur)
{
	g_WndMng.PutString(pszMessage, NULL, dwCouleur, CHATSTY_SYSTEM_CLIENT);
}

void CZckChangementTouche::RetablirDefauts()
{
	AnnulerEcoute();
	if (EstCompteCharge() == FALSE)
		return;								// sans compte, les touches d'origine sont deja en place

	std::vector<BYTE> vecSouhait(GetNbActions(), 0);
	for (int i = 0; i < GetNbActions(); ++i)
		vecSouhait[i] = m_vecActions[i].byDefaut;

	Attribuer(vecSouhait);
	Sauvegarder();
	Rafraichir();
	Message("Touches par d\351faut r\351tablies.", ZCK_TOUCHE_COULEUR_INFO);
}

//------------------------------------------------------------------------
// Ecoute d'une touche
//------------------------------------------------------------------------
void CZckChangementTouche::DemarrerEcoute(int nAction, CWndBase* pDemandeur)
{
	if (nAction < 0 || nAction >= GetNbActions() || pDemandeur == NULL)
		return;
	if (EstCompteCharge() == FALSE)
		return;								// avant l'entree en jeu : le compte n'est pas connu

	m_nActionEcoutee = nAction;
	m_pDemandeur = pDemandeur;
}

void CZckChangementTouche::AnnulerEcoute(CWndBase* pDemandeur)
{
	if (pDemandeur != NULL && pDemandeur != m_pDemandeur)
		return;

	m_nActionEcoutee = -1;
	m_pDemandeur = NULL;
}

// L'onglet qui ecoute doit etre affiche, ainsi que toute sa lignee
// (onglet choisi, fenetre Options ouverte et non masquee).
BOOL CZckChangementTouche::DemandeurAffiche() const
{
	CWndBase* pWnd = m_pDemandeur;
	for (int nGarde = 0; pWnd && nGarde < 16; ++nGarde)
	{
		if (pWnd->IsVisible() == FALSE)
			return FALSE;

		CWndBase* pParent = pWnd->GetParentWnd();
		if (pParent == NULL || pParent == pWnd)
			return TRUE;
		pWnd = pParent;
	}
	return FALSE;
}

BOOL CZckChangementTouche::TraiterMessage(UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (msg == WM_KILLFOCUS || (msg == WM_ACTIVATEAPP && wParam == FALSE))
	{
		m_byAvalee = 0;
		m_bAvalerCaractere = FALSE;
		AnnulerEcoute();
		return FALSE;
	}

	// Un clic pendant l'ecoute l'abandonne (clic dans la discussion, sur une
	// autre fenetre...) : la touche suivante ne change plus rien par surprise.
	// Le double-clic qui ouvre l'ecoute (WM_LBUTTONDBLCLK) n'est pas concerne.
	if (m_nActionEcoutee >= 0 && (msg == WM_LBUTTONDOWN || msg == WM_RBUTTONDOWN || msg == WM_MBUTTONDOWN))
	{
		AnnulerEcoute();
		return FALSE;
	}

	// Suite de la touche capturee : sa repetition, son caractere et son
	// relachement n'atteignent pas le jeu (la touche I capturee n'ouvre pas
	// l'inventaire, la touche C ne lance pas la barre d'action).
	// TranslateMessage poste le caractere d'un appui juste derriere lui : seul le
	// caractere qui suit la touche capturee (ou sa repetition) est avale.
	if (m_byAvalee != 0)
	{
		switch (msg)
		{
		case WM_KEYDOWN:
		case WM_SYSKEYDOWN:
			if (wParam == (WPARAM)m_byAvalee && (lParam & (1L << 30)))
			{
				m_bAvalerCaractere = TRUE;	// repetition : la touche est encore enfoncee
				return TRUE;
			}
			if (wParam == (WPARAM)m_byAvalee)
				m_byAvalee = 0;				// nouvel appui : le relachement precedent a ete perdu
			m_bAvalerCaractere = FALSE;		// le caractere suivant vient de cet appui
			break;

		case WM_CHAR:
		case WM_SYSCHAR:
		case WM_DEADCHAR:
		case WM_SYSDEADCHAR:
			if (m_bAvalerCaractere)
			{
				m_bAvalerCaractere = FALSE;
				return TRUE;
			}
			break;

		case WM_KEYUP:
		case WM_SYSKEYUP:
			if (wParam == (WPARAM)m_byAvalee)
			{
				m_byAvalee = 0;
				m_bAvalerCaractere = FALSE;
				return TRUE;
			}
			break;
		}
	}

	if (m_nActionEcoutee < 0)
		return FALSE;

	if (msg != WM_KEYDOWN && msg != WM_SYSKEYDOWN)
		return FALSE;

	if (DemandeurAffiche() == FALSE)
	{
		AnnulerEcoute();					// onglet ferme, masque ou quitte : plus rien a ecouter
		return FALSE;
	}

	if (wParam == 0 || wParam > 0xFF)
		return FALSE;

	if (lParam & (1L << 30))
		return FALSE;						// repetition d'une touche deja enfoncee avant l'ecoute

	const BYTE byTouche = (BYTE)wParam;
	if (EstModificateur(byTouche))
		return FALSE;						// Maj, Ctrl, Alt... : l'ecoute continue

	m_byAvalee = byTouche;
	m_bAvalerCaractere = TRUE;
	Capturer(byTouche);
	return TRUE;
}

void CZckChangementTouche::Capturer(BYTE byTouche)
{
	const int nAction = m_nActionEcoutee;
	AnnulerEcoute();
	if (nAction < 0 || nAction >= GetNbActions())
		return;

	CString strAction, strTouche, strMessage;
	GetLibelle(nAction, strAction);

	if (byTouche == VK_RETURN)
	{
		Message("Changement de touche annul\351.", ZCK_TOUCHE_COULEUR_INFO);
		return;
	}

	if (byTouche == VK_ESCAPE)
	{
		if (EstObligatoire(nAction))
		{
			strMessage.Format("%s doit garder une touche.", (LPCTSTR)strAction);
			Message(strMessage, ZCK_TOUCHE_COULEUR_REFUS);
			return;
		}

		if (GetTouche(nAction) != 0)
		{
			SetTouche(nAction, 0);
			Sauvegarder();
			Rafraichir();
		}
		strMessage.Format("%s : aucune touche.", (LPCTSTR)strAction);
		Message(strMessage, ZCK_TOUCHE_COULEUR_INFO);
		return;
	}

	CString strRaison;
	if (EstToucheAutorisee(byTouche, EstSysteme(nAction), &strRaison) == FALSE)
	{
		Message(strRaison, ZCK_TOUCHE_COULEUR_REFUS);
		return;
	}

	NomTouche(byTouche, strTouche);
	const BYTE byAncienne = GetTouche(nAction);
	if (byAncienne == byTouche)
	{
		strMessage.Format("%s : touche %s inchang\351e.", (LPCTSTR)strAction, (LPCTSTR)strTouche);
		Message(strMessage, ZCK_TOUCHE_COULEUR_INFO);
		return;
	}

	const int nAutre = TrouverAction(byTouche);
	if (nAutre >= 0 && nAutre != nAction)
	{
		CString strAutre;
		GetLibelle(nAutre, strAutre);

		if (EstObligatoire(nAutre))
		{
			if (EstObligatoire(nAction) == FALSE)
			{
				strMessage.Format("La touche %s sert \340 %s : changez d'abord la touche de cette action.", (LPCTSTR)strTouche, (LPCTSTR)strAutre);
				Message(strMessage, ZCK_TOUCHE_COULEUR_REFUS);
				return;
			}

			// Deux deplacements : les touches sont echangees.
			SetTouche(nAutre, byAncienne);
			SetTouche(nAction, byTouche);
			Sauvegarder();
			Rafraichir();
			strMessage.Format("%s et %s : touches \351chang\351es.", (LPCTSTR)strAction, (LPCTSTR)strAutre);
			Message(strMessage, ZCK_TOUCHE_COULEUR_INFO);
			return;
		}

		SetTouche(nAutre, 0);
		strMessage.Format("%s : touche %s retir\351e.", (LPCTSTR)strAutre, (LPCTSTR)strTouche);
		Message(strMessage, ZCK_TOUCHE_COULEUR_INFO);
	}

	SetTouche(nAction, byTouche);
	Sauvegarder();
	Rafraichir();
	strMessage.Format("%s : touche %s.", (LPCTSTR)strAction, (LPCTSTR)strTouche);
	Message(strMessage, ZCK_TOUCHE_COULEUR_INFO);
}

//------------------------------------------------------------------------
// Outils sans etat
//------------------------------------------------------------------------
void CZckChangementTouche::NomTouche(BYTE byTouche, CString& strNom)
{
	if (byTouche == 0)
		strNom.Empty();
	else if (byTouche >= VK_F1 && byTouche <= VK_F24)
		strNom.Format("F%d", (int)(byTouche - VK_F1) + 1);
	else
		strNom.Format("%c", (char)byTouche);	// lettres et chiffres : comme l'affichage d'origine
}

BOOL CZckChangementTouche::EstNommable(BYTE byTouche)
{
	return (byTouche >= 'A' && byTouche <= 'Z')
		|| (byTouche >= '0' && byTouche <= '9')
		|| (byTouche >= VK_F1 && byTouche <= VK_F24);
}

void CZckChangementTouche::InfobulleFenetre(const AppletFunc* pApplet, CString& strInfobulle)
{
	strInfobulle.Empty();
	if (pApplet == NULL)
		return;

	if (pApplet->m_cHotkey == 0)
	{
		strInfobulle.Format("%s", pApplet->m_pAppletDesc);
		return;
	}

	CString strTouche;
	NomTouche((BYTE)pApplet->m_cHotkey, strTouche);
	strInfobulle.Format("%s\n[%s %s]", pApplet->m_pAppletDesc, prj.GetText(TID_GAME_TOOLTIP_HOTKEY), (LPCTSTR)strTouche);
}

BOOL CZckChangementTouche::EstToucheAutorisee(BYTE byTouche, BOOL bSysteme, CString* pstrRaison)
{
	CString strNom;
	NomTouche(byTouche, strNom);

	if (byTouche >= 'A' && byTouche <= 'Z')
	{
		if (byTouche == ZCK_TOUCHE_RESERVEE_ACTION)
		{
			if (pstrRaison)
				pstrRaison->Format("La touche %s est r\351serv\351e \340 la barre d'action.", (LPCTSTR)strNom);
			return FALSE;
		}
		return TRUE;
	}

	// 1 a 9 et F1 a F9 : emplacements de la barre de raccourcis, 0 : capture d'ecran.
	if ((byTouche >= '0' && byTouche <= '9') || (byTouche >= VK_F1 && byTouche <= VK_F9))
	{
		if (pstrRaison)
			pstrRaison->Format("La touche %s est r\351serv\351e \340 la barre de raccourcis.", (LPCTSTR)strNom);
		return FALSE;
	}

	if (byTouche >= VK_F10 && byTouche <= VK_F24)
	{
		if (bSysteme)
		{
			if (pstrRaison)
				*pstrRaison = "D\351placements, Marcher et Suivre : lettres A \340 Z uniquement.";
			return FALSE;
		}

		if (byTouche == VK_F10)
		{
#if defined(__ZCK_IMGUI)
			// ZckImGui::HandleWndProc garde F10 (Developer Tools) : elle n'atteint jamais le jeu.
			if (pstrRaison)
				*pstrRaison = "La touche F10 est r\351serv\351e aux outils de d\351veloppement (ImGui).";
			return FALSE;
#elif defined(__AIO_NEUZAPP)
			// WM_SYSKEYDOWN est traite comme WM_KEYDOWN par CNeuzApp::MsgProc.
			return TRUE;
#else
			if (pstrRaison)
				*pstrRaison = "La touche F10 est une touche syst\350me de Windows : elle n'est pas prise en charge.";
			return FALSE;
#endif
		}
		return TRUE;
	}

	if (pstrRaison)
		*pstrRaison = "Touche non prise en charge : lettres A \340 Z, et F11 \340 F24 pour les fen\352tres.";
	return FALSE;
}

BOOL CZckChangementTouche::EstModificateur(BYTE byTouche)
{
	switch (byTouche)
	{
	case VK_SHIFT:
	case VK_CONTROL:
	case VK_MENU:
	case VK_LSHIFT:
	case VK_RSHIFT:
	case VK_LCONTROL:
	case VK_RCONTROL:
	case VK_LMENU:
	case VK_RMENU:
	case VK_LWIN:
	case VK_RWIN:
	case VK_APPS:
	case VK_CAPITAL:
	case VK_NUMLOCK:
	case VK_SCROLL:
	case VK_PROCESSKEY:
		return TRUE;
	}
	return FALSE;
}

BOOL CZckChangementTouche::LireNomTouche(const char* pszNom, BYTE* pbyTouche)
{
	if (pszNom == NULL || pbyTouche == NULL)
		return FALSE;

	while (*pszNom == ' ' || *pszNom == '\t')
		++pszNom;

	char szNom[16];
	size_t nLongueur = 0;
	while (pszNom[nLongueur] && nLongueur < sizeof(szNom) - 1)
	{
		szNom[nLongueur] = pszNom[nLongueur];
		++nLongueur;
	}
	if (pszNom[nLongueur] != '\0')
		return FALSE;						// trop long : illisible
	while (nLongueur > 0 && (szNom[nLongueur - 1] == ' ' || szNom[nLongueur - 1] == '\t'))
		--nLongueur;
	szNom[nLongueur] = '\0';

	// "Aucune", sans tenir compte de la casse.
	const char* pszAucune = ZCK_TOUCHE_INI_AUCUNE;
	if (nLongueur == strlen(pszAucune))
	{
		BOOL bAucune = TRUE;
		for (size_t i = 0; i < nLongueur; ++i)
		{
			char c = szNom[i];
			char d = pszAucune[i];
			if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
			if (d >= 'a' && d <= 'z') d = (char)(d - 'a' + 'A');
			if (c != d)
			{
				bAucune = FALSE;
				break;
			}
		}
		if (bAucune)
		{
			*pbyTouche = 0;
			return TRUE;
		}
	}

	if (nLongueur == 1)
	{
		char c = szNom[0];
		if (c >= 'a' && c <= 'z')
			c = (char)(c - 'a' + 'A');
		if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
		{
			*pbyTouche = (BYTE)c;
			return TRUE;
		}
		return FALSE;
	}

	if ((szNom[0] == 'F' || szNom[0] == 'f') && (nLongueur == 2 || nLongueur == 3))
	{
		int nNumero = 0;
		for (size_t i = 1; i < nLongueur; ++i)
		{
			if (szNom[i] < '0' || szNom[i] > '9')
				return FALSE;
			nNumero = nNumero * 10 + (szNom[i] - '0');
		}
		if (nNumero >= 1 && nNumero <= 24)
		{
			*pbyTouche = (BYTE)(VK_F1 + nNumero - 1);
			return TRUE;
		}
	}
	return FALSE;
}

#endif // __ZCK_CHANGEMENT_TOUCHE
