#include "stdafx.h"

#ifdef __ZCK_QUEST

#include "WndZckQuest.h"
#include "resdata.h"
#include "DPClient.h"
#include "defineObj.h"
#include "defineText.h"
#ifdef __ZCK_PRESTIGE
#include "ZckPrestige.h"
#endif // __ZCK_PRESTIGE
#include <algorithm>
#include <float.h>
#include <limits.h>
#include <math.h>

extern CDPClient g_DPlay;

namespace
{
	//////////////////////////////////////////////////////////////////
	// Journal (coordonnees client). Fenetre par defaut 960 x 640, zone
	// client 948 x 608 (CWndBase::SetWndRect retire 18 de legende puis 4,
	// 4, 8, 10). Tailles multiples de 16, comme l'exige CWndNeuz::OnSize
	// pour un fond en tuiles : de 768 x 544 a la zone d'affichage
	// arrondie a 16. Les colonnes se calent sur la zone client :
	//   bandeau 4..48, onglets 52..78, corps 84..H-42, pied H-36..H-8 ;
	//   corps : liste | detail (recompenses en bas) | apercu + fiche.
	//////////////////////////////////////////////////////////////////
	const int ZCK_QU_FENETRE_L = 960;
	const int ZCK_QU_FENETRE_H = 640;
	const int ZCK_QU_FENETRE_L_MIN = 768;
	const int ZCK_QU_FENETRE_H_MIN = 544;
	const int ZCK_QU_BORD = 8;
	const int ZCK_QU_ECART = 6;
	const int ZCK_QU_BANDEAU_HAUT = 4;
	const int ZCK_QU_BANDEAU_BAS = 48;
	const int ZCK_QU_ONGLETS_HAUT = 52;
	const int ZCK_QU_ONGLETS_BAS = 78;
	const int ZCK_QU_CORPS_HAUT = 84;
	const int ZCK_QU_PIED_H = 28;
	const int ZCK_QU_TITRE_H = 20;			// bande de titre d'un panneau
	const int ZCK_QU_LIGNE_H = 40;			// ligne de la liste
	const int ZCK_QU_PISTE_L = 6;			// barre de defilement de la liste
	const int ZCK_QU_LISTE_L_MIN = 210;
	const int ZCK_QU_LISTE_L_MAX = 320;
	const int ZCK_QU_MONSTRE_L_MIN = 220;
	const int ZCK_QU_MONSTRE_L_MAX = 330;
	const int ZCK_QU_APERCU_H_MIN = 120;
	const int ZCK_QU_TETE_H = 54;			// en-tete du detail
	const int ZCK_QU_SLOT = 40;				// cadre d'une recompense, icone 32 au centre
	const int ZCK_QU_ICONE = 32;
	const int ZCK_QU_CONDITION_H = 18;
	const int ZCK_QU_RECOMPENSE_H = 18;
	const int ZCK_QU_FICHE_H = 17;
	const int ZCK_QU_PUCE_H = 20;			// monstre de l'objectif (pastille cliquable)
	const int ZCK_QU_OBJECTIF_H_MIN = ZCK_QU_TITRE_H + 64;
	const int ZCK_QU_ACTION_L = 170;
	const int ZCK_QU_FERMER_L = 100;
	const int ZCK_QU_SUIVI_L = 132;
	const int ZCK_QU_AGRANDIR_L = 100;
	const int ZCK_QU_BOUTON_H = 22;
	const int ZCK_QU_DESC_LIGNES = 3;		// description : lignes au plus, la suite en infobulle
	const int ZCK_QU_DEFILEMENT = 3;		// lignes par cran de molette

	const DWORD ZCK_QU_ATTENTE_MS = 5000;	// reponse du serveur a une action attendue au plus
	const DWORD ZCK_QU_CONFIRMER_MS = 4000;	// second clic d'Abandonner attendu au plus
	const DWORD ZCK_QU_LISTE_MS = 250;		// les statuts suivent l'heure : liste recalculee
	const DWORD ZCK_QU_DEMANDE_MS = 5000;	// catalogue redemande au plus toutes les 5 s
	const DWORD ZCK_QU_OSCILLATION_MS = 12000;
	const float ZCK_QU_OSCILLATION_DEG = 30.0f;
	const float ZCK_QU_MARGE_VUE = 0.84f;	// part de la vue occupee par le monstre
	const float ZCK_QU_ZOOM_MIN = 0.5f;
	const float ZCK_QU_ZOOM_MAX = 1.6f;
	const float ZCK_QU_DEG_PAR_PIXEL = 0.8f;	// rotation a la souris

	const DWORD ZCK_QU_BULLE = 0x7C510000;	// base des identifiants d'infobulle

	//////////////////////////////////////////////////////////////////
	// Suivi (HUD). Sans legende : zone client = fenetre moins 4, 4, 8, 10
	// (CWndBase::SetWndRect) ; ces marges, invisibles, servent a
	// redimensionner (WBS_THICKFRAME). Barre de titre maison en haut.
	//////////////////////////////////////////////////////////////////
	const int ZCK_QU_SUIVI_L_MIN = 192;
	const int ZCK_QU_SUIVI_H_MIN = 96;
	const int ZCK_QU_SUIVI_L_MAX = 640;
	const int ZCK_QU_SUIVI_H_MAX = 720;
	const int ZCK_QU_SUIVI_H_DEFAUT = 224;
	const int ZCK_QU_SUIVI_TETE_H = 22;
	const int ZCK_QU_SUIVI_ENTREE_H = 36;
	const int ZCK_QU_SUIVI_BOUTON = 16;
	const int ZCK_QU_SUIVI_HAUT = 372;		// ouverture : a droite, sous le suivi des quetes d'origine
	const int ZCK_QU_CADRE_G = 4;
	const int ZCK_QU_CADRE_H = 4;
	const int ZCK_QU_CADRE_B = 10;
	const DWORD ZCK_QU_SUIVI_VIDE_MS = 3000;	// fermeture apres 3 s sans quete a suivre

	// Palette commune des fenetres Zck (achievements, prestige, buffs mondiaux).
	const DWORD ZCK_QU_OR = 0xFFFFDD66;
	const DWORD ZCK_QU_BLANC = 0xFFFFFFFF;
	const DWORD ZCK_QU_TEXTE = 0xFFE0E0E0;
	const DWORD ZCK_QU_GRIS = 0xFFA0A0A0;
	const DWORD ZCK_QU_GRIS_FONCE = 0xFF6A6A6A;
	const DWORD ZCK_QU_VERT = 0xFF7CFC7C;
	const DWORD ZCK_QU_ORANGE = 0xFFFFA040;
	const DWORD ZCK_QU_ROUGE = 0xFFFF6060;
	const DWORD ZCK_QU_BLEU = 0xFF7FC8FF;
	const DWORD ZCK_QU_VIOLET = 0xFFC8A0FF;
	const DWORD ZCK_QU_CADRE = 0x90C8A040;
	const DWORD ZCK_QU_SELECTION = 0xFFFFD040;
	const DWORD ZCK_QU_SURVOL = 0xFFC8A040;
	const DWORD ZCK_QU_OMBRE = 0xFF000000;
	const DWORD ZCK_QU_ACCOMPLIE = D3DCOLOR_ARGB(255, 63, 209, 106);
	const DWORD ZCK_QU_A_RECUPERER = D3DCOLOR_ARGB(255, 255, 200, 60);

	enum
	{
		ZCK_QU_BOUTON_INACTIF = 0,
		ZCK_QU_BOUTON_OR,
		ZCK_QU_BOUTON_NEUTRE
	};

	const char* const s_apszZckQuOnglets[] =
	{
		"Toutes",
		"Disponibles",
		"En cours",
		"\300 r\351cup\351rer",
		"Accomplies"
	};

	//////////////////////////////////////////////////////////////////
	// Etat du client hors fenetres : le catalogue reste dans
	// CZckQuestManager, l'etat du personnage dans CMover::m_ZckQuest.
	//////////////////////////////////////////////////////////////////
	BOOL s_bZckQuIndisponible = FALSE;	// le serveur a repondu INDISPONIBLE a une demande de catalogue
	BOOL s_bZckQuDemande = FALSE;		// une demande de catalogue a deja ete envoyee
	DWORD s_dwZckQuDemande = 0;			// GetTickCount() de cette demande

	void ZckQuDemanderCatalogue()
	{
		const DWORD dwTick = GetTickCount();
		if (s_bZckQuDemande && dwTick - s_dwZckQuDemande < ZCK_QU_DEMANDE_MS)
			return;
		s_bZckQuDemande = TRUE;
		s_dwZckQuDemande = dwTick;
		g_DPlay.SendZckQuest(ZCK_QUEST_ACTION_CATALOGUE, 0, 0);
	}

	// Contenu refuse (tout ou rien) : journal une fois par genre.
	void ZckQuSignaler(BYTE byGenre)
	{
		static BOOL s_abSignale[5] = { FALSE, FALSE, FALSE, FALSE, FALSE };
		const int n = (byGenre <= 4) ? (int)byGenre : 0;
		if (s_abSignale[n])
			return;
		s_abSignale[n] = TRUE;
		Error("__ZCK_QUEST : snapshot SNAPSHOTTYPE_ZCK_QUEST de genre %d refuse (contenu incoherent).", (int)byGenre);
	}

	// Bloc resdata.inc absent : journal une fois par fenetre.
	BOOL ZckQuBlocPresent(DWORD dwIdApplet, LPCTSTR lpszNom)
	{
		if (CWndBase::m_resMng.GetAt(dwIdApplet) != NULL)
			return TRUE;
		static DWORD s_adwSignales[2] = { 0, 0 };
		for (int i = 0; i < 2; ++i)
		{
			if (s_adwSignales[i] == dwIdApplet)
				return FALSE;
			if (s_adwSignales[i] == 0)
			{
				s_adwSignales[i] = dwIdApplet;
				Error("__ZCK_QUEST : bloc %s absent de resdata.inc (Data.res a refaire) : fenetre non ouverte.", lpszNom);
				break;
			}
		}
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////
	// Personnage et heure du serveur
	//////////////////////////////////////////////////////////////////
	int ZckQuNiveau()
	{
		return g_pPlayer ? (int)g_pPlayer->GetLevel() : 0;
	}

	int ZckQuPrestige()
	{
#ifdef __ZCK_PRESTIGE
		return g_pPlayer ? (int)g_pPlayer->GetZckPrestige() : 0;
#else
		return 0;
#endif // __ZCK_PRESTIGE
	}

	int ZckQuNiveauJeu()
	{
#ifdef __ZCK_4_CLASSES
		return MAX_4TH_JOBS_LEVEL;
#else
		return MAX_3RD_LEGEND_LEVEL;
#endif // __ZCK_4_CLASSES
	}

	int ZckQuPrestigeJeu()
	{
#ifdef __ZCK_PRESTIGE
		return ZCK_PRESTIGE_STORAGE_MAX;
#else
		return 0;
#endif // __ZCK_PRESTIGE
	}

	const ZCK_QUEST_ENTREE* ZckQuEntree(int nId)
	{
		return g_pPlayer ? g_pPlayer->m_ZckQuest.Find(nId) : NULL;
	}

	__int64 ZckQuMaintenant()
	{
		return CZckQuestManager::GetInstance()->HorlogeServeur();
	}

	// Meme calcul que le WorldServer (CZckQuestManager::CalculerStatut).
	int ZckQuStatut(const ZCK_QUEST_DEFINITION& def)
	{
		return CZckQuestManager::CalculerStatut(def, ZckQuEntree(def.nId), ZckQuMaintenant(), ZckQuNiveau(), ZckQuPrestige());
	}

	// Progression montree : celle de l'entree tant qu'elle compte, l'objectif une fois accomplie.
	int ZckQuProgression(const ZCK_QUEST_DEFINITION& def, const ZCK_QUEST_ENTREE* pEntree, int nStatut)
	{
		if (nStatut == ZCK_QUEST_STATUT_ACCOMPLIE)
			return def.nObjectif;
		if (pEntree && (nStatut == ZCK_QUEST_STATUT_EN_COURS || nStatut == ZCK_QUEST_STATUT_TERMINEE || nStatut == ZCK_QUEST_STATUT_ECHOUEE))
			return (pEntree->nProgression < def.nObjectif) ? pEntree->nProgression : def.nObjectif;
		return 0;
	}

	// A suivre : en cours, terminee (recompense jamais perdue), ou echouee
	// tant que l'horaire est ouvert (nouvel essai possible).
	BOOL ZckQuSuivable(const ZCK_QUEST_DEFINITION& def, int nStatut)
	{
		if (nStatut == ZCK_QUEST_STATUT_EN_COURS || nStatut == ZCK_QUEST_STATUT_TERMINEE)
			return TRUE;
		if (nStatut != ZCK_QUEST_STATUT_ECHOUEE)
			return FALSE;
		ZCK_QUEST_FENETRE fen;
		CZckQuestManager::CalculerFenetre(def, ZckQuMaintenant(), fen);
		return fen.bOuverte;
	}

	DWORD ZckQuCouleurStatut(int nStatut)
	{
		switch (nStatut)
		{
		case ZCK_QUEST_STATUT_DISPONIBLE:	return ZCK_QU_VERT;
		case ZCK_QUEST_STATUT_VERROUILLEE:	return ZCK_QU_ROUGE;
		case ZCK_QUEST_STATUT_EN_COURS:		return ZCK_QU_BLEU;
		case ZCK_QUEST_STATUT_ECHOUEE:		return ZCK_QU_ORANGE;
		case ZCK_QUEST_STATUT_TERMINEE:		return ZCK_QU_A_RECUPERER;
		case ZCK_QUEST_STATUT_ACCOMPLIE:	return ZCK_QU_ACCOMPLIE;
		default:							break;
		}
		return ZCK_QU_GRIS;
	}

	//////////////////////////////////////////////////////////////////
	// Textes (heure locale du WorldServer)
	//////////////////////////////////////////////////////////////////
	LPCTSTR ZckQuJourCourt(int nJour)
	{
		static const char* const s_apszJours[7] = { "Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam" };
		return (nJour >= 0 && nJour < 7) ? s_apszJours[nJour] : "?";
	}

	LPCTSTR ZckQuJourLong(int nJour)
	{
		static const char* const s_apszJours[7] = { "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi" };
		return (nJour >= 0 && nJour < 7) ? s_apszJours[nJour] : "?";
	}

	// Minutes depuis minuit (0 a 1440) : "HH:MM".
	CString ZckQuHeure(int nMinutes)
	{
		CString str;
		str.Format("%02d:%02d", nMinutes / 60, nMinutes % 60);
		return str;
	}

	CString ZckQuHoraire(const ZCK_QUEST_DEFINITION& def)
	{
		if (def.nDebut == 0 && def.nFin == 1440)
			return CString("Toute la journ\351e");
		return ZckQuHeure(def.nDebut) + " - " + ZckQuHeure(def.nFin);
	}

	CString ZckQuJours(BYTE byJours)
	{
		const BYTE by = (BYTE)(byJours & ZCK_QUEST_JOURS_TOUS);
		if (by == ZCK_QUEST_JOURS_TOUS)
			return CString("Tous les jours");
		if (by == 0x41)
			return CString("Le week-end");
		if (by == 0x3E)
			return CString("En semaine");
		// Du lundi au dimanche.
		static const int s_anOrdre[7] = { 1, 2, 3, 4, 5, 6, 0 };
		CString str;
		for (int i = 0; i < 7; ++i)
		{
			if ((by & (1 << s_anOrdre[i])) == 0)
				continue;
			if (!str.IsEmpty())
				str += ", ";
			str += ZckQuJourCourt(s_anOrdre[i]);
		}
		return str;
	}

	// Duree lisible : "45 s", "12 min", "1 h 05", "2 j 3 h".
	CString ZckQuDuree(__int64 n64Secondes)
	{
		if (n64Secondes < 0)
			n64Secondes = 0;
		CString str;
		if (n64Secondes < 60)
			str.Format("%d s", (int)n64Secondes);
		else if (n64Secondes < 3600)
			str.Format("%d min", (int)(n64Secondes / 60));
		else if (n64Secondes < ZCK_QUEST_JOUR_S)
			str.Format("%d h %02d", (int)(n64Secondes / 3600), (int)((n64Secondes % 3600) / 60));
		else
			str.Format("%d j %d h", (int)(n64Secondes / ZCK_QUEST_JOUR_S), (int)((n64Secondes % ZCK_QUEST_JOUR_S) / 3600));
		return str;
	}

	// Chrono : "12:34" ou "1:02:03".
	CString ZckQuChrono(__int64 n64Secondes)
	{
		if (n64Secondes < 0)
			n64Secondes = 0;
		if (n64Secondes > 99 * 3600)
			n64Secondes = 99 * 3600;
		const int nHeures = (int)(n64Secondes / 3600);
		const int nMinutes = (int)((n64Secondes % 3600) / 60);
		const int nSecondes = (int)(n64Secondes % 60);
		CString str;
		if (nHeures > 0)
			str.Format("%d:%02d:%02d", nHeures, nMinutes, nSecondes);
		else
			str.Format("%02d:%02d", nMinutes, nSecondes);
		return str;
	}

	// Instant : "Mer 18:00".
	CString ZckQuInstant(__int64 n64)
	{
		if (n64 < 0)
			n64 = 0;
		CString str;
		str.Format("%s %s", ZckQuJourCourt(CZckQuestManager::JourSemaine(n64 / ZCK_QUEST_JOUR_S)), (LPCTSTR)ZckQuHeure((int)((n64 % ZCK_QUEST_JOUR_S) / 60)));
		return str;
	}

	CString ZckQuDureeQuete(const ZCK_QUEST_DEFINITION& def)
	{
		if (def.nDuree <= 0)
			return CString("Jusqu'\340 la fin de l'horaire");
		return ZckQuDuree((__int64)def.nDuree * 60);
	}

	// "60 - 185", "60+" (jusqu'au maximum du jeu), "Tous".
	CString ZckQuBornes(int nMin, int nMax, int nMinJeu, int nMaxJeu)
	{
		CString str;
		if (nMin <= nMinJeu && nMax >= nMaxJeu)
			str = "Tous";
		else if (nMax >= nMaxJeu)
			str.Format("%d+", nMin);
		else if (nMin == nMax)
			str.Format("%d", nMin);
		else
			str.Format("%d - %d", nMin, nMax);
		return str;
	}

	// Lieu : texte de ZckQuetes.inc, sinon titres des mondes (World.inc).
	CString ZckQuLieu(const ZCK_QUEST_DEFINITION& def)
	{
		if (!def.strLieu.IsEmpty())
			return def.strLieu;
		if (def.vecMondes.empty())
			return CString("Tous les mondes");
		CString str;
		for (size_t i = 0; i < def.vecMondes.size(); ++i)
		{
			if (!str.IsEmpty())
				str += ", ";
			LPWORLD lpWorld = g_WorldMng.GetWorldStruct((OBJID)def.vecMondes[i]);
			if (lpWorld && lpWorld->IsValid() && lpWorld->m_szWorldName[0] != '\0')
				str += lpWorld->m_szWorldName;
			else
			{
				CString strMonde;
				strMonde.Format("Monde %u", (unsigned int)def.vecMondes[i]);
				str += strMonde;
			}
		}
		return str;
	}

	// Ligne 2 de la liste et du suivi : l'information du moment.
	void ZckQuInfoCourte(const ZCK_QUEST_DEFINITION& def, const ZCK_QUEST_ENTREE* pEntree, int nStatut, __int64 n64, CString& str, DWORD& dwCouleur)
	{
		ZCK_QUEST_FENETRE fen;
		CZckQuestManager::CalculerFenetre(def, n64, fen);
		dwCouleur = ZCK_QU_GRIS;
		str.Empty();
		if (n64 <= 0)
		{
			str = "--";
			return;
		}
		switch (nStatut)
		{
		case ZCK_QUEST_STATUT_EN_COURS:
		{
			const __int64 n64Reste = pEntree ? pEntree->n64Echeance - n64 : 0;
			str.Format("%d/%d  \267  %s", ZckQuProgression(def, pEntree, nStatut), def.nObjectif, (LPCTSTR)ZckQuChrono(n64Reste));
			dwCouleur = (n64Reste < 60) ? ZCK_QU_ROUGE : ((n64Reste < 300) ? ZCK_QU_ORANGE : ZCK_QU_BLEU);
			break;
		}
		case ZCK_QUEST_STATUT_TERMINEE:
			str.Format("%d/%d", def.nObjectif, def.nObjectif);
			dwCouleur = ZCK_QU_A_RECUPERER;
			break;
		case ZCK_QUEST_STATUT_DISPONIBLE:
			str.Format("encore %s", (LPCTSTR)ZckQuDuree(fen.n64Fin - n64));
			dwCouleur = ZCK_QU_VERT;
			break;
		case ZCK_QUEST_STATUT_VERROUILLEE:
		{
			const int nNiveau = ZckQuNiveau();
			const int nPrestige = ZckQuPrestige();
			if (nNiveau < def.nNiveauMin)
				str.Format("Niv. %d requis", def.nNiveauMin);
			else if (nNiveau > def.nNiveauMax)
				str.Format("Niv. %d au plus", def.nNiveauMax);
			else if (nPrestige < def.nPrestigeMin)
				str.Format("Prestige %d requis", def.nPrestigeMin);
			else
				str.Format("Prestige %d au plus", def.nPrestigeMax);
			dwCouleur = ZCK_QU_ROUGE;
			break;
		}
		case ZCK_QUEST_STATUT_ECHOUEE:
			if (fen.bOuverte)
			{
				str.Format("encore %s", (LPCTSTR)ZckQuDuree(fen.n64Fin - n64));
				dwCouleur = ZCK_QU_ORANGE;
			}
			else if (fen.n64Prochaine > 0)
				str.Format("dans %s", (LPCTSTR)ZckQuDuree(fen.n64Prochaine - n64));
			else
				str = "--";
			break;
		default:
			if (fen.n64Prochaine > 0)
				str.Format("dans %s", (LPCTSTR)ZckQuDuree(fen.n64Prochaine - n64));
			else
				str = "--";
			break;
		}
	}

	// Ligne de temps du detail : libelle et valeur.
	void ZckQuInfoTemps(const ZCK_QUEST_DEFINITION& def, const ZCK_QUEST_ENTREE* pEntree, int nStatut, __int64 n64, CString& strLibelle, CString& strValeur, DWORD& dwCouleur)
	{
		ZCK_QUEST_FENETRE fen;
		CZckQuestManager::CalculerFenetre(def, n64, fen);
		dwCouleur = ZCK_QU_BLANC;
		if (n64 <= 0)
		{
			strLibelle = "Heure";
			strValeur = "Synchronisation avec le serveur...";
			dwCouleur = ZCK_QU_GRIS;
			return;
		}
		CString strProchaine;
		if (fen.n64Prochaine > 0)
			strProchaine.Format("%s (dans %s)", (LPCTSTR)ZckQuInstant(fen.n64Prochaine), (LPCTSTR)ZckQuDuree(fen.n64Prochaine - n64));
		else
			strProchaine = "Aucune dans les 8 jours";

		switch (nStatut)
		{
		case ZCK_QUEST_STATUT_EN_COURS:
		{
			const __int64 n64Reste = pEntree ? pEntree->n64Echeance - n64 : 0;
			strLibelle = "Temps restant";
			strValeur.Format("%s  (fin %s)", (LPCTSTR)ZckQuChrono(n64Reste), pEntree ? (LPCTSTR)ZckQuInstant(pEntree->n64Echeance) : "?");
			dwCouleur = (n64Reste < 60) ? ZCK_QU_ROUGE : ((n64Reste < 300) ? ZCK_QU_ORANGE : ZCK_QU_BLEU);
			return;
		}
		case ZCK_QUEST_STATUT_TERMINEE:
			strLibelle = "Objectif atteint";
			strValeur = "R\351compense \340 r\351cup\351rer";
			dwCouleur = ZCK_QU_A_RECUPERER;
			return;
		case ZCK_QUEST_STATUT_ACCOMPLIE:
			strLibelle = "Prochaine ouverture";
			strValeur = strProchaine;
			dwCouleur = ZCK_QU_ACCOMPLIE;
			return;
		case ZCK_QUEST_STATUT_DISPONIBLE:
		case ZCK_QUEST_STATUT_VERROUILLEE:
			strLibelle = "Fermeture dans";
			strValeur.Format("%s  (%s)", (LPCTSTR)ZckQuDuree(fen.n64Fin - n64), (LPCTSTR)ZckQuInstant(fen.n64Fin));
			dwCouleur = (nStatut == ZCK_QUEST_STATUT_DISPONIBLE) ? ZCK_QU_VERT : ZCK_QU_GRIS;
			return;
		case ZCK_QUEST_STATUT_ECHOUEE:
			strLibelle = "Temps \351coul\351";
			if (fen.bOuverte)
				strValeur.Format("Recommencez : fermeture dans %s", (LPCTSTR)ZckQuDuree(fen.n64Fin - n64));
			else
				strValeur.Format("Prochaine ouverture : %s", (LPCTSTR)strProchaine);
			dwCouleur = ZCK_QU_ORANGE;
			return;
		default:
			strLibelle = "Ouverture";
			strValeur = strProchaine;
			dwCouleur = ZCK_QU_GRIS;
			return;
		}
	}

	//////////////////////////////////////////////////////////////////
	// Dessin (memes outils que la fenetre des achievements)
	//////////////////////////////////////////////////////////////////

	// Coupe une chaine a la largeur donnee (police courante), avec "...".
	void ZckQuTronquer(C2DRender* p2DRender, char* psz, int nLargeur)
	{
		if (p2DRender->m_pFont == NULL || nLargeur <= 0)
			return;
		if (p2DRender->m_pFont->GetTextExtent(psz).cx <= nLargeur)
			return;
		int nLong = (int)strlen(psz) - 3;
		if (nLong < 1)
			return;
		while (nLong > 0)
		{
			CString str;
			str.Format("%.*s...", nLong, psz);
			if (p2DRender->m_pFont->GetTextExtent(str).cx <= nLargeur)
				break;
			--nLong;
		}
		strcpy(psz + nLong, "...");
	}

	// Texte tronque a la largeur, ecrit a gauche (nAlign 0), centre (1) ou a
	// droite (2) de x, avec une ombre ; renvoie la largeur ecrite.
	int ZckQuTexte(C2DRender* p2DRender, int x, int y, LPCTSTR lpszTexte, DWORD dwCouleur, int nLargeurMax, int nAlign)
	{
		if (p2DRender->m_pFont == NULL || lpszTexte == NULL || nLargeurMax <= 0)
			return 0;
		char szTexte[256];
		_snprintf(szTexte, sizeof(szTexte) - 1, "%s", lpszTexte);
		szTexte[sizeof(szTexte) - 1] = '\0';
		ZckQuTronquer(p2DRender, szTexte, nLargeurMax);
		const int nLargeur = p2DRender->m_pFont->GetTextExtent(szTexte).cx;
		if (nAlign == 1)
			x -= nLargeur / 2;
		else if (nAlign == 2)
			x -= nLargeur;
		p2DRender->TextOut(x, y, szTexte, dwCouleur, ZCK_QU_OMBRE);
		return nLargeur;
	}

	int ZckQuHauteur(C2DRender* p2DRender)
	{
		return p2DRender->m_pFont ? p2DRender->m_pFont->GetTextExtent("Ag").cy : 12;
	}

	int ZckQuLargeur(C2DRender* p2DRender, LPCTSTR lpszTexte)
	{
		return (p2DRender->m_pFont && lpszTexte) ? p2DRender->m_pFont->GetTextExtent(lpszTexte).cx : 0;
	}

	BOOL ZckQuDepasse(C2DRender* p2DRender, LPCTSTR lpszTexte, int nLargeur)
	{
		return ZckQuLargeur(p2DRender, lpszTexte) > nLargeur;
	}

	// Texte centre sur les deux axes d'un rectangle.
	void ZckQuTexteCentre(C2DRender* p2DRender, const CRect& rect, LPCTSTR lpszTexte, DWORD dwCouleur)
	{
		const int y = rect.top + (rect.Height() - ZckQuHauteur(p2DRender)) / 2;
		ZckQuTexte(p2DRender, rect.CenterPoint().x, y, lpszTexte, dwCouleur, rect.Width() - 8, 1);
	}

	// Decoupe un texte en lignes de la largeur donnee (mots entiers, '\n'
	// respecte). Renvoie FALSE si tout ne tient pas dans nLignesMax lignes :
	// la derniere ligne est alors celle qui sera tronquee avec "...".
	BOOL ZckQuDecouper(C2DRender* p2DRender, LPCTSTR lpszTexte, int nLargeur, int nLignesMax, vector<CString>& vecLignes)
	{
		vecLignes.clear();
		if (p2DRender->m_pFont == NULL || lpszTexte == NULL || nLargeur <= 0 || nLignesMax <= 0)
			return TRUE;

		CString strLigne;
		const char* p = lpszTexte;
		while (*p)
		{
			if (*p == '\n')
			{
				vecLignes.push_back(strLigne);
				strLigne.Empty();
				++p;
				continue;
			}
			const char* pFin = p;
			while (*pFin && *pFin != ' ' && *pFin != '\n')
				++pFin;
			CString strMot(p, (int)(pFin - p));
			CString strEssai = strLigne.IsEmpty() ? strMot : strLigne + " " + strMot;
			if (!strLigne.IsEmpty() && p2DRender->m_pFont->GetTextExtent(strEssai).cx > nLargeur)
			{
				vecLignes.push_back(strLigne);
				strLigne = strMot;
			}
			else
				strLigne = strEssai;
			p = pFin;
			while (*p == ' ')
				++p;
		}
		if (!strLigne.IsEmpty())
			vecLignes.push_back(strLigne);

		if ((int)vecLignes.size() <= nLignesMax)
			return TRUE;
		CString strDerniere = vecLignes[nLignesMax - 1];
		for (int i = nLignesMax; i < (int)vecLignes.size(); ++i)
			strDerniere += " " + vecLignes[i];
		vecLignes.resize(nLignesMax);
		vecLignes[nLignesMax - 1] = strDerniere;
		return FALSE;
	}

	// Police de theme le temps d'un bloc, l'ancienne est remise a la sortie.
	struct ZckQuPolice
	{
		C2DRender* m_p2DRender;
		CD3DFont* m_pAncienne;
		ZckQuPolice(C2DRender* p2DRender, CD3DFont* pPolice)
			: m_p2DRender(p2DRender), m_pAncienne(p2DRender->GetFont())
		{
			if (pPolice)
				m_p2DRender->SetFont(pPolice);
		}
		~ZckQuPolice() { m_p2DRender->SetFont(m_pAncienne); }
	};

	// Pulsation 0..0x50..0 (onde triangulaire), plus lente quand dwDiviseur grandit.
	DWORD ZckQuPulsation(DWORD dwDiviseur)
	{
		const DWORD t = (GetTickCount() / dwDiviseur) % 0xA0;
		return (t < 0x50) ? t : (0xA0 - t);
	}

	// Ratio de progression borne a [0, 1].
	float ZckQuRatio(__int64 nProgress, __int64 nTarget)
	{
		if (nTarget <= 0 || nProgress <= 0)
			return 0.0f;
		if (nProgress >= nTarget)
			return 1.0f;
		return (float)((long double)nProgress / (long double)nTarget);
	}

	// Carte a bande de titre doree.
	void ZckQuCarte(C2DRender* p2DRender, const CRect& rect, LPCTSTR lpszTitre, DWORD dwTitre, DWORD dwCadre)
	{
		p2DRender->RenderFillRect(rect, 0xA0141020, 0xA0141020, 0x80080610, 0x80080610);
		p2DRender->RenderRoundRect(rect, dwCadre);

		const CRect rectTitre(rect.left + 1, rect.top + 1, rect.right - 1, rect.top + ZCK_QU_TITRE_H);
		p2DRender->RenderFillRect(rectTitre, 0xC05A4418, 0xC05A4418, 0x80281E08, 0x80281E08);
		p2DRender->RenderLine(CPoint(rectTitre.left, rectTitre.bottom), CPoint(rectTitre.right, rectTitre.bottom), 0xC0C8A040);
		ZckQuTexteCentre(p2DRender, rectTitre, lpszTitre, dwTitre);
	}

	// Pastille 14 x 14 : coche verte ou croix rouge.
	void ZckQuPastille(C2DRender* p2DRender, int x, int y, BOOL bOk)
	{
		const CRect rect(x, y, x + 14, y + 14);
		if (bOk)
		{
			p2DRender->RenderFillRect(rect, 0xFF3FAF4F, 0xFF3FAF4F, 0xFF226B2C, 0xFF226B2C);
			p2DRender->RenderRoundRect(rect, 0xFFB6E35A);
			for (int i = 0; i < 2; ++i)
			{
				p2DRender->RenderLine(CPoint(x + 3, y + 7 + i), CPoint(x + 6, y + 10 + i), ZCK_QU_BLANC);
				p2DRender->RenderLine(CPoint(x + 6, y + 10 + i), CPoint(x + 11, y + 4 + i), ZCK_QU_BLANC);
			}
		}
		else
		{
			p2DRender->RenderFillRect(rect, 0xFFAF3F3F, 0xFFAF3F3F, 0xFF6B2222, 0xFF6B2222);
			p2DRender->RenderRoundRect(rect, 0xFFFF9090);
			for (int i = 0; i < 2; ++i)
			{
				p2DRender->RenderLine(CPoint(x + 4 + i, y + 4), CPoint(x + 10 + i, y + 10), ZCK_QU_BLANC);
				p2DRender->RenderLine(CPoint(x + 10 + i, y + 4), CPoint(x + 4 + i, y + 10), ZCK_QU_BLANC);
			}
		}
	}

	// Icone de statut, 14 x 14 : horloge (fermee), losange vert (disponible),
	// cadenas (verrouillee), jauge (en cours), croix orange (echouee), point
	// d'exclamation dore (terminee), coche (accomplie).
	void ZckQuIcone(C2DRender* p2DRender, int x, int y, int nStatut, float fRatio)
	{
		const CRect rect(x, y, x + 14, y + 14);
		switch (nStatut)
		{
		case ZCK_QUEST_STATUT_ACCOMPLIE:
			ZckQuPastille(p2DRender, x, y, TRUE);
			return;
		case ZCK_QUEST_STATUT_TERMINEE:
			p2DRender->RenderFillRect(rect, 0xFFD8A63B, 0xFFD8A63B, 0xFF8A6418, 0xFF8A6418);
			p2DRender->RenderRoundRect(rect, 0xFFFFE070);
			p2DRender->RenderFillRect(CRect(x + 6, y + 3, x + 8, y + 9), ZCK_QU_BLANC);
			p2DRender->RenderFillRect(CRect(x + 6, y + 10, x + 8, y + 12), ZCK_QU_BLANC);
			return;
		case ZCK_QUEST_STATUT_EN_COURS:
		{
			p2DRender->RenderFillRect(rect, 0xB0141414);
			const int nHaut = (int)(12.0f * fRatio);
			if (nHaut > 0)
				p2DRender->RenderFillRect(CRect(x + 1, y + 13 - nHaut, x + 13, y + 13), 0xFF3A6AA0);
			p2DRender->RenderRoundRect(rect, ZCK_QU_BLEU);
			return;
		}
		case ZCK_QUEST_STATUT_ECHOUEE:
			p2DRender->RenderFillRect(rect, 0xFFB86A20, 0xFFB86A20, 0xFF6B3A10, 0xFF6B3A10);
			p2DRender->RenderRoundRect(rect, 0xFFFFC080);
			for (int i = 0; i < 2; ++i)
			{
				p2DRender->RenderLine(CPoint(x + 4 + i, y + 4), CPoint(x + 10 + i, y + 10), ZCK_QU_BLANC);
				p2DRender->RenderLine(CPoint(x + 10 + i, y + 4), CPoint(x + 4 + i, y + 10), ZCK_QU_BLANC);
			}
			return;
		case ZCK_QUEST_STATUT_DISPONIBLE:
			p2DRender->RenderFillTriangle(CPoint(x + 7, y), CPoint(x + 14, y + 7), CPoint(x, y + 7), 0xFF3FAF4F);
			p2DRender->RenderFillTriangle(CPoint(x, y + 7), CPoint(x + 14, y + 7), CPoint(x + 7, y + 14), 0xFF226B2C);
			p2DRender->RenderLine(CPoint(x + 7, y + 3), CPoint(x + 7, y + 11), ZCK_QU_BLANC);
			p2DRender->RenderLine(CPoint(x + 3, y + 7), CPoint(x + 11, y + 7), ZCK_QU_BLANC);
			return;
		case ZCK_QUEST_STATUT_VERROUILLEE:
			p2DRender->RenderFillRect(CRect(x + 2, y + 6, x + 12, y + 14), 0xFF8A3A3A, 0xFF8A3A3A, 0xFF5A2020, 0xFF5A2020);
			p2DRender->RenderRect(CRect(x + 2, y + 6, x + 12, y + 14), 0xFFFF9090);
			p2DRender->RenderLine(CPoint(x + 4, y + 6), CPoint(x + 4, y + 2), 0xFFFF9090);
			p2DRender->RenderLine(CPoint(x + 4, y + 2), CPoint(x + 10, y + 2), 0xFFFF9090);
			p2DRender->RenderLine(CPoint(x + 10, y + 2), CPoint(x + 10, y + 6), 0xFFFF9090);
			p2DRender->RenderFillRect(CRect(x + 6, y + 9, x + 8, y + 12), ZCK_QU_BLANC);
			return;
		default:
			p2DRender->RenderFillRect(rect, 0xB0202020);
			p2DRender->RenderRoundRect(rect, 0xFF808080);
			p2DRender->RenderLine(CPoint(x + 7, y + 7), CPoint(x + 7, y + 3), ZCK_QU_GRIS);
			p2DRender->RenderLine(CPoint(x + 7, y + 7), CPoint(x + 11, y + 7), ZCK_QU_GRIS);
			return;
		}
	}

	// Pastille de texte (statut, compteur).
	void ZckQuPilule(C2DRender* p2DRender, const CRect& rect, LPCTSTR lpszTexte, DWORD dwCouleur)
	{
		p2DRender->RenderFillRect(rect, 0xA0101010);
		p2DRender->RenderRoundRect(rect, dwCouleur);
		ZckQuTexteCentre(p2DRender, rect, lpszTexte, dwCouleur);
	}

	// Barre de progression : piste, remplissage bleu (en cours) ou dore (atteint).
	void ZckQuBarre(C2DRender* p2DRender, const CRect& rect, float fRatio, BOOL bTermine)
	{
		p2DRender->RenderFillRect(rect, 0xB0141414);
		CRect rectRempli = rect;
		rectRempli.right = rect.left + (int)((float)rect.Width() * fRatio);
		if (rectRempli.right > rectRempli.left)
		{
			if (bTermine)
				p2DRender->RenderFillRect(rectRempli, 0xFFC8A040, 0xFFFFD040, 0xFF9A7A20, 0xFFC8A040);
			else
				p2DRender->RenderFillRect(rectRempli, 0xFF3F7FAF, 0xFF7FC8FF, 0xFF2F5F8F, 0xFF5FA8DF);
		}
		p2DRender->RenderRect(rect, ZCK_QU_SURVOL);
	}

	// Bouton dessine.
	void ZckQuBouton(C2DRender* p2DRender, const CRect& rect, LPCTSTR lpszTexte, int nStyle, BOOL bSurvol)
	{
		DWORD dwTexte = ZCK_QU_BLANC;
		switch (nStyle)
		{
		case ZCK_QU_BOUTON_OR:
			p2DRender->RenderFillRect(rect, bSurvol ? 0xFFD8A63B : 0xFFB8862B, bSurvol ? 0xFFD8A63B : 0xFFB8862B, 0xFF6B4A12, 0xFF6B4A12);
			p2DRender->RenderRoundRect(rect, 0xFFFFE070);
			break;
		case ZCK_QU_BOUTON_NEUTRE:
			p2DRender->RenderFillRect(rect, bSurvol ? 0xFF4A4A5C : 0xFF3A3A48, bSurvol ? 0xFF4A4A5C : 0xFF3A3A48, 0xFF1C1C24, 0xFF1C1C24);
			p2DRender->RenderRoundRect(rect, bSurvol ? 0xFFC0C0D0 : 0xFF808090);
			break;
		default:
			p2DRender->RenderFillRect(rect, 0xB0303030, 0xB0303030, 0xB0181818, 0xB0181818);
			p2DRender->RenderRoundRect(rect, 0xFF606060);
			dwTexte = ZCK_QU_GRIS;
			break;
		}
		if (nStyle != ZCK_QU_BOUTON_INACTIF)
			p2DRender->RenderLine(CPoint(rect.left + 2, rect.top + 1), CPoint(rect.right - 2, rect.top + 1), 0x60FFFFFF);

		ZckQuPolice police(p2DRender, CWndBase::m_Theme.m_pFontWndTitle);
		ZckQuTexteCentre(p2DRender, rect, lpszTexte, dwTexte);
	}

	// Halo pulse autour d'un rectangle (action attendue).
	void ZckQuHalo(C2DRender* p2DRender, const CRect& rect, DWORD dwRgb)
	{
		const DWORD dwAlpha = 0x28 + ZckQuPulsation(10);
		CRect rectHalo = rect;
		for (int i = 0; i < 3; ++i)
		{
			rectHalo.InflateRect(1, 1);
			p2DRender->RenderRoundRect(rectHalo, ((dwAlpha - (DWORD)(i * 12)) << 24) | (dwRgb & 0x00FFFFFF));
		}
	}

	// Monstre ou objet du catalogue (envoye par le serveur) : NULL, sans rien
	// ecrire au journal d'erreurs, si le client ne le connait pas (propMover ou
	// propItem du client different de celui du WorldServer).
	MoverProp* ZckQuMoverProp(DWORD dwMonsterId)
	{
		MoverProp* pProp = prj.GetMoverPropEx((int)dwMonsterId);
		return (pProp && pProp->dwID == dwMonsterId) ? pProp : NULL;
	}

	ItemProp* ZckQuItemProp(DWORD dwItemId)
	{
		if (dwItemId == 0 || dwItemId >= (DWORD)prj.m_aPropItem.GetSize())
			return NULL;
		ItemProp* pProp = prj.GetItemProp((int)dwItemId);
		return (pProp && pProp->dwID == dwItemId) ? pProp : NULL;
	}

	// Icone d'objet : CWndBase::m_textureMng garde chaque fichier une seule fois.
	CTexture* ZckQuIconeItem(DWORD dwItemId)
	{
		ItemProp* pProp = ZckQuItemProp(dwItemId);
		if (pProp == NULL || pProp->szIcon[0] == '\0')
			return NULL;
		return CWndBase::m_textureMng.AddTexture(g_Neuz.m_pd3dDevice, MakePath(DIR_ITEM, pProp->szIcon), 0xffff00ff);
	}

	// Texture a la taille voulue, grisee sur demande.
	void ZckQuRendreTaille(C2DRender* p2DRender, CTexture* pTexture, CPoint pt, int nTaille, BOOL bGrise)
	{
		if (pTexture == NULL || pTexture->m_size.cx <= 0 || pTexture->m_size.cy <= 0)
			return;
		const float fX = (float)nTaille / (float)pTexture->m_size.cx;
		const float fY = (float)nTaille / (float)pTexture->m_size.cy;
		if (bGrise)
			p2DRender->RenderTexture2(pt, pTexture, fX, fY, 0xFF707070);
		else
			p2DRender->RenderTexture(pt, pTexture, 255, fX, fY);
	}

	LPCTSTR ZckQuNomItem(DWORD dwItemId)
	{
		ItemProp* pProp = ZckQuItemProp(dwItemId);
		return pProp ? pProp->szName : "?";
	}

	//////////////////////////////////////////////////////////////////
	// Monstre : fiche et apercu
	//////////////////////////////////////////////////////////////////

	LPCTSTR ZckQuNomElement(int nElement)
	{
		switch (nElement)
		{
		case SAI79::FIRE:			return prj.GetText(TID_UPGRADE_FIRE);
		case SAI79::WATER:			return prj.GetText(TID_UPGRADE_WATER);
		case SAI79::ELECTRICITY:	return prj.GetText(TID_UPGRADE_ELECTRICITY);
		case SAI79::WIND:			return prj.GetText(TID_UPGRADE_WIND);
		case SAI79::EARTH:			return prj.GetText(TID_UPGRADE_EARTH);
		default: break;
		}
		return NULL;
	}

	// Icone d'element (CWndWorld::m_texAttrIcon, celle de la barre de cible),
	// a nTaille pixels. CTexturePack::Render arrete le client sur un index
	// hors plage : il est verifie avant tout rendu.
	int ZckQuIconeElement(C2DRender* p2DRender, CPoint pt, int nElement, int nTaille)
	{
		if (nElement <= SAI79::NO_PROP || g_WndMng.m_pWndWorld == NULL)
			return 0;
		CTexturePack& pack = g_WndMng.m_pWndWorld->m_texAttrIcon;
		const DWORD dwIndex = (DWORD)(nElement - 1);
		if (dwIndex >= pack.GetNumber())
			return 0;
		CTexture* pTexture = pack.GetAt(dwIndex);
		if (pTexture == NULL || pTexture->m_size.cx <= 0 || pTexture->m_size.cy <= 0)
			return 0;
		const float fEchelle = (float)nTaille / (float)pTexture->m_size.cy;
		pack.Render(p2DRender, pt, dwIndex, 255, fEchelle, fEchelle);
		return (int)((float)pTexture->m_size.cx * fEchelle);
	}

	LPCTSTR ZckQuNomRang(DWORD dwClass)
	{
		switch (dwClass)
		{
		case RANK_LOW:		return "Faible";
		case RANK_NORMAL:	return "Normal";
		case RANK_CAPTAIN:	return "Capitaine";
		case RANK_BOSS:		return "Boss";
		case RANK_MIDBOSS:	return "Mini-boss";
		case RANK_MATERIAL:	return "Mat\351riau";
		case RANK_SUPER:	return "Super";
		case RANK_GUARD:	return "Garde";
		default: break;
		}
		return "Normal";
	}

	// Comportement (dwBelligerence de propMover). BELLI_MELEE2X, BELLI_MELEE
	// et BELLI_RANGE ne disent que le style d'attaque (CAIMonster::GetAtkMethod_*).
	LPCTSTR ZckQuComportement(DWORD dwBelligerence, DWORD& dwCouleur)
	{
		dwCouleur = ZCK_QU_BLANC;
		switch (dwBelligerence)
		{
		case BELLI_PEACEFUL:
			dwCouleur = ZCK_QU_VERT;
			return "Paisible";
		case BELLI_ACTIVEATTACK:
		case BELLI_ACTIVEATTACK_MELEE2X:
		case BELLI_ACTIVEATTACK_MELEE:
		case BELLI_ACTIVEATTACK_RANGE:
			dwCouleur = ZCK_QU_ROUGE;
			return "Agressif";
		case BELLI_CAUTIOUSATTACK:
		case BELLI_CAUTIOUSATTACK_MELEE2X:
		case BELLI_CAUTIOUSATTACK_MELEE:
		case BELLI_CAUTIOUSATTACK_RANGE:
			dwCouleur = ZCK_QU_ORANGE;
			return "Riposte si attaqu\351";
		case BELLI_ALLIANCE:
			dwCouleur = ZCK_QU_BLEU;
			return "Alli\351";
		case BELLI_MELEE2X:
			return "Corps \340 corps (coups lourds)";
		case BELLI_MELEE:
			return "Corps \340 corps";
		case BELLI_RANGE:
			return "Attaque \340 distance";
		default:
			break;
		}
		return "Inconnu";
	}

	// PV : meme calcul que CMover::GetMaxOriginHitPoint pour un monstre
	// (taux du serveur recus par le client compris).
	__int64 ZckQuPv(const MoverProp& prop)
	{
#ifdef __S1108_BACK_END_SYSTEM
		const long double dPv = static_cast<long double>(prop.dwAddHp)
			* static_cast<long double>(prj.m_fMonsterHitpointRate)
			* static_cast<long double>(prop.m_fHitPoint_Rate);
#else
		const long double dPv = static_cast<long double>(prop.dwAddHp);
#endif // __S1108_BACK_END_SYSTEM
		if (!(dPv > 0.0L))
			return 0;
		if (dPv >= static_cast<long double>(_I64_MAX))
			return _I64_MAX;
		return static_cast<__int64>(dPv);
	}

	// Couleur du niveau du monstre compare a celui du personnage.
	DWORD ZckQuCouleurNiveau(int nNiveauMonstre)
	{
		const int nEcart = nNiveauMonstre - ZckQuNiveau();
		if (nEcart >= 5)
			return ZCK_QU_ROUGE;
		if (nEcart >= 1)
			return ZCK_QU_ORANGE;
		if (nEcart >= -5)
			return ZCK_QU_BLANC;
		return ZCK_QU_GRIS;
	}

	struct ZCK_QU_FICHE
	{
		CString strLibelle;
		CString strValeur;
		CString strBulle;
		DWORD dwCouleur;
		int nElement;			// icone d'element devant la valeur, SAI79::NO_PROP sinon

		ZCK_QU_FICHE() : dwCouleur(ZCK_QU_BLANC), nElement(SAI79::NO_PROP) {}
	};

	// Fiche complete : uniquement des champs de MoverProp charges par le client.
	void ZckQuFiche(const MoverProp& prop, vector<ZCK_QU_FICHE>& vec)
	{
		vec.clear();
		ZCK_QU_FICHE ligne;
		CString str;

		ligne.strLibelle = "Points de vie";
		ligne.strValeur = Separator(ZckQuPv(prop), '.');
		ligne.strBulle = "Points de vie maximum du monstre (propMover et taux du serveur).";
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "Attaque";
		ligne.strValeur.Format("%s ~ %s", (LPCTSTR)Separator((__int64)prop.dwAtkMin, '.'), (LPCTSTR)Separator((__int64)prop.dwAtkMax, '.'));
		ligne.strBulle = "Attaque de base du monstre (minimum ~ maximum), avant la d\351fense de la cible.";
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "D\351fense";
		ligne.strValeur = Separator((__int64)prop.dwNaturalArmor, '.');
		ligne.strBulle = "Armure naturelle du monstre.";
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "R\351sistance magique";
		ligne.strValeur = Separator((__int64)prop.dwResisMgic, '.');
		ligne.strBulle = "R\351sistance magique de base du monstre.";
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "\311l\351ment";
		{
			const LPCTSTR lpszElement = ZckQuNomElement((int)prop.eElementType);
			if (lpszElement)
			{
				if (prop.wElementAtk > 0)
					ligne.strValeur.Format("%s  \267  niveau %d", lpszElement, (int)prop.wElementAtk);
				else
					ligne.strValeur = lpszElement;
				ligne.nElement = (int)prop.eElementType;
			}
			else
				ligne.strValeur = "Aucun";
		}
		ligne.strBulle = "\311l\351ment d'attaque et de d\351fense du monstre.";
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "R\351sistances";
		{
			const int anResist[5] = { prop.nResistFire, prop.nResistWater, prop.nResistElecricity, prop.nResistWind, prop.nResistEarth };
			const int anElement[5] = { SAI79::FIRE, SAI79::WATER, SAI79::ELECTRICITY, SAI79::WIND, SAI79::EARTH };
			CString strListe;
			for (int i = 0; i < 5; ++i)
			{
				if (anResist[i] == 0)
					continue;
				const LPCTSTR lpszElement = ZckQuNomElement(anElement[i]);
				str.Format("%s%s %d %%", strListe.IsEmpty() ? "" : "  \267  ", lpszElement ? lpszElement : "?", anResist[i]);
				strListe += str;
			}
			ligne.strValeur = strListe.IsEmpty() ? CString("Aucune") : strListe;
			ligne.strBulle = strListe.IsEmpty() ? CString("Aucune r\351sistance \351l\351mentaire.") : strListe;
		}
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "EXP";
		ligne.strValeur = Separator((__int64)prop.nExpValue, '.');
		ligne.dwCouleur = ZCK_QU_BLEU;
		ligne.strBulle = "EXP de base du monstre, avant les taux du serveur et l'\351cart de niveau.";
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "Comportement";
		ligne.strValeur = ZckQuComportement(prop.dwBelligerence, ligne.dwCouleur);
		ligne.strBulle = "Paisible : n'attaque pas le premier. Riposte : attaque s'il est attaqu\351. Agressif : attaque \340 vue. Corps \340 corps ou distance : style d'attaque du monstre.";
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "Rang";
		ligne.strValeur = ZckQuNomRang(prop.dwClass);
		if (prop.dwClass == RANK_BOSS || prop.dwClass == RANK_MIDBOSS || prop.dwClass == RANK_SUPER)
			ligne.dwCouleur = ZCK_QU_VIOLET;
		vec.push_back(ligne);

		ligne = ZCK_QU_FICHE();
		ligne.strLibelle = "D\351placement";
		ligne.strValeur.Format("%s  \267  vitesse %.2f", prop.dwFlying ? "Volant" : "Au sol", prop.fSpeed);
		vec.push_back(ligne);

		if (prop.m_nBerserkHP > 0 && prop.m_fBerserkDmgMul > 0.0f)
		{
			ligne = ZCK_QU_FICHE();
			ligne.strLibelle = "Rage";
			ligne.strValeur.Format("Sous %d %% PV : d\351g\342ts x%.1f", prop.m_nBerserkHP, prop.m_fBerserkDmgMul);
			ligne.dwCouleur = ZCK_QU_ORANGE;
			ligne.strBulle = "Sous ce seuil de PV, les d\351g\342ts du monstre sont multipli\351s.";
			vec.push_back(ligne);
		}
	}

	// Cadrage du monstre sur sa boite englobante (meme calcul que les
	// achievements), multiplie par le zoom. Renvoie FALSE sans boite
	// exploitable (cadrage d'origine en repli).
	BOOL ZckQuCadrer(VIEWPORT& view, CModelObject* pModel, const CRect& rectVue, float fZoom)
	{
		if (pModel->IsNullBoundBox() || rectVue.Width() <= 0 || rectVue.Height() <= 0)
			return FALSE;

		const D3DXVECTOR3 vMin = pModel->m_vMin;
		const D3DXVECTOR3 vMax = pModel->m_vMax;
		const float fHauteur = vMax.y - vMin.y;
		float fRayon = 0.0f;
		const float afX[2] = { vMin.x, vMax.x };
		const float afZ[2] = { vMin.z, vMax.z };
		for (int i = 0; i < 2; ++i)
		{
			for (int j = 0; j < 2; ++j)
			{
				const float fCoin = sqrtf(afX[i] * afX[i] + afZ[j] * afZ[j]);
				if (fCoin > fRayon)
					fRayon = fCoin;
			}
		}
		if (!_finite(fHauteur) || !_finite(fRayon) || fHauteur <= 0.001f || fRayon <= 0.001f)
			return FALSE;

		const float fFov = D3DX_PI / view.m_fFov;
		const float fVueH = cosf(fFov / 2.0f) / sinf(fFov / 2.0f);
		const float fVueL = fVueH * (float)rectVue.Width() / (float)rectVue.Height();
		float fEchelle = fVueH * ZCK_QU_MARGE_VUE / fHauteur;
		const float fEchelleL = fVueL * ZCK_QU_MARGE_VUE / (2.0f * fRayon);
		if (fEchelleL < fEchelle)
			fEchelle = fEchelleL;
		fEchelle *= fZoom;

		const float fCentreY = fEchelle * (vMin.y + vMax.y) * 0.5f;
		view.vecMatrixScaling = D3DXVECTOR3(fEchelle, fEchelle, fEchelle);
		view.vecMatrixTranslation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		view.vecPos = D3DXVECTOR3(0.0f, fCentreY, -10.0f);
		view.vecLookAt = D3DXVECTOR3(0.0f, fCentreY, 0.0f);
		return TRUE;
	}

	// Cadrage d'origine des fenetres de monstres : repli sans boite englobante.
	void ZckQuCadrageOrigine(VIEWPORT& view, CModelObject* pModel, float fZoom)
	{
		float fRayon = pModel->GetRadius();
		if (fRayon <= 0.001f)
			fRayon = 1.0f;

		D3DXVECTOR3 vecPos(0.0f, 0.0f, 0.0f);
		CObject3D* pObject3D = pModel->GetObject3D();
		if (pObject3D)
			vecPos = pObject3D->m_vEvent[0];

		const float fModelScale = pModel->m_pModelElem->m_fScale;
		if (fModelScale < 1.0f && fModelScale > 0.001f)
			vecPos *= (fModelScale - fModelScale * (0.5f + (1.0f - fModelScale) * 0.01f));
		else if (fModelScale > 1.0f)
			vecPos *= (fModelScale - fModelScale * (0.9f + fModelScale * 0.01f));

		vecPos.y += 2.2f;
		vecPos.z -= 3.0f;

		const float fScale = (1.0f / fRayon) * 1.5f * fZoom;
		view.vecPos = vecPos;
		view.vecLookAt = D3DXVECTOR3(0.0f, 0.28f, 1.0f);
		view.vecMatrixScaling = D3DXVECTOR3(fScale, fScale, fScale);
	}

	// Bouton gauche reellement enfonce (boutons inverses compris).
	BOOL ZckQuBoutonGauche()
	{
		const int nVirtKey = GetSystemMetrics(SM_SWAPBUTTON) ? VK_RBUTTON : VK_LBUTTON;
		return (GetAsyncKeyState(nVirtKey) & 0x8000) ? TRUE : FALSE;
	}

	// Taille maximale d'une fenetre en tuiles : la zone d'affichage
	// arrondie a 16, jamais sous le minimum.
	CSize ZckQuTailleMax(CWndBase* pRacine, int nMinL, int nMinH)
	{
		int nL = 4096;
		int nH = 4096;
		if (pRacine)
		{
			const CRect rectRacine = pRacine->GetLayoutRect();
			nL = rectRacine.Width() & ~15;
			nH = rectRacine.Height() & ~15;
		}
		if (nL < nMinL)
			nL = nMinL;
		if (nH < nMinH)
			nH = nMinH;
		return CSize(nL, nH);
	}

	// Fenetre ramenee dans la zone d'affichage (resolution changee depuis
	// la derniere position enregistree).
	void ZckQuGarderVisible(CWndBase* pWnd, CWndBase* pRacine)
	{
		if (pWnd == NULL || pRacine == NULL)
			return;
		const CRect rectRacine = pRacine->GetLayoutRect();
		const CRect rect = pWnd->GetWindowRect(TRUE);
		CPoint pt = rect.TopLeft();
		if (pt.x + rect.Width() > rectRacine.right)
			pt.x = rectRacine.right - rect.Width();
		if (pt.y + rect.Height() > rectRacine.bottom)
			pt.y = rectRacine.bottom - rect.Height();
		if (pt.x < rectRacine.left)
			pt.x = rectRacine.left;
		if (pt.y < rectRacine.top)
			pt.y = rectRacine.top;
		if (pt != rect.TopLeft())
			pWnd->Move(pt);
	}

	// Tri du suivi : terminees, en cours (echeance la plus proche d'abord), echouees.
	struct ZCK_QU_TRI
	{
		int nRang;
		__int64 n64Cle;
		int nId;

		bool operator<(const ZCK_QU_TRI& rhs) const
		{
			if (nRang != rhs.nRang)
				return nRang < rhs.nRang;
			if (n64Cle != rhs.n64Cle)
				return n64Cle < rhs.n64Cle;
			return nId < rhs.nId;
		}
	};
}

//////////////////////////////////////////////////////////////////////
// Reception (SNAPSHOTTYPE_ZCK_QUEST)
//////////////////////////////////////////////////////////////////////

// Un snapshot est lu en entier, quel que soit l'etat des fenetres : le
// catalogue et l'etat du personnage vivent hors d'elles. Un contenu refuse
// laisse l'ancien en place (lecture tout ou rien de CZckQuestManager).
void CWndZckQuest::Recevoir(CAr& ar)
{
	CZckQuestManager* pMng = CZckQuestManager::GetInstance();
	BYTE byGenre = 0;
	ar >> byGenre;

	switch (byGenre)
	{
	case ZCK_QUEST_GENRE_CATALOGUE:
		if (pMng->LireCatalogue(ar))
			s_bZckQuIndisponible = FALSE;
		else
			ZckQuSignaler(byGenre);
		break;

	case ZCK_QUEST_GENRE_ETAT:
	{
		CZckQuestState etat;
		DWORD dwVersion = 0;
		if (!pMng->LireEtat(ar, etat, dwVersion))
		{
			ZckQuSignaler(byGenre);
			break;
		}
		if (g_pPlayer)
			g_pPlayer->m_ZckQuest = etat;
		// Etat d'un autre catalogue (le notre a ete refuse) : catalogue redemande.
		if (dwVersion != pMng->GetVersion())
			ZckQuDemanderCatalogue();
		break;
	}

	case ZCK_QUEST_GENRE_MAJ:
	{
		CZckQuestState vide;
		CZckQuestState& etat = g_pPlayer ? g_pPlayer->m_ZckQuest : vide;
		int nId = 0;
		if (!pMng->LireMaj(ar, etat, nId))
			ZckQuSignaler(byGenre);
		break;
	}

	case ZCK_QUEST_GENRE_REPONSE:
	{
		BYTE byAction = 0;
		BYTE byCode = 0;
		int nId = 0;
		if (!CZckQuestManager::LireReponse(ar, byAction, byCode, nId))
		{
			ZckQuSignaler(byGenre);
			break;
		}
		if (byAction == ZCK_QUEST_ACTION_CATALOGUE)
		{
			// Demande automatique (entree en jeu, journal ouvert) : aucun message.
			if (byCode == ZCK_QUEST_REFUS_INDISPONIBLE)
				s_bZckQuIndisponible = TRUE;
		}
		else if (byCode != ZCK_QUEST_OK)
		{
			// Les reussites sont annoncees par le WorldServer lui-meme ; les refus ici.
			if (byCode == ZCK_QUEST_REFUS_INDISPONIBLE)
				s_bZckQuIndisponible = TRUE;
			const ZCK_QUEST_DEFINITION* pDef = pMng->GetDefinition(nId);
			CString str;
			if (pDef)
				str.Format("Qu\352tes (%s) : %s", (LPCTSTR)pDef->strNom, CZckQuestManager::TexteCode(byCode));
			else
				str.Format("Qu\352tes : %s", CZckQuestManager::TexteCode(byCode));
			g_WndMng.PutString(str, NULL, (byCode == ZCK_QUEST_REFUS_CATALOGUE) ? 0xffffd040 : 0xffff6060);
		}
		CWndZckQuest* pWnd = (CWndZckQuest*)g_WndMng.GetWndBase(APP_ZCK_QUEST);
		if (pWnd)
			pWnd->FinDemande(byAction, byCode, nId);
		break;
	}

	default:
		// Genre inconnu (client plus ancien que le serveur) : la suite est
		// sautee grace a la taille du snapshot (CDPClient::OnSnapshot).
		break;
	}

	CWndZckQuest* pWnd = (CWndZckQuest*)g_WndMng.GetWndBase(APP_ZCK_QUEST);
	if (pWnd)
		pWnd->Rafraichir();
	CWndZckQuestSuivi::Actualiser();
}

void CWndZckQuest::Ouvrir(int nId)
{
	CWndZckQuest* pWnd = (CWndZckQuest*)g_WndMng.GetWndBase(APP_ZCK_QUEST);
	if (pWnd == NULL)
		pWnd = (CWndZckQuest*)g_WndMng.CreateApplet(APP_ZCK_QUEST);
	if (pWnd == NULL)
		return;
	pWnd->SelectQuete(nId);
	pWnd->SetFocus();
}

//////////////////////////////////////////////////////////////////////
// Journal : construction
//////////////////////////////////////////////////////////////////////

CWndZckQuest::CWndZckQuest()
	: m_nOnglet(ZCK_QU_ONGLET_TOUTES)
	, m_nSelectedId(0)
	, m_nScroll(0)
	, m_dwTickListe(0)
	, m_dwTickEnvoi(0)
	, m_nEnvoiId(0)
	, m_dwTickConfirmer(0)
	, m_nConfirmerId(0)
	, m_ptSurvol(-1, -1)
	, m_bAppui(FALSE)
	, m_bRestaurable(FALSE)
	, m_rectRestauree(0, 0, 0, 0)
	, m_bPlace(FALSE)
	, m_nViewMonster(0)
	, m_pMonsterModel(NULL)
	, m_dwViewportMonsterId(NULL_ID)
	, m_dwNextFrameMove(0)
	, m_bTourne(FALSE)
	, m_bRotationLibre(FALSE)
	, m_fRotation(0.0f)
	, m_fZoom(1.0f)
	, m_ptTourne(0, 0)
	, m_nZonesMonstres(0)
	, m_nBulles(0)
{
	for (int i = 0; i < ZCK_QU_NB_ONGLETS; ++i)
		m_anCompte[i] = 0;
	for (int i = 0; i < ZCK_QU_MONSTRES_ZONES_MAX; ++i)
		m_anMonstre[i] = 0;
}

CWndZckQuest::~CWndZckQuest()
{
	// Jamais de g_pPlayer ici : a la fermeture du client il peut deja etre
	// detruit. Seules la capture souris et le modele sont rendus.
	FinTourner();
	ReleaseMonsterModel();
}

BOOL CWndZckQuest::Initialize(CWndBase* pWndParent, DWORD /*dwWndId*/)
{
	if (!ZckQuBlocPresent(APP_ZCK_QUEST, "APP_ZCK_QUEST"))
	{
		g_WndMng.PutString("Qu\352tes : fen\352tre absente des ressources du client (resdata.inc, Data.res \340 refaire).", NULL, 0xffff0000);
		return FALSE;
	}
	return CWndNeuz::InitDialog(g_Neuz.GetSafeHwnd(), APP_ZCK_QUEST, 0, CPoint(0, 0), pWndParent);
}

void CWndZckQuest::OnInitialUpdate()
{
	CWndNeuz::OnInitialUpdate();

	// Taille par defaut, bornee par la zone d'affichage (SetWndRect).
	CRect rectFenetre = GetWindowRect(TRUE);
	rectFenetre.right = rectFenetre.left + ZCK_QU_FENETRE_L;
	rectFenetre.bottom = rectFenetre.top + ZCK_QU_FENETRE_H;
	SetWndRect(rectFenetre);

	// Ouverture sur une recompense a recuperer, sinon une quete en cours.
	m_nOnglet = ZCK_QU_ONGLET_TOUTES;
	m_nSelectedId = 0;
	const map<int, ZCK_QUEST_DEFINITION>& definitions = CZckQuestManager::GetInstance()->GetDefinitions();
	for (int nPasse = 0; nPasse < 2 && m_nSelectedId == 0; ++nPasse)
	{
		const int nVoulu = (nPasse == 0) ? ZCK_QUEST_STATUT_TERMINEE : ZCK_QUEST_STATUT_EN_COURS;
		for (map<int, ZCK_QUEST_DEFINITION>::const_iterator it = definitions.begin(); it != definitions.end(); ++it)
		{
			if (ZckQuStatut(it->second) == nVoulu)
			{
				m_nSelectedId = it->first;
				break;
			}
		}
	}
	RebuildList();
	for (int i = 0; i < (int)m_vecList.size(); ++i)
	{
		if (m_vecList[i] == m_nSelectedId)
		{
			ScrollTo(i);
			break;
		}
	}

	MoveParentCenter();

	// Catalogue absent (refuse, ou systeme inactif au dernier essai) : redemande.
	if (!CZckQuestManager::GetInstance()->EstActif())
	{
		s_bZckQuIndisponible = FALSE;
		ZckQuDemanderCatalogue();
	}
}

void CWndZckQuest::OnDestroy()
{
	FinTourner();
	ReleaseMonsterModel();
	CWndNeuz::OnDestroy();
}

HRESULT CWndZckQuest::InvalidateDeviceObjects()
{
	CWndNeuz::InvalidateDeviceObjects();
	ReleaseMonsterModel();
	return S_OK;
}

// Redimensionnement par les bords (WBS_THICKFRAME), Agrandir et position
// enregistree : de la taille minimale a la zone d'affichage, multiples de 16.
void CWndZckQuest::SetWndRect(CRect rectWnd, BOOL bOnSize)
{
	const CSize sizeMax = ZckQuTailleMax(m_pWndRoot, ZCK_QU_FENETRE_L_MIN, ZCK_QU_FENETRE_H_MIN);
	AdjustMinRect(&rectWnd, ZCK_QU_FENETRE_L_MIN, ZCK_QU_FENETRE_H_MIN);
	AdjustMaxRect(&rectWnd, sizeMax.cx, sizeMax.cy);
	CWndNeuz::SetWndRect(rectWnd, bOnSize);
}

BOOL CWndZckQuest::EstAgrandie()
{
	const CSize sizeMax = ZckQuTailleMax(m_pWndRoot, ZCK_QU_FENETRE_L_MIN, ZCK_QU_FENETRE_H_MIN);
	const CRect rect = GetWindowRect(TRUE);
	return (rect.Width() >= sizeMax.cx && rect.Height() >= sizeMax.cy) ? TRUE : FALSE;
}

// Agrandir : toute la zone d'affichage ; Restaurer : le rectangle d'avant
// (a defaut, la taille par defaut au centre).
void CWndZckQuest::Agrandir()
{
	if (m_pWndRoot == NULL)
		return;
	const CRect rectRacine = m_pWndRoot->GetLayoutRect();
	if (!EstAgrandie())
	{
		m_rectRestauree = GetWindowRect(TRUE);
		m_bRestaurable = TRUE;
		const CSize sizeMax = ZckQuTailleMax(m_pWndRoot, ZCK_QU_FENETRE_L_MIN, ZCK_QU_FENETRE_H_MIN);
		SetWndRect(CRect(rectRacine.left, rectRacine.top, rectRacine.left + sizeMax.cx, rectRacine.top + sizeMax.cy));
		return;
	}
	CRect rect = m_rectRestauree;
	if (!m_bRestaurable || rect.Width() <= 0 || rect.Height() <= 0 || (rect.Width() >= rectRacine.Width() && rect.Height() >= rectRacine.Height()))
	{
		const int x = rectRacine.left + (rectRacine.Width() - ZCK_QU_FENETRE_L) / 2;
		const int y = rectRacine.top + (rectRacine.Height() - ZCK_QU_FENETRE_H) / 2;
		rect = CRect(x, y, x + ZCK_QU_FENETRE_L, y + ZCK_QU_FENETRE_H);
	}
	m_bRestaurable = FALSE;
	SetWndRect(rect);
	ZckQuGarderVisible(this, m_pWndRoot);
}

//////////////////////////////////////////////////////////////////////
// Journal : donnees
//////////////////////////////////////////////////////////////////////

const ZCK_QUEST_DEFINITION* CWndZckQuest::GetSelection() const
{
	if (m_nSelectedId <= 0)
		return NULL;
	return CZckQuestManager::GetInstance()->GetDefinition(m_nSelectedId);
}

BOOL CWndZckQuest::DansOnglet(int nOnglet, int nStatut) const
{
	switch (nOnglet)
	{
	case ZCK_QU_ONGLET_DISPONIBLES:		return nStatut == ZCK_QUEST_STATUT_DISPONIBLE || nStatut == ZCK_QUEST_STATUT_ECHOUEE;
	case ZCK_QU_ONGLET_EN_COURS:		return nStatut == ZCK_QUEST_STATUT_EN_COURS;
	case ZCK_QU_ONGLET_A_RECUPERER:		return nStatut == ZCK_QUEST_STATUT_TERMINEE;
	case ZCK_QU_ONGLET_ACCOMPLIES:		return nStatut == ZCK_QUEST_STATUT_ACCOMPLIE;
	default:							break;
	}
	return TRUE;
}

// Liste de l'onglet dans l'ordre des Id (ordre de ZckQuetes.inc) et
// compteurs des onglets. Les statuts suivent l'heure : recalcul regulier
// (Process). La quete detaillee reste choisie meme si elle quitte l'onglet
// (acceptee depuis Disponibles, elle reste sous les yeux).
void CWndZckQuest::RebuildList()
{
	m_dwTickListe = GetTickCount();
	m_vecList.clear();
	for (int i = 0; i < ZCK_QU_NB_ONGLETS; ++i)
		m_anCompte[i] = 0;

	const map<int, ZCK_QUEST_DEFINITION>& definitions = CZckQuestManager::GetInstance()->GetDefinitions();
	for (map<int, ZCK_QUEST_DEFINITION>::const_iterator it = definitions.begin(); it != definitions.end(); ++it)
	{
		const int nStatut = ZckQuStatut(it->second);
		for (int i = 0; i < ZCK_QU_NB_ONGLETS; ++i)
		{
			if (DansOnglet(i, nStatut))
				++m_anCompte[i];
		}
		if (DansOnglet(m_nOnglet, nStatut))
			m_vecList.push_back(it->first);
	}

	if (m_nSelectedId != 0 && GetSelection() == NULL)
	{
		m_nSelectedId = 0;
		m_nViewMonster = 0;
	}
	if (m_nSelectedId == 0 && !m_vecList.empty())
	{
		m_nSelectedId = m_vecList[0];
		m_nViewMonster = 0;
		m_bRotationLibre = FALSE;
		m_fZoom = 1.0f;
	}
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	if (pDef == NULL || m_nViewMonster < 0 || m_nViewMonster >= (int)pDef->vecMonstres.size())
		m_nViewMonster = 0;

	const int nMax = (int)m_vecList.size() - GetVisibleRows();
	if (m_nScroll > nMax)
		m_nScroll = nMax;
	if (m_nScroll < 0)
		m_nScroll = 0;
}

void CWndZckQuest::Rafraichir()
{
	if (m_nEnvoiId > 0 && CZckQuestManager::GetInstance()->GetDefinition(m_nEnvoiId) == NULL)
	{
		m_dwTickEnvoi = 0;
		m_nEnvoiId = 0;
	}
	RebuildList();
}

void CWndZckQuest::FinDemande(BYTE byAction, BYTE /*byCode*/, int /*nId*/)
{
	if (byAction == ZCK_QUEST_ACTION_CATALOGUE)
		return;
	m_dwTickEnvoi = 0;
	m_nEnvoiId = 0;
}

void CWndZckQuest::SelectOnglet(int nOnglet)
{
	if (nOnglet < 0 || nOnglet >= ZCK_QU_NB_ONGLETS || nOnglet == m_nOnglet)
		return;
	m_nOnglet = nOnglet;
	m_nScroll = 0;
	RebuildList();
	// Quete detaillee hors du nouvel onglet : la premiere de l'onglet.
	BOOL bPresente = FALSE;
	for (int i = 0; i < (int)m_vecList.size(); ++i)
	{
		if (m_vecList[i] == m_nSelectedId)
		{
			bPresente = TRUE;
			ScrollTo(i);
			break;
		}
	}
	if (!bPresente && !m_vecList.empty())
		SelectIndex(0);
}

// Selection depuis le suivi : la quete est montree, dans son onglet courant
// si elle y est, sinon dans Toutes.
void CWndZckQuest::SelectQuete(int nId)
{
	if (CZckQuestManager::GetInstance()->GetDefinition(nId) == NULL)
		return;
	if (nId != m_nSelectedId)
	{
		m_nSelectedId = nId;
		m_nViewMonster = 0;
		m_bRotationLibre = FALSE;
		m_fZoom = 1.0f;
	}
	RebuildList();
	int nIndex = -1;
	for (int i = 0; i < (int)m_vecList.size(); ++i)
	{
		if (m_vecList[i] == nId)
		{
			nIndex = i;
			break;
		}
	}
	if (nIndex < 0 && m_nOnglet != ZCK_QU_ONGLET_TOUTES)
	{
		m_nOnglet = ZCK_QU_ONGLET_TOUTES;
		m_nScroll = 0;
		RebuildList();
		for (int i = 0; i < (int)m_vecList.size(); ++i)
		{
			if (m_vecList[i] == nId)
			{
				nIndex = i;
				break;
			}
		}
	}
	if (nIndex >= 0)
		ScrollTo(nIndex);
}

void CWndZckQuest::SelectIndex(int nIndex)
{
	if (nIndex < 0 || nIndex >= (int)m_vecList.size())
		return;
	if (m_vecList[nIndex] != m_nSelectedId)
	{
		m_nSelectedId = m_vecList[nIndex];
		m_nViewMonster = 0;
		m_bRotationLibre = FALSE;
		m_fZoom = 1.0f;
		m_dwTickConfirmer = 0;
		m_nConfirmerId = 0;
	}
	ScrollTo(nIndex);
}

void CWndZckQuest::ScrollTo(int nIndex)
{
	const int nRows = GetVisibleRows();
	if (nIndex < m_nScroll)
		m_nScroll = nIndex;
	else if (nRows > 0 && nIndex >= m_nScroll + nRows)
		m_nScroll = nIndex - nRows + 1;
	const int nMax = (int)m_vecList.size() - nRows;
	if (m_nScroll > nMax)
		m_nScroll = nMax;
	if (m_nScroll < 0)
		m_nScroll = 0;
}

int CWndZckQuest::GetVisibleRows()
{
	const CRect rectListe = RectListe();
	const int nRows = (rectListe.Height() - ZCK_QU_TITRE_H - 8) / ZCK_QU_LIGNE_H;
	return (nRows > 0) ? nRows : 1;
}

// Bouton d'action du pied, selon le statut : memes refus que le WorldServer
// (CZckQuestManager::Accepter, Abandonner, Recuperer), qui revalide tout.
BOOL CWndZckQuest::ActionPossible(const ZCK_QUEST_DEFINITION& def, BYTE& byAction, CString& strBouton, CString& strRaison) const
{
	CZckQuestManager* pMng = CZckQuestManager::GetInstance();
	byAction = 0;
	strBouton = "Accepter";
	strRaison.Empty();
	if (g_pPlayer == NULL)
		return FALSE;
	if (!pMng->HorlogeConnue())
	{
		strRaison = "Synchronisation avec le serveur...";
		return FALSE;
	}
	if (!g_pPlayer->m_ZckQuest.IsBaseOk())
	{
		strRaison = CZckQuestManager::TexteCode(ZCK_QUEST_REFUS_BASE);
		return FALSE;
	}

	const __int64 n64 = pMng->HorlogeServeur();
	const int nStatut = ZckQuStatut(def);
	switch (nStatut)
	{
	case ZCK_QUEST_STATUT_TERMINEE:
		byAction = ZCK_QUEST_ACTION_RECUPERER;
		strBouton = "R\351cup\351rer";
		strRaison = "Objectif atteint : r\351cup\351rez la r\351compense.";
		return TRUE;

	case ZCK_QUEST_STATUT_EN_COURS:
		byAction = ZCK_QUEST_ACTION_ABANDONNER;
		if (m_dwTickConfirmer != 0 && m_nConfirmerId == def.nId)
		{
			strBouton = "Confirmer l'abandon";
			strRaison = "Cliquez encore pour abandonner : la progression sera perdue.";
		}
		else
		{
			strBouton = "Abandonner";
			strRaison = "Qu\352te en cours : vainquez les monstres avant la fin du temps imparti.";
		}
		return TRUE;

	case ZCK_QUEST_STATUT_ACCOMPLIE:
		strBouton = "Accomplie";
		strRaison = "R\351compense d\351j\340 re\347ue pour cette ouverture.";
		return FALSE;

	case ZCK_QUEST_STATUT_FERMEE:
		strRaison = "Hors horaire : la qu\352te s'accepte pendant son horaire.";
		return FALSE;

	case ZCK_QUEST_STATUT_VERROUILLEE:
	{
		const int nNiveau = ZckQuNiveau();
		if (nNiveau < def.nNiveauMin || nNiveau > def.nNiveauMax)
			strRaison.Format("Niveau requis : %s (le v\364tre : %d).", (LPCTSTR)ZckQuBornes(def.nNiveauMin, def.nNiveauMax, 1, ZckQuNiveauJeu()), nNiveau);
		else
			strRaison.Format("Prestige requis : %s (le v\364tre : %d).", (LPCTSTR)ZckQuBornes(def.nPrestigeMin, def.nPrestigeMax, 0, ZckQuPrestigeJeu()), ZckQuPrestige());
		return FALSE;
	}

	case ZCK_QUEST_STATUT_ECHOUEE:
	{
		strBouton = "Recommencer";
		ZCK_QUEST_FENETRE fen;
		CZckQuestManager::CalculerFenetre(def, n64, fen);
		if (!fen.bOuverte)
		{
			strRaison = "Temps \351coul\351, horaire termin\351 : \340 la prochaine ouverture.";
			return FALSE;
		}
		break;
	}

	default:
		break;
	}

	// Disponible, ou echouee dans un horaire encore ouvert.
	const int nActives = pMng->CompterActives(g_pPlayer->m_ZckQuest, n64);
	if (nActives >= pMng->GetActivesMax())
	{
		strRaison.Format("Trop de qu\352tes en cours (%d / %d) : terminez ou abandonnez-en une.", nActives, pMng->GetActivesMax());
		return FALSE;
	}
	byAction = ZCK_QUEST_ACTION_ACCEPTER;
	if (nStatut == ZCK_QUEST_STATUT_ECHOUEE)
		strRaison = "Temps \351coul\351 : recommencez tant que l'horaire est ouvert.";
	else
		strRaison = "Qu\352te disponible.";
	return TRUE;
}

// Le client ne nomme qu'une action et une quete ; le serveur juge tout.
// Abandonner demande un second clic (progression perdue).
void CWndZckQuest::Agir()
{
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	if (pDef == NULL || m_dwTickEnvoi != 0)
		return;
	BYTE byAction = 0;
	CString strBouton;
	CString strRaison;
	if (!ActionPossible(*pDef, byAction, strBouton, strRaison) || byAction == 0)
		return;

	if (byAction == ZCK_QUEST_ACTION_ABANDONNER && (m_dwTickConfirmer == 0 || m_nConfirmerId != pDef->nId))
	{
		m_dwTickConfirmer = GetTickCount() | 1;
		m_nConfirmerId = pDef->nId;
		return;
	}
	m_dwTickConfirmer = 0;
	m_nConfirmerId = 0;

	g_DPlay.SendZckQuest(byAction, pDef->nId, CZckQuestManager::GetInstance()->GetVersion());
	m_dwTickEnvoi = GetTickCount() | 1;
	m_nEnvoiId = pDef->nId;
}

//////////////////////////////////////////////////////////////////////
// Journal : monstre de l'apercu
//////////////////////////////////////////////////////////////////////

DWORD CWndZckQuest::GetViewMonsterId() const
{
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	if (pDef == NULL || pDef->vecMonstres.empty())
		return NULL_ID;
	const int nIndex = (m_nViewMonster >= 0 && m_nViewMonster < (int)pDef->vecMonstres.size()) ? m_nViewMonster : 0;
	return pDef->vecMonstres[nIndex];
}

// Modele charge a la demande (motion MTI_STAND), un seul a la fois ; rendu
// apres une perte du device.
CModelObject* CWndZckQuest::GetMonsterModel(DWORD dwMonsterId)
{
	if (dwMonsterId == NULL_ID)
	{
		ReleaseMonsterModel();
		return NULL;
	}
	// Un seul essai par monstre (ReleaseMonsterModel remet l'Id a NULL_ID,
	// apres une perte du peripherique par exemple) : un modele introuvable
	// n'est pas recharge a chaque image.
	if (dwMonsterId != m_dwViewportMonsterId)
	{
		ReleaseMonsterModel();
		m_dwViewportMonsterId = dwMonsterId;
		if (ZckQuMoverProp(dwMonsterId))
		{
			m_pMonsterModel = (CModelObject*)prj.m_modelMng.LoadModel(g_Neuz.m_pd3dDevice, OT_MOVER, dwMonsterId);
			if (m_pMonsterModel)
			{
				prj.m_modelMng.LoadMotion(m_pMonsterModel, OT_MOVER, dwMonsterId, MTI_STAND);
				m_pMonsterModel->InitDeviceObjects(g_Neuz.GetDevice());
			}
		}
	}
	return m_pMonsterModel;
}

void CWndZckQuest::ReleaseMonsterModel()
{
	SAFE_DELETE(m_pMonsterModel);
	m_dwViewportMonsterId = NULL_ID;
	m_dwNextFrameMove = 0;
}

void CWndZckQuest::ChangerMonstre(int nSens)
{
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	if (pDef == NULL || pDef->vecMonstres.size() < 2)
		return;
	const int nNombre = (int)pDef->vecMonstres.size();
	m_nViewMonster = ((m_nViewMonster + nSens) % nNombre + nNombre) % nNombre;
	m_bRotationLibre = FALSE;
}

// Angle montre : balancement lent autour de la face, ou angle choisi a la souris.
float CWndZckQuest::AngleVue() const
{
	if (m_bRotationLibre)
		return m_fRotation;
	const float fPhase = (float)(GetTickCount() % ZCK_QU_OSCILLATION_MS) / (float)ZCK_QU_OSCILLATION_MS;
	return sinf(fPhase * 2.0f * D3DX_PI) * ZCK_QU_OSCILLATION_DEG;
}

void CWndZckQuest::FinTourner()
{
	m_bTourne = FALSE;
	if (m_pWndCapture == this)
		ReleaseCapture();
}

//////////////////////////////////////////////////////////////////////
// Journal : geometrie
//////////////////////////////////////////////////////////////////////

CRect CWndZckQuest::RectBandeau()
{
	return CRect(ZCK_QU_BORD, ZCK_QU_BANDEAU_HAUT, GetClientRect().Width() - ZCK_QU_BORD, ZCK_QU_BANDEAU_BAS);
}

CRect CWndZckQuest::RectAgrandir()
{
	const CRect rect = RectBandeau();
	const int y = rect.top + (rect.Height() - ZCK_QU_BOUTON_H) / 2;
	return CRect(rect.right - 10 - ZCK_QU_AGRANDIR_L, y, rect.right - 10, y + ZCK_QU_BOUTON_H);
}

CRect CWndZckQuest::RectSuivi()
{
	const CRect rectAgrandir = RectAgrandir();
	return CRect(rectAgrandir.left - ZCK_QU_ECART - ZCK_QU_SUIVI_L, rectAgrandir.top, rectAgrandir.left - ZCK_QU_ECART, rectAgrandir.bottom);
}

CRect CWndZckQuest::RectOnglet(int nOnglet)
{
	if (nOnglet < 0 || nOnglet >= ZCK_QU_NB_ONGLETS)
		return CRect(0, 0, 0, 0);
	const int nZone = GetClientRect().Width() - 2 * ZCK_QU_BORD;
	const int nLargeur = (nZone - (ZCK_QU_NB_ONGLETS - 1) * ZCK_QU_ECART) / ZCK_QU_NB_ONGLETS;
	const int x = ZCK_QU_BORD + nOnglet * (nLargeur + ZCK_QU_ECART);
	const int xDroite = (nOnglet == ZCK_QU_NB_ONGLETS - 1) ? ZCK_QU_BORD + nZone : x + nLargeur;
	return CRect(x, ZCK_QU_ONGLETS_HAUT, xDroite, ZCK_QU_ONGLETS_BAS);
}

int CWndZckQuest::GetCorpsHaut() const
{
	return ZCK_QU_CORPS_HAUT;
}

int CWndZckQuest::GetCorpsBas()
{
	return GetClientRect().Height() - ZCK_QU_BORD - ZCK_QU_PIED_H - ZCK_QU_ECART;
}

CRect CWndZckQuest::RectListe()
{
	int nLargeur = GetClientRect().Width() * 27 / 100;
	if (nLargeur < ZCK_QU_LISTE_L_MIN)
		nLargeur = ZCK_QU_LISTE_L_MIN;
	if (nLargeur > ZCK_QU_LISTE_L_MAX)
		nLargeur = ZCK_QU_LISTE_L_MAX;
	return CRect(ZCK_QU_BORD, GetCorpsHaut(), ZCK_QU_BORD + nLargeur, GetCorpsBas());
}

// Ligne nIndex de m_vecList, vide si elle n'est pas visible.
CRect CWndZckQuest::RectLigne(int nIndex)
{
	const int nRang = nIndex - m_nScroll;
	if (nIndex < 0 || nIndex >= (int)m_vecList.size() || nRang < 0 || nRang >= GetVisibleRows())
		return CRect(0, 0, 0, 0);
	const CRect rectListe = RectListe();
	const int y = rectListe.top + ZCK_QU_TITRE_H + 4 + nRang * ZCK_QU_LIGNE_H;
	return CRect(rectListe.left + 4, y, rectListe.right - 4 - ZCK_QU_PISTE_L - 4, y + ZCK_QU_LIGNE_H - 2);
}

CRect CWndZckQuest::RectPiste()
{
	const CRect rectListe = RectListe();
	return CRect(rectListe.right - 4 - ZCK_QU_PISTE_L, rectListe.top + ZCK_QU_TITRE_H + 4, rectListe.right - 4, rectListe.bottom - 4);
}

CRect CWndZckQuest::RectColonneMonstre()
{
	const CRect rectClient = GetClientRect();
	int nLargeur = rectClient.Width() * 26 / 100;
	if (nLargeur < ZCK_QU_MONSTRE_L_MIN)
		nLargeur = ZCK_QU_MONSTRE_L_MIN;
	if (nLargeur > ZCK_QU_MONSTRE_L_MAX)
		nLargeur = ZCK_QU_MONSTRE_L_MAX;
	const int xDroite = rectClient.Width() - ZCK_QU_BORD;
	return CRect(xDroite - nLargeur, GetCorpsHaut(), xDroite, GetCorpsBas());
}

CRect CWndZckQuest::RectDetail()
{
	return CRect(RectListe().right + ZCK_QU_BORD, GetCorpsHaut(), RectColonneMonstre().left - ZCK_QU_BORD, GetCorpsBas());
}

// Recompenses en bas du detail : emplacements (objets puis buffs), Penya, EXP.
CRect CWndZckQuest::RectRecompenses()
{
	const CRect rectDetail = RectDetail();
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	BOOL bSlots = FALSE;
	int nLignes = 0;
	if (pDef)
	{
		bSlots = !pDef->vecObjets.empty() || !pDef->vecBuffs.empty();
		nLignes = ((pDef->nPenya > 0) ? 1 : 0) + ((pDef->n64Exp > 0 || pDef->nExpPourcent > 0) ? 1 : 0);
	}
	if (!bSlots && nLignes == 0)
		nLignes = 1;
	int nHauteur = ZCK_QU_TITRE_H + 6 + (bSlots ? ZCK_QU_SLOT + 6 : 0) + nLignes * ZCK_QU_RECOMPENSE_H + 6;
	const int nMax = rectDetail.Height() / 2;
	if (nHauteur > nMax)
		nHauteur = nMax;
	return CRect(rectDetail.left, rectDetail.bottom - nHauteur, rectDetail.right, rectDetail.bottom);
}

CRect CWndZckQuest::RectSlot(int nSlot)
{
	const CRect rect = RectRecompenses();
	const int x = rect.left + 8 + nSlot * (ZCK_QU_SLOT + 6);
	const int y = rect.top + ZCK_QU_TITRE_H + 6;
	return CRect(x, y, x + ZCK_QU_SLOT, y + ZCK_QU_SLOT);
}

// Fiche du monstre sous l'apercu : une ligne par information, sans jamais
// laisser moins de ZCK_QU_APERCU_H_MIN a l'apercu.
CRect CWndZckQuest::RectFiche()
{
	const CRect rectColonne = RectColonneMonstre();
	int nLignes = 10;
	const DWORD dwMonsterId = GetViewMonsterId();
	MoverProp* pProp = ZckQuMoverProp(dwMonsterId);
	if (pProp)
	{
		vector<ZCK_QU_FICHE> vecFiche;
		ZckQuFiche(*pProp, vecFiche);
		nLignes = (int)vecFiche.size();
	}
	int nHauteur = ZCK_QU_TITRE_H + 6 + nLignes * ZCK_QU_FICHE_H + 6;
	const int nMax = rectColonne.Height() - ZCK_QU_APERCU_H_MIN - ZCK_QU_ECART;
	if (nHauteur > nMax)
		nHauteur = nMax;
	return CRect(rectColonne.left, rectColonne.bottom - nHauteur, rectColonne.right, rectColonne.bottom);
}

CRect CWndZckQuest::RectApercu()
{
	const CRect rectColonne = RectColonneMonstre();
	return CRect(rectColonne.left, rectColonne.top, rectColonne.right, RectFiche().top - ZCK_QU_ECART);
}

// Vue 3D : sous la bande de titre, au-dessus du nom et du niveau.
CRect CWndZckQuest::RectVue()
{
	const CRect rectApercu = RectApercu();
	return CRect(rectApercu.left + 6, rectApercu.top + ZCK_QU_TITRE_H + 4, rectApercu.right - 6, rectApercu.bottom - 40);
}

// Fleches de la vue (monstre precedent -1, suivant +1), si plusieurs monstres.
CRect CWndZckQuest::RectFleche(int nSens)
{
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	if (pDef == NULL || pDef->vecMonstres.size() < 2)
		return CRect(0, 0, 0, 0);
	const CRect rectVue = RectVue();
	const int yCentre = rectVue.CenterPoint().y;
	if (nSens < 0)
		return CRect(rectVue.left + 2, yCentre - 16, rectVue.left + 22, yCentre + 16);
	return CRect(rectVue.right - 22, yCentre - 16, rectVue.right - 2, yCentre + 16);
}

CRect CWndZckQuest::RectAction()
{
	const CRect rectClient = GetClientRect();
	const int xDroite = rectClient.Width() - ZCK_QU_BORD - ZCK_QU_FERMER_L - ZCK_QU_BORD;
	const int yBas = rectClient.Height() - ZCK_QU_BORD;
	return CRect(xDroite - ZCK_QU_ACTION_L, yBas - ZCK_QU_PIED_H, xDroite, yBas);
}

CRect CWndZckQuest::RectFermer()
{
	const CRect rectClient = GetClientRect();
	const int xDroite = rectClient.Width() - ZCK_QU_BORD;
	const int yBas = rectClient.Height() - ZCK_QU_BORD;
	return CRect(xDroite - ZCK_QU_FERMER_L, yBas - ZCK_QU_PIED_H, xDroite, yBas);
}

//////////////////////////////////////////////////////////////////////
// Journal : dessin
//////////////////////////////////////////////////////////////////////

void CWndZckQuest::OnDraw(C2DRender* p2DRender)
{
	if (!p2DRender || !p2DRender->m_pFont)
		return;

	m_nZonesMonstres = 0;
	m_nBulles = 0;

	DessinerBandeau(p2DRender);

	CZckQuestManager* pMng = CZckQuestManager::GetInstance();
	if (!pMng->EstActif())
	{
		if (s_bZckQuIndisponible)
			DessinerVide(p2DRender, "Qu\352tes indisponibles", "Le syst\350me de qu\352tes est indisponible sur ce serveur (ZckQuetes.inc absent ou invalide).");
		else
			DessinerVide(p2DRender, "Qu\352tes", "Chargement des qu\352tes depuis le serveur...");
		DessinerPied(p2DRender);
		return;
	}
	if (pMng->GetDefinitions().empty())
	{
		DessinerVide(p2DRender, "Qu\352tes", "Aucune qu\352te n'est configur\351e sur ce serveur.");
		DessinerPied(p2DRender);
		return;
	}

	DessinerOnglets(p2DRender);
	DessinerListe(p2DRender);
	DessinerDetail(p2DRender);
	DessinerRecompenses(p2DRender);
	DessinerApercu(p2DRender);
	DessinerFiche(p2DRender);
	DessinerPied(p2DRender);
}

void CWndZckQuest::AjouterBulle(const CRect& rect, LPCTSTR lpszTitre, LPCTSTR lpszTexte)
{
	if (lpszTexte == NULL || lpszTexte[0] == '\0' || m_nBulles >= ZCK_QU_BULLES_MAX)
		return;
	m_arectBulle[m_nBulles] = rect;
	m_astrBulleTitre[m_nBulles] = lpszTitre ? lpszTitre : "";
	m_astrBulle[m_nBulles] = lpszTexte;
	++m_nBulles;
}

// Corps sans catalogue : un seul panneau et son message.
void CWndZckQuest::DessinerVide(C2DRender* p2DRender, LPCTSTR lpszTitre, LPCTSTR lpszTexte)
{
	const CRect rect(ZCK_QU_BORD, ZCK_QU_ONGLETS_HAUT, GetClientRect().Width() - ZCK_QU_BORD, GetCorpsBas());
	ZckQuCarte(p2DRender, rect, lpszTitre, ZCK_QU_OR, ZCK_QU_CADRE);
	const CRect rectCorps(rect.left, rect.top + ZCK_QU_TITRE_H, rect.right, rect.bottom);
	ZckQuTexteCentre(p2DRender, rectCorps, lpszTexte, ZCK_QU_GRIS);
}

// Titre, heure du serveur, compteurs, boutons Suivi et Agrandir.
void CWndZckQuest::DessinerBandeau(C2DRender* p2DRender)
{
	const CRect rect = RectBandeau();
	p2DRender->RenderFillRect(rect, 0xC0201438, 0xC0101828, 0xA0080410, 0xA0080C14);
	p2DRender->RenderRoundRect(rect, ZCK_QU_CADRE);

	CZckQuestManager* pMng = CZckQuestManager::GetInstance();
	const CRect rectSuivi = RectSuivi();
	const CRect rectAgrandir = RectAgrandir();
	const int xGauche = rect.left + 12;
	const int xDroite = rectSuivi.left - 12;

	int nTitre = 0;
	{
		ZckQuPolice police(p2DRender, CWndBase::m_Theme.m_pFontCaption);
		nTitre = ZckQuTexte(p2DRender, xGauche, rect.top + 4, "Qu\352tes de chasse", ZCK_QU_OR, (xDroite - xGauche) / 2, 0);
	}

	CString str;
	if (pMng->HorlogeConnue())
	{
		const __int64 n64 = pMng->HorlogeServeur();
		const int nSecondes = (int)(n64 % ZCK_QUEST_JOUR_S);
		str.Format("Heure du serveur : %s %02d:%02d:%02d", ZckQuJourLong(CZckQuestManager::JourSemaine(n64 / ZCK_QUEST_JOUR_S)), nSecondes / 3600, (nSecondes / 60) % 60, nSecondes % 60);
	}
	else
		str = "Heure du serveur : synchronisation...";
	const int nHeure = ZckQuTexte(p2DRender, xGauche, rect.top + 27, str, ZCK_QU_GRIS, (xDroite - xGauche) / 2, 0);

	// Compteurs, de droite a gauche, tant qu'ils ne touchent pas le titre.
	if (pMng->EstActif() && g_pPlayer)
	{
		CString astr[3];
		DWORD adw[3];
		astr[0].Format("Accomplies %d", m_anCompte[ZCK_QU_ONGLET_ACCOMPLIES]);
		adw[0] = ZCK_QU_ACCOMPLIE;
		astr[1].Format("\300 r\351cup\351rer %d", m_anCompte[ZCK_QU_ONGLET_A_RECUPERER]);
		adw[1] = (m_anCompte[ZCK_QU_ONGLET_A_RECUPERER] > 0) ? ZCK_QU_A_RECUPERER : ZCK_QU_GRIS;
		astr[2].Format("En cours %d / %d", m_anCompte[ZCK_QU_ONGLET_EN_COURS], pMng->GetActivesMax());
		adw[2] = (m_anCompte[ZCK_QU_ONGLET_EN_COURS] >= pMng->GetActivesMax()) ? ZCK_QU_ORANGE : ZCK_QU_BLEU;
		int x = xDroite;
		for (int i = 0; i < 3; ++i)
		{
			const int nLargeur = ZckQuLargeur(p2DRender, astr[i]);
			if (x - nLargeur < xGauche + nTitre + 16)
				break;
			ZckQuTexte(p2DRender, x, rect.top + 7, astr[i], adw[i], nLargeur + 1, 2);
			x -= nLargeur + 18;
		}

		if (!g_pPlayer->m_ZckQuest.IsBaseOk())
		{
			const LPCTSTR lpszAlerte = "Base de donn\351es non \340 jour : qu\352tes refus\351es";
			ZckQuTexte(p2DRender, xDroite, rect.top + 27, lpszAlerte, ZCK_QU_ROUGE, xDroite - xGauche - nHeure - 16, 2);
		}
	}

	const BOOL bSuivi = g_Option.m_bZckQueteSuivi;
	ZckQuBouton(p2DRender, rectSuivi, bSuivi ? "Suivi : affich\351" : "Suivi : masqu\351", bSuivi ? ZCK_QU_BOUTON_OR : ZCK_QU_BOUTON_NEUTRE, rectSuivi.PtInRect(m_ptSurvol));
	ZckQuBouton(p2DRender, rectAgrandir, EstAgrandie() ? "Restaurer" : "Agrandir", ZCK_QU_BOUTON_NEUTRE, rectAgrandir.PtInRect(m_ptSurvol));
}

// Un onglet par regroupement de statuts : libelle et compteur.
void CWndZckQuest::DessinerOnglets(C2DRender* p2DRender)
{
	for (int nOnglet = 0; nOnglet < ZCK_QU_NB_ONGLETS; ++nOnglet)
	{
		const CRect rect = RectOnglet(nOnglet);
		const BOOL bCourant = (nOnglet == m_nOnglet);
		const BOOL bSurvol = rect.PtInRect(m_ptSurvol);
		DWORD dwTexte = ZCK_QU_GRIS;
		if (bCourant)
		{
			p2DRender->RenderFillRect(rect, 0xFF7A6224, 0xFF7A6224, 0xFF3E3010, 0xFF3E3010);
			p2DRender->RenderRoundRect(rect, ZCK_QU_SELECTION);
			dwTexte = ZCK_QU_BLANC;
		}
		else if (bSurvol)
		{
			p2DRender->RenderFillRect(rect, 0xB0303848);
			p2DRender->RenderRoundRect(rect, ZCK_QU_SURVOL);
			dwTexte = ZCK_QU_OR;
		}
		else
		{
			p2DRender->RenderFillRect(rect, 0xA0202020);
			p2DRender->RenderRoundRect(rect, 0xFF606060);
		}

		// Compteur a droite ; recompenses en attente : pastille doree.
		CString strCompte;
		strCompte.Format("%d", m_anCompte[nOnglet]);
		const int yTexte = rect.top + (rect.Height() - ZckQuHauteur(p2DRender)) / 2;
		int xDroite = rect.right - 8;
		if (nOnglet == ZCK_QU_ONGLET_A_RECUPERER && m_anCompte[nOnglet] > 0)
		{
			const int nPastille = ZckQuLargeur(p2DRender, strCompte) + 10;
			const CRect rectDispo(xDroite - nPastille, rect.top + 5, xDroite, rect.bottom - 5);
			const DWORD dwAlpha = 0x30 + ZckQuPulsation(10);
			CRect rectHalo = rectDispo;
			rectHalo.InflateRect(1, 1);
			p2DRender->RenderRoundRect(rectHalo, (dwAlpha << 24) | (ZCK_QU_A_RECUPERER & 0x00FFFFFF));
			p2DRender->RenderFillRect(rectDispo, 0xFFD8A63B, 0xFFD8A63B, 0xFF8A6418, 0xFF8A6418);
			ZckQuTexteCentre(p2DRender, rectDispo, strCompte, ZCK_QU_BLANC);
			xDroite = rectDispo.left - 6;
		}
		else
			xDroite -= ZckQuTexte(p2DRender, xDroite, yTexte, strCompte, (m_anCompte[nOnglet] > 0) ? ZCK_QU_TEXTE : ZCK_QU_GRIS_FONCE, rect.Width() / 3, 2) + 6;

		ZckQuPolice police(p2DRender, CWndBase::m_Theme.m_pFontWndTitle);
		const int yTitre = rect.top + (rect.Height() - ZckQuHauteur(p2DRender)) / 2;
		ZckQuTexte(p2DRender, rect.left + 10, yTitre, s_apszZckQuOnglets[nOnglet], dwTexte, xDroite - rect.left - 14, 0);
	}
}

// Liste de l'onglet : statut, nom, horaire, information du moment.
void CWndZckQuest::DessinerListe(C2DRender* p2DRender)
{
	const CRect rectListe = RectListe();
	CString strTitre;
	strTitre.Format("%s  \267  %d", s_apszZckQuOnglets[m_nOnglet], (int)m_vecList.size());
	ZckQuCarte(p2DRender, rectListe, strTitre, ZCK_QU_OR, ZCK_QU_CADRE);

	if (m_vecList.empty())
	{
		const CRect rectCorps(rectListe.left, rectListe.top + ZCK_QU_TITRE_H, rectListe.right, rectListe.bottom);
		ZckQuTexteCentre(p2DRender, rectCorps, "Aucune qu\352te dans cet onglet", ZCK_QU_GRIS);
		return;
	}

	CZckQuestManager* pMng = CZckQuestManager::GetInstance();
	const __int64 n64 = ZckQuMaintenant();
	const int nHauteur = ZckQuHauteur(p2DRender);
	const int nRows = GetVisibleRows();
	for (int i = m_nScroll; i < (int)m_vecList.size() && i < m_nScroll + nRows; ++i)
	{
		const ZCK_QUEST_DEFINITION* pDef = pMng->GetDefinition(m_vecList[i]);
		if (pDef == NULL)
			continue;
		const CRect rect = RectLigne(i);
		const BOOL bSel = (pDef->nId == m_nSelectedId);
		const BOOL bSurvol = rect.PtInRect(m_ptSurvol);
		const ZCK_QUEST_ENTREE* pEntree = ZckQuEntree(pDef->nId);
		const int nStatut = ZckQuStatut(*pDef);
		const float fRatio = ZckQuRatio(ZckQuProgression(*pDef, pEntree, nStatut), pDef->nObjectif);

		if (bSel)
		{
			p2DRender->RenderFillRect(rect, 0xFF7A6224, 0xFF7A6224, 0xFF3E3010, 0xFF3E3010);
			p2DRender->RenderRoundRect(rect, ZCK_QU_SELECTION);
		}
		else if (bSurvol)
			p2DRender->RenderFillRect(rect, 0x90203040);
		else
			p2DRender->RenderFillRect(rect, (i % 2) ? 0x38303848 : 0x38000000);

		ZckQuIcone(p2DRender, rect.left + 6, rect.top + (rect.Height() - 14) / 2, nStatut, fRatio);

		// Ligne 1 : nom, statut a droite.
		const int xTexte = rect.left + 26;
		const int nStatutL = ZckQuTexte(p2DRender, rect.right - 6, rect.top + 3, CZckQuestManager::TexteStatut(nStatut), ZckQuCouleurStatut(nStatut), rect.Width() / 3, 2);
		DWORD dwNom = ZCK_QU_TEXTE;
		if (bSel)
			dwNom = ZCK_QU_BLANC;
		else if (nStatut == ZCK_QUEST_STATUT_TERMINEE)
			dwNom = ZCK_QU_A_RECUPERER;
		else if (nStatut == ZCK_QUEST_STATUT_FERMEE || nStatut == ZCK_QUEST_STATUT_VERROUILLEE)
			dwNom = ZCK_QU_GRIS;
		const int nNomL = rect.right - 6 - nStatutL - 8 - xTexte;
		ZckQuTexte(p2DRender, xTexte, rect.top + 3, pDef->strNom, dwNom, nNomL, 0);

		// Ligne 2 : horaire, information du moment a droite.
		CString strInfo;
		DWORD dwInfo = ZCK_QU_GRIS;
		ZckQuInfoCourte(*pDef, pEntree, nStatut, n64, strInfo, dwInfo);
		const int yLigne2 = rect.top + 5 + nHauteur;
		const int nInfoL = ZckQuTexte(p2DRender, rect.right - 6, yLigne2, strInfo, dwInfo, rect.Width() / 2, 2);
		ZckQuTexte(p2DRender, xTexte, yLigne2, ZckQuHoraire(*pDef), ZCK_QU_GRIS, rect.right - 6 - nInfoL - 8 - xTexte, 0);

		if (nStatut == ZCK_QUEST_STATUT_EN_COURS || nStatut == ZCK_QUEST_STATUT_TERMINEE)
			ZckQuBarre(p2DRender, CRect(xTexte, rect.bottom - 4, rect.right - 6, rect.bottom - 1), fRatio, nStatut == ZCK_QUEST_STATUT_TERMINEE);

		if (ZckQuDepasse(p2DRender, pDef->strNom, nNomL))
			AjouterBulle(rect, pDef->strNom, pDef->strDescription.IsEmpty() ? (LPCTSTR)ZckQuHoraire(*pDef) : (LPCTSTR)pDef->strDescription);
	}

	// Barre de defilement : seulement si la liste deborde.
	const int nTotal = (int)m_vecList.size();
	if (nTotal > nRows)
	{
		const CRect rectPiste = RectPiste();
		p2DRender->RenderFillRect(rectPiste, 0x60FFFFFF);
		int nPouce = rectPiste.Height() * nRows / nTotal;
		if (nPouce < 16)
			nPouce = 16;
		const int y = rectPiste.top + (rectPiste.Height() - nPouce) * m_nScroll / (nTotal - nRows);
		p2DRender->RenderFillRect(CRect(rectPiste.left, y, rectPiste.right, y + nPouce), ZCK_QU_OR);
	}
}

// Quete detaillee : en-tete, description, conditions, objectif.
void CWndZckQuest::DessinerDetail(C2DRender* p2DRender)
{
	const CRect rect = RectDetail();
	const int yMax = RectRecompenses().top - ZCK_QU_ECART;
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	if (pDef == NULL)
	{
		const CRect rectVide(rect.left, rect.top, rect.right, yMax);
		ZckQuCarte(p2DRender, rectVide, "D\351tail", ZCK_QU_OR, ZCK_QU_CADRE);
		const CRect rectCorps(rectVide.left, rectVide.top + ZCK_QU_TITRE_H, rectVide.right, rectVide.bottom);
		ZckQuTexteCentre(p2DRender, rectCorps, "Aucune qu\352te s\351lectionn\351e", ZCK_QU_GRIS);
		return;
	}

	const int nStatut = ZckQuStatut(*pDef);
	const DWORD dwStatut = ZckQuCouleurStatut(nStatut);
	const int nHauteur = ZckQuHauteur(p2DRender);
	const int x0 = rect.left + 10;
	const int x1 = rect.right - 10;

	// En-tete : nom, categorie et lieu, statut.
	const CRect rectTete(rect.left, rect.top, rect.right, rect.top + ZCK_QU_TETE_H);
	if (nStatut == ZCK_QUEST_STATUT_TERMINEE)
		ZckQuHalo(p2DRender, rectTete, ZCK_QU_A_RECUPERER);
	p2DRender->RenderFillRect(rectTete, 0xC0201438, 0xC0101828, 0xA0080410, 0xA0080C14);
	p2DRender->RenderRoundRect(rectTete, (nStatut == ZCK_QUEST_STATUT_FERMEE) ? ZCK_QU_CADRE : ((0xC0000000) | (dwStatut & 0x00FFFFFF)));
	{
		ZckQuPolice police(p2DRender, CWndBase::m_Theme.m_pFontCaption);
		ZckQuTexte(p2DRender, x0, rectTete.top + 5, pDef->strNom, (nStatut == ZCK_QUEST_STATUT_ACCOMPLIE) ? ZCK_QU_ACCOMPLIE : ZCK_QU_OR, x1 - x0, 0);
		if (ZckQuDepasse(p2DRender, pDef->strNom, x1 - x0))
			AjouterBulle(CRect(rectTete.left, rectTete.top, rectTete.right, rectTete.top + 28), pDef->strNom, pDef->strDescription);
	}
	const LPCTSTR lpszStatut = CZckQuestManager::TexteStatut(nStatut);
	const int nStatutL = ZckQuLargeur(p2DRender, lpszStatut) + 16;
	const CRect rectStatut(x1 - nStatutL, rectTete.top + 30, x1, rectTete.top + 30 + nHauteur + 4);
	ZckQuPilule(p2DRender, rectStatut, lpszStatut, dwStatut);
	CString strSous;
	strSous.Format("%s  \267  %s", (LPCTSTR)pDef->strCategorie, (LPCTSTR)ZckQuLieu(*pDef));
	const int nSousL = rectStatut.left - 8 - x0;
	ZckQuTexte(p2DRender, x0, rectTete.top + 32, strSous, ZCK_QU_GRIS, nSousL, 0);
	if (ZckQuDepasse(p2DRender, strSous, nSousL))
		AjouterBulle(CRect(x0, rectTete.top + 30, rectStatut.left, rectTete.bottom), "Cat\351gorie et lieu", strSous);

	int y = rectTete.bottom + ZCK_QU_ECART;

	// Description : autant de lignes que la place le permet (3 au plus), la
	// suite en infobulle ; conditions et objectif gardent leur place.
	const int nReserve = (ZCK_QU_TITRE_H + 2 * ZCK_QU_CONDITION_H + 8) + ZCK_QU_ECART + ZCK_QU_OBJECTIF_H_MIN + ZCK_QU_ECART;
	int nLignesMax = (yMax - y - nReserve - 10) / (nHauteur + 2);
	if (nLignesMax > ZCK_QU_DESC_LIGNES)
		nLignesMax = ZCK_QU_DESC_LIGNES;
	if (!pDef->strDescription.IsEmpty() && nLignesMax >= 1)
	{
		vector<CString> vecLignes;
		const BOOL bComplete = ZckQuDecouper(p2DRender, pDef->strDescription, x1 - x0, nLignesMax, vecLignes);
		const int nDescH = (int)vecLignes.size() * (nHauteur + 2) + 10;
		const CRect rectDesc(rect.left, y, rect.right, y + nDescH);
		p2DRender->RenderFillRect(rectDesc, 0x70000000);
		p2DRender->RenderRoundRect(rectDesc, 0x60C8A040);
		for (int i = 0; i < (int)vecLignes.size(); ++i)
			ZckQuTexte(p2DRender, x0, y + 5 + i * (nHauteur + 2), vecLignes[i], ZCK_QU_TEXTE, x1 - x0, 0);
		if (!bComplete)
			AjouterBulle(rectDesc, pDef->strNom, pDef->strDescription);
		y = rectDesc.bottom + ZCK_QU_ECART;
	}
	else if (!pDef->strDescription.IsEmpty())
		AjouterBulle(rectTete, pDef->strNom, pDef->strDescription);

	y = DessinerConditions(p2DRender, *pDef, y, yMax - ZCK_QU_OBJECTIF_H_MIN - ZCK_QU_ECART);
	DessinerObjectif(p2DRender, *pDef, y, yMax);
}

// Conditions : horaire, jours, duree, niveau, prestige, groupe, puis le lieu
// sur toute la largeur. Renvoie le haut du panneau suivant.
int CWndZckQuest::DessinerConditions(C2DRender* p2DRender, const ZCK_QUEST_DEFINITION& def, int y, int yMax)
{
	struct CONDITION
	{
		CString strLibelle;
		CString strValeur;
		DWORD dwCouleur;
		int nEtat;			// -1 : sans pastille, 0 : non remplie, 1 : remplie
	};
	vector<CONDITION> vec;
	CONDITION c;

	c.strLibelle = "Horaire";
	c.strValeur = ZckQuHoraire(def);
	c.dwCouleur = ZCK_QU_BLANC;
	c.nEtat = -1;
	vec.push_back(c);

	c.strLibelle = "Jours";
	c.strValeur = ZckQuJours(def.byJours);
	vec.push_back(c);

	c.strLibelle = "Dur\351e";
	c.strValeur = ZckQuDureeQuete(def);
	vec.push_back(c);

	const int nNiveau = ZckQuNiveau();
	c.strLibelle = "Niveau";
	c.strValeur = ZckQuBornes(def.nNiveauMin, def.nNiveauMax, 1, ZckQuNiveauJeu());
	c.nEtat = (nNiveau >= def.nNiveauMin && nNiveau <= def.nNiveauMax) ? 1 : 0;
	c.dwCouleur = c.nEtat ? ZCK_QU_BLANC : ZCK_QU_ROUGE;
	vec.push_back(c);

#ifdef __ZCK_PRESTIGE
	const int nPrestige = ZckQuPrestige();
	c.strLibelle = "Prestige";
	c.strValeur = ZckQuBornes(def.nPrestigeMin, def.nPrestigeMax, 0, ZckQuPrestigeJeu());
	c.nEtat = (nPrestige >= def.nPrestigeMin && nPrestige <= def.nPrestigeMax) ? 1 : 0;
	c.dwCouleur = c.nEtat ? ZCK_QU_BLANC : ZCK_QU_ROUGE;
	vec.push_back(c);
#endif // __ZCK_PRESTIGE

	c.strLibelle = "Groupe";
	c.strValeur = def.bGroupe ? "Partag\351e (64 m)" : "Individuelle";
	c.dwCouleur = def.bGroupe ? ZCK_QU_BLEU : ZCK_QU_BLANC;
	c.nEtat = -1;
	vec.push_back(c);

	const CRect rectDetail = RectDetail();
	const int nColonnes = (rectDetail.Width() >= 560) ? 3 : 2;
	const int nRangeesGrille = ((int)vec.size() + nColonnes - 1) / nColonnes;
	const int nRangees = nRangeesGrille + 1;	// + lieu
	int nPossibles = (yMax - y - ZCK_QU_TITRE_H - 8) / ZCK_QU_CONDITION_H;
	if (nPossibles > nRangees)
		nPossibles = nRangees;
	if (nPossibles < 1)
		return y;

	const CRect rect(rectDetail.left, y, rectDetail.right, y + ZCK_QU_TITRE_H + 4 + nPossibles * ZCK_QU_CONDITION_H + 4);
	ZckQuCarte(p2DRender, rect, "Conditions", ZCK_QU_OR, ZCK_QU_CADRE);

	// Tout le contenu en infobulle sur le titre (rangees coupees comprises).
	CString strTout;
	for (size_t i = 0; i < vec.size(); ++i)
		strTout += vec[i].strLibelle + " : " + vec[i].strValeur + "\n";
	strTout += "Lieu : " + ZckQuLieu(def);
	AjouterBulle(CRect(rect.left, rect.top, rect.right, rect.top + ZCK_QU_TITRE_H), "Conditions", strTout);

	const int nHauteur = ZckQuHauteur(p2DRender);
	const int x0 = rect.left + 8;
	const int nLargeurCellule = (rect.Width() - 16 - (nColonnes - 1) * 12) / nColonnes;
	const int yGrille = rect.top + ZCK_QU_TITRE_H + 4;
	for (int i = 0; i < (int)vec.size(); ++i)
	{
		const int nRangee = i / nColonnes;
		if (nRangee >= nPossibles)
			break;
		const int xCellule = x0 + (i % nColonnes) * (nLargeurCellule + 12);
		const int yCellule = yGrille + nRangee * ZCK_QU_CONDITION_H;
		const int yTexte = yCellule + (ZCK_QU_CONDITION_H - nHauteur) / 2;
		const int nLibelle = ZckQuTexte(p2DRender, xCellule, yTexte, vec[i].strLibelle, ZCK_QU_GRIS, nLargeurCellule / 2, 0);
		int xValeur = xCellule + nLargeurCellule;
		if (vec[i].nEtat >= 0)
		{
			ZckQuPastille(p2DRender, xValeur - 14, yCellule + (ZCK_QU_CONDITION_H - 14) / 2, vec[i].nEtat != 0);
			xValeur -= 20;
		}
		const int nValeurMax = xValeur - xCellule - nLibelle - 8;
		ZckQuTexte(p2DRender, xValeur, yTexte, vec[i].strValeur, vec[i].dwCouleur, nValeurMax, 2);
		if (ZckQuDepasse(p2DRender, vec[i].strValeur, nValeurMax))
			AjouterBulle(CRect(xCellule, yCellule, xCellule + nLargeurCellule, yCellule + ZCK_QU_CONDITION_H), vec[i].strLibelle, vec[i].strValeur);
	}

	// Lieu : derniere rangee, toute la largeur.
	if (nRangeesGrille < nPossibles)
	{
		const int yCellule = yGrille + nRangeesGrille * ZCK_QU_CONDITION_H;
		const int yTexte = yCellule + (ZCK_QU_CONDITION_H - nHauteur) / 2;
		const CString strLieu = ZckQuLieu(def);
		const int nLibelle = ZckQuTexte(p2DRender, x0, yTexte, "Lieu", ZCK_QU_GRIS, rect.Width() / 3, 0);
		const int nValeurMax = rect.Width() - 16 - nLibelle - 8;
		ZckQuTexte(p2DRender, rect.right - 8, yTexte, strLieu, def.vecMondes.empty() ? ZCK_QU_BLANC : ZCK_QU_BLEU, nValeurMax, 2);
		if (ZckQuDepasse(p2DRender, strLieu, nValeurMax))
			AjouterBulle(CRect(rect.left, yCellule, rect.right, yCellule + ZCK_QU_CONDITION_H), "Lieu", strLieu);
	}
	return rect.bottom + ZCK_QU_ECART;
}

// Objectif : progression, temps, monstres qui comptent (clic : apercu).
int CWndZckQuest::DessinerObjectif(C2DRender* p2DRender, const ZCK_QUEST_DEFINITION& def, int y, int yMax)
{
	const CRect rectDetail = RectDetail();
	if (yMax - y < ZCK_QU_TITRE_H + 40)
		return y;
	const CRect rect(rectDetail.left, y, rectDetail.right, yMax);
	CString str;
	str.Format("Objectif : vaincre %s monstre%s", (LPCTSTR)Separator(def.nObjectif, '.'), (def.nObjectif > 1) ? "s" : "");
	ZckQuCarte(p2DRender, rect, str, ZCK_QU_OR, ZCK_QU_CADRE);

	const ZCK_QUEST_ENTREE* pEntree = ZckQuEntree(def.nId);
	const int nStatut = ZckQuStatut(def);
	const int nProgression = ZckQuProgression(def, pEntree, nStatut);
	const BOOL bAtteint = (nStatut == ZCK_QUEST_STATUT_TERMINEE || nStatut == ZCK_QUEST_STATUT_ACCOMPLIE);
	const int nHauteur = ZckQuHauteur(p2DRender);
	const int x0 = rect.left + 10;
	const int x1 = rect.right - 10;
	int yy = rect.top + ZCK_QU_TITRE_H + 6;

	// Progression.
	ZckQuTexte(p2DRender, x0, yy + 2, "Monstres vaincus", ZCK_QU_GRIS, (x1 - x0) / 2, 0);
	str.Format("%s / %s", (LPCTSTR)Separator(nProgression, '.'), (LPCTSTR)Separator(def.nObjectif, '.'));
	{
		ZckQuPolice police(p2DRender, CWndBase::m_Theme.m_pFontWndTitle);
		ZckQuTexte(p2DRender, x1, yy, str, bAtteint ? ZCK_QU_A_RECUPERER : ZCK_QU_BLANC, (x1 - x0) / 2, 2);
		yy += ZckQuHauteur(p2DRender) + 4;
	}
	if (yy + 10 > rect.bottom - 4)
		return rect.bottom + ZCK_QU_ECART;
	ZckQuBarre(p2DRender, CRect(x0, yy, x1, yy + 10), ZckQuRatio(nProgression, def.nObjectif), bAtteint);
	yy += 10 + 6;

	// Temps.
	if (yy + nHauteur <= rect.bottom - 4)
	{
		CString strLibelle;
		CString strValeur;
		DWORD dwCouleur = ZCK_QU_BLANC;
		ZckQuInfoTemps(def, pEntree, nStatut, ZckQuMaintenant(), strLibelle, strValeur, dwCouleur);
		const int nLibelle = ZckQuTexte(p2DRender, x0, yy, strLibelle, ZCK_QU_GRIS, (x1 - x0) / 2, 0);
		const int nValeurMax = x1 - x0 - nLibelle - 10;
		ZckQuTexte(p2DRender, x1, yy, strValeur, dwCouleur, nValeurMax, 2);
		if (ZckQuDepasse(p2DRender, strValeur, nValeurMax))
			AjouterBulle(CRect(x0, yy, x1, yy + nHauteur), strLibelle, strValeur);
		yy += nHauteur + 8;
	}

	// Monstres : pastilles cliquables, sur autant de lignes que la place le
	// permet ; la liste complete est dans l'infobulle de l'etiquette.
	if (yy + ZCK_QU_PUCE_H > rect.bottom - 4)
		return rect.bottom + ZCK_QU_ECART;
	const int nNombre = (int)def.vecMonstres.size();
	CString strListe;
	for (int i = 0; i < nNombre; ++i)
	{
		MoverProp* pProp = ZckQuMoverProp(def.vecMonstres[i]);
		CString strMonstre;
		if (pProp)
			strMonstre.Format("%s (niveau %u)", pProp->szName, (unsigned int)pProp->dwLevel);
		else
			strMonstre.Format("Monstre %u", (unsigned int)def.vecMonstres[i]);
		if (!strListe.IsEmpty())
			strListe += "\n";
		strListe += strMonstre;
	}
	str.Format("Monstres (%d) :", nNombre);
	const int nEtiquette = ZckQuTexte(p2DRender, x0, yy + (ZCK_QU_PUCE_H - nHauteur) / 2, str, ZCK_QU_GRIS, (x1 - x0) / 3, 0);
	AjouterBulle(CRect(x0, yy, x0 + nEtiquette, yy + ZCK_QU_PUCE_H), "Monstres qui comptent", strListe);
	const int xDebut = x0 + nEtiquette + 8;
	int x = xDebut;
	int yLigne = yy;
	for (int i = 0; i < nNombre; ++i)
	{
		MoverProp* pProp = ZckQuMoverProp(def.vecMonstres[i]);
		CString strPuce;
		if (pProp)
			strPuce.Format("%s  (niv. %u)", pProp->szName, (unsigned int)pProp->dwLevel);
		else
			strPuce.Format("Monstre %u", (unsigned int)def.vecMonstres[i]);
		int nLargeur = ZckQuLargeur(p2DRender, strPuce) + 16;
		if (nLargeur > x1 - xDebut)
			nLargeur = x1 - xDebut;
		if (nLargeur <= 8)
			break;
		if (x + nLargeur > x1 && x > xDebut)
		{
			x = xDebut;
			yLigne += ZCK_QU_PUCE_H + 4;
		}
		if (yLigne + ZCK_QU_PUCE_H > rect.bottom - 4)
			break;

		const CRect rectPuce(x, yLigne, x + nLargeur, yLigne + ZCK_QU_PUCE_H);
		const BOOL bVu = (i == m_nViewMonster);
		const BOOL bSurvol = rectPuce.PtInRect(m_ptSurvol);
		if (bVu)
		{
			p2DRender->RenderFillRect(rectPuce, 0xFF7A6224, 0xFF7A6224, 0xFF3E3010, 0xFF3E3010);
			p2DRender->RenderRoundRect(rectPuce, ZCK_QU_SELECTION);
		}
		else
		{
			p2DRender->RenderFillRect(rectPuce, bSurvol ? 0xB0303848 : 0x90202028);
			p2DRender->RenderRoundRect(rectPuce, bSurvol ? ZCK_QU_SURVOL : 0xFF707080);
		}
		ZckQuTexteCentre(p2DRender, rectPuce, strPuce, bVu ? ZCK_QU_BLANC : (pProp ? ZckQuCouleurNiveau((int)pProp->dwLevel) : ZCK_QU_GRIS));
		if (m_nZonesMonstres < ZCK_QU_MONSTRES_ZONES_MAX)
		{
			m_arectMonstre[m_nZonesMonstres] = rectPuce;
			m_anMonstre[m_nZonesMonstres] = i;
			++m_nZonesMonstres;
		}
		AjouterBulle(rectPuce, pProp ? pProp->szName : "?", "Clic : afficher ce monstre dans l'aper\347u.");
		x = rectPuce.right + 6;
	}
	return rect.bottom + ZCK_QU_ECART;
}

// Recompenses : objets et buffs (infobulle d'objet), Penya, EXP.
void CWndZckQuest::DessinerRecompenses(C2DRender* p2DRender)
{
	const CRect rect = RectRecompenses();
	ZckQuCarte(p2DRender, rect, "R\351compenses", ZCK_QU_OR, ZCK_QU_CADRE);
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	if (pDef == NULL)
		return;

	const BOOL bRecue = (ZckQuStatut(*pDef) == ZCK_QUEST_STATUT_ACCOMPLIE);
	const int nHauteur = ZckQuHauteur(p2DRender);
	const int x0 = rect.left + 8;
	const int x1 = rect.right - 8;
	int y = rect.top + ZCK_QU_TITRE_H + 6;
	CString str;

	// Emplacements : objets puis buffs (cadre violet), grises une fois recus.
	const int nObjets = (int)pDef->vecObjets.size();
	const int nTotal = nObjets + (int)pDef->vecBuffs.size();
	if (nTotal > 0 && y + ZCK_QU_SLOT <= rect.bottom - 2)
	{
		const int nPlaces = (x1 - x0 + 6) / (ZCK_QU_SLOT + 6);
		const int nMontres = (nTotal > nPlaces) ? nPlaces - 1 : nTotal;
		for (int i = 0; i < nMontres; ++i)
		{
			const CRect rectSlot = RectSlot(i);
			const BOOL bBuff = (i >= nObjets);
			const DWORD dwItemId = bBuff ? pDef->vecBuffs[i - nObjets] : pDef->vecObjets[i].dwItemId;
			const BOOL bSurvol = rectSlot.PtInRect(m_ptSurvol);
			p2DRender->RenderFillRect(rectSlot, 0xFF1A1426, 0xFF1A1426, 0xFF0A0810, 0xFF0A0810);
			p2DRender->RenderRoundRect(rectSlot, bSurvol ? ZCK_QU_SELECTION : (bBuff ? ZCK_QU_VIOLET : 0xFF907030));
			const int nMarge = (ZCK_QU_SLOT - ZCK_QU_ICONE) / 2;
			ZckQuRendreTaille(p2DRender, ZckQuIconeItem(dwItemId), CPoint(rectSlot.left + nMarge, rectSlot.top + nMarge), ZCK_QU_ICONE, bRecue);
			if (bBuff)
				p2DRender->RenderFillTriangle(CPoint(rectSlot.left + 1, rectSlot.top + 1), CPoint(rectSlot.left + 11, rectSlot.top + 1), CPoint(rectSlot.left + 1, rectSlot.top + 11), ZCK_QU_VIOLET);
			else if (pDef->vecObjets[i].nNombre > 1)
			{
				str.Format("%d", pDef->vecObjets[i].nNombre);
				ZckQuTexte(p2DRender, rectSlot.right - 2, rectSlot.bottom - nHauteur - 1, str, ZCK_QU_BLANC, ZCK_QU_SLOT - 4, 2);
			}
		}
		if (nMontres < nTotal && nMontres >= 0)
		{
			const CRect rectReste = RectSlot(nMontres);
			CString strListe;
			for (int i = nMontres; i < nTotal; ++i)
			{
				if (!strListe.IsEmpty())
					strListe += "\n";
				if (i < nObjets)
				{
					str.Format("%s x%d", ZckQuNomItem(pDef->vecObjets[i].dwItemId), pDef->vecObjets[i].nNombre);
					strListe += str;
				}
				else
				{
					str.Format("Buff : %s", ZckQuNomItem(pDef->vecBuffs[i - nObjets]));
					strListe += str;
				}
			}
			p2DRender->RenderFillRect(rectReste, 0xFF1A1426, 0xFF1A1426, 0xFF0A0810, 0xFF0A0810);
			p2DRender->RenderRoundRect(rectReste, 0xFF907030);
			str.Format("+%d", nTotal - nMontres);
			ZckQuTexteCentre(p2DRender, rectReste, str, ZCK_QU_OR);
			AjouterBulle(rectReste, "Autres r\351compenses", strListe);
		}
		y += ZCK_QU_SLOT + 6;
	}

	// Lignes : libelle a gauche, valeur a droite.
	const int nPenya = pDef->nPenya;
	const __int64 n64Exp = CZckQuestManager::ExpRecompense(*pDef, ZckQuNiveau());
	if (nTotal == 0 && nPenya <= 0 && pDef->n64Exp <= 0 && pDef->nExpPourcent <= 0)
	{
		ZckQuTexte(p2DRender, x0, y + 2, "Aucune r\351compense configur\351e.", ZCK_QU_GRIS, x1 - x0, 0);
		return;
	}
	if (nPenya > 0 && y + ZCK_QU_RECOMPENSE_H <= rect.bottom - 2)
	{
		const CRect rectLigne(rect.left + 4, y, rect.right - 4, y + ZCK_QU_RECOMPENSE_H);
		p2DRender->RenderFillRect(rectLigne, 0x38000000);
		const int yTexte = y + (ZCK_QU_RECOMPENSE_H - nHauteur) / 2;
		const int nLibelle = ZckQuTexte(p2DRender, x0, yTexte, "Penya", ZCK_QU_GRIS, (x1 - x0) / 3, 0);
		ZckQuTexte(p2DRender, x1, yTexte, Separator((__int64)nPenya, '.'), bRecue ? ZCK_QU_GRIS : ZCK_QU_OR, x1 - x0 - nLibelle - 8, 2);
		y += ZCK_QU_RECOMPENSE_H;
	}
	if ((pDef->n64Exp > 0 || pDef->nExpPourcent > 0) && y + ZCK_QU_RECOMPENSE_H <= rect.bottom - 2)
	{
		const CRect rectLigne(rect.left + 4, y, rect.right - 4, y + ZCK_QU_RECOMPENSE_H);
		p2DRender->RenderFillRect(rectLigne, 0x38303848);
		const int yTexte = y + (ZCK_QU_RECOMPENSE_H - nHauteur) / 2;
		const int nLibelle = ZckQuTexte(p2DRender, x0, yTexte, "EXP", ZCK_QU_GRIS, (x1 - x0) / 3, 0);
		ZckQuTexte(p2DRender, x1, yTexte, Separator(n64Exp, '.'), bRecue ? ZCK_QU_GRIS : ZCK_QU_BLEU, x1 - x0 - nLibelle - 8, 2);
		CString strBulle;
		if (pDef->nExpPourcent > 0)
			strBulle.Format("EXP fixe : %s\nPlus %d %% de l'EXP de votre niveau actuel (%d), calcul\351 par le serveur \340 la r\351cup\351ration.", (LPCTSTR)Separator(pDef->n64Exp, '.'), pDef->nExpPourcent, ZckQuNiveau());
		else
			strBulle.Format("EXP fixe : %s", (LPCTSTR)Separator(pDef->n64Exp, '.'));
		AjouterBulle(rectLigne, "EXP", strBulle);
	}
}

// Apercu : monstre en 3D (glisser : tourner, molette : zoom), nom et niveau.
void CWndZckQuest::DessinerApercu(C2DRender* p2DRender)
{
	const CRect rect = RectApercu();
	const CRect rectVue = RectVue();
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	CString str;
	if (pDef && pDef->vecMonstres.size() > 1)
		str.Format("Monstre %d / %d", m_nViewMonster + 1, (int)pDef->vecMonstres.size());
	else
		str = "Aper\347u du monstre";
	ZckQuCarte(p2DRender, rect, str, ZCK_QU_OR, ZCK_QU_CADRE);

	if (rectVue.Height() <= 8 || rectVue.Width() <= 8)
		return;
	p2DRender->RenderFillRect(rectVue, 0xA0080808);
	p2DRender->RenderFillRect(rectVue, 0x00000000, 0x00000000, 0x40C8A040, 0x40C8A040);
	p2DRender->RenderRoundRect(rectVue, rectVue.PtInRect(m_ptSurvol) ? 0xFF807040 : 0xFF404040);
	if (pDef == NULL)
		return;

	const DWORD dwMonsterId = GetViewMonsterId();
	MoverProp* pProp = ZckQuMoverProp(dwMonsterId);
	if (pProp == NULL)
	{
		ZckQuTexteCentre(p2DRender, rectVue, "Aper\347u indisponible", ZCK_QU_GRIS);
		return;
	}
	DessinerModele(p2DRender, rectVue);

	// Fleches : monstre precedent / suivant.
	for (int nSens = -1; nSens <= 1; nSens += 2)
	{
		const CRect rectFleche = RectFleche(nSens);
		if (rectFleche.IsRectEmpty())
			continue;
		const BOOL bSurvol = rectFleche.PtInRect(m_ptSurvol);
		p2DRender->RenderFillRect(rectFleche, bSurvol ? 0xC0403010 : 0x80000000);
		p2DRender->RenderRoundRect(rectFleche, bSurvol ? ZCK_QU_SELECTION : 0xFF707070);
		const int yC = rectFleche.CenterPoint().y;
		const int xC = rectFleche.CenterPoint().x;
		if (nSens < 0)
			p2DRender->RenderFillTriangle(CPoint(xC + 4, yC - 7), CPoint(xC + 4, yC + 7), CPoint(xC - 4, yC), bSurvol ? ZCK_QU_SELECTION : ZCK_QU_TEXTE);
		else
			p2DRender->RenderFillTriangle(CPoint(xC - 4, yC - 7), CPoint(xC + 4, yC), CPoint(xC - 4, yC + 7), bSurvol ? ZCK_QU_SELECTION : ZCK_QU_TEXTE);
	}

	const int xCentre = rect.CenterPoint().x;
	const int nLargeur = rect.Width() - 12;
	{
		ZckQuPolice police(p2DRender, CWndBase::m_Theme.m_pFontWndTitle);
		ZckQuTexte(p2DRender, xCentre, rect.bottom - 36, pProp->szName, ZCK_QU_BLANC, nLargeur, 1);
	}
	str.Format("Niveau %u  \267  %s", (unsigned int)pProp->dwLevel, ZckQuNomRang(pProp->dwClass));
	ZckQuTexte(p2DRender, xCentre, rect.bottom - 17, str, ZckQuCouleurNiveau((int)pProp->dwLevel), nLargeur, 1);

	CString strBulle;
	strBulle.Format("Glisser : tourner le monstre.\nMolette : zoom (%d %%).", (int)(m_fZoom * 100.0f + 0.5f));
	if (pDef->vecMonstres.size() > 1)
		strBulle += "\nFl\350ches : monstre pr\351c\351dent ou suivant.";
	AjouterBulle(rectVue, pProp->szName, strBulle);
}

void CWndZckQuest::DessinerModele(C2DRender* p2DRender, const CRect& rectVue)
{
	CModelObject* pModel = GetMonsterModel(GetViewMonsterId());
	if (pModel == NULL || pModel->m_pModelElem == NULL || rectVue.Width() <= 2 || rectVue.Height() <= 2)
	{
		ZckQuTexteCentre(p2DRender, rectVue, "Aper\347u indisponible", ZCK_QU_GRIS);
		return;
	}

	// RenderObjectViewport ne lit que le rectangle du controle ; la vue est
	// retrecie d'un pixel pour laisser son cadre visible.
	CRect rectRendu = rectVue;
	rectRendu.DeflateRect(1, 1);
	WNDCTRL ctrlVue;
	ctrlVue.dwWndId = 0;
	ctrlVue.dwWndType = WTYPE_CUSTOM;
	ctrlVue.dwWndStyle = 0;
	ctrlVue.bTile = FALSE;
	ctrlVue.rect = rectRendu;
	ctrlVue.m_bVisible = TRUE;
	ctrlVue.m_bDisabled = FALSE;
	ctrlVue.m_bTabStop = FALSE;
	ctrlVue.m_bGroup = FALSE;

	VIEWPORT view;
	view.m_fRot = AngleVue();
	if (!ZckQuCadrer(view, pModel, rectRendu, m_fZoom))
		ZckQuCadrageOrigine(view, pModel, m_fZoom);

	pModel->SetTextureEx(pModel->m_pModelElem->m_nTextureEx);
	pModel->SetBlendFactor(255);
	g_WndMng.RenderObjectViewport(p2DRender, pModel, NULL, &ctrlVue, &view, GetWndId());
}

// Fiche du monstre montre : une ligne par information, le reste en infobulle.
void CWndZckQuest::DessinerFiche(C2DRender* p2DRender)
{
	const CRect rect = RectFiche();
	ZckQuCarte(p2DRender, rect, "Fiche du monstre", ZCK_QU_OR, ZCK_QU_CADRE);
	const DWORD dwMonsterId = GetViewMonsterId();
	MoverProp* pProp = ZckQuMoverProp(dwMonsterId);
	if (pProp == NULL)
	{
		const CRect rectCorps(rect.left, rect.top + ZCK_QU_TITRE_H, rect.right, rect.bottom);
		ZckQuTexteCentre(p2DRender, rectCorps, "Aucun monstre", ZCK_QU_GRIS);
		return;
	}

	vector<ZCK_QU_FICHE> vecFiche;
	ZckQuFiche(*pProp, vecFiche);
	const int nHauteur = ZckQuHauteur(p2DRender);
	const int x0 = rect.left + 8;
	const int x1 = rect.right - 8;
	int y = rect.top + ZCK_QU_TITRE_H + 6;
	const int nPlaces = (rect.bottom - 4 - y) / ZCK_QU_FICHE_H;
	if (nPlaces <= 0)
		return;
	const int nMontrees = ((int)vecFiche.size() > nPlaces) ? nPlaces - 1 : (int)vecFiche.size();
	for (int i = 0; i < nMontrees; ++i)
	{
		const ZCK_QU_FICHE& ligne = vecFiche[i];
		const CRect rectLigne(rect.left + 4, y, rect.right - 4, y + ZCK_QU_FICHE_H);
		p2DRender->RenderFillRect(rectLigne, (i % 2) ? 0x38303848 : 0x38000000);
		const int yTexte = y + (ZCK_QU_FICHE_H - nHauteur) / 2;
		const int nLibelle = ZckQuTexte(p2DRender, x0, yTexte, ligne.strLibelle, ZCK_QU_GRIS, (x1 - x0) * 45 / 100, 0);
		int nValeurMax = x1 - x0 - nLibelle - 8;
		const int nValeur = ZckQuTexte(p2DRender, x1, yTexte, ligne.strValeur, ligne.dwCouleur, nValeurMax, 2);
		if (ligne.nElement != SAI79::NO_PROP && x1 - nValeur - 18 > x0 + nLibelle)
			ZckQuIconeElement(p2DRender, CPoint(x1 - nValeur - 18, y + (ZCK_QU_FICHE_H - 14) / 2), ligne.nElement, 14);
		if (!ligne.strBulle.IsEmpty() || ZckQuDepasse(p2DRender, ligne.strValeur, nValeurMax))
		{
			CString strBulle = ligne.strValeur;
			if (!ligne.strBulle.IsEmpty() && ligne.strBulle != ligne.strValeur)
				strBulle += "\n" + ligne.strBulle;
			AjouterBulle(rectLigne, ligne.strLibelle, strBulle);
		}
		y += ZCK_QU_FICHE_H;
	}
	if (nMontrees < (int)vecFiche.size())
	{
		CString strListe;
		for (int i = nMontrees; i < (int)vecFiche.size(); ++i)
		{
			if (!strListe.IsEmpty())
				strListe += "\n";
			strListe += vecFiche[i].strLibelle + " : " + vecFiche[i].strValeur;
		}
		CString str;
		str.Format("... et %d autre%s (survol)", (int)vecFiche.size() - nMontrees, ((int)vecFiche.size() - nMontrees > 1) ? "s" : "");
		const CRect rectReste(rect.left + 4, y, rect.right - 4, y + ZCK_QU_FICHE_H);
		ZckQuTexte(p2DRender, x0, y + (ZCK_QU_FICHE_H - nHauteur) / 2, str, ZCK_QU_GRIS, x1 - x0, 0);
		AjouterBulle(rectReste, "Fiche du monstre", strListe);
	}
}

void CWndZckQuest::DessinerPied(C2DRender* p2DRender)
{
	const CRect rectAction = RectAction();
	const CRect rectFermer = RectFermer();
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	CZckQuestManager* pMng = CZckQuestManager::GetInstance();

	CString strBouton = "Accepter";
	CString strEtat;
	DWORD dwEtat = ZCK_QU_GRIS;
	BYTE byAction = 0;
	BOOL bActif = FALSE;
	if (!pMng->EstActif())
		strEtat = s_bZckQuIndisponible ? "Syst\350me de qu\352tes indisponible." : "Chargement des qu\352tes...";
	else if (pDef == NULL)
		strEtat = "Choisissez une qu\352te dans la liste.";
	else if (m_dwTickEnvoi != 0)
	{
		strEtat = "Demande envoy\351e, en attente du serveur...";
		strBouton = "Patientez...";
		dwEtat = ZCK_QU_ORANGE;
	}
	else
	{
		bActif = ActionPossible(*pDef, byAction, strBouton, strEtat);
		if (bActif)
			dwEtat = (m_dwTickConfirmer != 0 && m_nConfirmerId == pDef->nId) ? ZCK_QU_ORANGE : ZckQuCouleurStatut(ZckQuStatut(*pDef));
	}
	const int yEtat = rectAction.top + (rectAction.Height() - ZckQuHauteur(p2DRender)) / 2;
	ZckQuTexte(p2DRender, ZCK_QU_BORD + 4, yEtat, strEtat, dwEtat, rectAction.left - ZCK_QU_BORD - 12, 0);

	int nStyle = ZCK_QU_BOUTON_INACTIF;
	if (bActif)
	{
		if (byAction == ZCK_QUEST_ACTION_ABANDONNER)
			nStyle = (m_dwTickConfirmer != 0 && pDef && m_nConfirmerId == pDef->nId) ? ZCK_QU_BOUTON_OR : ZCK_QU_BOUTON_NEUTRE;
		else
			nStyle = ZCK_QU_BOUTON_OR;
		if (byAction == ZCK_QUEST_ACTION_RECUPERER)
			ZckQuHalo(p2DRender, rectAction, 0x00FFD040);
	}
	if (pMng->EstActif())
		ZckQuBouton(p2DRender, rectAction, strBouton, nStyle, bActif && rectAction.PtInRect(m_ptSurvol));
	ZckQuBouton(p2DRender, rectFermer, "Fermer", ZCK_QU_BOUTON_NEUTRE, rectFermer.PtInRect(m_ptSurvol));
}

//////////////////////////////////////////////////////////////////////
// Journal : traitement et entrees
//////////////////////////////////////////////////////////////////////

BOOL CWndZckQuest::Process()
{
	const DWORD dwTick = GetTickCount();

	// Pas de reponse du serveur : le bouton revient.
	if (m_dwTickEnvoi != 0 && dwTick - m_dwTickEnvoi > ZCK_QU_ATTENTE_MS)
	{
		m_dwTickEnvoi = 0;
		m_nEnvoiId = 0;
	}
	// Second clic d'Abandonner non venu : la demande de confirmation tombe.
	if (m_dwTickConfirmer != 0 && dwTick - m_dwTickConfirmer > ZCK_QU_CONFIRMER_MS)
	{
		m_dwTickConfirmer = 0;
		m_nConfirmerId = 0;
	}

	// Position enregistree hors de l'ecran (resolution changee) : ramenee une fois.
	if (!m_bPlace)
	{
		m_bPlace = TRUE;
		ZckQuGarderVisible(this, m_pWndRoot);
	}

	// Catalogue absent tant que le serveur n'a pas dit "indisponible" : redemande.
	if (!CZckQuestManager::GetInstance()->EstActif() && !s_bZckQuIndisponible)
		ZckQuDemanderCatalogue();

	if (dwTick - m_dwTickListe >= ZCK_QU_LISTE_MS)
		RebuildList();

	// Glisser dans la vue : fini des que le bouton est relache, meme ailleurs.
	if (m_bTourne && !ZckQuBoutonGauche())
		FinTourner();

	// Animation du seul modele montre, a cadence fixe.
	if (m_pMonsterModel && g_tmCurrent >= m_dwNextFrameMove)
	{
		m_pMonsterModel->FrameMove();
		m_dwNextFrameMove = g_tmCurrent + 1000 / FRAME_PER_SEC;
	}

	// Surbrillance : seulement tant que la souris est sur la fenetre elle-meme.
	if (CWndBase::m_pWndOnMouseMove != this && !m_bTourne)
		m_ptSurvol = CPoint(-1, -1);

	return CWndNeuz::Process();
}

// Appui dans la zone client : glisser dans la vue, ou futur clic (relache
// traite dans OnLButtonUp). Un relache sans appui dans la zone client (fin
// de redimensionnement par un bord) ne clique rien.
void CWndZckQuest::Appuyer(CPoint point)
{
	m_bAppui = TRUE;
	if (RectVue().PtInRect(point) && GetViewMonsterId() != NULL_ID && !RectFleche(-1).PtInRect(point) && !RectFleche(1).PtInRect(point))
	{
		m_bAppui = FALSE;
		m_fRotation = AngleVue();
		m_bRotationLibre = TRUE;
		m_bTourne = TRUE;
		m_ptTourne = point;
		SetCapture();
	}
}

void CWndZckQuest::OnLButtonDown(UINT nFlags, CPoint point)
{
	Appuyer(point);
	if (m_bTourne)
		return;
	CWndNeuz::OnLButtonDown(nFlags, point);
}

void CWndZckQuest::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// Deux clics rapides : le second arrive ici et non dans OnLButtonDown ;
	// il compte comme un appui.
	Appuyer(point);
	if (m_bTourne)
		return;
	CWndNeuz::OnLButtonDblClk(nFlags, point);
}

void CWndZckQuest::OnMouseMove(UINT nFlags, CPoint point)
{
	if (m_bTourne)
	{
		m_fRotation += (float)(point.x - m_ptTourne.x) * ZCK_QU_DEG_PAR_PIXEL;
		m_fRotation = fmodf(m_fRotation, 360.0f);
		m_ptTourne = point;
		return;
	}
	CWndNeuz::OnMouseMove(nFlags, point);
}

void CWndZckQuest::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (m_bTourne)
	{
		FinTourner();
		return;
	}
	// Clic seulement si l'appui a eu lieu dans la zone client, sans
	// deplacement ni redimensionnement en cours, et si le relache tombe dans
	// la zone client. Le point teste est GetMousePoint() (coordonnees client
	// de ce message, CWndBase::WindowProc) : CWndBase::DefWindowProc passe des
	// coordonnees fenetre quand le relache tombe sur le cadre ou la barre de
	// titre.
	const BOOL bClic = m_bAppui && !m_bPickup && m_nResizeDir == 0 && GetClientRect().PtInRect(GetMousePoint());
	m_bAppui = FALSE;
	if (!bClic)
	{
		CWndNeuz::OnLButtonUp(nFlags, point);
		return;
	}
	point = GetMousePoint();

	if (RectFermer().PtInRect(point))
	{
		Destroy();
		return;
	}
	if (RectAction().PtInRect(point))
	{
		Agir();
		CWndNeuz::OnLButtonUp(nFlags, point);
		return;
	}
	if (RectSuivi().PtInRect(point))
	{
		CWndZckQuestSuivi::Basculer();
		CWndNeuz::OnLButtonUp(nFlags, point);
		return;
	}
	if (RectAgrandir().PtInRect(point))
	{
		Agrandir();
		return;
	}

	if (CZckQuestManager::GetInstance()->EstActif())
	{
		for (int i = 0; i < ZCK_QU_NB_ONGLETS; ++i)
		{
			if (RectOnglet(i).PtInRect(point))
			{
				SelectOnglet(i);
				CWndNeuz::OnLButtonUp(nFlags, point);
				return;
			}
		}
		for (int i = m_nScroll; i < (int)m_vecList.size(); ++i)
		{
			if (RectLigne(i).PtInRect(point))
			{
				SelectIndex(i);
				CWndNeuz::OnLButtonUp(nFlags, point);
				return;
			}
		}
		for (int nSens = -1; nSens <= 1; nSens += 2)
		{
			if (RectFleche(nSens).PtInRect(point))
			{
				ChangerMonstre(nSens);
				CWndNeuz::OnLButtonUp(nFlags, point);
				return;
			}
		}
		for (int i = 0; i < m_nZonesMonstres; ++i)
		{
			if (m_arectMonstre[i].PtInRect(point))
			{
				if (m_anMonstre[i] != m_nViewMonster)
				{
					m_nViewMonster = m_anMonstre[i];
					m_bRotationLibre = FALSE;
				}
				break;
			}
		}
	}

	CWndNeuz::OnLButtonUp(nFlags, point);
}

// Molette : defilement de la liste, zoom de la vue.
BOOL CWndZckQuest::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	const CPoint ptSouris = GetMousePoint();
	if (zDelta != 0 && RectListe().PtInRect(ptSouris))
	{
		const int nMax = (int)m_vecList.size() - GetVisibleRows();
		m_nScroll += (zDelta > 0) ? -ZCK_QU_DEFILEMENT : ZCK_QU_DEFILEMENT;
		if (m_nScroll > nMax)
			m_nScroll = nMax;
		if (m_nScroll < 0)
			m_nScroll = 0;
		return TRUE;
	}
	if (zDelta != 0 && RectVue().PtInRect(ptSouris) && GetViewMonsterId() != NULL_ID)
	{
		m_fZoom *= (zDelta > 0) ? 1.1f : (1.0f / 1.1f);
		if (m_fZoom < ZCK_QU_ZOOM_MIN)
			m_fZoom = ZCK_QU_ZOOM_MIN;
		if (m_fZoom > ZCK_QU_ZOOM_MAX)
			m_fZoom = ZCK_QU_ZOOM_MAX;
		return TRUE;
	}
	return CWndNeuz::OnMouseWheel(nFlags, zDelta, pt);
}

// Fleches : haut / bas dans la liste, gauche / droite entre les onglets.
void CWndZckQuest::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	int nIndex = -1;
	for (int i = 0; i < (int)m_vecList.size(); ++i)
	{
		if (m_vecList[i] == m_nSelectedId)
		{
			nIndex = i;
			break;
		}
	}
	switch (nChar)
	{
	case VK_UP:		SelectIndex(nIndex > 0 ? nIndex - 1 : 0); return;
	case VK_DOWN:	SelectIndex(nIndex + 1 < (int)m_vecList.size() ? nIndex + 1 : nIndex); return;
	case VK_LEFT:	SelectOnglet(m_nOnglet - 1); return;
	case VK_RIGHT:	SelectOnglet(m_nOnglet + 1); return;
	default: break;
	}
	CWndNeuz::OnKeyUp(nChar, nRepCnt, nFlags);
}

void CWndZckQuest::InfoBulle(DWORD dwId, CEditString& strEdit, CRect rect, CPoint point)
{
	CPoint ptTip = point;
	ClientToScreen(&ptTip);
	ClientToScreen(&rect);
	g_toolTip.PutToolTip(dwId, strEdit, rect, ptTip, 1);
}

void CWndZckQuest::OnMouseWndSurface(CPoint point)
{
	m_ptSurvol = point;
	CString str;
	const ZCK_QUEST_DEFINITION* pDef = GetSelection();
	CZckQuestManager* pMng = CZckQuestManager::GetInstance();

	// Recompenses : infobulle d'objet (objets et buffs).
	if (pDef && pMng->EstActif())
	{
		const CRect rectRecompenses = RectRecompenses();
		const int nObjets = (int)pDef->vecObjets.size();
		const int nTotal = nObjets + (int)pDef->vecBuffs.size();
		const int nPlaces = (rectRecompenses.Width() - 16 + 6) / (ZCK_QU_SLOT + 6);
		const int nMontres = (nTotal > nPlaces) ? nPlaces - 1 : nTotal;
		for (int i = 0; i < nMontres; ++i)
		{
			CRect rectSlot = RectSlot(i);
			if (!rectSlot.PtInRect(point))
				continue;
			const BOOL bBuff = (i >= nObjets);
			const DWORD dwItemId = bBuff ? pDef->vecBuffs[i - nObjets] : pDef->vecObjets[i].dwItemId;
			if (ZckQuItemProp(dwItemId) == NULL)
				return;
			CItemElem itemElem;
			itemElem.m_dwItemId = dwItemId;
			itemElem.m_nItemNum = 1;
			if (!bBuff)
			{
				itemElem.m_nItemNum = (pDef->vecObjets[i].nNombre < SHRT_MAX) ? pDef->vecObjets[i].nNombre : SHRT_MAX;
				if (pDef->vecObjets[i].bLie)
					itemElem.SetFlag(CItemElem::binds);
			}
			CPoint pointScreen = point;
			ClientToScreen(&pointScreen);
			ClientToScreen(&rectSlot);
			g_WndMng.PutToolTip_Item(&itemElem, pointScreen, &rectSlot, GetWndId());
			return;
		}
	}

	// Onglets : contenu.
	if (pMng->EstActif())
	{
		for (int nOnglet = 0; nOnglet < ZCK_QU_NB_ONGLETS; ++nOnglet)
		{
			const CRect rect = RectOnglet(nOnglet);
			if (!rect.PtInRect(point))
				continue;
			static const char* const s_apszAides[ZCK_QU_NB_ONGLETS] =
			{
				"Toutes les qu\352tes du serveur.",
				"Qu\352tes \340 accepter maintenant (ou \340 recommencer apr\350s un \351chec).",
				"Qu\352tes accept\351es dont le temps n'est pas \351coul\351.",
				"Objectif atteint : la r\351compense attend, elle ne se perd jamais.",
				"R\351compense d\351j\340 re\347ue pour l'ouverture en cours."
			};
			CEditString strEdit;
			strEdit.AddString(s_apszZckQuOnglets[nOnglet], ZCK_QU_OR, ESSTY_BOLD);
			str.Format("\n%d qu\352te%s\n", m_anCompte[nOnglet], (m_anCompte[nOnglet] > 1) ? "s" : "");
			strEdit.AddString(str, ZCK_QU_BLANC);
			strEdit.AddString(s_apszAides[nOnglet], ZCK_QU_GRIS);
			InfoBulle(ZCK_QU_BULLE + 0x10 + nOnglet, strEdit, rect, point);
			return;
		}
	}

	// Boutons du bandeau.
	const CRect rectSuivi = RectSuivi();
	if (rectSuivi.PtInRect(point))
	{
		CEditString strEdit;
		strEdit.AddString("Suivi des qu\352tes", ZCK_QU_OR, ESSTY_BOLD);
		strEdit.AddString("\nPetite fen\352tre \340 l'\351cran : qu\352tes en cours, progression et temps restant.", ZCK_QU_BLANC);
		strEdit.AddString(g_Option.m_bZckQueteSuivi ? "\nClic : masquer le suivi." : "\nClic : afficher le suivi.", ZCK_QU_GRIS);
		strEdit.AddString("\nCommande : /quete suivi", ZCK_QU_GRIS);
		InfoBulle(ZCK_QU_BULLE + 0x20, strEdit, rectSuivi, point);
		return;
	}
	const CRect rectAgrandir = RectAgrandir();
	if (rectAgrandir.PtInRect(point))
	{
		CEditString strEdit;
		strEdit.AddString(EstAgrandie() ? "Restaurer" : "Agrandir", ZCK_QU_OR, ESSTY_BOLD);
		strEdit.AddString(EstAgrandie() ? "\nRend \340 la fen\352tre sa taille pr\351c\351dente." : "\nFen\352tre \340 la taille de l'\351cran.", ZCK_QU_BLANC);
		strEdit.AddString("\nLes bords de la fen\352tre la redimensionnent aussi.", ZCK_QU_GRIS);
		InfoBulle(ZCK_QU_BULLE + 0x21, strEdit, rectAgrandir, point);
		return;
	}

	// Bouton d'action.
	const CRect rectAction = RectAction();
	if (pDef && pMng->EstActif() && rectAction.PtInRect(point))
	{
		BYTE byAction = 0;
		CString strBouton;
		CString strRaison;
		ActionPossible(*pDef, byAction, strBouton, strRaison);
		CEditString strEdit;
		strEdit.AddString(strBouton, ZCK_QU_OR, ESSTY_BOLD);
		if (!strRaison.IsEmpty())
			strEdit.AddString("\n" + strRaison, ZCK_QU_BLANC);
		if (byAction == ZCK_QUEST_ACTION_RECUPERER)
			strEdit.AddString("\nLes objets doivent tenir dans l'inventaire.", ZCK_QU_GRIS);
		else if (byAction == ZCK_QUEST_ACTION_ABANDONNER)
			strEdit.AddString("\nDeux clics : la progression est perdue.", ZCK_QU_GRIS);
		InfoBulle(ZCK_QU_BULLE + 0x22, strEdit, rectAction, point);
		return;
	}

	// Textes tronques, reste des listes, fiche du monstre, conditions.
	for (int i = 0; i < m_nBulles; ++i)
	{
		if (!m_arectBulle[i].PtInRect(point))
			continue;
		CEditString strEdit;
		if (!m_astrBulleTitre[i].IsEmpty())
		{
			strEdit.AddString(m_astrBulleTitre[i], ZCK_QU_OR, ESSTY_BOLD);
			strEdit.AddString("\n" + m_astrBulle[i], ZCK_QU_BLANC);
		}
		else
			strEdit.AddString(m_astrBulle[i], ZCK_QU_BLANC);
		InfoBulle(ZCK_QU_BULLE + 0x100 + i, strEdit, m_arectBulle[i], point);
		return;
	}
}

//////////////////////////////////////////////////////////////////////
// Suivi a l'ecran
//////////////////////////////////////////////////////////////////////

CWndZckQuestSuivi::CWndZckQuestSuivi()
	: m_dwTickListe(0)
	, m_dwTickVide(0)
	, m_bReduit(FALSE)
	, m_nHauteurDepliee(ZCK_QU_SUIVI_H_DEFAUT)
	, m_bPlace(FALSE)
	, m_bAppui(FALSE)
	, m_ptSurvol(-1, -1)
	, m_nAlphaFond(0)
{
}

CWndZckQuestSuivi::~CWndZckQuestSuivi()
{
}

BOOL CWndZckQuestSuivi::Initialize(CWndBase* pWndParent, DWORD /*dwWndId*/)
{
	// Ouvert de lui-meme : bloc absent = journal une fois, aucun message au joueur.
	if (!ZckQuBlocPresent(APP_ZCK_QUEST_SUIVI, "APP_ZCK_QUEST_SUIVI"))
		return FALSE;
	return CWndNeuz::InitDialog(g_Neuz.GetSafeHwnd(), APP_ZCK_QUEST_SUIVI, 0, CPoint(0, 0), pWndParent);
}

void CWndZckQuestSuivi::OnInitialUpdate()
{
	CWndNeuz::OnInitialUpdate();

	m_bReduit = g_Option.m_bZckQueteSuiviReduit;
	// Premiere ouverture : a droite de l'ecran, sous le suivi des quetes
	// d'origine. Une position enregistree (regInfo.dat) la remplace ensuite.
	if (m_pWndRoot)
	{
		const CRect rectRacine = m_pWndRoot->GetLayoutRect();
		const CRect rect = GetWindowRect(TRUE);
		Move(CPoint(rectRacine.right - rect.Width() - 8, rectRacine.top + ZCK_QU_SUIVI_HAUT));
	}
	if (m_bReduit)
		SetWndRect(GetWindowRect(TRUE));
	ListerQuetes();
}

void CWndZckQuestSuivi::PaintFrame(C2DRender* /*p2DRender*/)
{
	// Ni cadre ni fond de theme : le panneau est dessine par OnDraw.
}

BOOL CWndZckQuestSuivi::OnEraseBkgnd(C2DRender* /*p2DRender*/)
{
	// Sans texture de fenetre, CWndBase::OnEraseBkgnd peindrait le fond du
	// theme : rien a effacer, comme l'icone des buffs mondiaux.
	return TRUE;
}

int CWndZckQuestSuivi::HauteurReduite() const
{
	return ZCK_QU_CADRE_H + ZCK_QU_SUIVI_TETE_H + ZCK_QU_CADRE_B;
}

// Bornes : 192 x 96 a 640 x 720, jamais plus que l'ecran ; reduit, la
// hauteur est celle de la barre de titre.
void CWndZckQuestSuivi::SetWndRect(CRect rectWnd, BOOL bOnSize)
{
	int nMaxL = ZCK_QU_SUIVI_L_MAX;
	int nMaxH = ZCK_QU_SUIVI_H_MAX;
	if (m_pWndRoot)
	{
		const CRect rectRacine = m_pWndRoot->GetLayoutRect();
		if (rectRacine.Width() < nMaxL)
			nMaxL = rectRacine.Width();
		if (rectRacine.Height() < nMaxH)
			nMaxH = rectRacine.Height();
	}
	if (nMaxL < ZCK_QU_SUIVI_L_MIN)
		nMaxL = ZCK_QU_SUIVI_L_MIN;
	if (nMaxH < ZCK_QU_SUIVI_H_MIN)
		nMaxH = ZCK_QU_SUIVI_H_MIN;

	if (m_bReduit)
	{
		AdjustMinRect(&rectWnd, ZCK_QU_SUIVI_L_MIN, HauteurReduite());
		AdjustMaxRect(&rectWnd, nMaxL, HauteurReduite());
	}
	else
	{
		AdjustMinRect(&rectWnd, ZCK_QU_SUIVI_L_MIN, ZCK_QU_SUIVI_H_MIN);
		AdjustMaxRect(&rectWnd, nMaxL, nMaxH);
	}
	CWndNeuz::SetWndRect(rectWnd, bOnSize);
}

// Deplacement par la barre de titre seulement (hors boutons) : le reste du
// panneau se clique.
BOOL CWndZckQuestSuivi::IsPickupSpace(CPoint point)
{
	const CPoint ptClient(point.x - ZCK_QU_CADRE_G, point.y - ZCK_QU_CADRE_H);
	if (point.y >= ZCK_QU_CADRE_H + ZCK_QU_SUIVI_TETE_H)
		return FALSE;
	if (RectReduire().PtInRect(ptClient) || RectMasquer().PtInRect(ptClient))
		return FALSE;
	return CWndNeuz::IsPickupSpace(point);
}

CRect CWndZckQuestSuivi::RectTete()
{
	return CRect(0, 0, GetClientRect().Width(), ZCK_QU_SUIVI_TETE_H);
}

CRect CWndZckQuestSuivi::RectMasquer()
{
	const CRect rectTete = RectTete();
	const int y = rectTete.top + (rectTete.Height() - ZCK_QU_SUIVI_BOUTON) / 2;
	return CRect(rectTete.right - 4 - ZCK_QU_SUIVI_BOUTON, y, rectTete.right - 4, y + ZCK_QU_SUIVI_BOUTON);
}

CRect CWndZckQuestSuivi::RectReduire()
{
	const CRect rectMasquer = RectMasquer();
	return CRect(rectMasquer.left - 4 - ZCK_QU_SUIVI_BOUTON, rectMasquer.top, rectMasquer.left - 4, rectMasquer.bottom);
}

int CWndZckQuestSuivi::GetEntreesVisibles()
{
	const int nHauteur = GetClientRect().Height() - ZCK_QU_SUIVI_TETE_H - 6;
	const int n = nHauteur / ZCK_QU_SUIVI_ENTREE_H;
	return (n > 0) ? n : 0;
}

CRect CWndZckQuestSuivi::RectEntree(int nRang)
{
	const CRect rectClient = GetClientRect();
	const int y = ZCK_QU_SUIVI_TETE_H + 4 + nRang * ZCK_QU_SUIVI_ENTREE_H;
	return CRect(4, y, rectClient.Width() - 4, y + ZCK_QU_SUIVI_ENTREE_H - 2);
}

// Quetes suivies : terminees, en cours (echeance la plus proche d'abord),
// echouees encore ouvertes.
void CWndZckQuestSuivi::ListerQuetes()
{
	m_dwTickListe = GetTickCount();
	m_vecQuetes.clear();
	vector<ZCK_QU_TRI> vecTri;
	const map<int, ZCK_QUEST_DEFINITION>& definitions = CZckQuestManager::GetInstance()->GetDefinitions();
	for (map<int, ZCK_QUEST_DEFINITION>::const_iterator it = definitions.begin(); it != definitions.end(); ++it)
	{
		const int nStatut = ZckQuStatut(it->second);
		if (!ZckQuSuivable(it->second, nStatut))
			continue;
		ZCK_QU_TRI tri;
		tri.nId = it->first;
		tri.n64Cle = 0;
		if (nStatut == ZCK_QUEST_STATUT_TERMINEE)
			tri.nRang = 0;
		else if (nStatut == ZCK_QUEST_STATUT_EN_COURS)
		{
			const ZCK_QUEST_ENTREE* pEntree = ZckQuEntree(it->first);
			tri.nRang = 1;
			tri.n64Cle = pEntree ? pEntree->n64Echeance : 0;
		}
		else
			tri.nRang = 2;
		vecTri.push_back(tri);
	}
	std::sort(vecTri.begin(), vecTri.end());
	for (size_t i = 0; i < vecTri.size() && i < (size_t)ZCK_QU_SUIVI_LIGNES_MAX; ++i)
		m_vecQuetes.push_back(vecTri[i].nId);
}

BOOL CWndZckQuestSuivi::QueteASuivre()
{
	if (g_pPlayer == NULL)
		return FALSE;
	const map<int, ZCK_QUEST_DEFINITION>& definitions = CZckQuestManager::GetInstance()->GetDefinitions();
	for (map<int, ZCK_QUEST_DEFINITION>::const_iterator it = definitions.begin(); it != definitions.end(); ++it)
	{
		if (ZckQuSuivable(it->second, ZckQuStatut(it->second)))
			return TRUE;
	}
	return FALSE;
}

void CWndZckQuestSuivi::Actualiser()
{
	if (!g_Option.m_bZckQueteSuivi || g_pPlayer == NULL)
		return;
	if (g_WndMng.GetApplet(APP_ZCK_QUEST_SUIVI) != NULL)
		return;
	if (!QueteASuivre())
		return;
	g_WndMng.CreateApplet(APP_ZCK_QUEST_SUIVI);
}

void CWndZckQuestSuivi::Basculer()
{
	g_Option.m_bZckQueteSuivi = !g_Option.m_bZckQueteSuivi;
	if (g_Option.m_bZckQueteSuivi)
	{
		const BOOL bASuivre = QueteASuivre();
		if (bASuivre)
			Actualiser();
		g_WndMng.PutString(bASuivre ? "Suivi des qu\352tes affich\351." : "Suivi des qu\352tes activ\351 : il s'affichera d\350s qu'une qu\352te sera en cours.", NULL, 0xff80e080);
	}
	else
	{
		CWndBase* pWnd = g_WndMng.GetApplet(APP_ZCK_QUEST_SUIVI);
		if (pWnd)
			pWnd->Destroy();
		g_WndMng.PutString("Suivi des qu\352tes masqu\351 (/quete suivi ou bouton Suivi du journal pour le r\351afficher).", NULL, 0xffffd040);
	}
}

// Bouton x : l'option est coupee (neuz.ini), le suivi ne revient plus de
// lui-meme.
void CWndZckQuestSuivi::Masquer()
{
	g_Option.m_bZckQueteSuivi = FALSE;
	g_WndMng.PutString("Suivi des qu\352tes masqu\351 (/quete suivi ou bouton Suivi du journal pour le r\351afficher).", NULL, 0xffffd040);
	Destroy();
}

void CWndZckQuestSuivi::Reduire(BOOL bReduit)
{
	CRect rect = GetWindowRect(TRUE);
	if (bReduit && !m_bReduit)
		m_nHauteurDepliee = rect.Height();
	m_bReduit = bReduit;
	g_Option.m_bZckQueteSuiviReduit = bReduit;
	if (bReduit)
		rect.bottom = rect.top + HauteurReduite();
	else
		rect.bottom = rect.top + ((m_nHauteurDepliee > ZCK_QU_SUIVI_H_MIN) ? m_nHauteurDepliee : ZCK_QU_SUIVI_H_DEFAUT);
	SetWndRect(rect);
	ZckQuGarderVisible(this, m_pWndRoot);
}

// Destroy est differe (CWndBase::m_wndRemove) : retourner TRUE laisse les
// fenetres suivantes de CALL_CHILD_WND(Process()) traiter cette image.
BOOL CWndZckQuestSuivi::Process()
{
	if (g_pPlayer == NULL || !g_Option.m_bZckQueteSuivi)
	{
		Destroy();
		return TRUE;
	}
	if (!m_bPlace)
	{
		m_bPlace = TRUE;
		ZckQuGarderVisible(this, m_pWndRoot);
	}

	const DWORD dwTick = GetTickCount();
	if (dwTick - m_dwTickListe >= ZCK_QU_LISTE_MS)
		ListerQuetes();

	// Plus rien a suivre depuis quelques secondes : le suivi se ferme ; il
	// revient de lui-meme a la prochaine quete acceptee.
	if (m_vecQuetes.empty())
	{
		if (m_dwTickVide == 0)
			m_dwTickVide = dwTick | 1;
		else if (dwTick - m_dwTickVide >= ZCK_QU_SUIVI_VIDE_MS)
		{
			Destroy();
			return TRUE;
		}
	}
	else
		m_dwTickVide = 0;

	// Fond discret au repos, plus marque sous la souris (deplacement et
	// redimensionnement compris).
	const BOOL bSurvol = (CWndBase::m_pWndOnMouseMove == this || m_nResizeDir != 0 || m_bPickup);
	if (bSurvol)
		m_nAlphaFond = (m_nAlphaFond + 24 < 255) ? m_nAlphaFond + 24 : 255;
	else
		m_nAlphaFond = (m_nAlphaFond - 12 > 0) ? m_nAlphaFond - 12 : 0;
	if (CWndBase::m_pWndOnMouseMove != this)
		m_ptSurvol = CPoint(-1, -1);

	return CWndNeuz::Process();
}

void CWndZckQuestSuivi::OnDraw(C2DRender* p2DRender)
{
	if (!p2DRender || !p2DRender->m_pFont)
		return;

	const CRect rectClient = GetClientRect();
	const DWORD dwAlphaHaut = 0x58 + (DWORD)(m_nAlphaFond * 0x68 / 255);
	const DWORD dwAlphaBas = 0x38 + (DWORD)(m_nAlphaFond * 0x68 / 255);
	const DWORD dwAlphaCadre = 0x50 + (DWORD)(m_nAlphaFond * 0x90 / 255);
	p2DRender->RenderFillRect(rectClient, (dwAlphaHaut << 24) | 0x141020, (dwAlphaHaut << 24) | 0x141020, (dwAlphaBas << 24) | 0x080610, (dwAlphaBas << 24) | 0x080610);
	p2DRender->RenderRoundRect(rectClient, (dwAlphaCadre << 24) | 0xC8A040);

	// Barre de titre : nom et nombre, Reduire, Masquer.
	const CRect rectTete = RectTete();
	p2DRender->RenderFillRect(rectTete, 0xC05A4418, 0xC05A4418, 0x80281E08, 0x80281E08);
	p2DRender->RenderLine(CPoint(rectTete.left, rectTete.bottom), CPoint(rectTete.right, rectTete.bottom), 0xC0C8A040);
	const CRect rectReduire = RectReduire();
	const CRect rectMasquer = RectMasquer();
	CString str;
	int nAccomplir = 0;
	for (size_t i = 0; i < m_vecQuetes.size(); ++i)
	{
		const ZCK_QUEST_DEFINITION* pDef = CZckQuestManager::GetInstance()->GetDefinition(m_vecQuetes[i]);
		if (pDef && ZckQuStatut(*pDef) == ZCK_QUEST_STATUT_TERMINEE)
			++nAccomplir;
	}
	if (nAccomplir > 0)
		str.Format("Qu\352tes  (%d)  \267  %d \340 r\351cup\351rer", (int)m_vecQuetes.size(), nAccomplir);
	else
		str.Format("Qu\352tes  (%d)", (int)m_vecQuetes.size());
	{
		ZckQuPolice police(p2DRender, CWndBase::m_Theme.m_pFontWndTitle);
		const int yTitre = rectTete.top + (rectTete.Height() - ZckQuHauteur(p2DRender)) / 2;
		ZckQuTexte(p2DRender, rectTete.left + 8, yTitre, str, (nAccomplir > 0) ? ZCK_QU_A_RECUPERER : ZCK_QU_OR, rectReduire.left - 6 - rectTete.left - 8, 0);
	}
	for (int nBouton = 0; nBouton < 2; ++nBouton)
	{
		const CRect& rectBouton = (nBouton == 0) ? rectReduire : rectMasquer;
		const BOOL bSurvol = rectBouton.PtInRect(m_ptSurvol);
		p2DRender->RenderFillRect(rectBouton, bSurvol ? 0xFF4A4A5C : 0xC0303040);
		p2DRender->RenderRoundRect(rectBouton, bSurvol ? ZCK_QU_SELECTION : 0xFF808090);
		const int xC = rectBouton.CenterPoint().x;
		const int yC = rectBouton.CenterPoint().y;
		const DWORD dwTrait = bSurvol ? ZCK_QU_SELECTION : ZCK_QU_TEXTE;
		if (nBouton == 0)
		{
			p2DRender->RenderLine(CPoint(xC - 4, yC), CPoint(xC + 5, yC), dwTrait);
			if (m_bReduit)
				p2DRender->RenderLine(CPoint(xC, yC - 4), CPoint(xC, yC + 5), dwTrait);
		}
		else
		{
			p2DRender->RenderLine(CPoint(xC - 4, yC - 4), CPoint(xC + 4, yC + 4), dwTrait);
			p2DRender->RenderLine(CPoint(xC + 4, yC - 4), CPoint(xC - 4, yC + 4), dwTrait);
		}
	}
	if (m_bReduit)
		return;

	// Entrees.
	CZckQuestManager* pMng = CZckQuestManager::GetInstance();
	const __int64 n64 = ZckQuMaintenant();
	const int nHauteur = ZckQuHauteur(p2DRender);
	const int nVisibles = GetEntreesVisibles();
	const int nNombre = (int)m_vecQuetes.size();
	const int nMontrees = (nNombre > nVisibles) ? nVisibles - 1 : nNombre;
	if (nNombre == 0)
	{
		const CRect rectCorps(rectClient.left, rectTete.bottom, rectClient.right, rectClient.bottom);
		ZckQuTexteCentre(p2DRender, rectCorps, "Aucune qu\352te en cours", ZCK_QU_GRIS);
	}
	for (int i = 0; i < nMontrees; ++i)
	{
		const ZCK_QUEST_DEFINITION* pDef = pMng->GetDefinition(m_vecQuetes[i]);
		if (pDef == NULL)
			continue;
		const CRect rect = RectEntree(i);
		const ZCK_QUEST_ENTREE* pEntree = ZckQuEntree(pDef->nId);
		const int nStatut = ZckQuStatut(*pDef);
		const int nProgression = ZckQuProgression(*pDef, pEntree, nStatut);
		const float fRatio = ZckQuRatio(nProgression, pDef->nObjectif);
		const BOOL bSurvol = rect.PtInRect(m_ptSurvol);
		if (bSurvol)
		{
			p2DRender->RenderFillRect(rect, 0x90203040);
			p2DRender->RenderRoundRect(rect, ZCK_QU_SURVOL);
		}
		if (nStatut == ZCK_QUEST_STATUT_TERMINEE)
			ZckQuHalo(p2DRender, rect, ZCK_QU_A_RECUPERER);

		ZckQuIcone(p2DRender, rect.left + 2, rect.top + 2, nStatut, fRatio);

		// Ligne 1 : nom, temps ou etat a droite.
		CString strDroite;
		DWORD dwDroite = ZCK_QU_BLANC;
		if (nStatut == ZCK_QUEST_STATUT_TERMINEE)
		{
			strDroite = "Termin\351e !";
			dwDroite = ZCK_QU_A_RECUPERER;
		}
		else if (nStatut == ZCK_QUEST_STATUT_ECHOUEE)
		{
			strDroite = "\311chou\351e";
			dwDroite = ZCK_QU_ORANGE;
		}
		else
		{
			const __int64 n64Reste = (pEntree && n64 > 0) ? pEntree->n64Echeance - n64 : 0;
			strDroite = ZckQuChrono(n64Reste);
			dwDroite = (n64Reste < 60) ? ZCK_QU_ROUGE : ((n64Reste < 300) ? ZCK_QU_ORANGE : ZCK_QU_BLANC);
		}
		const int xTexte = rect.left + 20;
		const int nDroite = ZckQuTexte(p2DRender, rect.right - 4, rect.top + 2, strDroite, dwDroite, rect.Width() / 2, 2);
		const int nNomL = rect.right - 4 - nDroite - 8 - xTexte;
		ZckQuTexte(p2DRender, xTexte, rect.top + 2, pDef->strNom, (nStatut == ZCK_QUEST_STATUT_TERMINEE) ? ZCK_QU_A_RECUPERER : ZCK_QU_TEXTE, nNomL, 0);

		// Ligne 2 : progression, ou ce qu'il reste a faire.
		const int yLigne2 = rect.top + 4 + nHauteur;
		if (nStatut == ZCK_QUEST_STATUT_TERMINEE)
			ZckQuTexte(p2DRender, xTexte, yLigne2, "R\351compense \340 r\351cup\351rer (clic)", ZCK_QU_A_RECUPERER, rect.right - 4 - xTexte, 0);
		else if (nStatut == ZCK_QUEST_STATUT_ECHOUEE)
		{
			CString strInfo;
			DWORD dwInfo = ZCK_QU_GRIS;
			ZckQuInfoCourte(*pDef, pEntree, nStatut, n64, strInfo, dwInfo);
			str.Format("Temps \351coul\351 : recommencer (%s)", (LPCTSTR)strInfo);
			ZckQuTexte(p2DRender, xTexte, yLigne2, str, ZCK_QU_ORANGE, rect.right - 4 - xTexte, 0);
		}
		else
		{
			str.Format("%d / %d", nProgression, pDef->nObjectif);
			const int nCompte = ZckQuTexte(p2DRender, rect.right - 4, yLigne2, str, ZCK_QU_BLEU, rect.Width() / 2, 2);
			const int yBarre = yLigne2 + (nHauteur - 6) / 2;
			const CRect rectBarre(xTexte, yBarre, rect.right - 4 - nCompte - 8, yBarre + 6);
			if (rectBarre.Width() > 8)
				ZckQuBarre(p2DRender, rectBarre, fRatio, FALSE);
		}
	}
	if (nMontrees < nNombre && nMontrees >= 0)
	{
		const CRect rect = RectEntree(nMontrees);
		str.Format("+ %d autre%s qu\352te%s (clic : journal)", nNombre - nMontrees, (nNombre - nMontrees > 1) ? "s" : "", (nNombre - nMontrees > 1) ? "s" : "");
		ZckQuTexte(p2DRender, rect.left + 20, rect.top + (rect.Height() - nHauteur) / 2, str, rect.PtInRect(m_ptSurvol) ? ZCK_QU_OR : ZCK_QU_GRIS, rect.Width() - 24, 0);
	}

	// Poignee de redimensionnement, sous la souris seulement.
	if (m_nAlphaFond > 0)
	{
		const DWORD dwPoignee = ((DWORD)(m_nAlphaFond * 0xC0 / 255) << 24) | 0xC8A040;
		const int xD = rectClient.right - 3;
		const int yB = rectClient.bottom - 3;
		for (int i = 0; i < 3; ++i)
			p2DRender->RenderLine(CPoint(xD - 4 - i * 4, yB), CPoint(xD, yB - 4 - i * 4), dwPoignee);
	}
}

void CWndZckQuestSuivi::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_bAppui = TRUE;
	CWndNeuz::OnLButtonDown(nFlags, point);
}

void CWndZckQuestSuivi::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	m_bAppui = TRUE;
	CWndNeuz::OnLButtonDblClk(nFlags, point);
}

// Clic : seulement apres un appui dans la zone client, jamais a la fin d'un
// deplacement par la barre de titre (la fenetre reste a l'ecran, le curseur
// peut finir sur une ligne ou un bouton) ou d'un redimensionnement, et
// seulement si le relache tombe dans la zone client (voir CWndZckQuest).
void CWndZckQuestSuivi::OnLButtonUp(UINT nFlags, CPoint point)
{
	const BOOL bClic = m_bAppui && !m_bPickup && m_nResizeDir == 0 && GetClientRect().PtInRect(GetMousePoint());
	m_bAppui = FALSE;
	if (!bClic)
	{
		CWndNeuz::OnLButtonUp(nFlags, point);
		return;
	}
	point = GetMousePoint();

	if (RectMasquer().PtInRect(point))
	{
		Masquer();
		return;
	}
	if (RectReduire().PtInRect(point))
	{
		Reduire(!m_bReduit);
		return;
	}
	if (!m_bReduit)
	{
		const int nVisibles = GetEntreesVisibles();
		const int nNombre = (int)m_vecQuetes.size();
		const int nMontrees = (nNombre > nVisibles) ? nVisibles - 1 : nNombre;
		for (int i = 0; i < nMontrees; ++i)
		{
			if (RectEntree(i).PtInRect(point))
			{
				CWndZckQuest::Ouvrir(m_vecQuetes[i]);
				return;
			}
		}
		if (nMontrees < nNombre && nMontrees >= 0 && RectEntree(nMontrees).PtInRect(point))
		{
			CWndZckQuest::Ouvrir(m_vecQuetes[nMontrees]);
			return;
		}
	}
	CWndNeuz::OnLButtonUp(nFlags, point);
}

void CWndZckQuestSuivi::OnMouseWndSurface(CPoint point)
{
	m_ptSurvol = point;
	CString str;

	const CRect rectReduire = RectReduire();
	const CRect rectMasquer = RectMasquer();
	if (rectReduire.PtInRect(point) || rectMasquer.PtInRect(point))
	{
		const BOOL bReduire = rectReduire.PtInRect(point);
		CEditString strEdit;
		if (bReduire)
		{
			strEdit.AddString(m_bReduit ? "D\351plier" : "R\351duire", ZCK_QU_OR, ESSTY_BOLD);
			strEdit.AddString(m_bReduit ? "\nAfficher les qu\352tes suivies." : "\nGarder la seule barre de titre.", ZCK_QU_BLANC);
		}
		else
		{
			strEdit.AddString("Masquer", ZCK_QU_OR, ESSTY_BOLD);
			strEdit.AddString("\nLe suivi ne s'affichera plus de lui-m\352me.", ZCK_QU_BLANC);
			strEdit.AddString("\nPour le r\351afficher : /quete suivi ou bouton Suivi du journal.", ZCK_QU_GRIS);
		}
		CRect rect = bReduire ? rectReduire : rectMasquer;
		CPoint ptTip = point;
		ClientToScreen(&ptTip);
		ClientToScreen(&rect);
		g_toolTip.PutToolTip(ZCK_QU_BULLE + (bReduire ? 0x30 : 0x31), strEdit, rect, ptTip, 0);
		return;
	}

	if (m_bReduit)
		return;
	const int nVisibles = GetEntreesVisibles();
	const int nNombre = (int)m_vecQuetes.size();
	const int nMontrees = (nNombre > nVisibles) ? nVisibles - 1 : nNombre;
	for (int i = 0; i < nMontrees; ++i)
	{
		CRect rect = RectEntree(i);
		if (!rect.PtInRect(point))
			continue;
		const ZCK_QUEST_DEFINITION* pDef = CZckQuestManager::GetInstance()->GetDefinition(m_vecQuetes[i]);
		if (pDef == NULL)
			return;
		const ZCK_QUEST_ENTREE* pEntree = ZckQuEntree(pDef->nId);
		const int nStatut = ZckQuStatut(*pDef);
		CEditString strEdit;
		strEdit.AddString(pDef->strNom, ZCK_QU_OR, ESSTY_BOLD);
		str.Format("\n%s  \267  %d / %d", CZckQuestManager::TexteStatut(nStatut), ZckQuProgression(*pDef, pEntree, nStatut), pDef->nObjectif);
		strEdit.AddString(str, ZckQuCouleurStatut(nStatut));
		CString strLibelle;
		CString strValeur;
		DWORD dwCouleur = ZCK_QU_BLANC;
		ZckQuInfoTemps(*pDef, pEntree, nStatut, ZckQuMaintenant(), strLibelle, strValeur, dwCouleur);
		strEdit.AddString("\n" + strLibelle + " : " + strValeur, ZCK_QU_BLANC);
		CString strMonstres;
		for (size_t k = 0; k < pDef->vecMonstres.size(); ++k)
		{
			MoverProp* pProp = ZckQuMoverProp(pDef->vecMonstres[k]);
			if (!strMonstres.IsEmpty())
				strMonstres += ", ";
			strMonstres += pProp ? pProp->szName : "?";
		}
		strEdit.AddString("\nMonstres : " + strMonstres, ZCK_QU_GRIS);
		strEdit.AddString("\nLieu : " + ZckQuLieu(*pDef), ZCK_QU_GRIS);
		strEdit.AddString("\nClic : ouvrir le journal.", ZCK_QU_GRIS);
		CPoint ptTip = point;
		ClientToScreen(&ptTip);
		ClientToScreen(&rect);
		g_toolTip.PutToolTip(ZCK_QU_BULLE + 0x200 + i, strEdit, rect, ptTip, 0);
		return;
	}
}

#endif // __ZCK_QUEST
