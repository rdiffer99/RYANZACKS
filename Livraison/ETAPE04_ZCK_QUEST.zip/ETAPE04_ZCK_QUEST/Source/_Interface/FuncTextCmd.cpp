﻿#include "stdafx.h"
#include "defineText.h"
#include "defineObj.h"
#include "FuncTextCmd.h"
#include "WorldMng.h"
#include "definequest.h"

#ifdef __CLIENT
#include "AppDefine.h"
#include "WndAdminCreateItem.h"
#include "WndIndirectTalk.h"
#include "WndChangeFace.h"
#include "dpclient.h"
#include "timeLimit.h"
#ifdef __ZCK_WEATHER
#include "SkyBox.h"
#endif // __ZCK_WEATHER
#ifdef __ZCK_IA_FARM
#include "ZckIaFarm.h"
extern CZckIaFarm g_ZckIaFarm;
#endif // __ZCK_IA_FARM
#ifdef __ZCK_VOIR_INVENTAIRE_JOUEURS
#include "WndZckVoirInventaire.h"
#endif // __ZCK_VOIR_INVENTAIRE_JOUEURS
#ifdef __ZCK_QUEST
#include "WndZckQuest.h"
#endif // __ZCK_QUEST
#endif // __CLIENT

#ifdef __WORLDSERVER
#include "User.h"
#include "UserMacro.h"
#include "DPCoreClient.h"
#include "dpdatabaseclient.h"
#include "dpSrvr.h"
#include "eveschool.h"
#include "WorldDialog.h"
#if defined(__ZCK_COMBAT_MC)
#include "ZckCombatMC.h"
#endif // __ZCK_COMBAT_MC
#if defined(__ZCK_TOUR_INFINI)
#include "ZckTourInfini.h"
#endif // __ZCK_TOUR_INFINI
#if defined(__ZCK_MUTATEURS)
#include "ZckMutateurs.h"
#endif // __ZCK_MUTATEURS
#if defined(__ZCK_IA_FARM)
#include "ZckIaFarmServeur.h"
#endif // __ZCK_IA_FARM
#if __VER >= 13 // __EXT_ENCHANT
#include "ItemUpgrade.h"
#endif // __EXT_ENCHANT
#endif	// __WORLDSERVER
#ifdef __ZCK_CRAFT_LOAD_TEX
#ifdef __WORLDSERVER
#include "ZckCraftLoadTexTraitement.h"
#endif // __WORLDSERVER
#else
#line 50 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX

#if __VER >= 11 // __SYS_IDENTIFY
#include "randomoption.h"
#endif	// __SYS_IDENTIFY

#if __VER >= 11 // __SYS_PLAYER_DATA
#include "playerdata.h"
#endif	// __SYS_PLAYER_DATA

#if __VER >= 12 // __SECRET_ROOM
#include "SecretRoom.h"
#endif // __SECRET_ROOM

#if __VER >= 12 // __LORD
#ifdef __CLIENT
#include "clord.h"
#endif	// __CLIENT
#endif	// __LORD

#if __VER >= 12 // __TAX
#include "Tax.h"
#endif // __TAX

#if __VER >= 13
#include "honor.h"
#endif

#include "guild.h"
#include "party.h"
#include "post.h"

#if __VER >= 13 // __COUPLE_1117
#include "couplehelper.h"
#include "couple.h"
#endif	// __COUPLE_1117

#if __VER >= 15 // __GUILD_HOUSE
#include "GuildHouse.h"
#endif // __GUILD_HOUSE

extern	CPartyMng			g_PartyMng;
extern	CGuildMng			g_GuildMng;

#ifdef __CLIENT
extern	CParty				g_Party;
extern  CDPClient			g_DPlay;
#endif // __CLITEM

#ifdef __WORLDSERVER
extern	CDPDatabaseClient	g_dpDBClient;
extern	CDPCoreClient		g_DPCoreClient;
extern	CUserMng			g_UserMng;
extern  CWorldMng			g_WorldMng;
extern	CDPSrvr				g_DPSrvr;
extern	CGuildCombat		g_GuildCombatMng;
#endif

#if __VER >= 11 // __SYS_COLLECTING
#include "definesound.h"
#endif	// __SYS_COLLECTING

#ifdef __FL_FFA
#ifdef __WORLDSERVER
#include "FFAManager.h"
#endif
#endif

#ifdef __FL_TDM
#ifdef __WORLDSERVER
#include "TDMManager.h"
#endif
#endif

#ifdef __FL_WHEEL_OF_FORTUNE
#include "WheelOfFortune.h"
#endif

#ifdef __FL_WORLDBOSS
#ifdef __WORLDSERVER
#include "WorldBoss.h"
#endif
#endif

#ifdef __ZCK_FENETRE_CHAT_MJ
#include "ZckFenetreChatMj.h"
#endif // __ZCK_FENETRE_CHAT_MJ

#ifdef __ZCK_ANARCHY
#include "ZckAnarchy.h"
#endif // __ZCK_ANARCHY
#ifdef __ZCK_MONDIAL_BUFF
#include "ZckMondialBuff.h"
#endif // __ZCK_MONDIAL_BUFF
#ifdef __ZCK_PERIN_BUFF
#include "ZckPerinBuff.h"
#endif // __ZCK_PERIN_BUFF

#define TCM_CLIENT 0
#define TCM_SERVER 1
#define TCM_BOTH   2


#define BEGINE_TEXTCMDFUNC_MAP TextCmdFunc m_textCmdFunc[] = {
#define END_TEXTCMDFUNC_MAP 0, 0, 0, 0, 0, 0, AUTH_GENERAL, 0 };
#define ON_TEXTCMDFUNC( a, b, c, d, e, f, g, h ) a, b, c, d, e, f, g, h,

#ifdef __FL_CATCH_THE_PET
BOOL TextCmd_CreateCatchedPet(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	if (!IsValidObj(pUser))
		return FALSE;

	const DWORD dwMonsterID = (DWORD)s.GetNumber();
	pUser->CreateCatchedPetItem(dwMonsterID);
#endif	// __WORLDSERVER
	return TRUE;
}
#endif

BOOL TextCmd_SetAllBinds(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	if (!IsValidObj(pUser))
		return FALSE;

	for (DWORD i = 0; i < pUser->m_Inventory.m_dwItemMax; i++)
	{
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(i);
		if (pItemElem && !pItemElem->IsFlag(CItemElem::binds))
			pItemElem->SetFlag(CItemElem::binds);
	}

#endif	// __WORLDSERVER
	return TRUE;
}

#ifdef __FL_WHEEL_OF_FORTUNE
BOOL TextCmd_WofInit(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;

	DWORD idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);
	if (idPlayer == 0)
		return TRUE;

	CUser* pTarget = (CUser*)prj.GetUserByID(idPlayer);
	if (!IsValidObj(pTarget))
		return TRUE;

	int nWheelIndex = s.GetNumber();

	CWheelOfFortune::GetInstance()->InitProcess(nWheelIndex, pUser);

#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_WofFinish(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;

	DWORD idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);
	if (idPlayer == 0)
		return TRUE;

	CUser* pTarget = (CUser*)prj.GetUserByID(idPlayer);
	if (!IsValidObj(pTarget))
		return TRUE;

	CWheelOfFortune::GetInstance()->FinishProcess(pUser);

#endif	// __WORLDSERVER
	return TRUE;
}
#endif

BOOL TextCmd_PushPower(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;

	DWORD idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);
	if (idPlayer == 0)
		return TRUE;

	CUser* pTarget = (CUser*)prj.GetUserByID(idPlayer);
	if (!IsValidObj(pTarget))
		return TRUE;

	pTarget->pushedByAnotherPower(pTarget->GetAngle() + 180.0f, 0.5f);

#endif	// __WORLDSERVER
	return TRUE;
}

#ifdef __FL_VENDORS
BOOL TextCmd_DestroyAllVendors(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (!IsValidObj(pUser))
		return FALSE;

	for (auto& it : prj.m_mapPlayerShops)
	{
		CMover* pVendor = prj.GetMover(it.second);
		if (IsValidObj(pVendor))
			pVendor->ShutdownVendor(TRUE);
	}

	prj.m_mapPlayerShops.clear();
#endif	// __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_DestroyVendor(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (!IsValidObj(pUser))
		return FALSE;

	DWORD objid = scanner.GetNumber();
	CMover* pVendor = prj.GetMover(objid);
	if (!IsValidObj(pVendor))
		return FALSE;

	pVendor->ShutdownVendor();
#endif	// __WORLDSERVER
	return TRUE;
}
#endif

#ifdef __FL_FFA
BOOL TextCmd_ReloadFFA(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	CFFAManager::GetInstance()->ReadConfig();
	if (pUser)
#ifdef __ZCK_TRAD_FR
		pUser->AddText("FFA recharg\351");
#else
		pUser->AddText("FFA Reloaded");
#endif // __ZCK_TRAD_FR
#endif	// __WORLDSERVER
	return TRUE;
}
#endif

#ifdef __FL_TDM
BOOL TextCmd_ReloadTDM(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	CTDMManager::GetInstance()->ReadConfig();
	if (pUser)
#ifdef __ZCK_TRAD_FR
		pUser->AddText("TDM recharg\351");
#else
		pUser->AddText("TDM Reloaded");
#endif // __ZCK_TRAD_FR
#endif	// __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_StartTDM(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	CTDMManager::GetInstance()->AnnounceTDM();
#endif	// __WORLDSERVER
	return TRUE;
}
#endif

#ifdef __FL_UPDATE_READSTAFF
BOOL TextCmd_LoadServerStaff(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	prj.LoadServerStaff();
#ifdef __ZCK_TRAD_FR
	pUser->AddText("Liste du staff recharg\351e");
#else
	pUser->AddText("Staff list reloaded");
#endif // __ZCK_TRAD_FR
#endif	// __WORLDSERVER
	return TRUE;
}
#endif

BOOL TextCmd_Open(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	DWORD dwIdApplet = g_WndMng.GetAppletId(scanner.token);
	g_WndMng.CreateApplet(dwIdApplet);
#endif
	return TRUE;
}
BOOL TextCmd_Close(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	DWORD dwIdApplet = g_WndMng.GetAppletId(scanner.token);
	CWndBase* pWndBase = g_WndMng.GetWndBase(dwIdApplet);
	if (pWndBase) pWndBase->Destroy();
#endif
	return TRUE;
}

BOOL TextCmd_Time(CScanner& scanner)
{
#ifdef __CLIENT
	CString string;
	CTime time = CTime::GetCurrentTime();
	//time.Get
#ifdef __ZCK_TRAD_FR
	string = time.Format("Heure r\351elle - %H:%M:%S");
	g_WndMng.PutString(string);
	string.Format("Heure de Madrigal - %d:%d:%d", g_GameTimer.m_nHour, g_GameTimer.m_nMin, g_GameTimer.m_nSec);
#else
	string = time.Format("Real Time - %H:%M:%S");
	g_WndMng.PutString(string);
	string.Format("Madrigal Time - %d:%d:%d", g_GameTimer.m_nHour, g_GameTimer.m_nMin, g_GameTimer.m_nSec);
#endif // __ZCK_TRAD_FR
	g_WndMng.PutString(string);

#endif
	return TRUE;
}

BOOL TextCmd_ChangeShopCost(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	FLOAT f = scanner.GetFloat();
	int nAllServer = scanner.GetNumber();

	if (f > 2.0f)
		f = 1.0f;
	else if (f < 0.5f)
		f = 1.0f;

	if (nAllServer != 0)
	{
		g_DPCoreClient.SendGameRate(f, GAME_RATE_SHOPCOST);
		return TRUE;
	}

	prj.m_fShopCost = f;
	g_UserMng.AddGameRate(prj.m_fShopCost, GAME_RATE_SHOPCOST);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_SetMonsterRespawn(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	D3DXVECTOR3 vPos = pUser->GetPos();
	CWorld* pWorld = pUser->GetWorld();

	MoverProp* pMoverProp = NULL;

	scanner.GetToken();
	if (scanner.tokenType == NUMBER)
	{
		DWORD dwID = _ttoi(scanner.Token);
		pMoverProp = prj.GetMoverPropEx(dwID);

	}
	else
		pMoverProp = prj.GetMoverProp(scanner.Token);

	if (pMoverProp && pMoverProp->dwID != 0)
	{
		DWORD dwNum = scanner.GetNumber();
		if (dwNum > 30) dwNum = 30;
		if (dwNum < 1) dwNum = 1;

		DWORD dwAttackNum = scanner.GetNumber();
		if (dwAttackNum > dwNum) dwAttackNum = dwNum;
		if (dwAttackNum < 1) dwAttackNum = 0;

		DWORD dwRect = scanner.GetNumber();
		if (dwRect > 255) dwRect = 255;
		if (dwRect < 1) dwRect = 1;

		DWORD dwTime = scanner.GetNumber();
		if (dwTime > 10800) dwTime = 10800;
		if (dwTime < 10) dwTime = 10;

		int nAllServer = scanner.GetNumber();
		if (nAllServer != 0)
		{
			BOOL bFlying = FALSE;
			if (pMoverProp->dwFlying)
				bFlying = TRUE;
			g_DPCoreClient.SendSetMonsterRespawn(pUser->m_idPlayer, pMoverProp->dwID, dwNum, dwAttackNum, dwRect, dwTime, bFlying);
			return TRUE;
		}

		CRespawnInfo ri;
		ri.m_dwType = OT_MOVER;
		ri.m_dwIndex = pMoverProp->dwID;
		ri.m_cb = dwNum;
		ri.m_nActiveAttackNum = dwAttackNum;
		if (pMoverProp->dwFlying != 0)
			ri.m_vPos = vPos;
		ri.m_rect.left = (LONG)(vPos.x - dwRect);
		ri.m_rect.right = (LONG)(vPos.x + dwRect);
		ri.m_rect.top = (LONG)(vPos.z - dwRect);
		ri.m_rect.bottom = (LONG)(vPos.z + dwRect);
		ri.m_uTime = (u_short)(dwTime);
		ri.m_cbTime = 0;

		char chMessage[512] = { 0, };
#ifdef __S1108_BACK_END_SYSTEM
		pWorld->m_respawner.Add(ri, TRUE);
#else // __S1108_BACK_END_SYSTEM
		pWorld->m_respawner.Add(ri);
#endif // __S1108_BACK_END_SYSTEM

#ifdef __ZCK_TRAD_FR
		sprintf(chMessage, "R\351apparition de monstres ajout\351e : %s(%d/%d) Rect(%d, %d, %d, %d) D\351lai : %d",
			pMoverProp->szName, ri.m_cb, ri.m_nActiveAttackNum, ri.m_rect.left, ri.m_rect.right, ri.m_rect.top, ri.m_rect.bottom, ri.m_uTime);
#else
		sprintf(chMessage, "Add Respwan Monster : %s(%d/%d) Rect(%d, %d, %d, %d) Time : %d",
			pMoverProp->szName, ri.m_cb, ri.m_nActiveAttackNum, ri.m_rect.left, ri.m_rect.right, ri.m_rect.top, ri.m_rect.bottom, ri.m_uTime);
#endif // __ZCK_TRAD_FR
		pUser->AddText(chMessage);
	}
#endif	// __WORLDSERVER
	return TRUE;
}

#ifdef __S1108_BACK_END_SYSTEM

BOOL TextCmd_PropMonster(CScanner& scanner)
{
#ifdef __CLIENT
	char chMessage[1024] = { 0, };
	if (0 < prj.m_nAddMonsterPropSize)
	{
		for (int i = 0; i < prj.m_nAddMonsterPropSize; ++i)
		{
#ifdef __ZCK_TRAD_FR
			sprintf(chMessage, "Propri\351t\351s du monstre (%s) Attaque(%d), D\351fense(%d), Exp(%d), PV(%d), Butin(%d), Penya(%d)",
				prj.m_aAddProp[i].szMonsterName, prj.m_aAddProp[i].nAttackPower, prj.m_aAddProp[i].nDefence, prj.m_aAddProp[i].nExp,
				prj.m_aAddProp[i].nHitPoint, prj.m_aAddProp[i].nItemDrop, prj.m_aAddProp[i].nPenya);
#else
			sprintf(chMessage, "Monster Prop(%s) AttackPower(%d), Defence(%d), Exp(%d), Hitpioint(%d), ItemDorp(%d), Penya(%d)",
				prj.m_aAddProp[i].szMonsterName, prj.m_aAddProp[i].nAttackPower, prj.m_aAddProp[i].nDefence, prj.m_aAddProp[i].nExp,
				prj.m_aAddProp[i].nHitPoint, prj.m_aAddProp[i].nItemDrop, prj.m_aAddProp[i].nPenya);
#endif // __ZCK_TRAD_FR
			g_WndMng.PutString(chMessage, NULL, 0xffff0000, CHATSTY_GENERAL);
		}
	}
	else
	{
#ifdef __ZCK_TRAD_FR
		sprintf(chMessage, "Aucune donn\351e de propri\351t\351s de monstre.");
#else
		sprintf(chMessage, "Monster Prop Not Data");
#endif // __ZCK_TRAD_FR
		g_WndMng.PutString(chMessage, NULL, 0xffff0000, CHATSTY_GENERAL);
	}
#endif	// __CLIENT
	return TRUE;
}
#endif // __S1108_BACK_END_SYSTEM

BOOL TextCmd_GameSetting(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->AddGameSetting();
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ChangeFace(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	DWORD dwFace = scanner.GetNumber();
	if (dwFace < 0 || 4 < dwFace)
		return TRUE;

	if ((pUser->m_dwMode & NOTFRESH_MODE) || (pUser->m_dwMode & NOTFRESH_MODE2))
	{
		pUser->m_dwHeadMesh = dwFace;
		g_UserMng.AddChangeFace(pUser->m_idPlayer, dwFace);
		if (pUser->m_dwMode & NOTFRESH_MODE)
		{
			pUser->m_dwMode &= ~NOTFRESH_MODE;
			pUser->AddDefinedText(TID_CHANGEFACE_ONE, "");

		}
		else
		{
			pUser->m_dwMode &= ~NOTFRESH_MODE2;
			pUser->AddDefinedText(TID_CHANGEFACE_TWO, "");

		}
	}
	else
	{
		pUser->AddDefinedText(TID_CHANGEFACE_THREE, "");

	}
#else // __WORLDSERVER
	SAFE_DELETE(g_WndMng.m_pWndChangeSex);
	g_WndMng.m_pWndChangeSex = new CWndChangeSex;
	g_WndMng.m_pWndChangeSex->Initialize();
	g_WndMng.m_pWndChangeSex->SetData(NULL_ID);
	return FALSE;
#endif
	return TRUE;
}

BOOL TextCmd_AroundKill(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	CWorld* pWorld = pUser->GetWorld();
	if (pWorld)
		pUser->SendDamageAround(AF_MAGICSKILL, (CMover*)pUser, OBJTYPE_MONSTER, 1, 64.0f, 0.0, 1.0f);
#endif // __WORLDSERVER
	return TRUE;
}

#if __VER >= 9	// __PET_0410
BOOL	TextCmd_PetLevel(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CPet* pPet = pUser->GetPet();
	if (pPet && pPet->GetExpPercent() == 100)
		pUser->PetLevelup();
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL	TextCmd_MakePetFeed(CScanner& s)
{
#ifdef __CLIENT
	if (g_WndMng.m_pWndPetFoodMill == NULL)
	{
		SAFE_DELETE(g_WndMng.m_pWndPetFoodMill);
		g_WndMng.m_pWndPetFoodMill = new CWndPetFoodMill;
		g_WndMng.m_pWndPetFoodMill->Initialize(&g_WndMng, APP_PET_FOOD);
		return FALSE;
	}
#endif	// __CLIENT
	return TRUE;
}

BOOL	TextCmd_PetExp(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CPet* pPet = pUser->GetPet();
	if (pPet && pPet->GetLevel() != PL_S)
	{
		pPet->SetExp(MAX_PET_EXP);
		pUser->AddPetSetExp(pPet->GetExp());
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Pet(CScanner& s)
{
	// /pet 1 100
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;
	DWORD idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);
	if (idPlayer == 0)
		return TRUE;
	CUser* pTarget = (CUser*)prj.GetUserByID(idPlayer);
	if (IsValidObj(pTarget) == FALSE)
		return TRUE;
	CPet* pPet = pTarget->GetPet();
	if (pPet == NULL)
		return TRUE;

	// kind
	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;
	BYTE nKind = atoi(s.token);
#ifdef __ZCK_FISH_AND_QOL
	if (!CPetProperty::GetInstance()->ZckFaqKindValide(nKind))
		return TRUE;	// types 0 a PK_MAX - 1 et types ZCK lus dans pet.inc
#else
#line 669 // __ZCK_FISH_AND_QOL
	if (nKind >= PK_MAX)
		return TRUE;
#line 670 // __ZCK_FISH_AND_QOL
#endif // __ZCK_FISH_AND_QOL

	// exp
	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;
	BYTE nExpRate = atoi(s.token);

	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;
	BYTE nLevel = s.Token.GetLength();

	if (nLevel > PL_S)
		return TRUE;

	BYTE anAvail[PL_MAX - 1] = { 0, };
	char sAvail[2] = { 0, };

	for (int i = 0; i < nLevel; i++)
	{
		sAvail[0] = s.Token.GetAt(i);
		sAvail[1] = '\0';
		anAvail[i] = atoi(sAvail);
		if (anAvail[i] < 1 || anAvail[i] > 9)
			return TRUE;
	}

	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;
	BYTE nLife = atoi(s.token);
	if (nLife > 99)
		nLife = 99;

	CItemElem* pItemElem = pTarget->GetPetItem();
	pPet->SetKind(nKind);
	pPet->SetLevel(nLevel);
	if (nLevel == PL_EGG)
		pPet->SetKind(0);	// initialize
	pItemElem->m_dwItemId = pPet->GetItemId();
	pPet->SetEnergy(pPet->GetMaxEnergy());
	DWORD dwExp = pPet->GetMaxExp() * nExpRate / 100;
	pPet->SetExp(dwExp);

	for (int i = PL_D; i <= nLevel; i++)
		pPet->SetAvailLevel(i, anAvail[i - 1]);
	for (int i = nLevel + 1; i <= PL_S; i++)
		pPet->SetAvailLevel(i, 0);

	pPet->SetLife(nLife);

	if (pTarget->HasPet())
		pTarget->RemovePet();

	//	g_dpDBClient.CalluspPetLog(pTarget->m_idPlayer, pItemElem->GetSerialNumber(), 0, PETLOGTYPE_LEVELUP, pPet);

	pTarget->AddPet(pPet, PF_PET_GET_AVAIL);
	g_UserMng.AddPetLevelup(pTarget, MAKELONG((WORD)pPet->GetIndex(), (WORD)pPet->GetLevel()));
#endif	// __WORLDSERVER
#ifdef __ZCK_FISH_AND_QOL
// define retire : numeros de ligne retablis apres le bloc conditionnel ci-dessus
#else
#line 729 // __ZCK_FISH_AND_QOL
#endif // __ZCK_FISH_AND_QOL
	return TRUE;
}

#endif	// __PET_0410

#ifdef __FL_EQUALIZED_MODE
BOOL TextCmd_SaveTemporalPreset(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	if (pUser->GetWorld())
	{
		if (pUser->bTmpMode)
		{
			g_dpDBClient.SendSaveTmpPreset(pUser);
			CString str;
#ifdef __ZCK_TRAD_FR
			str.Format("\311quipement temporaire mis \340 jour ou enregistr\351 pour : monde %d, sexe %d, classe %d", pUser->GetWorld()->GetID(), pUser->GetSex(), pUser->GetJob());
			pUser->AddText(str);
		}
		else
			pUser->AddText("Vous ne pouvez pas enregistrer de pr\351r\351glages d'\351quipement pour le moment ! Contactez Florist pour plus de d\351tails.");
#else
			str.Format("Temporal equipment updated or saved for: World: %d, Gender: %d, Job: %d", pUser->GetWorld()->GetID(), pUser->GetSex(), pUser->GetJob());
			pUser->AddText(str);
		}
		else
			pUser->AddText("You cant save equipment presets right now! PM Florist for details..");
#endif // __ZCK_TRAD_FR
	}
#endif	// __WORLDSERVER
	return TRUE;
}
#endif

#if defined(__ZCK_UPGRADE) && defined(__CLIENT)
static BOOL OpenZckUpgradeWindow()
{
	if (!g_pPlayer || !g_pPlayer->IsAuthHigher(AUTH_ADMINISTRATOR))
		return FALSE;

	if (g_WndMng.GetApplet(APP_UPGRADE))
		return TRUE;

	return g_WndMng.CreateApplet(APP_UPGRADE) != NULL;
}
#endif

#if __VER >= 11 // __SYS_COLLECTING
BOOL TextCmd_RefineCollector(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int nAbilityOption = s.GetNumber();
	if (s.tok == FINISHED)
		nAbilityOption = 0;
	if (nAbilityOption > 5)
		nAbilityOption = 5;
	CItemElem* pTarget = pUser->m_Inventory.GetAt(0);
	if (pTarget && pTarget->IsCollector(TRUE))
	{
		pUser->AddDefinedText(TID_UPGRADE_SUCCEEFUL);
		pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
		if (pUser->IsMode(TRANSPARENT_MODE) == 0)
			g_UserMng.AddCreateSfxObj(pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);
		pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_AO, nAbilityOption);
	}
#elif defined(__CLIENT) && defined(__ZCK_UPGRADE)
	s.GetNumber();
	if (s.tok == FINISHED && OpenZckUpgradeWindow())
		return FALSE;
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_RefineAccessory(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int nAbilityOption = s.GetNumber();
	if (s.tok == FINISHED)
		nAbilityOption = 0;
	CItemElem* pTarget = pUser->m_Inventory.GetAt(0);
	if (pTarget && pTarget->IsAccessory())
		pUser->UpdateItem((BYTE)(pTarget->m_dwObjId), UI_AO, nAbilityOption);
#elif defined(__CLIENT) && defined(__ZCK_UPGRADE)
	s.GetNumber();
	if (s.tok == FINISHED && OpenZckUpgradeWindow())
		return FALSE;
#endif	// __WORLDSERVER
	return TRUE;
}
#endif	// __SYS_COLLECTING

#if __VER >= 11 // __SYS_IDENTIFY
BOOL TextCmd_SetRandomOption(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CItemElem* pItemElem = pUser->m_Inventory.GetAt(0);
	if (pItemElem)
	{
		int nRandomOptionKind = g_xRandomOptionProperty->GetRandomOptionKind(pItemElem);
		if (nRandomOptionKind >= 0)
		{
			g_xRandomOptionProperty->InitializeRandomOption(pItemElem->GetRandomOptItemIdPtr());
#ifdef __ZCK_SYSTEME_EVEIL
			// Correctif 4 : l'eveil courant vient d'etre detruit, le point
			// de retour persiste est perime.
			pUser->UpdateItemEx((BYTE)(pItemElem->m_dwObjId), UI_ZCK_PREV_AWAKE, (__int64)0);
#endif // __ZCK_SYSTEME_EVEIL
			int nDst, nAdj;
			int cb = 0;
			nDst = s.GetNumber();
			while (s.tok != FINISHED)
			{
				nAdj = s.GetNumber();

				if (nDst == 48)
					break;
				if (nDst < 1 || nDst >= MAX_ADJPARAMARY)
					return false;
				if (nAdj > 512 || nAdj < -512)
					return false;

				if (s.tok == FINISHED)
					break;
				g_xRandomOptionProperty->SetParam(pItemElem->GetRandomOptItemIdPtr(), nDst, nAdj);
				cb++;
				if (cb >= MAX_RANDOM_OPTION)
					break;
				nDst = s.GetNumber();
			}
			pUser->UpdateItemEx((BYTE)(pItemElem->m_dwObjId), UI_RANDOMOPTITEMID, pItemElem->GetRandomOptItemId());
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_GenRandomOption(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	//	int i	= s.GetNumber();
	CItemElem* pItemElem = pUser->m_Inventory.GetAt(0);
	if (pItemElem)
	{
		int nRandomOptionKind = g_xRandomOptionProperty->GetRandomOptionKind(pItemElem);
		if (nRandomOptionKind >= 0)
		{
			g_xRandomOptionProperty->InitializeRandomOption(pItemElem->GetRandomOptItemIdPtr());
#ifdef __ZCK_SYSTEME_EVEIL
			// Correctif 4 : l'eveil courant vient d'etre detruit, le point
			// de retour persiste est perime.
			pUser->UpdateItemEx((BYTE)(pItemElem->m_dwObjId), UI_ZCK_PREV_AWAKE, (__int64)0);
#endif // __ZCK_SYSTEME_EVEIL
			g_xRandomOptionProperty->GenRandomOption(pItemElem->GetRandomOptItemIdPtr(), nRandomOptionKind, pItemElem->GetProp()->dwParts);
			pUser->UpdateItemEx((BYTE)(pItemElem->m_dwObjId), UI_RANDOMOPTITEMID, pItemElem->GetRandomOptItemId());
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_PickupPetAwakeningCancel(CScanner& s)
{
#ifdef __CLIENT
	SAFE_DELETE(g_WndMng.m_pWndPetAwakCancel);
	g_WndMng.m_pWndPetAwakCancel = new CWndPetAwakCancel;
	g_WndMng.m_pWndPetAwakCancel->Initialize(&g_WndMng);
#endif	// __CLIENT
	return TRUE;
}

BOOL TextCmd_InitializeRandomOption(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	//	int i	= s.GetNumber();
	CItemElem* pItemElem = pUser->m_Inventory.GetAt(0);
	if (pItemElem)
	{
		int nRandomOptionKind = g_xRandomOptionProperty->GetRandomOptionKind(pItemElem);
		if (nRandomOptionKind >= 0)
		{
			g_xRandomOptionProperty->InitializeRandomOption(pItemElem->GetRandomOptItemIdPtr());
#ifdef __ZCK_SYSTEME_EVEIL
			// Correctif 4 : l'eveil courant vient d'etre detruit, le point
			// de retour persiste est perime.
			pUser->UpdateItemEx((BYTE)(pItemElem->m_dwObjId), UI_ZCK_PREV_AWAKE, (__int64)0);
#endif // __ZCK_SYSTEME_EVEIL
			pUser->UpdateItemEx((BYTE)(pItemElem->m_dwObjId), UI_RANDOMOPTITEMID, pItemElem->GetRandomOptItemId());
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ItemLevel(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int i = s.GetNumber();
	if (s.tok == FINISHED)
		i = 0;
	CItemElem* pTarget = pUser->m_Inventory.GetAt(0);
	if (pTarget)
	{
		ItemProp* pProp = pTarget->GetProp();
		if (pProp->dwParts != NULL_ID && pProp->dwLimitLevel1 != 0xFFFFFFFF)
		{
			pTarget->SetLevelDown(i);
			pUser->UpdateItemEx((BYTE)(pTarget->m_dwObjId), UI_RANDOMOPTITEMID, pTarget->GetRandomOptItemId());
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}
#endif	// __SYS_IDENTIFY

BOOL TextCmd_Level(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	scanner.GetToken();
	CString strJob = scanner.Token;

	int nJob = JOB_VAGRANT;

	LONG nLevel = scanner.GetNumber();

	if (nLevel == 0)
		nLevel = 1;

	int	nJobCode = 0;
	nJobCode = _ttoi(strJob.GetString());

	if (nJobCode != 0 && nJobCode < MAX_JOB)
	{
		nJob = nJobCode;
	}
	else
	{
		for (int i = 0; i < MAX_JOB; i++)
		{
			if (strcmp(strJob, prj.m_aJob[i].szName) == 0 || strcmp(strJob, prj.m_aJob[i].szEName) == 0)
			{
				nJob = i;
				break;
			}
		}
	}

	char chMessage[MAX_PATH] = { 0, };
	if (MAX_JOB_LEVEL < nLevel && nJob == 0)
	{
		sprintf(chMessage, prj.GetText(TID_GAME_CHOICEJOB));
		pUser->AddText(chMessage);
		return TRUE;
	}

	LONG	nLegend = scanner.GetNumber();

	if ((nLegend > 0) && (nLegend < 4))
	{
		for (int i = nJob + 1; i < MAX_JOB; i++)
		{
			if (strcmp(strJob, prj.m_aJob[i].szName) == 0 || strcmp(strJob, prj.m_aJob[i].szEName) == 0)
			{
				nJob = i;
				if (nLegend == 3)
					break;
				else if (nLegend == 1)
					break;
				else
					nLegend--;
			}
		}

		pUser->InitLevel(nJob, nLevel);
		return	TRUE;
	}

	if (nLevel <= MAX_JOB_LEVEL)
	{
		pUser->InitLevel(JOB_VAGRANT, nLevel);
	}
	else if (MAX_JOB_LEVEL < nLevel && nLevel <= MAX_JOB_LEVEL + MAX_EXP_LEVEL)
	{
		if (MAX_JOBBASE <= nJob && nJob < MAX_EXPERT)
		{
			pUser->InitLevel(nJob, nLevel);
		}
		else
		{
#ifdef __ZCK_TRAD_FR
			sprintf(chMessage, "Pas une classe experte");
			pUser->AddText(chMessage);
			sprintf(chMessage, "Classes expertes : ");
#else
			sprintf(chMessage, "Not Expert Job");
			pUser->AddText(chMessage);
			sprintf(chMessage, "Expert Job : ");
#endif // __ZCK_TRAD_FR
			for (int i = MAX_JOBBASE; i < MAX_EXPERT; ++i)
			{
				if (strlen(prj.m_aJob[i].szName) < 15)
				{
					strcat(chMessage, prj.m_aJob[i].szName);
					if (i + 1 != MAX_EXPERT)
					{
						strcat(chMessage, ", ");
					}
				}
			}
			pUser->AddText(chMessage);
#ifdef __ZCK_TRAD_FR
			sprintf(chMessage, "Niveaux experts : %d ~ %d", MAX_JOB_LEVEL + 1, MAX_JOB_LEVEL + MAX_EXP_LEVEL);
#else
			sprintf(chMessage, "Expert Level : %d ~ %d", MAX_JOB_LEVEL + 1, MAX_JOB_LEVEL + MAX_EXP_LEVEL);
#endif // __ZCK_TRAD_FR
			pUser->AddText(chMessage);
			return TRUE;
		}
	}
	else if (MAX_JOB_LEVEL + MAX_EXP_LEVEL < nLevel && nLevel <= MAX_GENERAL_LEVEL)
	{
		if (MAX_EXPERT <= nJob && nJob < MAX_PROFESSIONAL)
		{
			pUser->InitLevel(nJob, nLevel);	// lock
		}
		else
		{
#ifdef __ZCK_TRAD_FR
			sprintf(chMessage, "Pas une classe professionnelle");
			pUser->AddText(chMessage);
			sprintf(chMessage, "Classes professionnelles : ");
#else
			sprintf(chMessage, "Not Professional Job");
			pUser->AddText(chMessage);
			sprintf(chMessage, "Professional Job : ");
#endif // __ZCK_TRAD_FR
			for (int i = MAX_EXPERT; i < MAX_PROFESSIONAL; ++i)
			{
				if (strlen(prj.m_aJob[i].szName) < 15)
				{
					strcat(chMessage, prj.m_aJob[i].szName);
					if (i + 1 != MAX_PROFESSIONAL)
					{
						strcat(chMessage, ", ");
					}
				}
			}
			pUser->AddText(chMessage);
#ifdef __ZCK_TRAD_FR
			sprintf(chMessage, "Niveaux professionnels : %d ~~~ ", MAX_JOB_LEVEL + MAX_EXP_LEVEL + 1);
#else
			sprintf(chMessage, "Professional Level : %d ~~~ ", MAX_JOB_LEVEL + MAX_EXP_LEVEL + 1);
#endif // __ZCK_TRAD_FR
			pUser->AddText(chMessage);
			return TRUE;
		}
	}
#endif // __WORLDSERVER
	return TRUE;
}


BOOL TextCmd_SetSnoop(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;

	s.GetToken();
	if (s.tok != FINISHED)
	{
		if (lstrcmp(pUser->GetName(), s.Token))
		{
			u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);

			if (idPlayer > 0)
			{
				BOOL bRelease = FALSE;
				s.GetToken();
				if (s.tok != FINISHED)
					bRelease = (BOOL)atoi(s.Token);
				g_DPCoreClient.SendSetSnoop(idPlayer, pUser->m_idPlayer, bRelease);
			}
			else
				pUser->AddReturnSay(3, s.Token);
		}
	}
#endif	// __WORLDSERVER
	return FALSE;
}


BOOL TextCmd_QuerySetPlayerName(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	scanner.GetToken();
	CString strPlayer = scanner.Token;
	strPlayer.TrimLeft();
	strPlayer.TrimRight();
	g_dpDBClient.SendQuerySetPlayerName(pUser->m_idPlayer, strPlayer, MAKELONG(0xffff, 0));
	return TRUE;
#endif	// __WORLDSERVER
	return FALSE;
}

BOOL TextCmd_QuerySetGuildName(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	scanner.GetToken();
	CString strGuild = scanner.Token;
	strGuild.TrimLeft();
	strGuild.TrimRight();
	CGuild* pGuild = g_GuildMng.GetGuild(pUser->m_idGuild);
	if (pGuild && pGuild->IsMaster(pUser->m_idPlayer))
	{
		g_DPCoreClient.SendQuerySetGuildName(pUser->m_idPlayer, pUser->m_idGuild, (LPSTR)(LPCSTR)strGuild, 0xff);
	}
	else
	{
		// is not kingpin
	}
	return TRUE;
#endif	// __WORLDSERVER
	return FALSE;
}

BOOL TextCmd_CreateGuild(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	scanner.GetToken();
	GUILD_MEMBER_INFO	info;
	info.idPlayer = pUser->m_idPlayer;
	g_DPCoreClient.SendCreateGuild(&info, 1, scanner.Token);
	return TRUE;
#endif	// __WORLDSERVER
	return FALSE;
}

BOOL TextCmd_DestroyGuild(CScanner& scanner)
{
#ifdef __CLIENT
	g_DPlay.SendDestroyGuild();
#endif
	return TRUE;
}

BOOL TextCmd_RemoveGuildMember(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	char lpszPlayer[MAX_PLAYER] = { 0, };
	lstrcpy(lpszPlayer, scanner.Token);
	u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(lpszPlayer);
	if (idPlayer != 0)
		g_DPlay.SendRemoveGuildMember(idPlayer);
	return TRUE;
#endif	// __CLIENT
	return FALSE;
}

BOOL TextCmd_GuildChat(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

#ifdef __JEFF_9_20
	int nText = pUser->GetMuteText();
	if (nText)
	{
		pUser->AddDefinedText(nText);
		return TRUE;
	}
#endif	// __JEFF_9_20

	char sChat[260] = { 0, };
	scanner.GetLastFull();
	if (strlen(scanner.token) >= 260)
		return TRUE;
	strcpy(sChat, scanner.token);

	StringTrimRight(sChat);
	if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
		ParsingEffect(sChat, strlen(sChat));

	RemoveCRLF(sChat);
	Removeat(sChat);
#ifdef __ZCK_LINK
	ZckLienAssainir(pUser, sChat);
#else
#line 1218
#endif // __ZCK_LINK

#ifdef __ZCK_FENETRE_CHAT_MJ
	CZckChatMjManager::GetInstance()->Capture(
		ZCK_CHATMJ_CAT_GUILDE, pUser, NULL, sChat);
#endif // __ZCK_FENETRE_CHAT_MJ

	g_DPCoreClient.SendGuildChat(pUser, sChat);
	return TRUE;
#else	// __WORLDSERVER
#ifdef __ZCK_LINK
// define retire : numeros de ligne retablis au debut de cette branche
#else
#line 1227
#endif // __ZCK_LINK
#ifdef __CLIENT
	CString string = scanner.m_pProg;
	g_WndMng.WordChange(string);

	if (::GetLanguage() == LANG_THA)
		string = '"' + string + '"';

	CString strCommand;
	strCommand.Format("/g %s", string);
	g_DPlay.SendChat(strCommand);
	return FALSE;
#endif	// __CLIENT
#endif	// __WORLDSERVER
#ifdef __ZCK_LINK
// define retire : numeros de ligne retablis apres le bloc conditionnel ci-dessus
#else
#line 1240
#endif // __ZCK_LINK
	return FALSE;
}

BOOL TextCmd_DeclWar(CScanner& scanner)
{
	return FALSE;
}

BOOL TextCmd_GuildStat(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	scanner.GetToken();
	CString strstat = scanner.Token;

	strstat.MakeLower();

	if (strstat == "logo")
	{
		DWORD dwLogo = scanner.GetNumber();
		TRACE("guild Logo:%d\n", dwLogo);
		g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_LOGO, dwLogo);
	}
	else if (strstat == "pxp")
	{
		DWORD dwPxpCount = scanner.GetNumber();
		TRACE("guild pxpCount:%d\n", dwPxpCount);
		g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_PXPCOUNT, dwPxpCount);
	}
	else if (strstat == "penya")
	{
		DWORD dwPenya = scanner.GetNumber();
		TRACE("guild dwPenya:%d\n", dwPenya);
		g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_PENYA, dwPenya);
	}
	else if (strstat == "notice")
	{
		scanner.GetToken();
		TRACE("guild notice:%s\n", scanner.Token);
		g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_NOTICE, (DWORD)(LPCTSTR)scanner.Token);
	}
	else if (strstat == "level")
	{
		u_long idGuild = pUser->m_idGuild;
		CGuild* pGuild = g_GuildMng.GetGuild(idGuild);

		if (pGuild)
		{
			DWORD dwLevel = scanner.GetNumber();
			if (dwLevel > MAX_GUILD_LEVEL)
				dwLevel = MAX_GUILD_LEVEL;

			else if (dwLevel < 1 || dwLevel == NULL)
				dwLevel = 1;

			pGuild->m_nLevel = dwLevel;
			TRACE("guild level:%d\n", dwLevel);
			g_DPCoreClient.SendGuildStat(pUser, GUILD_STAT_LEVEL, 0);
		}
	}
	else
	{
#ifdef __ZCK_TRAD_FR
		strstat += " : erreur de syntaxe de la commande de statistiques de guilde.";
#else
		strstat += "syntax error guild stat command.";
#endif // __ZCK_TRAD_FR
		pUser->AddText(strstat);
	}

#endif
	return FALSE;
}

BOOL TextCmd_SetGuildQuest(CScanner& s)
{
#ifdef __WORLDSERVER

	s.GetToken();
	char sGuild[MAX_G_NAME];
	lstrcpy(sGuild, s.Token);
	int nQuestId = s.GetNumber();
	int nState = s.GetNumber();
	GUILDQUESTPROP* pProp = prj.GetGuildQuestProp(nQuestId);
	if (!pProp)
		return FALSE;

	CGuild* pGuild = g_GuildMng.GetGuild(sGuild);
	if (pGuild)
	{
		if (nState < QS_BEGIN || nState > QS_END)
		{
		}
		else
		{
			pGuild->SetQuest(nQuestId, nState);
			g_dpDBClient.SendUpdateGuildQuest(pGuild->m_idGuild, nQuestId, nState);
		}
	}
	return TRUE;

#endif	// __WORLDSERVER
	return FALSE;
}

BOOL TextCmd_PartyLevel(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	DWORD dwLevel = scanner.GetNumber();
	DWORD dwPoint = scanner.GetNumber();
	if (dwPoint == 0)
		dwPoint = 100;

	TRACE("plv LV:%d POINT:%d\n", dwLevel, dwPoint);

	CParty* pParty;
	pParty = g_PartyMng.GetParty(pUser->GetPartyId());
	if (pParty)
	{
		pParty->SetPartyLevel(pUser, dwLevel, dwPoint, pParty->GetExp());
	}
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_whisper(CScanner& scanner)
{
#ifdef __WORLDSERVER
	static	CHAR	lpString[260];

	CUser* pUser = (CUser*)scanner.dwValue;
	if (pUser->IsMode(SAYTALK_MODE))
		return TRUE;
#ifdef __JEFF_9_20
	int nText = pUser->GetMuteText();
	if (nText)
	{
		pUser->AddDefinedText(nText);
		return TRUE;
	}
#endif	// __JEFF_9_20

	scanner.GetToken();

	if (strcmp(pUser->GetName(), scanner.Token))
	{
		u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
		if (idPlayer > 0)
		{
#ifdef __ZCK_FENETRE_CHAT_MJ
			// GetLastFull() ecrase token PUIS fait Token = token
			// (_Common/scanner.cpp l.572). Le nom de la cible doit donc
			// etre recopie AVANT l'appel, sinon la capture recoit le
			// corps du message a la place du destinataire.
			TCHAR szZckChatMjTo[ZCK_CHATMJ_NAME_MAX];
			_tcsncpy(szZckChatMjTo, (LPCTSTR)scanner.Token, ZCK_CHATMJ_NAME_MAX - 1);
			szZckChatMjTo[ZCK_CHATMJ_NAME_MAX - 1] = '\0';
#endif // __ZCK_FENETRE_CHAT_MJ

			scanner.GetLastFull();
			if (strlen(scanner.token) >= 260)
				return TRUE;
			strcpy(lpString, scanner.token);

			StringTrimRight(lpString);

			if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
			{
				ParsingEffect(lpString, strlen(lpString));
			}
			RemoveCRLF(lpString);
			Removeat(lpString);
#ifdef __ZCK_LINK
			ZckLienAssainir(pUser, lpString);
#else
#line 1414
#endif // __ZCK_LINK


			if (0 < strlen(lpString))
			{
#ifdef __ZCK_FENETRE_CHAT_MJ
				CZckChatMjManager::GetInstance()->Capture(
					ZCK_CHATMJ_CAT_PRIVE, pUser, szZckChatMjTo, lpString);
#endif // __ZCK_FENETRE_CHAT_MJ
				g_DPCoreClient.SendWhisper(pUser->m_idPlayer, idPlayer, lpString);
			}
		}
		else
		{
			pUser->AddReturnSay(3, scanner.Token);
		}
	}
	else
	{
		pUser->AddReturnSay(2, " ");
	}
#endif	// __WORLDSERVER
#ifdef __ZCK_LINK
// define retire : numeros de ligne retablis apres le bloc conditionnel ci-dessus
#else
#line 1435
#endif // __ZCK_LINK

	return TRUE;
}

BOOL TextCmd_say(CScanner& scanner)
{
#ifdef __WORLDSERVER
	static	CHAR	lpString[1024];
	CUser* pUser = (CUser*)scanner.dwValue;

	if (pUser->IsMode(SAYTALK_MODE))
		return TRUE;
#ifdef __JEFF_9_20
	int nText = pUser->GetMuteText();
	if (nText)
	{
		pUser->AddDefinedText(nText);
		return TRUE;
	}
#endif	// __JEFF_9_20

	scanner.GetToken();
	if (strcmp(pUser->GetName(), scanner.Token))
	{
		u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
		if (idPlayer > 0)
		{
#ifdef __ZCK_FENETRE_CHAT_MJ
			// Meme piege que dans TextCmd_whisper : GetLastFull() ecrase
			// Token avec le corps du message (scanner.cpp l.572).
			TCHAR szZckChatMjTo[ZCK_CHATMJ_NAME_MAX];
			_tcsncpy(szZckChatMjTo, (LPCTSTR)scanner.Token, ZCK_CHATMJ_NAME_MAX - 1);
			szZckChatMjTo[ZCK_CHATMJ_NAME_MAX - 1] = '\0';
#endif // __ZCK_FENETRE_CHAT_MJ

			scanner.GetLastFull();
			if (strlen(scanner.token) >= 260)
				return TRUE;

			strcpy(lpString, scanner.token);

			StringTrimRight(lpString);

			if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
			{
				ParsingEffect(lpString, strlen(lpString));
			}
			RemoveCRLF(lpString);
			Removeat(lpString);
#ifdef __ZCK_LINK
			ZckLienAssainir(pUser, lpString);
#else
#line 1484
#endif // __ZCK_LINK

#ifdef __ZCK_FENETRE_CHAT_MJ
			CZckChatMjManager::GetInstance()->Capture(
				ZCK_CHATMJ_CAT_PRIVE, pUser, szZckChatMjTo, lpString);
#endif // __ZCK_FENETRE_CHAT_MJ

			g_DPCoreClient.SendSay(pUser->m_idPlayer, idPlayer, lpString);
		}
		else
		{
			pUser->AddReturnSay(3, scanner.Token);
		}
	}
	else
	{
		pUser->AddReturnSay(2, " ");
	}

#endif	// __WORLDSERVER
#ifdef __ZCK_LINK
// define retire : numeros de ligne retablis apres le bloc conditionnel ci-dessus
#else
#line 1503
#endif // __ZCK_LINK
	return TRUE;
}

BOOL TextCmd_ResistItem(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	DWORD dwObjId = scanner.GetNumber();
	BYTE bItemResist = scanner.GetNumber();
	int nResistAbilityOption = scanner.GetNumber();
	int nAbilityOption = scanner.GetNumber();

	if (bItemResist < 0 || 5 < bItemResist)
	{
		return FALSE;
	}

	if (nResistAbilityOption < 0 || CItemUpgrade::GetInstance()->GetMaxAttributeEnchantSize() < nResistAbilityOption
		|| nAbilityOption < 0 || CItemUpgrade::GetInstance()->GetMaxGeneralEnchantSize() < nAbilityOption)
	{
		return FALSE;
	}

	if (bItemResist == 0)
	{
		nResistAbilityOption = 0;
	}

	CItemElem* pItemElem0 = pUser->m_Inventory.GetAtId(dwObjId);
	if (!pItemElem0)
		return FALSE;

	if (pUser->m_Inventory.IsEquip(dwObjId))
	{
		pUser->AddDefinedText(TID_GAME_EQUIPPUT, "");
		return FALSE;
	}

	ItemProp* pProp = pItemElem0->GetProp();
	if (!pProp)
		return FALSE;

	if (!pProp->IsEleRefineryAble())
	{
		bItemResist = 0;
		nResistAbilityOption = 0;
	}

	pUser->UpdateItem((BYTE)(pItemElem0->m_dwObjId), UI_IR, bItemResist);
	pUser->UpdateItem((BYTE)(pItemElem0->m_dwObjId), UI_RAO, nResistAbilityOption);
	pUser->UpdateItem((BYTE)(pItemElem0->m_dwObjId), UI_AO, nAbilityOption);
	if (nAbilityOption > 5 && pItemElem0->GetProp()->dwReferStat1 == WEAPON_ULTIMATE)
		pUser->UpdateItem((BYTE)pItemElem0->m_dwObjId, UI_ULTIMATE_PIERCING_SIZE, nAbilityOption - 5);
#else // __WORLDSEVER
#ifdef __CLIENT
	if (g_WndMng.m_pWndUpgradeBase == NULL)
	{
		SAFE_DELETE(g_WndMng.m_pWndUpgradeBase);
		g_WndMng.m_pWndUpgradeBase = new CWndUpgradeBase;
		g_WndMng.m_pWndUpgradeBase->Initialize(&g_WndMng, APP_TEST);
		return FALSE;
	}

	BYTE bItemResist = scanner.GetNumber();
	int nResistAbilityOption = scanner.GetNumber();
	int nAbilityOption = scanner.GetNumber();
	if (bItemResist < 0 || 5 < bItemResist)
	{
		return FALSE;
	}

	if (nResistAbilityOption < 0 || 20 < nResistAbilityOption || nAbilityOption < 0 || 10 < nAbilityOption)
	{
		return FALSE;
	}

	if (bItemResist == 0)
	{
		nResistAbilityOption = 0;
	}

	if (g_WndMng.m_pWndUpgradeBase)
	{
		if (g_WndMng.m_pWndUpgradeBase->m_pItemElem[0])
		{
			DWORD dwObjId = g_WndMng.m_pWndUpgradeBase->m_pItemElem[0]->m_dwObjId;
			char szSkillLevel[MAX_PATH];
			sprintf(szSkillLevel, "/ritem %d %d %d %d", dwObjId, bItemResist, nResistAbilityOption, nAbilityOption);
			scanner.SetProg(szSkillLevel);
		}
		else
		{
			return FALSE;
		}
	}
	else
	{
		return FALSE;
	}
#endif // __CLIENT
#endif // __WORLDSERVER
	return TRUE;
}


BOOL TextCmd_Piercing(CScanner& scanner)
{
#if defined(__CLIENT) && defined(__ZCK_UPGRADE)
	scanner.GetNumber();
	if (scanner.tok == FINISHED && OpenZckUpgradeWindow())
		return FALSE;
#endif
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	DWORD dwObjId = scanner.GetNumber();
	BYTE bPierNum = scanner.GetNumber();

	CItemElem* pItemElem0 = pUser->m_Inventory.GetAtId(dwObjId);
	if (NULL == pItemElem0)
		return FALSE;

	if (bPierNum < 0 || bPierNum > MAX_PIERCING)
		return FALSE;

	if (pUser->m_Inventory.IsEquip(dwObjId))
	{
		pUser->AddDefinedText(TID_GAME_EQUIPPUT, "");
		return FALSE;
	}

	if (bPierNum < pItemElem0->GetPiercingSize())
	{
		pUser->UpdateItem((BYTE)pItemElem0->m_dwObjId, UI_PIERCING_SIZE, bPierNum);
		return TRUE;
	}

	for (int i = 1; i <= bPierNum; i++)
	{
#if __VER >= 12 // __EXT_PIERCING
		if (pItemElem0->IsPierceAble(NULL_ID, TRUE))
#endif // __EXT_PIERCING
			pUser->UpdateItem((BYTE)pItemElem0->m_dwObjId, UI_PIERCING_SIZE, i);
	}
#else // __WORLDSEVER

#endif // __WORLDSERVER
	return TRUE;
}

BOOL IsRight(CString& str)
{
	if (str.GetLength() == 1)
	{
		if (str.Find("#", 0) == 0)
			return FALSE;
	}
	else
		if (str.GetLength() == 2)
		{
			if (str.Find("#u", 0) == 0)
				return FALSE;

			if (str.Find("#b", 0) == 0)
				return FALSE;
		}

	int nFind = str.Find("#c", 0);
	if (nFind != -1)
	{
		if ((str.GetLength() - nFind) < 8)
			return FALSE;
	}

	return TRUE;
}

BOOL TextCmd_shout(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (pUser->IsMode(SHOUTTALK_MODE))
		return FALSE;

#ifdef __JEFF_9_20
	int nText = pUser->GetMuteText();
	if (nText)
	{
		pUser->AddDefinedText(nText);
		return FALSE;
	}
#endif	// 

	if ((GetLanguage() == LANG_TWN || GetLanguage() == LANG_HK) && pUser->GetLevel() < 15)
	{
		pUser->AddDefinedText(TID_GAME_CANNOT_SHOUT_BELOW_15_LEVEL);
		return FALSE;
	}

	char szString[1024];
	szString[0] = '\0';

	scanner.GetLastFull();
	if (strlen(scanner.token) >= 260)
		return TRUE;

	strcpy(szString, scanner.token);
	StringTrimRight(szString);

	if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
	{
		ParsingEffect(szString, strlen(szString));
	}
	RemoveCRLF(szString);
	Removeat(szString);
#ifdef __ZCK_LINK
	ZckLienAssainir(pUser, szString);
#else
#line 1719
#endif // __ZCK_LINK

	CAr arBlock;
	arBlock << NULL_ID << SNAPSHOTTYPE_SHOUT;
	arBlock << GETID(pUser);
	arBlock.WriteString(pUser->GetName());
	arBlock.WriteString(szString);

	DWORD dwColor = 0xffff99cc;
	if (pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_LS_SHOUT))
		dwColor = 0xff00ff00;
	arBlock << dwColor;

	GETBLOCK(arBlock, lpBlock, uBlockSize);

	int nRange = 0x000000ff;
	if (pUser->IsShoutFull())
		nRange = 0;

#ifdef __ZCK_FENETRE_CHAT_MJ
	CZckChatMjManager::GetInstance()->Capture(
		ZCK_CHATMJ_CAT_CRI, pUser, NULL, szString);
#endif // __ZCK_FENETRE_CHAT_MJ

	g_UserMng.AddShout(pUser, nRange, lpBlock, uBlockSize);
#else	// __WORLDSERVER
#ifdef __ZCK_LINK
// define retire : numeros de ligne retablis au debut de cette branche
#else
#line 1744
#endif // __ZCK_LINK
#ifdef __CLIENT

	static CTimer timerDobe;
	static CString stringBack;
	static CTimeLimit timeLimit(g_Neuz.m_nShoutLimitCount, g_Neuz.m_dwShoutLimitSecond);

	CString string = scanner.m_pProg;

	CString strTrim = string;
	strTrim.TrimLeft();

	if (IsRight(strTrim) == FALSE)
		return FALSE;

	g_WndMng.WordChange(string);
	CString strCommand;
	strCommand.Format("/s %s", string);
	g_DPlay.SendChat(strCommand);

	return FALSE;
#endif // __CLIENT
#endif // __WORLDSERVER
#ifdef __ZCK_LINK
// define retire : numeros de ligne retablis apres le bloc conditionnel ci-dessus
#else
#line 1766
#endif // __ZCK_LINK
	return TRUE;
}

BOOL TextCmd_PartyChat(CScanner& scanner)
{
#ifdef __WORLDSERVER
	static	\
		CHAR lpString[260];

	CUser* pUser = (CUser*)scanner.dwValue;

#ifdef __JEFF_9_20
	int nText = pUser->GetMuteText();
	if (nText)
	{
		pUser->AddDefinedText(nText);
		return TRUE;
	}
#endif	// __JEFF_9_20

	lpString[0] = '\0';

	scanner.GetLastFull();
	if (lstrlen(scanner.token) >= 260)
		return TRUE;
	strcpy(lpString, scanner.token);

	StringTrimRight(lpString);

	if (!(pUser->HasBuff(BUFF_ITEM, II_SYS_SYS_SCR_FONTEDIT)))
	{
		ParsingEffect(lpString, strlen(lpString));
	}
	RemoveCRLF(lpString);
	Removeat(lpString);
#ifdef __ZCK_LINK
	ZckLienAssainir(pUser, lpString);
#else
#line 1801
#endif // __ZCK_LINK

	CParty* pParty;

	pParty = g_PartyMng.GetParty(pUser->GetPartyId());
	if (pParty && pParty->IsMember(pUser->m_idPlayer))
	{
#ifdef __ZCK_FENETRE_CHAT_MJ
		CZckChatMjManager::GetInstance()->Capture(
			ZCK_CHATMJ_CAT_GROUPE, pUser, pParty->m_sParty, lpString);
#endif // __ZCK_FENETRE_CHAT_MJ
		g_DPCoreClient.SendPartyChat(pUser, lpString);
	}
	else
	{

		pUser->AddSendErrorParty(ERROR_NOPARTY);
	}


#else // __WORLDSERVER
#ifdef __ZCK_LINK
// define retire : numeros de ligne retablis au debut de cette branche
#else
#line 1821
#endif // __ZCK_LINK
#ifdef __CLIENT
	if (g_Party.GetSizeofMember() >= 2)
	{
		CString string = scanner.m_pProg;
		g_WndMng.WordChange(string);

		if (::GetLanguage() == LANG_THA)
			string = '"' + string + '"';

		CString strCommand;
		strCommand.Format("/p %s", string);
		g_DPlay.SendChat(strCommand);
	}
	else
	{



		g_WndMng.PutString(prj.GetText(TID_GAME_PARTYNOTCHAT), NULL, prj.GetTextColor(TID_GAME_PARTYNOTCHAT));

	}
	return FALSE;
#endif // __CLIENT
#endif // __WORLDSERVER
#ifdef __ZCK_LINK
// define retire : numeros de ligne retablis apres le bloc conditionnel ci-dessus
#else
#line 1845
#endif // __ZCK_LINK
	return TRUE;
}


BOOL TextCmd_Music(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	u_long idmusic = scanner.GetNumber();
	g_DPCoreClient.SendPlayMusic(pUser->GetWorld()->GetID(), idmusic);
#endif	// __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_Sound(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	u_long idsound = scanner.GetNumber();
	g_DPCoreClient.SendPlaySound(pUser->GetWorld()->GetID(), idsound);
#endif	// __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_Summon(CScanner& scanner)
{
#ifdef __WORLDSERVER
	scanner.GetToken();
	CUser* pUser = (CUser*)scanner.dwValue;

	const u_long idSummonPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
	if (pUser->m_idPlayer == idSummonPlayer)
	{
		pUser->AddReturnSay(2, " ");
		return TRUE;
	}

	CUser* pDestUser = g_UserMng.GetUserByPlayerID(idSummonPlayer);
	if (IsValidObj(pDestUser) == FALSE)
	{
		pUser->AddReturnSay(3, scanner.Token);
		return TRUE;
	}

	pUser->SummonPlayer(pDestUser);
#endif	// __WORLDSERVER
	return TRUE;
}

#ifdef __PET_1024
BOOL TextCmd_ClearPetName(CScanner& s)
{
#ifdef __CLIENT
	g_DPlay.SendClearPetName();
#endif	// __CLIENT
	return TRUE;
}

BOOL TextCmd_SetPetName(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CPet* pPet = pUser->GetPet();
	if (!pPet)
		return TRUE;
	s.GetToken();
	pPet->SetName(s.token);
	g_UserMng.AddSetPetName(pUser, s.token);
#endif	// __WORLDSERVER
	return TRUE;
}
#endif	// __PET_1024

#ifdef __LAYER_1020
BOOL TextCmd_CreateLayer(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	DWORD dwWorld = s.GetNumber();
	CWorld* pWorld = g_WorldMng.GetWorld(dwWorld);
	if (pWorld)
	{
		int nLayer = s.GetNumber();
		pWorld->CreateLayer(nLayer);
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_DeleteLayer(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	DWORD dwWorld = s.GetNumber();
	CWorld* pWorld = g_WorldMng.GetWorld(dwWorld);
	if (pWorld)
	{
		int nLayer = s.GetNumber();
		pWorld->ReleaseLayer(nLayer);		// do not call ReleaseLayer directly
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Layer(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	DWORD dwWorld = s.GetNumber();
	CWorld* pWorld = g_WorldMng.GetWorld(dwWorld);
	if (pWorld)
	{
		int nLayer = s.GetNumber();
		CLinkMap* pLinkMap = pWorld->m_linkMap.GetLinkMap(nLayer);
		if (pLinkMap)
		{
			FLOAT x = s.GetFloat();
			FLOAT z = s.GetFloat();
			if (pWorld->VecInWorld(x, z) && x > 0 && z > 0)
				pUser->REPLACE(g_uIdofMulti, pWorld->GetID(), D3DXVECTOR3(x, 0, z), REPLACE_NORMAL, nLayer);
			else
#ifdef __ZCK_TRAD_FR
				pUser->AddText("HORS DU MONDE");
		}
		else
		{
			pUser->AddText("COUCHE INEXISTANTE");
#else
				pUser->AddText("OUT OF WORLD");
		}
		else
		{
			pUser->AddText("LAYER NO EXISTS");
#endif // __ZCK_TRAD_FR
		}
	}
	else
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("MONDE NON D\311FINI");
#else
		pUser->AddText("UNDEFINED WORLD");
#endif // __ZCK_TRAD_FR
	}
#endif	// __WORLDSERVER
	return TRUE;
}
#endif	// __LAYER_1020

#if __VER >= 13 // __COUPLE_1117
#if __VER >= 13 // __COUPLE_1202
BOOL TextCmd_NextCoupleLevel(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CCouple* pCouple = CCoupleHelper::Instance()->GetCouple(pUser->m_idPlayer);
	if (pCouple)
	{
		if (pCouple->GetLevel() < CCouple::eMaxLevel)
		{
			int nExperience = CCoupleProperty::Instance()->GetTotalExperience(pCouple->GetLevel() + 1) - pCouple->GetExperience();
			g_dpDBClient.SendQueryAddCoupleExperience(pUser->m_idPlayer, nExperience);
		}
		else
#ifdef __ZCK_TRAD_FR
			pUser->AddText("NIVEAU DE COUPLE MAXIMAL");
	}
	else
		pUser->AddText("COUPLE INTROUVABLE");
#else
			pUser->AddText("MAX COUPLE LEVEL");
	}
	else
		pUser->AddText("COUPLE NOT FOUND");
#endif // __ZCK_TRAD_FR
#endif	// __WORLDSERVER
	return TRUE;
}
#endif	// __COUPLE_1202

BOOL TextCmd_Propose(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	s.GetToken();
	CCoupleHelper::Instance()->OnPropose(pUser, s.token);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Refuse(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CCoupleHelper::Instance()->OnRefuse(pUser);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Couple(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CCoupleHelper::Instance()->OnCouple(pUser);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Decouple(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CCoupleHelper::Instance()->OnDecouple(pUser);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ClearPropose(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	g_dpDBClient.SendClearPropose();
#endif	// __WORLDSERVER
	return TRUE;
}
#endif	// __COUPLE_1117

BOOL TextCmd_Teleport(CScanner& scanner)
{
#ifdef __WORLDSERVER
	TCHAR* lpszPlayer = NULL;
	int x, z;
	CUser* pUser = (CUser*)scanner.dwValue;


	int nTok = scanner.GetToken();
	if (nTok != NUMBER)
	{
		u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
		CUser* pUserTarget = static_cast<CUser*>(prj.GetUserByID(idPlayer));
		if (IsValidObj(pUserTarget))
		{
			CWorld* pWorld = pUserTarget->GetWorld();
			if (pWorld)
			{
				pUser->REPLACE(g_uIdofMulti, pWorld->GetID(), pUserTarget->GetPos(), REPLACE_NORMAL, pUserTarget->GetLayer());
			}
		}
		else
		{
			pUser->AddReturnSay(3, scanner.m_mszToken);
		}
	}

	DWORD dwWorldId = atoi(scanner.token);
#if __VER >= 14 // __INSTANCE_DUNGEON
	if (CInstanceDungeonHelper::GetInstance()->IsInstanceDungeon(dwWorldId))
	{
		if (pUser->GetWorld() && pUser->GetWorld()->GetID() != dwWorldId)
			return TRUE;
	}
#endif // __INSTANCE_DUNGEON
	if (g_WorldMng.GetWorldStruct(dwWorldId))
	{

		if (scanner.GetToken() != NUMBER)
		{
			PRegionElem pRgnElem = g_WorldMng.GetRevivalPos(dwWorldId, scanner.token);
			if (NULL != pRgnElem)
				pUser->REPLACE(g_uIdofMulti, pRgnElem->m_dwWorldId, pRgnElem->m_vPos, REPLACE_NORMAL, nRevivalLayer);
		}

		else
		{
			x = atoi(scanner.token);
			z = scanner.GetNumber();

			CWorld* pWorld = g_WorldMng.GetWorld(dwWorldId);
			if (pWorld && pWorld->VecInWorld((FLOAT)(x), (FLOAT)(z)) && x > 0 && z > 0)
			{
				int nLayer = pWorld == pUser->GetWorld() ? pUser->GetLayer() : nDefaultLayer;
				pUser->REPLACE(g_uIdofMulti, dwWorldId, D3DXVECTOR3((FLOAT)x, 0, (FLOAT)z), REPLACE_NORMAL, nLayer);
			}
		}
	}
#endif // __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_Out(CScanner& scanner)
{
#ifdef __WORLDSERVER
	//	TCHAR lpszPlayer[MAX_PLAYER];
	scanner.GetToken();

	CUser* pUser = (CUser*)scanner.dwValue;
	if (strcmp(pUser->GetName(), scanner.Token))
	{
		u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);

		if (idPlayer > 0) {
			g_DPCoreClient.SendKillPlayer(pUser->m_idPlayer, idPlayer);
		}
		else {

			pUser->AddReturnSay(3, scanner.Token);
		}
	}
	else
	{
		pUser->AddReturnSay(2, " ");
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_RemoveNpc(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	OBJID objid = (OBJID)s.GetNumber();

	CMover* pMover = prj.GetMover(objid);
	if (IsValidObj((CObj*)pMover))
	{
		if (pMover->IsNPC())
			pMover->Delete();
	}
#endif	// __WORLDSERVER
	return TRUE;
}


BOOL TextCmd_CreateItem2(CScanner& s)
{
#ifdef __WORLDSERVER
	s.GetToken();
	ItemProp* pItemProp = prj.GetItemProp(s.Token);
	if (pItemProp && pItemProp->dwItemKind3 != IK3_VIRTUAL)
	{
		int nRandomOptItemId = s.GetNumber();
		PRANDOMOPTITEM pRandomOptItem = CRandomOptItemGen::GetInstance()->GetRandomOptItem(nRandomOptItemId);
		if (pRandomOptItem)
		{
			CItemElem itemElem;
			itemElem.m_dwItemId = pItemProp->dwID;
			itemElem.m_nItemNum = 1;
			itemElem.m_nHitPoint = -1;
			itemElem.SetRandomOpt(pRandomOptItem->nId);
			CUser* pUser = (CUser*)s.dwValue;
			pUser->CreateItem(&itemElem);
		}
	}
	return TRUE;
#else	// __WORLDSERVER
	return TRUE;
#endif	// __WORLDSERVER
}

BOOL TextCmd_CreateItem(CScanner& scanner)
{
	scanner.GetToken();

#ifdef __CLIENT

	if (scanner.tok == FINISHED)
	{
		return FALSE;
	}
	return TRUE;
#else   // __CLIENT
	short nNum;
	DWORD dwCharged = 0;
	ItemProp* pProp = NULL;

	if (scanner.tokenType == NUMBER)
		pProp = prj.GetItemProp(_ttoi(scanner.Token));
	else
		pProp = prj.GetItemProp(scanner.Token);

	if (pProp && pProp->dwItemKind3 != IK3_VIRTUAL)
	{
		if (pProp->dwItemKind3 == IK3_EGG && pProp->dwID != II_PET_EGG)
			return TRUE;

		nNum = scanner.GetNumber();
		if (nNum < 1 || nNum > 9999)
			nNum = 1;
		dwCharged = scanner.GetNumber();
		dwCharged = (dwCharged == 0 ? 0 : 1);

		CItemElem itemElem;
		itemElem.m_dwItemId = pProp->dwID;
		itemElem.m_nItemNum = (short)(nNum);
		itemElem.m_nHitPoint = -1;

		CUser* pUser = (CUser*)scanner.dwValue;
		pUser->CreateItem(&itemElem);
	}
#endif	// !__CLIENT
	return TRUE;
}

BOOL TextCmd_LocalEvent(CScanner& s)
{
	return TRUE;
}


BOOL TextCmd_CreateChar(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	D3DXVECTOR3 vPos = pUser->GetPos();
	CWorld* pWorld = pUser->GetWorld();

	MoverProp* pMoverProp = NULL;

	scanner.GetToken();
	if (scanner.tokenType == NUMBER)
	{
		DWORD dwID = _ttoi(scanner.Token);
		pMoverProp = prj.GetMoverPropEx(dwID);
	}
	else
		pMoverProp = prj.GetMoverProp(scanner.Token);

	scanner.GetToken();
	CString strName = scanner.Token;

	if (pMoverProp && pMoverProp->dwID != 0)
	{
		DWORD dwNum = scanner.GetNumber();
		if (dwNum > 100) dwNum = 100;
		if (dwNum == 0) dwNum = 1;

		BOOL bActiveAttack = scanner.GetNumber();
		for (DWORD dw = 0; dw < dwNum; dw++)
		{
			CMover* pMover = (CMover*)CreateObj(D3DDEVICE, OT_MOVER, pMoverProp->dwID);
			if (NULL == pMover) return FALSE; // ASSERT( pObj );
			strcpy(pMover->m_szCharacterKey, strName);
			pMover->InitNPCProperty();
			pMover->InitCharacter(pMover->GetCharacter());
			pMover->SetPos(vPos);
			pMover->InitMotion(MTI_STAND);
			pMover->UpdateLocalMatrix();
			if (bActiveAttack)
				pMover->m_bActiveAttack = bActiveAttack;
			if (pWorld->ADDOBJ(pMover, TRUE, pUser->GetLayer()) == FALSE)
			{
				SAFE_DELETE(pMover);
			}
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_CreateCtrl(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	D3DXVECTOR3 vPos = pUser->GetPos();
	CWorld* pWorld = pUser->GetWorld();

	DWORD dwID = s.GetNumber();

	if (dwID == 0)
		return FALSE;

	CCtrl* pCtrl = (CCtrl*)CreateObj(D3DDEVICE, OT_CTRL, dwID);
	if (!pCtrl)
		return FALSE;

	pCtrl->SetPos(vPos);
	if (pWorld->ADDOBJ(pCtrl, TRUE, pUser->GetLayer()) == FALSE)
	{
		SAFE_DELETE(pCtrl);
	}
#endif	// __WORLDSERVER
	return TRUE;
}

#if __VER >= 9 // __EVENTLUA
BOOL TextCmd_Lua(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	s.GetToken();
	s.Token.MakeLower();

	if (s.Token == "event")
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Rechargement de Event.lua...");
#else
		pUser->AddText("Event.lua Reload...");
#endif // __ZCK_TRAD_FR
		Error("Event.lua Reload... - %s", pUser->GetName());
		g_dpDBClient.SendEventLuaChanged();
	}
#if __VER >= 12 // __MONSTER_SKILL
	else if (s.Token == "ms")
	{
		CMonsterSkill::GetInstance()->Clear();
		CMonsterSkill::GetInstance()->LoadScript();
	}
#endif // __MONSTER_SKILL
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_LuaEventList(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	prj.m_EventLua.GetAllEventList(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_LuaEventInfo(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	prj.m_EventLua.GetEventInfo(pUser, s.GetNumber());
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __EVENTLUA

#ifdef __JEFF_9_20
BOOL TextCmd_Mute(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	s.GetToken();
	if (s.tok == FINISHED)
		return TRUE;

	u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);

	if (idPlayer == 0)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("joueur introuvable");
#else
		pUser->AddText("player not found");
#endif // __ZCK_TRAD_FR
		return TRUE;
	}
	CUser* pTarget = g_UserMng.GetUserByPlayerID(idPlayer);
	if (IsValidObj(pTarget))
	{
		DWORD dwMute = (DWORD)s.GetNumber();
		if (s.tok == FINISHED)
			return TRUE;
		pTarget->m_dwMute = dwMute;
	}
#endif	// __WORLDSERVER
	return TRUE;
}
#endif	// __JEFF_9_20

#if __VER >= 8 // __CSC_VER8_5
BOOL TextCmd_AngelExp(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int nAddExp = s.GetNumber();

	if (pUser->HasBuffByIk3(IK3_ANGEL_BUFF))
	{
		int nAngel = 100;
#ifdef __BUFF_1107
		IBuff* pBuff = pUser->m_buffs.GetBuffByIk3(IK3_ANGEL_BUFF);
		WORD wId = (pBuff ? pBuff->GetId() : 0);
#else	// __BUFF_1107
		LPSKILLINFLUENCE lpSkillIn = pUser->m_SkillState.GetItemBuf(IK3_ANGEL_BUFF);
		WORD wId = (lpSkillIn ? lpSkillIn->wID : 0);
#endif	// __BUFF_1107
		if (wId)
		{
			ItemProp* pItemProp = prj.GetItemProp(wId);
			if (pItemProp)
				nAngel = (int)((float)pItemProp->nAdjParamVal1);
		}
		if (nAngel <= 0 || 100 < nAngel)
			nAngel = 100;

		EXPINTEGER nMaxAngelExp = prj.m_aExpCharacter[pUser->m_nAngelLevel].nExp1 / 100 * nAngel;
		if (pUser->m_nAngelExp < nMaxAngelExp)
		{
			pUser->m_nAngelExp += nAddExp;
			BOOL bAngelComplete = FALSE;
			if (pUser->m_nAngelExp > nMaxAngelExp)
			{
				pUser->m_nAngelExp = nMaxAngelExp;
				bAngelComplete = TRUE;
			}
			pUser->AddAngelInfo(bAngelComplete);
		}
	}
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __CSC_VER8_5

BOOL TextCmd_CreateNPC(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	D3DXVECTOR3 vPos = pUser->GetPos();
	CWorld* pWorld = pUser->GetWorld();

	MoverProp* pMoverProp = NULL;

	scanner.GetToken();
	if (scanner.tokenType == NUMBER)
	{
		DWORD dwID = _ttoi(scanner.Token);
		pMoverProp = prj.GetMoverPropEx(dwID);
	}
	else
		pMoverProp = prj.GetMoverProp(scanner.Token);

	CString strName = scanner.Token;

	if (pMoverProp && pMoverProp->dwID != 0)
	{
		if (pMoverProp->dwAI != AII_MONSTER
			&& pMoverProp->dwAI != AII_CLOCKWORKS
			&& pMoverProp->dwAI != AII_BIGMUSCLE
			&& pMoverProp->dwAI != AII_KRRR
			&& pMoverProp->dwAI != AII_BEAR
			&& pMoverProp->dwAI != AII_METEONYKER
			)
			return TRUE;

		DWORD dwNum = scanner.GetNumber();
		if (dwNum > 100) dwNum = 100;
		if (dwNum == 0) dwNum = 1;

		BOOL bActiveAttack = scanner.GetNumber();
		for (DWORD dw = 0; dw < dwNum; dw++)
		{
			if (pWorld->GetObjCount() >= MAX_ADDOBJS || pWorld->GetObjCount() >= MAX_DYNAMICOBJ)
			{
				pUser->AddText("TextCmd_CreateNPC : MAX_ADDOBJS || MAX_DYNAMICOBJ");
				return FALSE;
			}

			CObj* pObj = CreateObj(D3DDEVICE, OT_MOVER, pMoverProp->dwID);
			if (NULL == pObj)
				return FALSE;
			pObj->SetPos(vPos);
			pObj->InitMotion(MTI_STAND);
			pObj->UpdateLocalMatrix();

			if (bActiveAttack)
				((CMover*)pObj)->m_bActiveAttack = bActiveAttack;

			((CMover*)pObj)->SetGold(((CMover*)pObj)->GetLevel() * 15);
			if (pWorld->ADDOBJ(pObj, TRUE, pUser->GetLayer()) == FALSE)
			{
				SAFE_DELETE(pObj);
			}
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Invisible(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->m_dwMode |= TRANSPARENT_MODE;
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_NoInvisible(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->m_dwMode &= (~TRANSPARENT_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_NoUndying(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->m_dwMode &= (~MATCHLESS_MODE);
	pUser->m_dwMode &= (~MATCHLESS2_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif
	return TRUE;
}


BOOL TextCmd_ExpUpStop(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->ChangeExpUpState();
#endif // __WORLDSERVER

	return TRUE;
}
BOOL TextCmd_PartyInvite(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	MoverProp* pMoverProp = NULL;
	scanner.GetToken();
	u_long uidPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
	if (0 < uidPlayer)
	{
		CUser* pUser2 = g_UserMng.GetUserByPlayerID(uidPlayer);
		if (IsValidObj(pUser2))
		{
			if (pUser != pUser2)
				g_DPSrvr.InviteParty(pUser->m_idPlayer, pUser2->m_idPlayer, FALSE);
		}
		else
			pUser->AddDefinedText(TID_DIAG_0060, "\"%s\"", scanner.Token);
	}
	else
	{
		pUser->AddDefinedText(TID_DIAG_0061, "\"%s\"", scanner.Token);
	}
#endif // __WORLDSERVER

	return TRUE;
}
BOOL TextCmd_GuildInvite(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	MoverProp* pMoverProp = NULL;
	scanner.GetToken();
	u_long uidPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
	if (0 < uidPlayer)
	{
		CUser* pUser2 = g_UserMng.GetUserByPlayerID(uidPlayer);
		if (IsValidObj(pUser2))
		{
			if (pUser != pUser2)
				g_DPSrvr.InviteCompany(pUser, pUser2->GetId());
		}
		else
			pUser->AddDefinedText(TID_DIAG_0060, "\"%s\"", scanner.Token);
	}
	else
	{
		pUser->AddDefinedText(TID_DIAG_0061, "\"%s\"", scanner.Token);
	}
#endif // __WORLDSERVER

	return TRUE;
}

BOOL TextCmd_Undying(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->m_dwMode &= (~MATCHLESS2_MODE);
	pUser->m_dwMode |= MATCHLESS_MODE;
	g_UserMng.AddModifyMode(pUser);
#else // __WORLDSERVER
#ifndef __CLIENT
	CMover* pUser = (CMover*)scanner.dwValue;
	pUser->m_dwMode &= (~MATCHLESS2_MODE);
	pUser->m_dwMode |= MATCHLESS_MODE;
#endif
#endif
	return TRUE;
}
BOOL TextCmd_Undying2(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->m_dwMode &= (~MATCHLESS_MODE);
	pUser->m_dwMode |= MATCHLESS2_MODE;
	g_UserMng.AddModifyMode(pUser);
#else // __WORLDSERVER
#ifndef __CLIENT
	CMover* pUser = (CMover*)scanner.dwValue;
	pUser->m_dwMode &= (~MATCHLESS_MODE);
	pUser->m_dwMode |= MATCHLESS2_MODE;
#endif
#endif
	return TRUE;
}


BOOL TextCmd_Disguise(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	MoverProp* pMoverProp = NULL;
	scanner.GetToken();
	if (scanner.tokenType == NUMBER)
	{
		DWORD dwID = _ttoi(scanner.Token);
		pMoverProp = prj.GetMoverPropEx(dwID);
	}
	else
		pMoverProp = prj.GetMoverProp(scanner.Token);

	if (pMoverProp)
		g_UserMng.AddDisguise(pUser, pMoverProp->dwID);
#endif
	return TRUE;
}
BOOL TextCmd_NoDisguise(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_UserMng.AddNoDisguise(pUser);
#endif // __WORLDSERVER
	return TRUE;
}


BOOL TextCmd_Freeze(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	scanner.GetToken();

	if (strcmp(pUser->GetName(), scanner.Token))
	{
		u_long idFrom, idTo;

		idFrom = CPlayerDataCenter::GetInstance()->GetPlayerId((char*)pUser->GetName());
		idTo = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
		if (idFrom > 0 && idTo > 0)
		{
			g_DPCoreClient.SendModifyMode(DONMOVE_MODE, (BYTE)1, idFrom, idTo);
		}
		else
		{

			pUser->AddReturnSay(3, scanner.Token);
		}
	}
	else
	{
		pUser->AddReturnSay(2, " ");
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_NoFreeze(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	scanner.GetToken();
	if (strcmp(pUser->GetName(), scanner.Token))
	{
		u_long idFrom, idTo;

		idFrom = CPlayerDataCenter::GetInstance()->GetPlayerId((char*)pUser->GetName());
		idTo = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);

		if (idFrom > 0 && idTo > 0)
		{
			g_DPCoreClient.SendModifyMode(DONMOVE_MODE, (BYTE)0, idFrom, idTo);
		}
		else
		{

			pUser->AddReturnSay(3, scanner.Token);
		}
	}
	else
	{
		pUser->AddReturnSay(2, " ");
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Talk(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;

	scanner.GetToken();

	u_long idFrom, idTo;
	idFrom = CPlayerDataCenter::GetInstance()->GetPlayerId((char*)pUser->GetName());
	idTo = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);

	if (idFrom > 0 && idTo > 0)
	{
		g_DPCoreClient.SendModifyMode(DONTALK_MODE, (BYTE)0, idFrom, idTo);
	}
	else
	{

		pUser->AddReturnSay(3, scanner.Token);
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_NoTalk(CScanner& scanner)
{
#ifdef __WORLDSERVER

	CUser* pUser = (CUser*)scanner.dwValue;

	scanner.GetToken();

	{
		u_long idFrom, idTo;
		idFrom = CPlayerDataCenter::GetInstance()->GetPlayerId((char*)pUser->GetName());
		idTo = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);

		if (idFrom > 0 && idTo > 0)
		{
			g_DPCoreClient.SendModifyMode(DONTALK_MODE, (BYTE)1, idFrom, idTo);
		}
		else
		{

			pUser->AddReturnSay(3, scanner.Token);
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_GetGold(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	int nGold = scanner.GetNumber();
	pUser->AddGold(nGold, TRUE, false);
#endif	// __WORLDSERVER
	return TRUE;
}


BOOL TextCmd_indirect(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	DWORD dwIdNPC = scanner.GetNumber();
	TCHAR szString[1024];

	scanner.GetLastFull();
	if (strlen(scanner.token) >= 260)
		return TRUE;
	strcpy(szString, scanner.token);
	StringTrimRight(szString);

	if (szString[0])
	{
		CMover* pMover = prj.GetMover(dwIdNPC);
		if (pMover)
			g_UserMng.AddChat((CCtrl*)pMover, (LPCSTR)szString);
	}
#else // __WORLDSERVER
	scanner.GetToken();
	if (g_pPlayer->IsAuthHigher(AUTH_GAMEMASTER))
	{
		if (scanner.tok == FINISHED)
		{
			SAFE_DELETE(g_WndMng.m_pWndIndirectTalk);
			g_WndMng.m_pWndIndirectTalk = new CWndIndirectTalk;
			g_WndMng.m_pWndIndirectTalk->Initialize();
			return FALSE;
		}
	}
#endif // __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_ItemMode(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->SetMode(ITEM_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ItemNotMode(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->SetNotMode(ITEM_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_AttackMode(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->SetMode(NO_ATTACK_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_EscapeReset(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	CMover* pMover = prj.GetUserByID(scanner.GetNumber());
	if (IsValidObj(pMover)) {
		pMover->SetSMMode(SM_ESCAPE, 0);
	}
	else {
		pUser->SetSMMode(SM_ESCAPE, 0);
	}
#else	// __WORLDSERVER
#ifdef __CLIENT
	CWorld* pWorld = g_WorldMng.Get();
	CObj* pObj;

	pObj = pWorld->GetObjFocus();
	if (pObj && pObj->GetType() == OT_MOVER && ((CMover*)pObj)->IsPlayer())
	{
		CMover* pMover = (CMover*)pObj;
		CString strSend;
		if (pMover->IsPlayer())
		{
			strSend.Format("/EscapeReset %d", pMover->m_idPlayer);
		}

		g_DPlay.SendChat((LPCSTR)strSend);

		return FALSE;
	}
#endif //__CLIENT
#endif	// __WORLDSERVER
	return TRUE;
}



BOOL TextCmd_AttackNotMode(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->SetNotMode(NO_ATTACK_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_CommunityMode(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->SetMode(COMMUNITY_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_CommunityNotMode(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->SetNotMode(COMMUNITY_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ObserveMode(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->SetMode(OBSERVE_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ObserveNotMode(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->SetNotMode(OBSERVE_MODE);
	g_UserMng.AddModifyMode(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Onekill(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->m_dwMode |= ONEKILL_MODE;
	g_UserMng.AddModifyMode(pUser);
#else // __WORLDSERVER
#ifndef __CLIENT
	CMover* pUser = (CMover*)scanner.dwValue;
	pUser->m_dwMode |= ONEKILL_MODE;
#endif
#endif
	return TRUE;
}
BOOL TextCmd_Position(CScanner& scanner)
{
#ifdef __CLIENT
	CString string;
	D3DXVECTOR3 vPos = g_pPlayer->GetPos();

	string.Format(prj.GetText(TID_GAME_NOWPOSITION), vPos.x, vPos.y, vPos.z);
	g_WndMng.PutString(string, NULL, prj.GetTextColor(TID_GAME_NOWPOSITION));
#endif // __CLIENT
	return TRUE;
}

BOOL TextCmd_NoOnekill(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->m_dwMode &= (~ONEKILL_MODE);
	g_UserMng.AddModifyMode(pUser);
#else // __WORLDSERVER
#ifndef __CLIENT
	CMover* pUser = (CMover*)scanner.dwValue;
	pUser->m_dwMode &= (~ONEKILL_MODE);
#endif
#endif
	return TRUE;
}
BOOL TextCmd_ip(CScanner& scanner)
{
#ifdef __WORLDSERVER
	scanner.GetToken();

	CUser* pUser = (CUser*)scanner.dwValue;
	u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
	if (idPlayer > 0)
		g_DPCoreClient.SendGetPlayerAddr(pUser->m_idPlayer, idPlayer);
	else
		pUser->AddReturnSay(3, scanner.Token);
#else	// __WORLDSERVER
#ifdef __CLIENT
	CWorld* pWorld = g_WorldMng.Get();
	CObj* pObj;

	pObj = pWorld->GetObjFocus();
	if (pObj && pObj->GetType() == OT_MOVER)
	{
		CMover* pMover = (CMover*)pObj;
		CString strSend;
		if (pMover->IsPlayer())
		{
			strSend.Format("/ip %s", pMover->GetName());
		}
		else
		{
			strSend.Format("%s", scanner.m_pBuf);
		}
		g_DPlay.SendChat((LPCSTR)strSend);
		return FALSE;
	}
#endif //__CLIENT
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_userlist(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_DPCoreClient.SendGetCorePlayer(pUser->m_idPlayer);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_count(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_DPCoreClient.SendGetPlayerCount(pUser->m_idPlayer);

	char szCount[128] = { 0, };
#ifdef __ZCK_TRAD_FR
	sprintf(szCount, "Joueurs en ligne : %d", g_UserMng.GetCount());
#else
	sprintf(szCount, "Players online: %d", g_UserMng.GetCount());
#endif // __ZCK_TRAD_FR
	pUser->AddText(szCount);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_System(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CHAR szString[512] = "";

	CUser* pUser = (CUser*)scanner.dwValue;

	scanner.GetLastFull();
	if (strlen(scanner.token) >= 512)
		return TRUE;
	strcpy(szString, scanner.token);
	StringTrimRight(szString);

	g_DPCoreClient.SendSystem(szString);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_LoadScript(CScanner& scanner)
{
#ifdef __WORLDSERVER
#if defined(__REMOVE_SCIRPT_060712)
	if (CWorldDialog::GetInstance().Reload() == FALSE)
		Error("WorldScript.dll reload error");
#else
	CUser* pUser = (CUser*)scanner.dwValue;
	pUser->GetWorld()->LoadAllMoverDialog();
#endif
#endif
	return TRUE;
}

#ifdef __ZCK_WEATHER

BOOL TextCmd_TestRain(CScanner& scanner)
{
#ifdef __CLIENT
	if (!g_pPlayer)
		return FALSE;

	CWorld* pWorld = g_pPlayer->GetWorld();
	if (!pWorld)
		return FALSE;

	// S'assure que l'affichage météo est autorisé.
	g_Option.m_nWeatherEffect = TRUE;
	pWorld->m_bViewWeather = TRUE;

	CSkyBox* pSkyBox = CSkyBox::GetInstance();
	if (!pSkyBox)
		return FALSE;

	// Certaines zones peuvent verrouiller leur météo.
	pSkyBox->m_bLockWeather = FALSE;

	// FORCE la pluie immédiatement.
	pSkyBox->SetWeather(WEATHER_RAIN, TRUE);

	g_Neuz.m_nRealWeather = WEATHER_RAIN;

#ifdef __ZCK_TRAD_FR
	g_WndMng.PutString("TEST WEATHER : PLUIE ACTIV\311E");
#else
	g_WndMng.PutString("TEST WEATHER : PLUIE ACTIVEE");
#endif // __ZCK_TRAD_FR
#endif // __CLIENT

	return TRUE;
}

BOOL TextCmd_TestRainStop(CScanner& scanner)
{
#ifdef __CLIENT
	CSkyBox* pSkyBox = CSkyBox::GetInstance();
	if (!pSkyBox)
		return FALSE;

	pSkyBox->m_bLockWeather = FALSE;
	pSkyBox->SetWeather(WEATHER_NONE, FALSE);

	g_Neuz.m_nRealWeather = WEATHER_NONE;

#ifdef __ZCK_TRAD_FR
	g_WndMng.PutString("TEST WEATHER : PLUIE ARR\312T\311E");
#else
	g_WndMng.PutString("TEST WEATHER : PLUIE ARRETEE");
#endif // __ZCK_TRAD_FR
#endif // __CLIENT

	return TRUE;
}

#endif // __ZCK_WEATHER

BOOL TextCmd_FallSnow(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_DPCoreClient.SendFallSnow();
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_FallRain(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_DPCoreClient.SendFallRain();
#endif // __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_StopSnow(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_DPCoreClient.SendStopSnow();
#endif // __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_StopRain(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_DPCoreClient.SendStopRain();
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_JobName(CScanner& scanner)
{
#ifdef __CLIENT
	char chMessage[MAX_PATH] = { 0, };
#ifdef __ZCK_TRAD_FR
	sprintf(chMessage, "Classes expertes : ");
#else
	sprintf(chMessage, "Expert Job : ");
#endif // __ZCK_TRAD_FR
	for (int i = MAX_JOBBASE; i < MAX_EXPERT; ++i)
	{
		if (strlen(prj.m_aJob[i].szName) < 15)
		{
			strcat(chMessage, prj.m_aJob[i].szName);
			if (i + 1 != MAX_EXPERT)
			{
				strcat(chMessage, ", ");
			}
		}
	}
	g_WndMng.PutString(chMessage, NULL, 0xffff0000);
#ifdef __ZCK_TRAD_FR
	sprintf(chMessage, "Niveaux experts : %d ~ %d", MAX_JOB_LEVEL + 1, MAX_JOB_LEVEL + MAX_EXP_LEVEL);
	g_WndMng.PutString(chMessage, NULL, 0xffff0000);

	sprintf(chMessage, "Classes professionnelles : ");
#else
	sprintf(chMessage, "Expert Level : %d ~ %d", MAX_JOB_LEVEL + 1, MAX_JOB_LEVEL + MAX_EXP_LEVEL);
	g_WndMng.PutString(chMessage, NULL, 0xffff0000);

	sprintf(chMessage, "Professional Job : ");
#endif // __ZCK_TRAD_FR
	for (int i = MAX_EXPERT; i < MAX_PROFESSIONAL; ++i)
	{
		if (strlen(prj.m_aJob[i].szName) < 15)
		{
			strcat(chMessage, prj.m_aJob[i].szName);
			if (i + 1 != MAX_PROFESSIONAL)
			{
				strcat(chMessage, ", ");
			}
		}
	}
	g_WndMng.PutString(chMessage, NULL, 0xffff0000);
#ifdef __ZCK_TRAD_FR
	sprintf(chMessage, "Niveaux professionnels : %d ~~~ ", MAX_JOB_LEVEL + MAX_EXP_LEVEL);
#else
	sprintf(chMessage, "Professional Level : %d ~~~ ", MAX_JOB_LEVEL + MAX_EXP_LEVEL);
#endif // __ZCK_TRAD_FR
	g_WndMng.PutString(chMessage, NULL, 0xffff0000);
#endif // __CLIENT
	return TRUE;
}

#ifdef __CLIENT

BOOL TextCmd_tradeagree(CScanner& scanner)
{
	g_Option.m_bTrade = 1;
	g_WndMng.PutString(prj.GetText(TID_GAME_TRADEAGREE), NULL, prj.GetTextColor(TID_GAME_TRADEAGREE));
	return TRUE;
}
BOOL TextCmd_traderefuse(CScanner& scanner)
{
	g_Option.m_bTrade = 0;
	g_WndMng.PutString(prj.GetText(TID_GAME_TRADEREFUSE), NULL, prj.GetTextColor(TID_GAME_TRADEREFUSE));
	return TRUE;
}
BOOL TextCmd_whisperagree(CScanner& scanner)
{
	g_Option.m_bSay = 1;
	g_WndMng.PutString(prj.GetText(TID_GAME_WHISPERAGREE), NULL, prj.GetTextColor(TID_GAME_WHISPERAGREE));
	return TRUE;
}
BOOL TextCmd_whisperrefuse(CScanner& scanner)
{
	g_Option.m_bSay = 0;
	g_WndMng.PutString(prj.GetText(TID_GAME_WHISPERREFUSE), NULL, prj.GetTextColor(TID_GAME_WHISPERREFUSE));
	return TRUE;
}
BOOL TextCmd_messengeragree(CScanner& scanner)
{
	g_Option.m_bMessenger = 1;
	g_WndMng.PutString(prj.GetText(TID_GAME_MSGERAGREE), NULL, prj.GetTextColor(TID_GAME_MSGERAGREE));
	return TRUE;
}
BOOL TextCmd_messengerrefuse(CScanner& scanner)
{
	g_Option.m_bMessenger = 0;
	g_WndMng.PutString(prj.GetText(TID_GAME_MSGERREFUSE), NULL, prj.GetTextColor(TID_GAME_MSGERREFUSE));
	return TRUE;
}
BOOL TextCmd_stageagree(CScanner& scanner)
{
	g_Option.m_bParty = 1;
	g_WndMng.PutString(prj.GetText(TID_GAME_STAGEAGREE), NULL, prj.GetTextColor(TID_GAME_STAGEAGREE));
	return TRUE;
}
BOOL TextCmd_stagerefuse(CScanner& scanner)
{
	g_Option.m_bParty = 0;
	g_WndMng.PutString(prj.GetText(TID_GAME_STAGEREFUSE), NULL, prj.GetTextColor(TID_GAME_STAGEREFUSE));
	return TRUE;
}
BOOL TextCmd_connectagree(CScanner& scanner)
{
	g_Option.m_bMessengerJoin = 1;
	g_WndMng.PutString(prj.GetText(TID_GAME_CONNAGREE), NULL, prj.GetTextColor(TID_GAME_CONNAGREE));
	return TRUE;
}
BOOL TextCmd_connectrefuse(CScanner& scanner)
{
	g_Option.m_bMessengerJoin = 0;
	g_WndMng.PutString(prj.GetText(TID_GAME_CONNREFUSE), NULL, prj.GetTextColor(TID_GAME_CONNREFUSE));
	return TRUE;
}

#ifdef __YS_CHATTING_BLOCKING_SYSTEM
BOOL TextCmd_BlockUser(CScanner& scanner)
{
	if (prj.m_setBlockedUserID.size() >= CProject::BLOCKING_NUMBER_MAX)
	{

		g_WndMng.PutString(prj.GetText(TID_GAME_ERROR_FULL_BLOCKED_USER_LIST), NULL, prj.GetTextColor(TID_GAME_ERROR_FULL_BLOCKED_USER_LIST));
		return FALSE;
	}
	scanner.GetToken();
	CString strUserName = scanner.token;
	if (strUserName == _T(""))
	{

		g_WndMng.PutString(prj.GetText(TID_GAME_ERROR_INVALID_USER_ID), NULL, prj.GetTextColor(TID_GAME_ERROR_INVALID_USER_ID));
		return FALSE;
	}
	if (g_pPlayer && g_pPlayer->GetName(TRUE) == strUserName)
	{

		g_WndMng.PutString(prj.GetText(TID_GAME_ERROR_MY_CHARACTER_CANT_BLOCKING), NULL, prj.GetTextColor(TID_GAME_ERROR_MY_CHARACTER_CANT_BLOCKING));
		return FALSE;
	}
	set< CString >::iterator BlockedUserIterator = prj.m_setBlockedUserID.find(strUserName);
	if (BlockedUserIterator != prj.m_setBlockedUserID.end())
	{

		g_WndMng.PutString(prj.GetText(TID_GAME_ERROR_ALREADY_BLOCKED), NULL, prj.GetTextColor(TID_GAME_ERROR_ALREADY_BLOCKED));
	}
	else
	{
		prj.m_setBlockedUserID.insert(strUserName);

		if (g_WndMng.m_pWndChattingBlockingList)
		{
			g_WndMng.m_pWndChattingBlockingList->UpdateInformation();
		}

		CString strMessage = _T("");

		strMessage.Format(prj.GetText(TID_GAME_USER_CHATTING_BLOCKING), strUserName);
		g_WndMng.PutString(strMessage, NULL, prj.GetTextColor(TID_GAME_USER_CHATTING_BLOCKING));
	}
	return TRUE;
}

BOOL TextCmd_CancelBlockedUser(CScanner& scanner)
{
	scanner.GetToken();
	CString strUserName = scanner.token;
	set< CString >::iterator BlockedUserIterator = prj.m_setBlockedUserID.find(strUserName);
	if (BlockedUserIterator != prj.m_setBlockedUserID.end())
	{
		prj.m_setBlockedUserID.erase(strUserName);

		if (g_WndMng.m_pWndChattingBlockingList)
		{
			g_WndMng.m_pWndChattingBlockingList->UpdateInformation();
		}

		CString strMessage = _T("");

		strMessage.Format(prj.GetText(TID_GAME_USER_CHATTING_UNBLOCKING), strUserName);
		g_WndMng.PutString(strMessage, NULL, prj.GetTextColor(TID_GAME_USER_CHATTING_UNBLOCKING));
	}
	else
	{

		g_WndMng.PutString(prj.GetText(TID_GAME_ERROR_THERE_IS_NO_BLOCKED_TARGET), NULL, prj.GetTextColor(TID_GAME_ERROR_THERE_IS_NO_BLOCKED_TARGET));
	}
	return TRUE;
}

BOOL TextCmd_IgnoreList(CScanner& scanner)
{
	SAFE_DELETE(g_WndMng.m_pWndChattingBlockingList);
	g_WndMng.m_pWndChattingBlockingList = new CWndChattingBlockingList;
	g_WndMng.m_pWndChattingBlockingList->Initialize();
	return TRUE;
}
#endif // __YS_CHATTING_BLOCKING_SYSTEM

#endif // __CLIENT

BOOL TextCmd_QuestState(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pAdmin = (CUser*)s.dwValue;
	CUser* pUser = NULL;
	int nQuest = s.GetNumber();
	int nState = s.GetNumber();
	s.GetToken();
	if (s.tok != FINISHED)
	{
#if __VER >= 11 // __SYS_PLAYER_DATA
		u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);
#else	// __SYS_PLAYER_DATA
		u_long idPlayer = prj.GetPlayerID(s.Token);
#endif	// __SYS_PLAYER_DATA
		if (idPlayer)
			pUser = g_UserMng.GetUserByPlayerID(idPlayer);
		if (pUser == NULL)
		{
			pAdmin->AddDefinedText(TID_DIAG_0061, "%s", s.Token);
			return TRUE;
		}
	}
	else
	{
		pUser = pAdmin;
	}
	if (nState >= QS_BEGIN && nState < QS_END)
	{
		QUEST quest;
		if (pUser->SetQuest(nQuest, nState, &quest))
		{
			pUser->AddSetQuest(&quest);

			char pszComment[100] = { 0, };
			sprintf(pszComment, "%s %d", pAdmin->GetName(), nState);
			g_dpDBClient.CalluspLoggingQuest(pUser->m_idPlayer, nQuest, 11, pszComment);
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_BeginQuest(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int nQuest = s.GetNumber();
	QUEST quest;
	if (pUser->SetQuest(nQuest, 0, &quest))
		pUser->AddSetQuest(&quest);
#endif
	return TRUE;
}
BOOL TextCmd_EndQuest(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int nQuest = s.GetNumber();
	QUEST quest;
	if (pUser->SetQuest(nQuest, QS_END, &quest))
		pUser->AddSetQuest(&quest);
#endif
	return TRUE;
}

BOOL TextCmd_RemoveQuest(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pAdmin = (CUser*)s.dwValue;
	CUser* pUser = NULL;
	int nQuest = s.GetNumber();
	s.GetToken();
	if (s.tok != FINISHED)
	{
#if __VER >= 11 // __SYS_PLAYER_DATA
		u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);
#else	// __SYS_PLAYER_DATA
		u_long idPlayer = prj.GetPlayerID(s.Token);
#endif	// __SYS_PLAYER_DATA
		if (idPlayer)
			pUser = g_UserMng.GetUserByPlayerID(idPlayer);
		if (pUser == NULL)
		{
			pAdmin->AddDefinedText(TID_DIAG_0061, "%s", s.Token);
			return TRUE;
		}
	}
	else
	{
		pUser = pAdmin;
	}

	LPQUEST pQuest = pUser->FindQuest(nQuest);
	char pszComment[100] = { 0, };
	sprintf(pszComment, "%s %d", pAdmin->GetName(), (pQuest ? pQuest->m_nState : -1));
	g_dpDBClient.CalluspLoggingQuest(pUser->m_idPlayer, nQuest, 40, pszComment);

	pUser->RemoveQuest(nQuest);
	pUser->AddRemoveQuest(nQuest);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_RemoveAllQuest(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int nQuest = s.GetNumber();
	pUser->RemoveAllQuest();
	pUser->AddRemoveAllQuest();
#endif
	return TRUE;
}

BOOL TextCmd_RemoveCompleteQuest(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int nQuest = s.GetNumber();
	pUser->RemoveCompleteQuest();
	pUser->AddRemoveCompleteQuest();
#endif
	return TRUE;
}

BOOL TextCmd_PvpParam(CScanner& scanner)
{
#if defined(__WORLDSERVER)
	CUser* pUser = (CUser*)scanner.dwValue;
	int	nFame = scanner.GetNumber();
	int nSlaughter = scanner.GetNumber();

	pUser->m_nFame = nFame;
	g_UserMng.AddSetFame(pUser, nFame);

#if __VER < 8 // __S8_PK
	pUser->ChangeSlaughter(CHANGE_SLAUGHTER_SET, NULL, nSlaughter);
#endif // __VER < 8 // __S8_PK
#endif
	return TRUE;
}
#if __VER >= 8 // __S8_PK
BOOL TextCmd_PKParam(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	int		nPKValue = scanner.GetNumber();
	int		nPKPropensity = scanner.GetNumber();

	if (nPKValue >= 0)
	{
		pUser->SetPKValue(nPKValue);
		pUser->AddPKValue();
#if __VER >= 13
		pUser->CheckHonorStat();
		pUser->AddHonorListAck();
		g_UserMng.AddHonorTitleChange(pUser, pUser->m_nHonor);
#endif
	}

	if (nPKPropensity >= 0)
	{
		pUser->SetPKPropensity(nPKPropensity);
		g_UserMng.AddPKPropensity(pUser);
	}
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __VER >= 8 // __S8_PK

BOOL TextCmd_ReloadConstant(CScanner& scanner)
{
#ifdef __WORLDSERVER
	g_DPCoreClient.SendLoadConstant();
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_GuildCombatRequest(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	DWORD dwPenya = scanner.GetNumber();
	g_GuildCombatMng.GuildCombatRequest(pUser, dwPenya);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_GuildCombatCancel(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_GuildCombatMng.GuildCombatCancel(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_GuildCombatOpen(CScanner& scanner)
{
#ifdef __CLIENT
#endif // __CLINET
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (g_GuildCombatMng.m_nState != CGuildCombat::CLOSE_STATE)
	{
		char chMessage[128] = { 0, };
#ifdef __ZCK_TRAD_FR
		sprintf(chMessage, "Ouverture de la guerre de guilde impossible : \351tat diff\351rent de CLOSE_STATE");
#else
		sprintf(chMessage, "Not GuildCombat Open :: Not CLOSE_STATE");
#endif // __ZCK_TRAD_FR
		pUser->AddText(chMessage);
		return TRUE;
	}

	g_GuildCombatMng.GuildCombatOpen();
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_GuildCombatIn(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_GuildCombatMng.GuildCombatEnter(pUser);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_GuildCombatClose(CScanner& scanner)
{
#ifdef __WORLDSERVER
	int	nClose = scanner.GetNumber();

	CUser* pUser = (CUser*)scanner.dwValue;
	if (g_GuildCombatMng.m_nState == CGuildCombat::CLOSE_STATE)
	{
		char chMessage[128] = { 0, };
#ifdef __ZCK_TRAD_FR
		sprintf(chMessage, "Fermeture de la guerre de guilde impossible : d\351j\340 en CLOSE_STATE");
#else
		sprintf(chMessage, "Not GuildCombat Close :: Is CLOSE_STATE");
#endif // __ZCK_TRAD_FR
		pUser->AddText(chMessage);
		return TRUE;
	}

	if (nClose == 0)
		g_GuildCombatMng.SetGuildCombatClose(TRUE);
	else
		g_GuildCombatMng.SetGuildCombatCloseWait(TRUE);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_GuildCombatNext(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (g_GuildCombatMng.m_nState == CGuildCombat::CLOSE_STATE)
	{
		char chMessage[128] = { 0, };
#ifdef __ZCK_TRAD_FR
		sprintf(chMessage, "Fermeture de la guerre de guilde impossible : d\351j\340 en CLOSE_STATE");
#else
		sprintf(chMessage, "Not GuildCombat Close :: Is CLOSE_STATE");
#endif // __ZCK_TRAD_FR
		pUser->AddText(chMessage);
		return TRUE;
	}

	g_GuildCombatMng.m_dwTime = GetTickCount();
#endif // __WORLDSERVER
	return TRUE;
}

#if __VER >= 10 // __REMOVE_ATTRIBUTE
BOOL TextCmd_RemoveAttribute(CScanner& scanner)
{
#ifdef __CLIENT
	if (g_WndMng.m_pWndUpgradeBase == NULL)
	{
		SAFE_DELETE(g_WndMng.m_pWndUpgradeBase);
		g_WndMng.m_pWndUpgradeBase = new CWndUpgradeBase;
		g_WndMng.m_pWndUpgradeBase->Initialize(&g_WndMng, APP_TEST);
		return FALSE;
	}

	if (g_WndMng.m_pWndUpgradeBase)
	{
		if (g_WndMng.m_pWndUpgradeBase->m_pItemElem[0])
		{
			DWORD dwObjId = g_WndMng.m_pWndUpgradeBase->m_pItemElem[0]->m_dwObjId;
			g_DPlay.SendRemoveAttribute(dwObjId);
		}
		else
		{
			return FALSE;
		}
	}
	else
	{
		return FALSE;
	}
#endif // __CLIENT
	return TRUE;
}
#endif // __REMOVE_ATTRIBUTE

#ifdef __NPC_BUFF
BOOL TextCmd_RemoveAllBuff(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
#ifdef __FL_EQUALIZED_MODE
	((CMover*)pUser)->DisableAllPets();
#endif
	pUser->RemoveAllBuff();
	pUser->ClearAllSMMode();
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __NPC_BUFF

#if __VER >= 12 // __HEAVEN_TOWER
BOOL TextCmd_HeavenTower(CScanner& s)
{
#ifdef __CLIENT
	SAFE_DELETE(g_WndMng.m_pWndHeavenTower);
	g_WndMng.m_pWndHeavenTower = new CWndHeavenTower;
	g_WndMng.m_pWndHeavenTower->Initialize(NULL);
#endif // __CLIENT
	return TRUE;
}
#endif //__HEAVEN_TOWER


#if __VER >= 12 // __SECRET_ROOM
BOOL TextCmd_SecretRoomOpen(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	if (CSecretRoomMng::GetInstance()->m_nState == SRMNG_CLOSE)
		CSecretRoomMng::GetInstance()->SecretRoomOpen();
	else
#ifdef __ZCK_TRAD_FR
		pUser->AddText("La chambre secr\350te n'est pas ferm\351e !");
#else
		pUser->AddText("Is Not Close State!!!");
#endif // __ZCK_TRAD_FR
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_SecretRoomEntrance(CScanner& s)
{
#ifdef __CLIENT
	if (s.GetNumber() == 1)
	{
		return TRUE;
	}

	CWndWorld* pWndWorld = (CWndWorld*)g_WndMng.GetWndBase(APP_WORLD);
	if (pWndWorld)
	{
		for (int i = 0; i < MAX_KILLCOUNT_CIPHERS; i++)
		{
			pWndWorld->m_stKillCountCiphers[i].bDrawMyGuildKillCount = TRUE;
			pWndWorld->m_stKillCountCiphers[i].szMyGuildKillCount = '0';
			pWndWorld->m_stKillCountCiphers[i].ptPos = CPoint(0, 0);
			pWndWorld->m_stKillCountCiphers[i].fScaleX = 1.0f;
			pWndWorld->m_stKillCountCiphers[i].fScaleY = 1.0f;
			pWndWorld->m_stKillCountCiphers[i].nAlpha = 255;

			//			pWndWorld->m_bDrawMyGuildKillCount[i] = TRUE;
			//			pWndWorld->m_szMyGuildKillCount[i] = '0';
		}
	}

	if (g_WndMng.m_pWndSecretRoomMsg)
		SAFE_DELETE(g_WndMng.m_pWndSecretRoomMsg);

	g_DPlay.SendSecretRoomEntrance();
#endif // __CLIENT
	return TRUE;
}

BOOL TextCmd_SecretRoomNext(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CSecretRoomMng::GetInstance()->m_dwRemainTime = 0;
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_SecretRoomTender(CScanner& s)
{
#ifdef __CLIENT
	g_DPlay.SendSecretRoomTenderOpenWnd();
#endif // __CLIENT
	return TRUE;
}

BOOL TextCmd_SecretRoomLineUp(CScanner& s)
{
#ifdef __CLIENT
	g_DPlay.SendSecretRoomLineUpOpenWnd();
#endif // __CLIENT
	return TRUE;
}

BOOL TextCmd_SecretRoomClose(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;

	if (CSecretRoomMng::GetInstance()->m_nState == SRMNG_WAR)
	{
		map<BYTE, CSecretRoomContinent*>::iterator it = CSecretRoomMng::GetInstance()->m_mapSecretRoomContinent.begin();
		for (; it != CSecretRoomMng::GetInstance()->m_mapSecretRoomContinent.end(); it++)
		{
			CSecretRoomContinent* pSRCont = it->second;
			if (pSRCont && pSRCont->m_nState != SRCONT_CLOSE)
				pSRCont->m_dwRemainTime = 0;
			//pSRCont->SetContCloseWait();
		}
	}
	else
#ifdef __ZCK_TRAD_FR
		pUser->AddText("La chambre secr\350te n'est pas en phase de combat !");
#else
		pUser->AddText("Is Not War State!!!");
#endif // __ZCK_TRAD_FR
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_SecretRoomTenderView(CScanner& s)
{
#ifdef __CLIENT
	g_DPlay.SendSecretRoomTenderView();

	SAFE_DELETE(g_WndMng.m_pWndSecretRoomCheckTaxRate);
	g_WndMng.m_pWndSecretRoomCheckTaxRate = new CWndSecretRoomCheckTaxRate;
	g_WndMng.m_pWndSecretRoomCheckTaxRate->Initialize(NULL);
#endif // __CLIENT
	return TRUE;
}

BOOL TextCmd_SecretRoomTenderCancelReturn(CScanner& s)
{
#ifdef __CLIENT
	g_DPlay.SendSecretRoomTenderCancelReturn();
#endif // __CLIENT
	return TRUE;
}
#endif // __SECRET_ROOM

#if __VER >= 12 // __LORD
BOOL TextCmd_ElectionRequirement(CScanner& s)
{
#ifdef __CLIENT
	IElection* pElection = CCLord::Instance()->GetElection();
	char lpString[100] = { 0, };
#ifdef __ZCK_TRAD_FR
	sprintf(lpString, "\311tat de l'\351lection : total(%d)/requis(%d)", pElection->GetVote(), pElection->GetRequirement());
#else
	sprintf(lpString, "election state : total(%d)/requirement(%d)", pElection->GetVote(), pElection->GetRequirement());
#endif // __ZCK_TRAD_FR
	g_WndMng.PutString(lpString);
#endif	// __CLIENT
	return TRUE;
}

//#ifdef __INTERNALSERVER
BOOL TextCmd_RemoveTotalGold(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	__int64 iGold = static_cast<__int64>(s.GetInt64());
	if (iGold > pUser->GetTotalGold())
	{
		char szText[100] = { 0, };
		sprintf(szText, "TextCmd_RemoveTotalGold: %I64d", pUser->GetTotalGold());
		pUser->AddText(szText);
	}
	else
		pUser->RemoveTotalGold(iGold);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ElectionAddDeposit(CScanner& s)
{
#ifdef __CLIENT
	__int64 iDeposit = static_cast<__int64>(s.GetNumber());
	g_DPlay.SendElectionAddDeposit(iDeposit);
#endif	// __CLIENT
	return TRUE;
}
BOOL TextCmd_ElectionSetPledge(CScanner& s)
{
#ifdef __CLIENT
	char szPledge[CCandidate::nMaxPledgeLen] = { 0, };

	s.GetLastFull();
	if (lstrlen(s.token) >= CCandidate::nMaxPledgeLen)
		return TRUE;
	lstrcpy(szPledge, s.token);
	StringTrimRight(szPledge);
	//	RemoveCRLF( szPledge );
	g_DPlay.SendElectionSetPledge(szPledge);
#endif	// __CLIENT
	return TRUE;
}

BOOL TextCmd_ElectionIncVote(CScanner& s)
{
#ifdef __CLIENT
	s.GetToken();
	u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);
	if (idPlayer > 0)
		g_DPlay.SendElectionIncVote(idPlayer);
	else
		g_WndMng.PutString(prj.GetText(TID_GAME_ELECTION_INC_VOTE_E001));
#endif	// __CLIENT
	return TRUE;
}

BOOL TextCmd_ElectionProcess(CScanner& s)
{
#ifdef __WORLDSERVER
	BOOL bRun = static_cast<BOOL>(s.GetNumber());
	g_dpDBClient.SendElectionProcess(bRun);
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ElectionBeginCandidacy(CScanner& s)
{
#ifdef __WORLDSERVER
	g_dpDBClient.SendElectionBeginCandidacy();
#endif	// __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_ElectionBeginVote(CScanner& s)
{
#ifdef __WORLDSERVER
	g_dpDBClient.SendElectionBeginVote();
#endif	// __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_ElectionEndVote(CScanner& s)
{
#ifdef __WORLDSERVER
	g_dpDBClient.SendElectionBeginEndVote();
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_ElectionState(CScanner& s)
{
#ifdef __CLIENT
	CCElection* pElection = static_cast<CCElection*>(CCLord::Instance()->GetElection());
	pElection->State();
#endif	// __CLIENT
	return TRUE;
}

BOOL TextCmd_LEventCreate(CScanner& s)
{
#ifdef __CLIENT
	int iEEvent = s.GetNumber();
	int iIEvent = s.GetNumber();
#ifndef __FL_UPDATE_LORDEVENT
	g_DPlay.SendLEventCreate(iEEvent, iIEvent);
#else
	int iPEvent = s.GetNumber();
	g_DPlay.SendLEventCreate(iEEvent, iIEvent, iPEvent);
#endif

#endif	// __CLIENT
	return TRUE;
}

BOOL TextCmd_LEventInitialize(CScanner& s)
{
#ifdef __WORLDSERVER
	g_dpDBClient.SendLEventInitialize();
#endif	// __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_LSkill(CScanner& s)
{
#ifdef __CLIENT
	int nSkill = s.GetNumber();
	s.GetToken();
	char szTarget[MAX_PLAYER] = { 0, };
	strncpy(szTarget, s.token, MAX_PLAYER);
	szTarget[MAX_PLAYER - 1] = '\0';
	g_DPlay.SendLordSkillUse(nSkill, szTarget);
#endif	// __CLIENT
	return TRUE;
}
//#endif	// __INTERNALSERVER
#endif	// __LORD

#if __VER >= 12 // __TAX
BOOL TextCmd_TaxApplyNow(CScanner& s)
{
#ifdef __WORLDSERVER
	CTax::GetInstance()->SetApplyTaxRateNow();
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __TAX

#if __VER >= 13
BOOL TextCmd_HonorTitleSet(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	int nIdx = -1;
	s.GetToken();
	if (s.tokenType == NUMBER)
	{
		nIdx = _ttoi(s.Token);
	}
	else
	{
		nIdx = CTitleManager::Instance()->GetIdxByName(s.Token);
	}

	if (nIdx < 0 || nIdx >= MAX_HONOR_TITLE)
		return FALSE;

	DWORD dwNum = s.GetNumber();
	if (dwNum > 100000000) dwNum = 100000000;
	if (dwNum < 0) dwNum = 0;

	pUser->SetHonorCount(nIdx, dwNum);
	pUser->AddHonorListAck();
#endif // __WORLDSERVER
	return TRUE;
}

#endif

#if __VER >= 13 // __HOUSING
BOOL TextCmd_HousingVisitRoom(CScanner& s)
{
#ifdef __CLIENT
	s.GetToken();
	if (s.Token == "")
		g_DPlay.SendHousingVisitRoom(NULL_ID);
	else
	{
		DWORD dwPlayerId = CPlayerDataCenter::GetInstance()->GetPlayerId(s.token);
		if (dwPlayerId)
			g_DPlay.SendHousingVisitRoom(dwPlayerId);
	}
#endif // __CLIENT
	return TRUE;
}

BOOL TextCmd_HousingGMRemoveAll(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	CHousingMng::GetInstance()->ReqGMFunrnitureListAll(pUser);
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __HOUSING

#if __VER >= 15 // __15_5TH_ELEMENTAL_SMELT_SAFETY
BOOL TextCmd_SmeltSafetyElement(CScanner& s)
{
#ifdef __CLIENT
	SAFE_DELETE(g_WndMng.m_pWndSmeltSafety);
	g_WndMng.m_pWndSmeltSafety = new CWndSmeltSafety(CWndSmeltSafety::WND_ELEMENT);
	g_WndMng.m_pWndSmeltSafety->Initialize(NULL);
#endif // __CLIENT
	return TRUE;
}
#endif // __15_5TH_ELEMENTAL_SMELT_SAFETY

#if __VER >= 15 // __GUILD_HOUSE
BOOL TextCmd_BuyGuildHouse(CScanner& s)
{
#ifdef __CLIENT
	g_DPlay.SendBuyGuildHouse();
#endif // __CLIENT
	return TRUE;
}

#ifdef __CLIENT
#include "WndGuildHouse.h"
#endif // __CLIENT
BOOL TextCmd_GuildHouseUpkeep(CScanner& s)
{
#ifdef __CLIENT
	if (!g_WndMng.m_pWndUpkeep)
	{
		g_WndMng.m_pWndUpkeep = new CWndGHUpkeep;
		g_WndMng.m_pWndUpkeep->Initialize(&g_WndMng, APP_CONFIRM_BUY_);
	}
	else
	{
		SAFE_DELETE(g_WndMng.m_pWndUpkeep);
	}
#endif // __CLIENT
	return TRUE;
}
#endif // __GUILD_HOUSE

#ifdef __ZCK_CRAFT_LOAD_TEX
// /artisanat (alias /craft) : ouvre la fenetre APP_ZCK_CRAFT (tout joueur, rien n'est
// envoye). /artisanat recharger | exp <n> (administration) : la ligne part au WorldServer
// (TCM_BOTH), qui revalide les droits dans ZckCraftCommande.
BOOL TextCmd_ZckCraft(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	if (scanner.tok == FINISHED)
	{
		if (g_WndMng.GetWndBase(APP_ZCK_CRAFT) == NULL)
			g_WndMng.CreateApplet(APP_ZCK_CRAFT);
		return FALSE;
	}
	if (g_pPlayer == NULL || !g_pPlayer->IsAuthHigher(AUTH_ADMINISTRATOR))
	{
		g_WndMng.PutString("Artisanat : /artisanat seul ouvre la fen\352tre, les sous-commandes sont r\351serv\351es \340 l'administration.", NULL, 0xffff0000);
		return FALSE;
	}
#endif // __CLIENT
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;
	ZckCraftCommande(pUser, scanner);
#endif // __WORLDSERVER
	return TRUE;
}

#else
#line 4163 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#ifdef __ZCK_QUEST
// /quete (alias /quetes, /quest) : ouvre le journal des quetes APP_ZCK_QUEST (tout joueur,
// rien n'est envoye). /quete suivi : affiche ou masque le suivi a l'ecran (client seul,
// neuz.ini ZckQueteSuivi). /quete recharger | reinitialiser (administration) : la ligne
// part au WorldServer (TCM_BOTH), qui revalide les droits dans CZckQuestManager::Commande.
BOOL TextCmd_ZckQuest(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	if (scanner.tok == FINISHED)
	{
		if (g_WndMng.GetWndBase(APP_ZCK_QUEST) == NULL)
			g_WndMng.CreateApplet(APP_ZCK_QUEST);
		return FALSE;
	}
	CString strSous = scanner.Token;
	strSous.MakeLower();
	if (strSous == "suivi")
	{
		CWndZckQuestSuivi::Basculer();
		return FALSE;
	}
	if (g_pPlayer == NULL || !g_pPlayer->IsAuthHigher(AUTH_ADMINISTRATOR))
	{
		g_WndMng.PutString("Qu\352tes : /quete ouvre le journal, /quete suivi affiche ou masque le suivi ; les autres sous-commandes sont r\351serv\351es \340 l'administration.", NULL, 0xffff0000);
		return FALSE;
	}
#endif // __CLIENT
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;
	CZckQuestManager::GetInstance()->Commande(pUser, scanner);
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_QUEST
BOOL TextCmd_InvenRemove(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsValidObj(pUser))
	{
		int nSize = pUser->m_Inventory.GetMax();
		for (int i = 0; i < nSize; ++i)
		{
			CItemElem* pItemElem = pUser->m_Inventory.GetAtId(i);
			if (IsUsableItem(pItemElem) && !pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId) && !pUser->IsUsing(pItemElem))
				pUser->RemoveItem((BYTE)(i), pItemElem->m_nItemNum);
		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}
#ifdef __ZCK_RARE
BOOL TextCmd_ZckRare(CScanner&)
{
#ifdef __CLIENT
#ifdef __ZCK_TRAD_FR
	g_WndMng.PutString("Utilisez le PNJ d'ascension de raret\351.", NULL, 0xFFFFFF00);
#else
	g_WndMng.PutString("Utilisez le PNJ d'ascension de rarete.", NULL, 0xFFFFFF00);
#endif // __ZCK_TRAD_FR
#endif
	return TRUE;
}

BOOL TextCmd_SetZckRare(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser) || !pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
		return TRUE;

	const int nRare = scanner.GetNumber();
	if (nRare < 1 || nRare > ZCK_RARE_MAX_LEVEL || !prj.IsZckRareLevelValid(nRare))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Raret\351 invalide : utilisez /swr 1 \340 /swr 10.");
#else
		pUser->AddText("Rarete invalide : utilisez /swr 1 a /swr 10.");
#endif // __ZCK_TRAD_FR
		return TRUE;
	}

	CItemElem* pItem = pUser->m_Inventory.GetAt(0);
	if (!IsUsableItem(pItem) || pItem->m_nItemNum != 1 || pUser->IsUsing(pItem) || pUser->m_Inventory.IsEquip(pItem->m_dwObjId))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Placez un objet valide et non \351quip\351 dans le premier slot de l'inventaire.");
#else
		pUser->AddText("Placez un objet valide et non equipe dans le premier slot de l'inventaire.");
#endif // __ZCK_TRAD_FR
		return TRUE;
	}

	ItemProp* pProp = pItem->GetProp();
	if (!pProp || !IsZckRareItem(pProp->dwItemKind3))
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Le premier slot doit contenir une arme ou une armure compatible avec la raret\351.");
#else
		pUser->AddText("Le premier slot doit contenir une arme ou une armure compatible avec la rarete.");
#endif // __ZCK_TRAD_FR
		return TRUE;
	}

	ZCK_RARE_DATA* pData = prj.GetZckRareData(nRare);
	if (!pData)
		return TRUE;

	if (pItem->m_dwObjId > 0xFF)
		return TRUE;

	const BYTE byId = static_cast<BYTE>(pItem->m_dwObjId);
	pUser->UpdateItem(byId, UI_ZCK_RARE, nRare);

	const BYTE byOldFlag = pItem->m_byFlag;
	if (prj.HasZckRareReflect(nRare))
		pItem->SetFlag(CItemElem::zckRareReflect);
	else
		pItem->ResetFlag(CItemElem::zckRareReflect);
	if (byOldFlag != pItem->m_byFlag)
		pUser->UpdateItem(byId, UI_FLAG, MAKELONG(pItem->m_dwObjIndex, pItem->m_byFlag));

	if (pUser->GetWorld())
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

	CString str;
#ifdef __ZCK_TRAD_FR
	str.Format("Raret\351 appliqu\351e : %s (%d).", pData->m_szName, nRare);
#else
	str.Format("Rarete appliquee : %s (%d).", pData->m_szName, nRare);
#endif // __ZCK_TRAD_FR
	pUser->AddText(str);
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_RARE

#ifdef __ZCK_JOB_FACTOR
// /zjf : recharge ZckJobFactor.inc a chaud. En cas d'erreur, l'ancienne configuration reste active.
BOOL TextCmd_ReloadZckJobFactor(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (!IsValidObj(pUser))
		return TRUE;

	if (prj.LoadZckJobFactor())
		pUser->AddText("ZckJobFactor.inc recharg\351.");
	else
		pUser->AddText("\311chec du rechargement de ZckJobFactor.inc : ancienne configuration conserv\351e (voir le log d'erreurs).");
#endif // __WORLDSERVER
	return TRUE;
}

// /zjfdps : 1er appel = demarre la mesure, 2e appel = affiche le DPS (du premier au dernier coup).
BOOL TextCmd_ZckJobFactorDps(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (!IsValidObj(pUser))
		return TRUE;

	if (pUser->m_nZckJobFactorMesure == 0)
	{
		pUser->m_nZckJobFactorMesure = 1;
		pUser->m_dwZckJobFactorDebut = 0;
		pUser->m_dwZckJobFactorFin = 0;
		pUser->m_n64ZckJobFactorDegats = 0;
		pUser->AddText("Mesure DPS d\351marr\351e : frappez la cible, puis retapez /zjfdps.");
		return TRUE;
	}

	pUser->m_nZckJobFactorMesure = 0;
	const DWORD dwDureeMs = pUser->m_dwZckJobFactorFin - pUser->m_dwZckJobFactorDebut;
	if (pUser->m_n64ZckJobFactorDegats <= 0 || dwDureeMs < 1000)
	{
		pUser->AddText("Mesure DPS annul\351e : moins d'une seconde de combat mesur\351e.");
		return TRUE;
	}

	const int nJob = pUser->GetJob();
	const double dSecondes = dwDureeMs / 1000.0;
	CString str;
	str.Format("%s : %I64d d\351g\342ts en %.1f s = %.0f DPS (facteurs actuels PvE %.2f / PvP %.2f)",
		(nJob >= 0 && nJob < MAX_JOB) ? prj.m_aJob[nJob].szName : "?",
		pUser->m_n64ZckJobFactorDegats, dSecondes, pUser->m_n64ZckJobFactorDegats / dSecondes,
		prj.GetZckJobFactor(nJob, FALSE), prj.GetZckJobFactor(nJob, TRUE));
	pUser->AddText(str);
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_JOB_FACTOR

#ifdef __ZCK_MONSTRE_FCT
// /zmf : recharge ZckMonstreFct.inc a chaud. En cas d'erreur, l'ancienne configuration reste active.
BOOL TextCmd_ReloadZckMonstreFct(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (!IsValidObj(pUser))
		return TRUE;

	if (prj.LoadZckMonstreFct())
	{
		CString str;
		str.Format("ZckMonstreFct.inc recharg\351 : %d boss r\351gl\351(s).", (int)prj.m_mapZckMonstreFct.size());
		pUser->AddText(str);
	}
	else
		pUser->AddText("\311chec du rechargement de ZckMonstreFct.inc : ancienne configuration conserv\351e (voir le log d'erreurs).");
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_MONSTRE_FCT

#ifdef __ZCK_NIVEAU_ARME
BOOL TextCmd_SetZckArmeNiveau(CScanner& scanner)
{
#ifdef __WORLDSERVER
    CUser* pUser = reinterpret_cast<CUser*>(scanner.dwValue);
    if (IsInvalidObj(pUser) || !pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
        return TRUE;

    const int nRequestedLevel = scanner.GetNumber();
    if (scanner.Token.IsEmpty() || scanner.tokenType != NUMBER ||
        nRequestedLevel < prj.m_ZckArmeNiveauConfig.m_nMinLevel ||
        nRequestedLevel > prj.m_ZckArmeNiveauConfig.m_nMaxLevel)
    {
        CString strUsage;
#ifdef __ZCK_TRAD_FR
        strUsage.Format("Utilisation : /swl %d \340 %d",
            prj.m_ZckArmeNiveauConfig.m_nMinLevel,
            prj.m_ZckArmeNiveauConfig.m_nMaxLevel);
#else
        strUsage.Format("Utilisation : /swl %d a %d",
            prj.m_ZckArmeNiveauConfig.m_nMinLevel,
            prj.m_ZckArmeNiveauConfig.m_nMaxLevel);
#endif // __ZCK_TRAD_FR
        pUser->AddText(strUsage, 0xFFFF0000);
        return TRUE;
    }

    CItemElem* pItemElem = pUser->m_Inventory.GetEquip(PARTS_RWEAPON);
    if (!pItemElem)
    {
#ifdef __ZCK_TRAD_FR
        pUser->AddText("Aucune arme \351quip\351e en main droite.", 0xFFFF0000);
#else
        pUser->AddText("Aucune arme equipee en main droite.", 0xFFFF0000);
#endif // __ZCK_TRAD_FR
        return TRUE;
    }

    ItemProp* pItemProp = pItemElem->GetProp();
    if (!pItemProp || !prj.IsZckArmeNiveauEligible(pItemProp) || pItemElem->IsFlag(CItemElem::expired))
    {
#ifdef __ZCK_TRAD_FR
        pUser->AddText("Cette arme n'est pas \351ligible au niveau d'arme.", 0xFFFF0000);
#else
        pUser->AddText("Cette arme n'est pas eligible au niveau d'arme.", 0xFFFF0000);
#endif // __ZCK_TRAD_FR
        return TRUE;
    }

    if (pItemElem->m_dwObjId > 0xFF)
        return TRUE;

    const DWORD dwOldStat = pItemElem->m_dwZckArmeNiveauStat;
    const int nOldBonus = prj.IsZckArmeNiveauStatValid(dwOldStat)
        ? prj.GetZckArmeNiveauStatBonus(pItemProp, pItemElem->m_nZckArmeNiveau)
        : 0;
    if (nOldBonus > 0)
        pUser->ResetDestParam(dwOldStat, nOldBonus);

    pItemElem->m_nZckArmeNiveau = prj.ClampZckArmeNiveauLevel(nRequestedLevel);
    pItemElem->m_dwZckArmeNiveauExp = 0;
    if (!prj.IsZckArmeNiveauStatValid(pItemElem->m_dwZckArmeNiveauStat))
        pItemElem->m_dwZckArmeNiveauStat = prj.PickRandomZckArmeNiveauStat();

    const int nNewBonus = prj.GetZckArmeNiveauStatBonus(pItemProp, pItemElem->m_nZckArmeNiveau);
    if (nNewBonus > 0)
        pUser->SetDestParam(pItemElem->m_dwZckArmeNiveauStat, nNewBonus, NULL_CHGPARAM);

    const BYTE byId = static_cast<BYTE>(pItemElem->m_dwObjId);
    pUser->UpdateItem(byId, UI_ZCK_ARME_NIVEAU_LEVEL, pItemElem->m_nZckArmeNiveau);
    pUser->UpdateItem(byId, UI_ZCK_ARME_NIVEAU_EXP, pItemElem->m_dwZckArmeNiveauExp);
    pUser->UpdateItem(byId, UI_ZCK_ARME_NIVEAU_STAT, pItemElem->m_dwZckArmeNiveauStat);

    if (pUser->GetWorld())
        g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

    CString str;
#ifdef __ZCK_TRAD_FR
    str.Format("Niveau d'arme appliqu\351 : %d. Bonus : +%d.", pItemElem->m_nZckArmeNiveau, nNewBonus);
#else
    str.Format("Niveau d'arme applique : %d. Bonus : +%d.", pItemElem->m_nZckArmeNiveau, nNewBonus);
#endif // __ZCK_TRAD_FR
    pUser->AddText(str, 0xFF00FF00);
#endif // __WORLDSERVER
    return TRUE;
}
#endif // __ZCK_NIVEAU_ARME

#ifdef __ZCK_PRESTIGE
BOOL TextCmd_ResetPrestige(CScanner& scanner)
{
#ifdef __WORLDSERVER
    CUser* pUser = reinterpret_cast<CUser*>(scanner.dwValue);
    if (IsInvalidObj(pUser) || !pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
        return TRUE;

    if (!pUser->SetZckPrestigeAdmin(0))
#ifdef __ZCK_TRAD_FR
        pUser->AddText("Impossible de remettre le Prestige \340 0.", 0xFFFF0000);
    else
        pUser->AddText("Prestige remis \340 0.", 0xFF00FF00);
#else
        pUser->AddText("Impossible de remettre le Prestige a 0.", 0xFFFF0000);
    else
        pUser->AddText("Prestige remis a 0.", 0xFF00FF00);
#endif // __ZCK_TRAD_FR
#endif
    return TRUE;
}

BOOL TextCmd_SetPrestige(CScanner& scanner)
{
#ifdef __WORLDSERVER
    CUser* pUser = reinterpret_cast<CUser*>(scanner.dwValue);
    if (IsInvalidObj(pUser) || !pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
        return TRUE;

    const int nPrestige = scanner.GetNumber();
    if (scanner.Token.IsEmpty() || scanner.tokenType != NUMBER ||
        nPrestige < 0 || nPrestige > prj.m_ZckPrestigeConfig.nMaxPrestige)
    {
        CString strUsage;
#ifdef __ZCK_TRAD_FR
        strUsage.Format("Utilisation : /setprestige 0 \340 %d",
            prj.m_ZckPrestigeConfig.nMaxPrestige);
#else
        strUsage.Format("Utilisation : /setprestige 0 a %d",
            prj.m_ZckPrestigeConfig.nMaxPrestige);
#endif // __ZCK_TRAD_FR
        pUser->AddText(strUsage, 0xFFFF0000);
        return TRUE;
    }

    if (!pUser->SetZckPrestigeAdmin(nPrestige))
        pUser->AddText("Impossible de modifier le Prestige.", 0xFFFF0000);
    else
    {
        CString str;
#ifdef __ZCK_TRAD_FR
        str.Format("Prestige d\351fini \340 %d.", nPrestige);
#else
        str.Format("Prestige defini a %d.", nPrestige);
#endif // __ZCK_TRAD_FR
        pUser->AddText(str, 0xFF00FF00);
    }
#endif
    return TRUE;
}
#endif // __ZCK_PRESTIGE

#ifdef __AIO_ADMIN_THINGS
BOOL TextCmd_Duplicate(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsValidObj(pUser))
	{
		CItemElem* pItemElem = pUser->m_Inventory.GetAt(0);
		if (pItemElem)
		{
			int nNumber = scanner.GetNumber();
			if (scanner.tok == FINISHED)
			{
				if (pUser->m_Inventory.GetEmptyCount() < 1)
				{
					pUser->AddDefinedText(TID_GAME_LACKSPACE);
				}
				else
				{
					CItemElem itemElem;
					itemElem = *pItemElem;

					pUser->CreateItem(&itemElem);
				}
			}
			else
			{
				if (nNumber > MAX_INVENTORY)
					nNumber = MAX_INVENTORY;

				else if (nNumber < 1)
					nNumber = 1;

				if (pUser->m_Inventory.GetEmptyCount() - nNumber < 1)
				{
					pUser->AddDefinedText(TID_GAME_LACKSPACE);
				}
				else
				{
					CItemElem itemElem;
					itemElem = *pItemElem;

					for (int i = nNumber; i != 0; i--)
						pUser->CreateItem(&itemElem);
				}
			}
		}
	}
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_Restart(CScanner& scanner)
{
#ifdef __CLIENT
	ShellExecute(g_Neuz.GetSafeHwnd(), TEXT("open"), TEXT("Neuz.exe"), TEXT(__NEUZ_BOOTS), 0, SW_SHOW);
	::PostMessage(g_Neuz.GetSafeHwnd(), WM_CLOSE, TRUE, 0);
#endif
	return TRUE;
}
BOOL TextCmd_SetRandomScroll(CScanner& s)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)s.dwValue;
	if (IsInvalidObj(pUser))
		return FALSE;
	CItemElem* pItemElem = pUser->m_Inventory.GetAt(0);

	if (pItemElem)
	{
		if (IsUsableItem(pItemElem) == FALSE)
		{
			return FALSE;
		}
		if (!(pItemElem->GetProp()->dwItemKind1 == IK1_WEAPON || pItemElem->GetProp()->dwItemKind2 == IK2_ARMOR || pItemElem->GetProp()->dwItemKind2 == IK2_ARMORETC))
		{
			pUser->AddDefinedText(TID_GAME_RANDOMSCROLL_ERROR, "");
			return FALSE;
		}

		s.GetToken();
		CString strstat = s.Token;
		DWORD dwNum = s.GetNumber();
		int finishnum;

		if (2 <= strstat.GetLength() && strstat.GetLength() <= 7)
		{
			strstat.MakeLower();
			if (strcmp(strstat, "str") == 0)
			{
				if (dwNum == 1)
				{
					finishnum = 1;
				}
				else if (dwNum == 2)
				{
					finishnum = 9;
				}
				else if (dwNum == 3)
				{
					finishnum = 21;
				}
				else
				{
					finishnum = 37;
				}
			}
			else if (strcmp(strstat, "dex") == 0)
			{
				if (dwNum == 1)
				{
					finishnum = 2;
				}
				else if (dwNum == 2)
				{
					finishnum = 10;
				}
				else if (dwNum == 3)
				{
					finishnum = 22;
				}
				else
				{
					finishnum = 38;
				}
			}
			else if (strcmp(strstat, "int") == 0)
			{
				if (dwNum == 1)
				{
					finishnum = 3;
				}
				else if (dwNum == 2)
				{
					finishnum = 11;
				}
				else if (dwNum == 3)
				{
					finishnum = 23;
				}
				else
				{
					finishnum = 39;
				}
			}
			else if (strcmp(strstat, "sta") == 0)
			{
				if (dwNum == 1)
				{
					finishnum = 4;
				}
				else if (dwNum == 2)
				{
					finishnum = 12;
				}
				else if (dwNum == 3)
				{
					finishnum = 24;
				}
				else
				{
					finishnum = 40;
				}
			}
			else
			{
#ifdef __ZCK_TRAD_FR
				pUser->AddText("Exemple : /srs str 4");
#else
				pUser->AddText("Example: /srs str 4");
#endif // __ZCK_TRAD_FR
				return FALSE;
			}


			pUser->UpdateItem((BYTE)pItemElem->m_dwObjId, UI_RANDOMOPTITEMID, finishnum);
			pUser->AddPlaySound(SND_INF_UPGRADESUCCESS);
			g_UserMng.AddCreateSfxObj((CMover*)pUser, XI_INT_SUCCESS, pUser->GetPos().x, pUser->GetPos().y, pUser->GetPos().z);


		}
	}
#endif	// __WORLDSERVER
	return TRUE;
}
BOOL TextCmd_KillPlayer(CScanner& scanner)
{
#ifdef __WORLDSERVER
	scanner.GetToken();
	CUser* pUser = (CUser*)scanner.dwValue;
	u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
	CUser* pUserTarget = static_cast<CUser*>(prj.GetUserByID(idPlayer));

	if (!pUser)
		return FALSE;

	if (pUser == pUserTarget && !pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
	{
		return FALSE;
	}

	if (idPlayer > 0)
	{
		if (IsValidObj(pUserTarget))
		{
			CString str[2];
#ifdef __ZCK_AUTH
			if (pUser->IsAuthHigher(pUserTarget->m_dwAuthorization))
#else
			if (pUserTarget->m_dwAuthorization <= pUser->m_dwAuthorization)
#endif // __ZCK_AUTH
			{
				if (pUserTarget->DoDie(NULL))
					pUserTarget->SetHitPoint(0);
			}
		}
		else
			pUser->AddReturnSay(4, scanner.Token);
	}
	else
		pUser->AddReturnSay(3, scanner.Token);
#endif // __WORLDSERVER
	return TRUE;
}

BOOL TextCmd_LevelPlayer(CScanner& scanner)
{
#ifdef __WORLDSERVER
	scanner.GetToken();
	CUser* pUser = (CUser*)scanner.dwValue;

	if (scanner.tok == FINISHED)
		return TRUE;

	u_long idPlayer = CPlayerDataCenter::GetInstance()->GetPlayerId(scanner.token);
	CUser* pUserTarget = static_cast<CUser*>(prj.GetUserByID(idPlayer));

	if (idPlayer > 0)
	{
		if (IsValidObj(pUserTarget))
		{
			scanner.GetToken();
			CString strJob = scanner.Token;
			int nJob = JOB_VAGRANT;
			LONG nLevel = scanner.GetNumber();

			if (nLevel < 1)
				nLevel = 1;

#ifdef __ZCK_4_CLASSES
			if (nLevel > MAX_4TH_JOBS_LEVEL)
				nLevel = MAX_4TH_JOBS_LEVEL;
#else
			if (nLevel > MAX_3RD_LEGEND_LEVEL)
				nLevel = MAX_3RD_LEGEND_LEVEL;
#endif // __ZCK_4_CLASSES

			for (int i = 0; i < MAX_JOB; i++)
			{
				if (strcmp(strJob, prj.m_aJob[i].szName) == 0 || strcmp(strJob, prj.m_aJob[i].szEName) == 0)
				{
					nJob = i;
					break;
				}
			}
#ifdef __ZCK_4_CLASSES

			if (nLevel > MAX_3RD_LEGEND_LEVEL && (nJob < MAX_LEGEND_HERO || nJob >= MAX_LEGEND_HERO_ULTIMATE))
				nLevel = MAX_3RD_LEGEND_LEVEL;
#endif // __ZCK_4_CLASSES

			char chMessage[MAX_PATH] = { 0, };
			if (MAX_JOB_LEVEL < nLevel && nJob == 0)
			{
				sprintf(chMessage, prj.GetText(TID_GAME_CHOICEJOB));
				pUser->AddText(chMessage);
				return TRUE;
			}

			LONG nLegend = scanner.GetNumber();
			if ((nLegend > 0) && (nLegend < 3))
			{
				for (int i = nJob + 1; i < MAX_JOB; i++)
				{
					if (strcmp(strJob, prj.m_aJob[i].szName) == 0 || strcmp(strJob, prj.m_aJob[i].szEName) == 0)
					{
						nJob = i;
						if (nLegend == 1)
							break;
						else
							nLegend--;
					}
				}
#ifdef __ZCK_AUTH
				if (pUser->IsAuthHigher(pUserTarget->m_dwAuthorization))
#else
				if (pUserTarget->m_dwAuthorization <= pUser->m_dwAuthorization)
#endif // __ZCK_AUTH
					pUserTarget->InitLevel(nJob, nLevel);

				return	TRUE;
			}

			if (nLevel <= MAX_JOB_LEVEL)
			{
#ifdef __ZCK_AUTH
				if (pUser->IsAuthHigher(pUserTarget->m_dwAuthorization))
#else
				if (pUserTarget->m_dwAuthorization <= pUser->m_dwAuthorization)
#endif // __ZCK_AUTH
					pUserTarget->InitLevel(nJob, nLevel);
			}
			else if (MAX_JOB_LEVEL < nLevel && nLevel <= MAX_JOB_LEVEL + MAX_EXP_LEVEL)
			{
				if (MAX_JOBBASE <= nJob && nJob < MAX_EXPERT)
				{
#ifdef __ZCK_AUTH
					if (pUser->IsAuthHigher(pUserTarget->m_dwAuthorization))
#else
					if (pUserTarget->m_dwAuthorization <= pUser->m_dwAuthorization)
#endif // __ZCK_AUTH
						pUserTarget->InitLevel(nJob, nLevel);
				}
				else
				{
#ifdef __ZCK_TRAD_FR
					sprintf(chMessage, "Pas une classe experte");
					pUser->AddText(chMessage);
					sprintf(chMessage, "Classes expertes : ");
#else
					sprintf(chMessage, "Not Expert Job");
					pUser->AddText(chMessage);
					sprintf(chMessage, "Expert Job : ");
#endif // __ZCK_TRAD_FR
					for (int i = MAX_JOBBASE; i < MAX_EXPERT; ++i)
					{
						if (strlen(prj.m_aJob[i].szName) < 15)
						{
							strcat(chMessage, prj.m_aJob[i].szName);
							if (i + 1 != MAX_EXPERT)
							{
								strcat(chMessage, ", ");
							}
						}
					}
					pUser->AddText(chMessage);
#ifdef __ZCK_TRAD_FR
					sprintf(chMessage, "Niveaux experts : %d ~ %d", MAX_JOB_LEVEL + 1, MAX_JOB_LEVEL + MAX_EXP_LEVEL);
#else
					sprintf(chMessage, "Expert Level : %d ~ %d", MAX_JOB_LEVEL + 1, MAX_JOB_LEVEL + MAX_EXP_LEVEL);
#endif // __ZCK_TRAD_FR
					pUser->AddText(chMessage);
					return TRUE;
				}
			}
			else if (MAX_JOB_LEVEL + MAX_EXP_LEVEL < nLevel && nLevel < MAX_GENERAL_LEVEL + 1)
			{
				if (MAX_EXPERT <= nJob && nJob < MAX_PROFESSIONAL)
				{
#ifdef __ZCK_AUTH
					if (pUser->IsAuthHigher(pUserTarget->m_dwAuthorization))
#else
					if (pUserTarget->m_dwAuthorization <= pUser->m_dwAuthorization)
#endif // __ZCK_AUTH
					{
						pUserTarget->InitLevel(nJob, nLevel);
					}
				}
				else
				{
#ifdef __ZCK_TRAD_FR
					sprintf(chMessage, "Pas une classe professionnelle");
					pUser->AddText(chMessage);
					sprintf(chMessage, "Classes professionnelles : ");
#else
					sprintf(chMessage, "Not Professional Job");
					pUser->AddText(chMessage);
					sprintf(chMessage, "Professional Job : ");
#endif // __ZCK_TRAD_FR
					for (int i = MAX_EXPERT; i < MAX_PROFESSIONAL; ++i)
					{
						if (strlen(prj.m_aJob[i].szName) < 15)
						{
							strcat(chMessage, prj.m_aJob[i].szName);
							if (i + 1 != MAX_PROFESSIONAL)
							{
								strcat(chMessage, ", ");
							}
						}
					}
					pUser->AddText(chMessage);
#ifdef __ZCK_TRAD_FR
					sprintf(chMessage, "Niveaux professionnels : %d ~~~ ", MAX_JOB_LEVEL + MAX_EXP_LEVEL + 1);
#else
					sprintf(chMessage, "Professional Level : %d ~~~ ", MAX_JOB_LEVEL + MAX_EXP_LEVEL + 1);
#endif // __ZCK_TRAD_FR
					pUser->AddText(chMessage);
					return TRUE;
				}
			}
		}
		else
			pUser->AddReturnSay(4, scanner.Token);
	}
	else
		pUser->AddReturnSay(3, scanner.Token);
#endif // __WORLDSERVER
	return TRUE;
}

#ifdef __ZCK_UPGRADE
BOOL TextCmd_Upgrade(CScanner&)
{
#ifdef __CLIENT
	if (OpenZckUpgradeWindow())
		return FALSE;
#endif
	return TRUE;
}
#endif // __ZCK_UPGRADE

#ifdef __ZCK_SYSTEME_EVEIL
BOOL TextCmd_ZckSystemeEveil(CScanner&)
{
#ifdef __CLIENT
    CWndBase* pWnd = g_WndMng.GetApplet(APP_ZCK_SYSTEME_EVEIL);
    if (!pWnd)
        pWnd = g_WndMng.CreateApplet(APP_ZCK_SYSTEME_EVEIL);

    if (pWnd)
        pWnd->SetFocus();
#endif
    return TRUE;
}

BOOL TextCmd_ReloadZckAwakeMastery(CScanner& scanner)
{
#ifdef __WORLDSERVER
    CUser* pUser = (CUser*)scanner.dwValue;
    if (!IsValidObj(pUser))
        return TRUE;

    if (!prj.LoadZckAwakeMastery())
    {
#ifdef __ZCK_TRAD_FR
        pUser->AddText("\311chec du rechargement de ZckAwakeMastery.txt. Ancienne configuration conserv\351e.");
#else
        pUser->AddText("Echec du rechargement de ZckAwakeMastery.txt. Ancienne configuration conservee.");
#endif // __ZCK_TRAD_FR
        return TRUE;
    }

    for (std::unordered_map<DWORD, CUser*>::iterator it = g_UserMng.m_users.begin();
         it != g_UserMng.m_users.end(); ++it)
    {
        CUser* pTarget = it->second;
        if (!IsValidObj(pTarget))
            continue;

        pTarget->m_ZckAwakeMastery.Normalize((WORD)prj.m_ZckAwakeMasteryConfig.nMasteryMax);
        pTarget->AddZckAwakeMasteryState();
    }

#ifdef __ZCK_TRAD_FR
    pUser->AddText("ZckAwakeMastery.txt recharg\351 avec succ\350s.");
#else
    pUser->AddText("ZckAwakeMastery.txt recharge avec succes.");
#endif // __ZCK_TRAD_FR
#endif
    return TRUE;
}
#endif // __ZCK_SYSTEME_EVEIL

BOOL TextCmd_OutAll(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	g_UserMng.KickAllPlayers();
#endif    // __WORLDSERVER
	return TRUE;
}
#endif

#ifdef __ZCK_ANTICHEAT
// Commande GM. Trois formes :
//   /ZckAnticheat            liste les joueurs au score de suspicion non nul
//   /ZckAnticheat <n>        idem, filtre sur un score minimal
//   /ZckAnticheat reload     recharge ZckAnticheat.inc a chaud
//   /ZckAnticheat reset <nom>  remet a zero les compteurs d'un joueur
// Aucun paquet : le mecanisme de commande chat existe deja.
BOOL TextCmd_ZckAnticheat(CScanner& scanner)
{
#ifdef __WORLDSERVER
    CUser* pUser = (CUser*)scanner.dwValue;
    if (!IsValidObj(pUser))
        return TRUE;

    scanner.GetToken();

    if (scanner.tok == FINISHED)
        CZckAnticheatManager::GetInstance()->ReportTo(pUser, 0);
    else if (scanner.Token == _T("reload"))
        CZckAnticheatManager::GetInstance()->ReloadTo(pUser, _T("ZckAnticheat.inc"));
    else if (scanner.Token == _T("reset"))
    {
        scanner.GetToken();
        CZckAnticheatManager::GetInstance()->ResetTo(pUser,
            (scanner.tok == FINISHED) ? _T("") : scanner.token);
    }
    else
        CZckAnticheatManager::GetInstance()->ReportTo(pUser, atoi(scanner.token));
#endif    // __WORLDSERVER
    return TRUE;
}
#endif // __ZCK_ANTICHEAT

#ifdef __ZCK_FENETRE_CHAT_MJ
// Commande MJ. Trois formes :
//   /ZckChatMj           ouvre la fenetre (client) et affiche l'etat (serveur)
//   /ZckChatMj reload    recharge ZckFenetreChatMj.inc a chaud
//   /ZckChatMj status    etat seul, sans ouvrir la fenetre
//
// L'ouverture de la fenetre est un acte purement CLIENT et n'est
// jamais une autorisation : le serveur refuse l'abonnement si le
// compte n'est pas AUTH_ADMINISTRATOR. Un client modifie peut ouvrir
// une fenetre vide, rien de plus.
BOOL TextCmd_ZckChatMj(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (!IsValidObj(pUser))
		return TRUE;

	scanner.GetToken();

	if (scanner.tok != FINISHED && scanner.Token == _T("reload"))
		CZckChatMjManager::GetInstance()->ReloadTo(pUser, _T("ZckFenetreChatMj.inc"));
	else
		CZckChatMjManager::GetInstance()->ReportTo(pUser);
#else	// __WORLDSERVER
#ifdef __CLIENT
	scanner.GetToken();

	if (scanner.tok == FINISHED)
	{
		if (g_WndMng.GetWndBase(APP_ZCK_FENETRE_CHAT_MJ) == NULL)
			g_WndMng.CreateApplet(APP_ZCK_FENETRE_CHAT_MJ);
	}
#endif	// __CLIENT
#endif	// __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_FENETRE_CHAT_MJ

#ifdef __ZCK_ANARCHY
// Commande MJ. Cinq formes :
//   /ZckAnarchy            client : ouvre la fenetre / serveur : etat
//   /ZckAnarchy status     etat seul
//   /ZckAnarchy reload     recharge ZckAnarchy.inc a chaud
//   /ZckAnarchy reset      remet a zero le classement saisonnier
//   /ZckAnarchy 0          active TOUS les buffs (compatibilite ancienne)
//   /ZckAnarchy <n>        active le buff d'index n
//   /ZckAnarchy only <n>   active le seul buff d'index n, y compris 0
//
// La forme "0 = tous" est celle de l'ancien systeme : elle rendait
// l'index 0 inatteignable. "only" comble ce trou sans rien changer au
// comportement historique.
BOOL TextCmd_ZckAnarchy(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;

	CZckAnarchyManager* pMng = CZckAnarchyManager::GetInstance();

	scanner.GetToken();

	if (scanner.tok == FINISHED || scanner.Token == _T("status"))
	{
		pMng->ReportTo(pUser);
		return TRUE;
	}

	if (scanner.Token == _T("reload"))
	{
		pMng->ReloadTo(pUser, _T("ZckAnarchy.inc"));
		return TRUE;
	}

	if (scanner.Token == _T("reset"))
	{
		// Remise a zero SAISONNIERE. Le cumul total est conserve a cote,
		// il n'est jamais efface. Le CoreServer ecrit son fichier dans la
		// foulee et rediffuse la table a tous les mondes.
		g_DPCoreClient.SendZckAnarchyReset();
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Anarchy : classement saisonnier remis \340 z\351ro.", 0xffffffff);
#else
		pUser->AddText("Anarchy : classement saisonnier remis a zero.", 0xffffffff);
#endif // __ZCK_TRAD_FR
		return TRUE;
	}

	BOOL bForceSingle = FALSE;

	if (scanner.Token == _T("only"))
	{
		bForceSingle = TRUE;
		scanner.GetToken();

		if (scanner.tok == FINISHED)
		{
			pUser->AddText("Usage : /ZckAnarchy only <index>", 0xffff0000);
			return TRUE;
		}
	}

	const int nArg = atoi(scanner.Token);

	// Diffusion de tous les buffs declares.
	if (nArg == 0 && !bForceSingle)
	{
		const int nCount = pMng->GetBuffCount();

		for (int i = 0; i < nCount; ++i)
		{
			const ZCK_ANARCHY_BUFF* pBuff = pMng->GetBuff(i);
			if (pBuff && pBuff->nId > 0)
				g_DPCoreClient.SendZckAnarchy((DWORD)pBuff->nId);
		}

#ifdef __ZCK_TRAD_FR
		g_DPCoreClient.SendSystem("Anarchy : tous les buffs serveur ont \351t\351 activ\351s.");
#else
		g_DPCoreClient.SendSystem("Anarchy : tous les buffs serveur ont ete actives.");
#endif // __ZCK_TRAD_FR
		return TRUE;
	}

	const ZCK_ANARCHY_BUFF* pBuff = pMng->GetBuff(nArg);
	if (!pBuff || pBuff->nId <= 0)
	{
		pUser->AddText("Index anarchy invalide.", 0xffff0000);
		return TRUE;
	}

	g_DPCoreClient.SendZckAnarchy((DWORD)pBuff->nId);

	CString str;
#ifdef __ZCK_TRAD_FR
	str.Format("Anarchy : buff %d activ\351.", nArg);
#else
	str.Format("Anarchy : buff %d active.", nArg);
#endif // __ZCK_TRAD_FR
	g_DPCoreClient.SendSystem(str.GetString());
#else	// __WORLDSERVER
#ifdef __CLIENT
	scanner.GetToken();

	if (scanner.tok == FINISHED)
	{
		if (g_WndMng.GetWndBase(APP_ANARCHY_SKILL) == NULL)
			g_WndMng.CreateApplet(APP_ANARCHY_SKILL);
	}
#endif	// __CLIENT
#endif	// __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_ANARCHY

#ifdef __ZCK_INVASION
// /createinvasion <creneau> : lance tout de suite le creneau d'index donne du
// bloc Schedule de ZckInvasion.inc (0 = premier Slot), avec sa carte, sa
// position et son invasion. Refuse si une invasion est deja en cours.
BOOL TextCmd_ZckInvasion(CScanner& scanner)
{
#ifdef __WORLDSERVER
	// ZckInvasion.h arrive par User.h, inclus plus haut sous __WORLDSERVER.
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;

	// "/createinvasion abc" : GetNumber rend 0, le jeton doit etre un nombre.
	const int nSlotId = scanner.GetNumber();
	if (scanner.tok == FINISHED || scanner.tokenType != NUMBER || nSlotId < 0)
	{
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Usage : /createinvasion <index du cr\351neau> (0 = premier Slot du bloc Schedule de ZckInvasion.inc)", 0xffff0000);
#else
		pUser->AddText("Usage : /createinvasion <index du creneau> (0 = premier Slot du bloc Schedule de ZckInvasion.inc)", 0xffff0000);
#endif // __ZCK_TRAD_FR
		return TRUE;
	}

	CString strResult;
	const BOOL bStarted = CZckInvasionManager::GetInstance()->StartSlotManual((size_t)nSlotId, strResult);
	pUser->AddText(strResult, bStarted ? 0xff00ff00 : 0xffff0000);
#endif // __WORLDSERVER

	return TRUE;
}
#endif // __ZCK_INVASION
#ifdef __ZCK_CLEAN_INVENTAIRE
// /cleaninventaire (alias /cleaninv) : vide les cases du sac de l'inventaire du MJ qui tape la commande.
// Meme regle que /irm (TextCmd_InvenRemove, inchange) : l'equipement porte, les objets en cours
// d'utilisation (familier invoque...) et les objets poses dans un echange ou une boutique personnelle
// sont conserves. Bilan affiche au MJ (CustomCommon.h).
BOOL TextCmd_ZckCleanInventaire(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;

	int nCases = 0;
	int nObjets = 0;
	int nUtilises = 0;
	int nEchanges = 0;
	int nHorsBorne = 0;
	const int nMax = pUser->m_Inventory.GetMax();
	for (int i = 0; i < nMax; ++i)
	{
		CItemElem* pItemElem = pUser->m_Inventory.GetAtId(i);
		if (pItemElem == NULL)
			continue;
		if (pUser->m_Inventory.IsEquip(pItemElem->m_dwObjId))
			continue;					// equipement porte : conserve
		if (pItemElem->GetExtra() != 0)
		{
			nEchanges++;				// pose dans un echange ou dans la boutique personnelle : conserve
			continue;
		}
		if (pUser->IsUsing(pItemElem))
		{
			nUtilises++;				// familier invoque, objet en cours d'utilisation : conserve
			continue;
		}
		if (i > 0xFF)
		{
			nHorsBorne++;				// RemoveItem prend un BYTE (168 + 32 cases : jamais atteint)
			continue;
		}
		const int nNombre = pItemElem->m_nItemNum;
		pUser->RemoveItem((BYTE)(i), pItemElem->m_nItemNum);
		nCases++;
		nObjets += nNombre;
	}

	CString str;
	if (nCases > 0)
	{
		str.Format("/cleaninventaire : %d case(s) vid\351e(s), %d objet(s) supprim\351(s). \311quipement port\351 conserv\351.", nCases, nObjets);
		pUser->AddText(str, 0xff80ff80);
	}
	else
		pUser->AddText("/cleaninventaire : aucun objet \340 supprimer dans le sac. \311quipement port\351 conserv\351.", 0xffff8040);
	if (nUtilises > 0)
	{
		str.Format("%d objet(s) conserv\351(s) car en cours d'utilisation (familier invoqu\351...).", nUtilises);
		pUser->AddText(str, 0xffff8040);
	}
	if (nEchanges > 0)
	{
		str.Format("%d objet(s) conserv\351(s) car pos\351(s) dans un \351change ou dans votre boutique personnelle.", nEchanges);
		pUser->AddText(str, 0xffff8040);
	}
	if (nHorsBorne > 0)
	{
		str.Format("%d objet(s) non trait\351(s) : case au-del\340 de 255.", nHorsBorne);
		pUser->AddText(str, 0xffff0000);
	}
#else // __WORLDSERVER
	(void)scanner;
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_CLEAN_INVENTAIRE
#ifdef __ZCK_PLAGE_OBJET
// /ciplage <ID debut> <ID fin> (alias /cip) : cree dans l'inventaire du MJ un exemplaire de
// chaque objet de la plage d'ID, comme /ci le ferait objet par objet (memes refus : objets
// virtuels, oeufs autres que II_PET_EGG). Au plus ZCK_PLAGE_OBJET_MAX objets par commande,
// arret propre si l'inventaire est plein, bilan affiche au MJ (CustomCommon.h).
#ifdef __WORLDSERVER
static BOOL ZckPlageObjetNombre(CScanner& scanner, int* pnValeur)
{
	if (scanner.tokenType != NUMBER)
		return FALSE;
	int nLongueur = scanner.Token.GetLength();
	if (nLongueur <= 0 || nLongueur > 6)
		return FALSE;
	for (int i = 0; i < nLongueur; i++)
	{
		if (scanner.Token[i] < '0' || scanner.Token[i] > '9')
			return FALSE;
	}
	*pnValeur = _ttoi(scanner.Token);
	return TRUE;
}
#endif // __WORLDSERVER

BOOL TextCmd_ZckPlageObjet(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;

	int anValeur[2] = { 0, 0 };
	int nValeurs = 0;
	BOOL bSyntaxe = TRUE;
	while (bSyntaxe)
	{
		scanner.GetToken();
		if (scanner.tok == FINISHED)
			break;
		if (nValeurs >= 2 || ZckPlageObjetNombre(scanner, &anValeur[nValeurs]) == FALSE)
			bSyntaxe = FALSE;
		else
			nValeurs++;
	}
	CString str;
	if (bSyntaxe == FALSE || nValeurs != 2)
	{
		str.Format("Usage : /ciplage <ID d\351but> <ID fin>   (un exemplaire de chaque objet, %d objets au plus)", ZCK_PLAGE_OBJET_MAX);
		pUser->AddText(str, 0xffff0000);
		return TRUE;
	}
	int nDebut = anValeur[0];
	int nFin = anValeur[1];
	if (nDebut <= 0 || nFin < nDebut || nFin - nDebut + 1 > ZCK_PLAGE_OBJET_PLAGE_MAX)
	{
		str.Format("/ciplage : plage invalide (ID de d\351but >= 1, ID de fin >= d\351but, %d ID au plus).", ZCK_PLAGE_OBJET_PLAGE_MAX);
		pUser->AddText(str, 0xffff0000);
		return TRUE;
	}

	int nCrees = 0;
	int nAbsents = 0;
	int nPremierAbsent = 0;
	int nRefuses = 0;
	int nPremierRefuse = 0;
	int nEchecs = 0;
	int nPremierEchec = 0;
	int nArret = 0;			// 1 = inventaire plein, 2 = limite ZCK_PLAGE_OBJET_MAX atteinte
	int nNonCrees = 0;
	int nPremierNonCree = 0;
	for (int nId = nDebut; nId <= nFin; nId++)
	{
		// borne verifiee ici : hors du tableau, GetItemProp ecrirait une erreur "range_error"
		ItemProp* pProp = NULL;
		if (nId < prj.m_aPropItem.GetSize())
			pProp = prj.GetItemProp(nId);
		if (pProp == NULL || pProp->dwID == 0)
		{
			if (nAbsents++ == 0)
				nPremierAbsent = nId;
			continue;
		}
		if (pProp->dwItemKind3 == IK3_VIRTUAL || (pProp->dwItemKind3 == IK3_EGG && pProp->dwID != II_PET_EGG))
		{
			if (nRefuses++ == 0)
				nPremierRefuse = nId;
			continue;
		}
		if (nArret != 0)
		{
			nNonCrees++;
			continue;
		}
		if (nCrees >= ZCK_PLAGE_OBJET_MAX)
		{
			nArret = 2;
			nNonCrees = 1;
			nPremierNonCree = nId;
			continue;
		}
		CItemElem itemElem;
		itemElem.m_dwItemId = pProp->dwID;
		itemElem.m_nItemNum = 1;
		itemElem.m_nHitPoint = -1;
		if (pUser->CreateItem(&itemElem))
			nCrees++;
		else if (pUser->m_Inventory.GetEmptyCount() <= 0)
		{
			nArret = 1;
			nNonCrees = 1;
			nPremierNonCree = nId;
		}
		else if (nEchecs++ == 0)
			nPremierEchec = nId;
	}

	str.Format("/ciplage %d \340 %d : %d objet(s) cr\351\351(s) dans l'inventaire.", nDebut, nFin, nCrees);
	pUser->AddText(str, nCrees > 0 ? 0xff80ff80 : 0xffff0000);
	if (nAbsents > 0)
	{
		str.Format("%d ID sans objet dans le propItem du serveur (premier : %d).", nAbsents, nPremierAbsent);
		pUser->AddText(str, 0xffff8040);
	}
	if (nRefuses > 0)
	{
		str.Format("%d objet(s) refus\351(s) comme avec /ci : objets virtuels ou oeufs (premier : %d).", nRefuses, nPremierRefuse);
		pUser->AddText(str, 0xffff8040);
	}
	if (nArret == 1)
	{
		str.Format("Inventaire plein : %d objet(s) non cr\351\351(s). Faites de la place puis /ciplage %d %d", nNonCrees, nPremierNonCree, nFin);
		pUser->AddText(str, 0xffff0000);
	}
	else if (nArret == 2)
	{
		str.Format("Limite de %d objets atteinte : %d objet(s) non cr\351\351(s). Pour la suite : /ciplage %d %d", ZCK_PLAGE_OBJET_MAX, nNonCrees, nPremierNonCree, nFin);
		pUser->AddText(str, 0xffff8040);
	}
	if (nEchecs > 0)
	{
		str.Format("%d \351chec(s) de cr\351ation (premier ID : %d).", nEchecs, nPremierEchec);
		pUser->AddText(str, 0xffff0000);
	}
#else // __WORLDSERVER
	(void)scanner;
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_PLAGE_OBJET
#ifdef __ZCK_PLAGE
// /cnplage <ID debut> <ID fin> [0|1] (alias /cnp) : invoque une fois chaque monstre
// de la plage d'ID, en grille centree sur le MJ (meme monde, meme couche), pose au
// sol comme le respawn (GetUnderHeight). 3e nombre : 0 ou absent = pas agressif,
// 1 = agressif. Seuls les movers acceptes par /cn (IA de monstre) sont crees ; un
// bilan est affiche au MJ. Reglages : ZCK_PLAGE_MAX, ZCK_PLAGE_ECART (CustomCommon.h).
#ifdef __WORLDSERVER
static BOOL ZckPlageEstMonstre(MoverProp* pProp)
{
	if (pProp == NULL || pProp->dwID == 0)
		return FALSE;
	if (pProp->dwAI == AII_MONSTER
		|| pProp->dwAI == AII_CLOCKWORKS
		|| pProp->dwAI == AII_BIGMUSCLE
		|| pProp->dwAI == AII_KRRR
		|| pProp->dwAI == AII_BEAR
		|| pProp->dwAI == AII_METEONYKER)
		return TRUE;
	return FALSE;
}

static BOOL ZckPlageNombre(CScanner& scanner, int* pnValeur)
{
	if (scanner.tokenType != NUMBER)
		return FALSE;
	int nLongueur = scanner.Token.GetLength();
	if (nLongueur <= 0 || nLongueur > 6)
		return FALSE;
	for (int i = 0; i < nLongueur; i++)
	{
		if (scanner.Token[i] < '0' || scanner.Token[i] > '9')
			return FALSE;
	}
	*pnValeur = _ttoi(scanner.Token);
	return TRUE;
}
#endif // __WORLDSERVER

BOOL TextCmd_ZckPlage(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;
	CWorld* pWorld = pUser->GetWorld();
	if (pWorld == NULL)
		return TRUE;

	int anValeur[3] = { 0, 0, 0 };
	int nValeurs = 0;
	BOOL bSyntaxe = TRUE;
	while (bSyntaxe)
	{
		scanner.GetToken();
		if (scanner.tok == FINISHED)
			break;
		if (nValeurs >= 3 || ZckPlageNombre(scanner, &anValeur[nValeurs]) == FALSE)
			bSyntaxe = FALSE;
		else
			nValeurs++;
	}
	if (bSyntaxe == FALSE || nValeurs < 2 || (nValeurs == 3 && anValeur[2] != 0 && anValeur[2] != 1))
	{
		pUser->AddText("Usage : /cnplage <ID d\351but> <ID fin> [0|1]   (0 ou rien = pas agressif, 1 = agressif)", 0xffff0000);
		return TRUE;
	}
	int nDebut = anValeur[0];
	int nFin = anValeur[1];
	BOOL bAgressif = (nValeurs == 3 && anValeur[2] == 1) ? TRUE : FALSE;
	CString str;
	if (nDebut <= 0 || nFin < nDebut || nFin - nDebut + 1 > ZCK_PLAGE_MAX)
	{
		str.Format("/cnplage : plage invalide (ID de d\351but >= 1, ID de fin >= d\351but, %d ID au plus).", ZCK_PLAGE_MAX);
		pUser->AddText(str, 0xffff0000);
		return TRUE;
	}

	int nMonstres = 0;
	int nAbsents = 0;
	int nPremierAbsent = 0;
	int nAutres = 0;
	int nPremierAutre = 0;
	for (int nId = nDebut; nId <= nFin; nId++)
	{
		MoverProp* pProp = prj.GetMoverPropEx(nId);
		if (pProp == NULL || pProp->dwID == 0)
		{
			if (nAbsents++ == 0)
				nPremierAbsent = nId;
		}
		else if (ZckPlageEstMonstre(pProp) == FALSE)
		{
			if (nAutres++ == 0)
				nPremierAutre = nId;
		}
		else
			nMonstres++;
	}

	// grille de nColonnes (nombre pair : aucune case au centre, donc aucun monstre sur le MJ)
	int nColonnes = 2;
	while (nColonnes * nColonnes < nMonstres)
		nColonnes += 2;
	int nLignes = (nMonstres + nColonnes - 1) / nColonnes;
	D3DXVECTOR3 vCentre = pUser->GetPos();
	int nCrees = 0;
	int nHorsCarte = 0;
	int nEchecs = 0;
	int nPremierEchec = 0;
	BOOL bLimite = FALSE;
	int nCase = 0;
	for (int nId = nDebut; nId <= nFin; nId++)
	{
		MoverProp* pProp = prj.GetMoverPropEx(nId);
		if (ZckPlageEstMonstre(pProp) == FALSE)
			continue;
		if (pWorld->GetObjCount() >= MAX_ADDOBJS || pWorld->GetObjCount() >= MAX_DYNAMICOBJ)
		{
			bLimite = TRUE;
			break;
		}
		D3DXVECTOR3 v = vCentre;
		v.x += ((FLOAT)(nCase % nColonnes) - (FLOAT)(nColonnes - 1) * 0.5f) * ZCK_PLAGE_ECART;
		v.z += ((FLOAT)(nCase / nColonnes) - (FLOAT)(nLignes - 1) * 0.5f) * ZCK_PLAGE_ECART;
		v.y += 1.0f;
		nCase++;
		if (pWorld->VecInWorld(v) == FALSE)
		{
			nHorsCarte++;
			continue;
		}
		if (pProp->dwFlying == 0)
			v.y = pWorld->GetUnderHeight(v);

		CObj* pObj = CreateObj(D3DDEVICE, OT_MOVER, pProp->dwID);
		if (pObj == NULL)
		{
			if (nEchecs++ == 0)
				nPremierEchec = nId;
			continue;
		}
		pObj->SetPos(v);
		pObj->InitMotion(MTI_STAND);
		pObj->UpdateLocalMatrix();
		((CMover*)pObj)->m_bActiveAttack = bAgressif;
		((CMover*)pObj)->SetGold(((CMover*)pObj)->GetLevel() * 15);
		if (pWorld->ADDOBJ(pObj, TRUE, pUser->GetLayer()) == FALSE)
		{
			SAFE_DELETE(pObj);
			if (nEchecs++ == 0)
				nPremierEchec = nId;
			continue;
		}
		nCrees++;
	}

	str.Format("/cnplage %d \340 %d : %d monstre(s) invoqu\351(s), %s.", nDebut, nFin, nCrees, bAgressif ? "agressifs" : "pas agressifs");
	pUser->AddText(str, nCrees > 0 ? 0xff80ff80 : 0xffff0000);
	if (nAbsents > 0)
	{
		str.Format("%d ID sans monstre dans le propMover du serveur (premier : %d).", nAbsents, nPremierAbsent);
		pUser->AddText(str, 0xffff8040);
	}
	if (nAutres > 0)
	{
		str.Format("%d ID ignor\351(s) : PNJ ou IA que /cn refuse aussi (premier : %d).", nAutres, nPremierAutre);
		pUser->AddText(str, 0xffff8040);
	}
	if (nHorsCarte > 0)
	{
		str.Format("%d monstre(s) non pos\351(s) : case hors de la carte, \351loignez-vous du bord.", nHorsCarte);
		pUser->AddText(str, 0xffff8040);
	}
	if (nEchecs > 0)
	{
		str.Format("%d \351chec(s) de cr\351ation (premier ID : %d).", nEchecs, nPremierEchec);
		pUser->AddText(str, 0xffff0000);
	}
	if (bLimite)
		pUser->AddText("Arr\352t : limite d'objets du monde atteinte.", 0xffff0000);
#else // __WORLDSERVER
	(void)scanner;
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_PLAGE
#ifdef __ZCK_MUTATEURS
// /zckmut : etat du systeme ; /zckmut <n> : combinaisons de la semaine
// courante + n pour les donjons du .inc ; /zckmut force <id> [<id> ...] :
// combinaison de la prochaine instance creee par ce MJ ; /zckmut force : annule.
BOOL TextCmd_ZckMutateurs(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;
	CZckMutateursMng::GetInstance()->CommandeMj(pUser, scanner);
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_MUTATEURS
#ifdef __ZCK_IA_FARM
// /iafarm : ouvre la fenetre APP_BOTSYSTEMZCK ; /iafarm start | stop | on | off :
// commandes du module (donneur : /ai ouvrait CWndRefresher) ;
// /iafarm offline on | off : armement du mode hors ligne (WorldServer).
BOOL TextCmd_ZckIaFarm(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	if (scanner.tok != FINISHED)
	{
		if (scanner.Token == _T("start"))
			g_ZckIaFarm.Demarrer();
		else if (scanner.Token == _T("stop"))
			g_ZckIaFarm.Arreter();
		else if (scanner.Token == _T("on"))
			g_ZckIaFarm.Activer(true);
		else if (scanner.Token == _T("off"))
			g_ZckIaFarm.Activer(false);
		else if (scanner.Token == _T("offline"))
		{
			scanner.GetToken();
			if (scanner.tok != FINISHED && scanner.Token == _T("on"))
				g_ZckIaFarm.ArmerHorsLigne(true);
			else if (scanner.tok != FINISHED && scanner.Token == _T("off"))
				g_ZckIaFarm.ArmerHorsLigne(false);
			else
				g_WndMng.PutString("Usage : /iafarm offline on | off", NULL, 0xffff0000);
		}
		return TRUE;
	}
	if (g_WndMng.GetWndBase(APP_BOTSYSTEMZCK) == NULL)
		g_WndMng.CreateApplet(APP_BOTSYSTEMZCK);
#endif // __CLIENT
	return TRUE;
}

// /iafarmfantomes : liste des personnages en farm hors ligne sur ce WorldServer ;
// /iafarmfantomes <nom> : arrete le farm hors ligne de ce personnage (TCM_SERVER,
// AUTH_GAMEMASTER ; le personnage est sauvegarde et retire du monde).
BOOL TextCmd_ZckIaFarmFantomes(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;
	scanner.GetToken();
	if (scanner.tok != FINISHED)
		g_ZckIaFarmServeur.CommandeMj(pUser, (LPCTSTR)scanner.Token);
	else
		g_ZckIaFarmServeur.CommandeMj(pUser, NULL);
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
// /mondialbuff : ouvre la fenetre APP_ZCK_MONDIAL_BUFF (tout joueur, rien
// n'est envoye). /mondialbuff <index|nom> <minutes> | stop <index|nom> |
// liste | palier <n> <minutes> (AUTH_GAMEMASTER) | recharger
// (AUTH_ADMINISTRATOR) : la ligne part au WorldServer (TCM_BOTH), qui
// revalide les droits dans CZckMondialBuffMng::Commande.
BOOL TextCmd_ZckMondialBuff(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	if (scanner.tok == FINISHED)
	{
		if (g_WndMng.GetWndBase(APP_ZCK_MONDIAL_BUFF) == NULL)
			g_WndMng.CreateApplet(APP_ZCK_MONDIAL_BUFF);
		return FALSE;
	}
	if (g_pPlayer == NULL || !g_pPlayer->IsAuthHigher(AUTH_GAMEMASTER))
	{
		g_WndMng.PutString("Buffs mondiaux : /mondialbuff seul ouvre la fen\352tre, les sous-commandes sont r\351serv\351es aux MJ.", NULL, 0xffff0000);
		return FALSE;
	}
#endif // __CLIENT
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;
	CZckMondialBuffMng::GetInstance()->Commande(pUser, scanner);
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_MONDIAL_BUFF

#ifdef __ZCK_PERIN_BUFF
// /perinbuff : ouvre la fenetre APP_ZCK_PERIN_BUFF (tout joueur, rien n'est
// envoye). /perinbuff liste | ajouter <n> | retirer <n> | niveau <n> | vider |
// remplir (AUTH_GAMEMASTER) | recharger (AUTH_ADMINISTRATOR) : la ligne part
// au WorldServer (TCM_BOTH), qui revalide les droits dans
// CZckPerinBuffMng::Commande.
BOOL TextCmd_ZckPerinBuff(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	if (scanner.tok == FINISHED)
	{
		if (g_WndMng.GetWndBase(APP_ZCK_PERIN_BUFF) == NULL)
			g_WndMng.CreateApplet(APP_ZCK_PERIN_BUFF);
		return FALSE;
	}
	if (g_pPlayer == NULL || !g_pPlayer->IsAuthHigher(AUTH_GAMEMASTER))
	{
		g_WndMng.PutString("Buffs Perin : /perinbuff seul ouvre la fen\352tre, les sous-commandes sont r\351serv\351es aux MJ.", NULL, 0xffff0000);
		return FALSE;
	}
#endif // __CLIENT
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;
	CZckPerinBuffMng::GetInstance()->Commande(pUser, scanner);
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_PERIN_BUFF

#ifdef __ZCK_COMBAT_MC
BOOL TextCmd_ZckCombatMCStart(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CMonsterClashMng::GetInstance()->StartRegister();
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_COMBAT_MC

#ifdef __ZCK_TOUR_INFINI
// /tour quitter : sortie volontaire de la montee (TCM_SERVER, AUTH_GENERAL).
// Le joueur garde ce qu'il a recu ; son record est mis a jour.
BOOL TextCmd_ZckTourInfini(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;

	// ParsingCommand ne normalise que le nom de la commande : l'argument est
	// compare sans tenir compte de la casse.
	scanner.GetToken();
	CString strZckTourArg = scanner.Token;
	strZckTourArg.MakeLower();
	if (scanner.tok != FINISHED && strZckTourArg == _T("quitter"))
		CZckTourInfiniMng::GetInstance()->Leave(pUser);
	else
		pUser->AddText("Usage : /tour quitter", 0xffff0000);
#endif // __WORLDSERVER
	return TRUE;
}

// /tourstop <layer> : arret d'une montee (AUTH_ADMINISTRATOR). layer = id du premier
// membre parti de l'equipe (celui qui l'a inscrite, s'il etait la).
BOOL TextCmd_ZckTourInfiniStop(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;

	const int nLayer = scanner.GetNumber();
	if (nLayer > 0 && CZckTourInfiniMng::GetInstance()->RequestStop(nLayer))
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Tour infinie : arr\352t demand\351, effectif au prochain tick.", 0xffffffff);
	else
		pUser->AddText("Usage : /tourstop <layer> (layer = id du premier membre parti de l'\351quipe ; aucune mont\351e active pour cette valeur)", 0xffff0000);
#else
		pUser->AddText("Tour infinie : arret demande, effectif au prochain tick.", 0xffffffff);
	else
		pUser->AddText("Usage : /tourstop <layer> (layer = id du premier membre parti de l'equipe ; aucune montee active pour cette valeur)", 0xffff0000);
#endif // __ZCK_TRAD_FR
#endif // __WORLDSERVER
	return TRUE;
}

// /tourstart : ouverture immediate des inscriptions (AUTH_ADMINISTRATOR), comme
// /mcstart. Sans effet si une session est deja ouverte ou en cours.
BOOL TextCmd_ZckTourInfiniStart(CScanner& scanner)
{
#ifdef __WORLDSERVER
	CUser* pUser = (CUser*)scanner.dwValue;
	if (IsInvalidObj(pUser))
		return TRUE;

	if (CZckTourInfiniMng::GetInstance()->OpenSession(static_cast<time_t>(CTime::GetCurrentTime().GetTime())))
		pUser->AddText("Tour infinie : inscriptions ouvertes.", 0xffffffff);
	else
#ifdef __ZCK_TRAD_FR
		pUser->AddText("Tour infinie : ouverture impossible (session d\351j\340 ouverte ou en cours, ou configuration invalide).", 0xffff0000);
#else
		pUser->AddText("Tour infinie : ouverture impossible (session deja ouverte ou en cours, ou configuration invalide).", 0xffff0000);
#endif // __ZCK_TRAD_FR
#endif // __WORLDSERVER
	return TRUE;
}
#endif // __ZCK_TOUR_INFINI
#ifdef __ZCK_VOIR_INVENTAIRE_JOUEURS
// /voirinventaire <nom> [coffre] (MJ) : inventaire, equipement et coffre d'un
// joueur connecte, en lecture seule (portage de /viewinv de Titanium). Commande
// cote client : elle n'envoie que le nom, le WorldServer juge tout.
BOOL TextCmd_ZckVoirInventaire(CScanner& scanner)
{
#ifdef __CLIENT
	scanner.GetToken();
	const CString strNom = scanner.Token;
	scanner.GetToken();
	const BOOL bCoffre = (scanner.Token.CompareNoCase(_T("coffre")) == 0) ? TRUE : FALSE;
	CWndZckVoirInventaire::Demander(strNom, bCoffre ? ZCK_VOIR_INV_ONGLET_COFFRE : ZCK_VOIR_INV_ONGLET_INVENTAIRE);
#else // __CLIENT
	(void)scanner;
#endif // __CLIENT
	return TRUE;
}
#endif // __ZCK_VOIR_INVENTAIRE_JOUEURS

BEGINE_TEXTCMDFUNC_MAP
////////////////////////////////////////////////// AUTH_GENERAL begin///////////////////////////////////////////////
#ifdef __ZCK_TRAD_FR
ON_TEXTCMDFUNC(TextCmd_whisper, "whisper", "w", "±УјУё»", "±У", TCM_SERVER, AUTH_GENERAL, "Chuchoter [/commande nom message]")
ON_TEXTCMDFUNC(TextCmd_say, "say", "say", "ё»", "ё»", TCM_SERVER, AUTH_GENERAL, "Message priv\351 [/commande nom message]")
ON_TEXTCMDFUNC(TextCmd_Position, "position", "pos", "БВЗҐ", "БВЗҐ", TCM_CLIENT, AUTH_GENERAL, "Afficher les coordonn\351es actuelles")
ON_TEXTCMDFUNC(TextCmd_shout, "shout", "s", "їЬДЎ±в", "їЬ", TCM_BOTH, AUTH_GENERAL, "Crier [/commande message]")
ON_TEXTCMDFUNC(TextCmd_PartyChat, "partychat", "p", "±ШґЬё»", "±Ш", TCM_BOTH, AUTH_GENERAL, "Discussion de groupe [/commande message]")
ON_TEXTCMDFUNC(TextCmd_Time, "Time", "ti", "ЅГ°Ј", "ЅГ", TCM_CLIENT, AUTH_GENERAL, "Afficher l'heure [/time]")

ON_TEXTCMDFUNC(TextCmd_GuildChat, "GuildChat", "g", "±жµеё»", "±жё»", TCM_BOTH, AUTH_GENERAL, "Discussion de guilde")
ON_TEXTCMDFUNC(TextCmd_PartyInvite, "PartyInvite", "partyinvite", "±ШґЬГКГ»", "±ШГК", TCM_SERVER, AUTH_GENERAL, "Inviter dans le groupe")
ON_TEXTCMDFUNC(TextCmd_GuildInvite, "GuildInvite", "guildinvite", "±жµеГКГ»", "±жГК", TCM_SERVER, AUTH_GENERAL, "Inviter dans la guilde")
#else
ON_TEXTCMDFUNC(TextCmd_whisper, "whisper", "w", "±УјУё»", "±У", TCM_SERVER, AUTH_GENERAL, "±УјУё» [/ён·Й ѕЖАМµр і»їл]")
ON_TEXTCMDFUNC(TextCmd_say, "say", "say", "ё»", "ё»", TCM_SERVER, AUTH_GENERAL, "јУ»иАУ [/ён·Й ѕЖАМµр і»їл]")
ON_TEXTCMDFUNC(TextCmd_Position, "position", "pos", "БВЗҐ", "БВЗҐ", TCM_CLIENT, AUTH_GENERAL, "ЗцАз БВЗҐё¦ Гв·ВЗШБШґЩ.")
ON_TEXTCMDFUNC(TextCmd_shout, "shout", "s", "їЬДЎ±в", "їЬ", TCM_BOTH, AUTH_GENERAL, "їЬДЎ±в [/ён·Й ѕЖАМµр і»їл]")
ON_TEXTCMDFUNC(TextCmd_PartyChat, "partychat", "p", "±ШґЬё»", "±Ш", TCM_BOTH, AUTH_GENERAL, "ЖДЖј Г¤ЖГ [/ён·Й і»їл]")
ON_TEXTCMDFUNC(TextCmd_Time, "Time", "ti", "ЅГ°Ј", "ЅГ", TCM_CLIENT, AUTH_GENERAL, "ЅГ°Ј єё±в [/ЅГ°Ј]")

ON_TEXTCMDFUNC(TextCmd_GuildChat, "GuildChat", "g", "±жµеё»", "±жё»", TCM_BOTH, AUTH_GENERAL, "±жµеё»")
ON_TEXTCMDFUNC(TextCmd_PartyInvite, "PartyInvite", "partyinvite", "±ШґЬГКГ»", "±ШГК", TCM_SERVER, AUTH_GENERAL, "±ШґЬ ГКГ»")
ON_TEXTCMDFUNC(TextCmd_GuildInvite, "GuildInvite", "guildinvite", "±жµеГКГ»", "±жГК", TCM_SERVER, AUTH_GENERAL, "±жµе ГКГ»")
#endif // __ZCK_TRAD_FR
#ifdef __CLIENT
#ifdef __ZCK_TRAD_FR
ON_TEXTCMDFUNC(TextCmd_tradeagree, "tradeagree", "ta", "°Е·ЎЅВАО", "°ЕЅВ", TCM_CLIENT, AUTH_GENERAL, "Accepter les \351changes [/commande] ")
ON_TEXTCMDFUNC(TextCmd_traderefuse, "traderefuse", "tr", "°Е·Ў°ЕАэ", "°ЕАэ", TCM_CLIENT, AUTH_GENERAL, "Refuser les \351changes [/commande] ")
ON_TEXTCMDFUNC(TextCmd_whisperagree, "whisperagree", "wa", "±УјУё»ЅВАО", "±УЅВ", TCM_CLIENT, AUTH_GENERAL, "Accepter les chuchotements [/commande] ")
ON_TEXTCMDFUNC(TextCmd_whisperrefuse, "whisperrefuse", "wr", "±УјУё»°ЕАэ", "±УАэ", TCM_CLIENT, AUTH_GENERAL, "Refuser les chuchotements [/commande] ")
ON_TEXTCMDFUNC(TextCmd_messengeragree, "messengeragree", "ma", "ёЮЅЕАъЅВАО", "ёЮЅВ", TCM_CLIENT, AUTH_GENERAL, "Accepter les demandes de la messagerie [/commande] ")
ON_TEXTCMDFUNC(TextCmd_messengerrefuse, "messengerrefuse", "mr", "ёЮЅЕАъ°ЕАэ", "ёЮАэ", TCM_CLIENT, AUTH_GENERAL, "Refuser les demandes de la messagerie [/commande] ")
ON_TEXTCMDFUNC(TextCmd_stageagree, "stageagree", "ga", "±ШґЬЅВАО", "±ШЅВ", TCM_CLIENT, AUTH_GENERAL, "Accepter les invitations de groupe [/commande] ")
ON_TEXTCMDFUNC(TextCmd_stagerefuse, "stagerefuse", "gr", "±ШґЬ°ЕАэ", "±ШАэ", TCM_CLIENT, AUTH_GENERAL, "Refuser les invitations de groupe [/commande] ")
ON_TEXTCMDFUNC(TextCmd_connectagree, "connectagree", "ca", "БўјУѕЛёІ", "БўѕЛ", TCM_CLIENT, AUTH_GENERAL, "Activer les alertes de connexion [/commande] ")
ON_TEXTCMDFUNC(TextCmd_connectrefuse, "connectrefuse", "cr", "БўјУѕЛёІЗШБ¦", "БўЗШ", TCM_CLIENT, AUTH_GENERAL, "D\351sactiver les alertes de connexion [/commande] ")
#else
ON_TEXTCMDFUNC(TextCmd_tradeagree, "tradeagree", "ta", "°Е·ЎЅВАО", "°ЕЅВ", TCM_CLIENT, AUTH_GENERAL, "°Е·Ў ЅВАО [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_traderefuse, "traderefuse", "tr", "°Е·Ў°ЕАэ", "°ЕАэ", TCM_CLIENT, AUTH_GENERAL, "°Е·Ў °ЕАэ [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_whisperagree, "whisperagree", "wa", "±УјУё»ЅВАО", "±УЅВ", TCM_CLIENT, AUTH_GENERAL, "±УјУё» ЅВАО [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_whisperrefuse, "whisperrefuse", "wr", "±УјУё»°ЕАэ", "±УАэ", TCM_CLIENT, AUTH_GENERAL, "±УјУё» °ЕАэ [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_messengeragree, "messengeragree", "ma", "ёЮЅЕАъЅВАО", "ёЮЅВ", TCM_CLIENT, AUTH_GENERAL, "ёЮЅЕАъ ЅВАО [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_messengerrefuse, "messengerrefuse", "mr", "ёЮЅЕАъ°ЕАэ", "ёЮАэ", TCM_CLIENT, AUTH_GENERAL, "ёЮЅЕАъ °ЕАэ [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_stageagree, "stageagree", "ga", "±ШґЬЅВАО", "±ШЅВ", TCM_CLIENT, AUTH_GENERAL, "±ШґЬ ЅВАО [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_stagerefuse, "stagerefuse", "gr", "±ШґЬ°ЕАэ", "±ШАэ", TCM_CLIENT, AUTH_GENERAL, "±ШґЬ °ЕАэ [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_connectagree, "connectagree", "ca", "БўјУѕЛёІ", "БўѕЛ", TCM_CLIENT, AUTH_GENERAL, "БўјУѕЛёІ [/ён·Й] ")
ON_TEXTCMDFUNC(TextCmd_connectrefuse, "connectrefuse", "cr", "БўјУѕЛёІЗШБ¦", "БўЗШ", TCM_CLIENT, AUTH_GENERAL, "БўјУѕЛёІ ЗШБ¦ [/ён·Й] ")
#endif // __ZCK_TRAD_FR
#ifdef __YS_CHATTING_BLOCKING_SYSTEM
#ifdef __ZCK_TRAD_FR
ON_TEXTCMDFUNC(TextCmd_BlockUser, "ignore", "ig", "Г¤ЖГВчґЬ", "Г¤Вч", TCM_CLIENT, AUTH_GENERAL, "Bloquer la discussion d'un joueur [/commande nom]")
ON_TEXTCMDFUNC(TextCmd_CancelBlockedUser, "unignore", "uig", "Г¤ЖГВчґЬЗШБ¦", "Г¤ВчЗШ", TCM_CLIENT, AUTH_GENERAL, "D\351bloquer la discussion d'un joueur [/commande nom]")
ON_TEXTCMDFUNC(TextCmd_IgnoreList, "ignorelist", "igl", "Г¤ЖГВчґЬёс·П", "Г¤Вчёс", TCM_CLIENT, AUTH_GENERAL, "Liste des joueurs bloqu\351s")
#else
ON_TEXTCMDFUNC(TextCmd_BlockUser, "ignore", "ig", "Г¤ЖГВчґЬ", "Г¤Вч", TCM_CLIENT, AUTH_GENERAL, "Г¤ЖГВчґЬ [/ён·Й ѕЖАМµр]")
ON_TEXTCMDFUNC(TextCmd_CancelBlockedUser, "unignore", "uig", "Г¤ЖГВчґЬЗШБ¦", "Г¤ВчЗШ", TCM_CLIENT, AUTH_GENERAL, "Г¤ЖГВчґЬЗШБ¦ [/ён·Й ѕЖАМµр]")
ON_TEXTCMDFUNC(TextCmd_IgnoreList, "ignorelist", "igl", "Г¤ЖГВчґЬёс·П", "Г¤Вчёс", TCM_CLIENT, AUTH_GENERAL, "Г¤ЖГ ВчґЬ ёс·П")
#endif // __ZCK_TRAD_FR
#endif // __YS_CHATTING_BLOCKING_SYSTEM
#endif //__CLIENT
////////////////////////////////////////////////// AUTH_GENERAL end///////////////////////////////////////////////
	// GM_LEVEL_1
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_Teleport, "teleport", "te", "ЕЪ·№ЖчЖ®", "ЕЪ·№", TCM_SERVER, AUTH_GAMEMASTER, "T\351l\351portation")
	ON_TEXTCMDFUNC(TextCmd_Invisible, "invisible", "inv", "Ехён", "Ехён", TCM_SERVER, AUTH_GAMEMASTER, "Invisibilit\351")
	ON_TEXTCMDFUNC(TextCmd_NoInvisible, "noinvisible", "noinv", "ЕхёнЗШБ¦", "ЕхЗШ", TCM_SERVER, AUTH_GAMEMASTER, "Fin de l'invisibilit\351")
	ON_TEXTCMDFUNC(TextCmd_Summon, "summon", "su", "јТИЇ", "јТИЇ", TCM_SERVER, AUTH_GAMEMASTER, "Invoquer un joueur")
	ON_TEXTCMDFUNC(TextCmd_count, "count", "cnt", "БўјУАЪјц", "БўјУАЪјц", TCM_SERVER, AUTH_GAMEMASTER, "Nombre de joueurs connect\351s")

	// GM_LEVEL_2
	ON_TEXTCMDFUNC(TextCmd_Out, "out", "out", "ЕрГв", "ЕрГв", TCM_SERVER, AUTH_GAMEMASTER2, "Expulser un joueur")
	ON_TEXTCMDFUNC(TextCmd_Talk, "talk", "nota", "ё»ЗШБ¦", "ё»ЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Rendre la parole \340 un joueur")
	ON_TEXTCMDFUNC(TextCmd_NoTalk, "notalk", "ta", "ё»Б¤Бц", "ё»Б¤", TCM_SERVER, AUTH_GAMEMASTER2, "Rendre un joueur muet")
	ON_TEXTCMDFUNC(TextCmd_ip, "ip", "ip", "ѕЖАМЗЗ", "ѕЖАМЗЗ", TCM_BOTH, AUTH_GAMEMASTER2, "Afficher l'IP d'un joueur")
#else
	ON_TEXTCMDFUNC(TextCmd_Teleport, "teleport", "te", "ЕЪ·№ЖчЖ®", "ЕЪ·№", TCM_SERVER, AUTH_GAMEMASTER, "ЕЪ·№ЖчЖ®")
	ON_TEXTCMDFUNC(TextCmd_Invisible, "invisible", "inv", "Ехён", "Ехён", TCM_SERVER, AUTH_GAMEMASTER, "ЕхёнИ­")
	ON_TEXTCMDFUNC(TextCmd_NoInvisible, "noinvisible", "noinv", "ЕхёнЗШБ¦", "ЕхЗШ", TCM_SERVER, AUTH_GAMEMASTER, "ЕхёнИ­ ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_Summon, "summon", "su", "јТИЇ", "јТИЇ", TCM_SERVER, AUTH_GAMEMASTER, "АЇАъјТИЇ")
	ON_TEXTCMDFUNC(TextCmd_count, "count", "cnt", "БўјУАЪјц", "БўјУАЪјц", TCM_SERVER, AUTH_GAMEMASTER, "БўјУАЪ Д«їоЖ®")

	// GM_LEVEL_2
	ON_TEXTCMDFUNC(TextCmd_Out, "out", "out", "ЕрГв", "ЕрГв", TCM_SERVER, AUTH_GAMEMASTER2, "ЕрГв")
	ON_TEXTCMDFUNC(TextCmd_Talk, "talk", "nota", "ё»ЗШБ¦", "ё»ЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "ё»ЗПБц ёшЗП°Ф ЗП±в ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_NoTalk, "notalk", "ta", "ё»Б¤Бц", "ё»Б¤", TCM_SERVER, AUTH_GAMEMASTER2, "ё»ЗПБц ёшЗП°Ф ЗП±в")
	ON_TEXTCMDFUNC(TextCmd_ip, "ip", "ip", "ѕЖАМЗЗ", "ѕЖАМЗЗ", TCM_BOTH, AUTH_GAMEMASTER2, "»уґл IPѕЛ±в")
#endif // __ZCK_TRAD_FR
#ifdef __JEFF_9_20
	ON_TEXTCMDFUNC(TextCmd_Mute, "Mute", "mute", "Б¶їлИч", "Б¶їлИч", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif	// __JEFF_9_20
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_FallSnow, "FallSnow", "fs", "ґ«їН¶у", "ґ«їН", TCM_SERVER, AUTH_GAMEMASTER2, "Faire tomber la neige")
	ON_TEXTCMDFUNC(TextCmd_StopSnow, "StopSnow", "ss", "ґ«±Чёё", "ґ«іЎ", TCM_SERVER, AUTH_GAMEMASTER2, "Arr\352ter la neige")
	ON_TEXTCMDFUNC(TextCmd_FallRain, "FallRain", "frain", "єсїН¶у", "єсїН", TCM_SERVER, AUTH_GAMEMASTER2, "Faire tomber la pluie")
	ON_TEXTCMDFUNC(TextCmd_StopRain, "StopRain", "sr", "єс±Чёё", "єсіЎ", TCM_SERVER, AUTH_GAMEMASTER2, "Arr\352ter la pluie")
	ON_TEXTCMDFUNC(TextCmd_System, "system", "sys", "ѕЛёІ", "ѕЛ", TCM_SERVER, AUTH_GAMEMASTER2, "Message syst\350me")

	// GM_LEVEL_3
	ON_TEXTCMDFUNC(TextCmd_PvpParam, "PvpParam", "p_Param", "PVP����", "�Ǽ�", TCM_SERVER, AUTH_GAMEMASTER2, "Param\350tres PvP (chaos)")
#else
	ON_TEXTCMDFUNC(TextCmd_FallSnow, "FallSnow", "fs", "ґ«їН¶у", "ґ«їН", TCM_SERVER, AUTH_GAMEMASTER2, "ґ« і»ё®±в Ед±Ы")
	ON_TEXTCMDFUNC(TextCmd_StopSnow, "StopSnow", "ss", "ґ«±Чёё", "ґ«іЎ", TCM_SERVER, AUTH_GAMEMASTER2, "ґ« і»ё®±в ёшЗП°Ф Ед±Ы")
	ON_TEXTCMDFUNC(TextCmd_FallRain, "FallRain", "frain", "єсїН¶у", "єсїН", TCM_SERVER, AUTH_GAMEMASTER2, "єс і»ё®±в Ед±Ы")
	ON_TEXTCMDFUNC(TextCmd_StopRain, "StopRain", "sr", "єс±Чёё", "єсіЎ", TCM_SERVER, AUTH_GAMEMASTER2, "єс і»ё®±в ёшЗП°Ф Ед±Ы")
	ON_TEXTCMDFUNC(TextCmd_System, "system", "sys", "ѕЛёІ", "ѕЛ", TCM_SERVER, AUTH_GAMEMASTER2, "ЅГЅєЕЫ ёЮЅГБц")

	// GM_LEVEL_3
	ON_TEXTCMDFUNC(TextCmd_PvpParam, "PvpParam", "p_Param", "PVP����", "�Ǽ�", TCM_SERVER, AUTH_GAMEMASTER2, "PVP(ī��)����")
#endif // __ZCK_TRAD_FR
#if __VER >= 8 // __S8_PK
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_PKParam, "PKParam", "pkparam", "PK����", "pk����", TCM_SERVER, AUTH_GAMEMASTER2, "Param\350tres PK (chaos)")
#else
	ON_TEXTCMDFUNC(TextCmd_PKParam, "PKParam", "pkparam", "PK����", "pk����", TCM_SERVER, AUTH_GAMEMASTER2, "ī������")
#endif // __ZCK_TRAD_FR
#endif // __VER >= 8 // __S8_PK
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_Undying, "undying", "ud", "№«Аы", "№«", TCM_BOTH, AUTH_GAMEMASTER2, "Invincibilit\351")
	ON_TEXTCMDFUNC(TextCmd_Undying2, "undying2", "ud2", "№Э№«Аы", "№Э№«", TCM_BOTH, AUTH_GAMEMASTER2, "Semi-invincibilit\351")
	ON_TEXTCMDFUNC(TextCmd_NoUndying, "noundying", "noud", "№«АыЗШБ¦", "№«ЗШ", TCM_BOTH, AUTH_GAMEMASTER2, "Fin de l'invincibilit\351")
	ON_TEXTCMDFUNC(TextCmd_Onekill, "onekill", "ok", "ГКЗК", "ГКЗК", TCM_BOTH, AUTH_GAMEMASTER2, "Tuer les ennemis en un coup")
	ON_TEXTCMDFUNC(TextCmd_NoOnekill, "noonekill", "nook", "ГКЗКЗШБ¦", "ГКЗШ", TCM_BOTH, AUTH_GAMEMASTER2, "Ne plus tuer les ennemis en un coup")
	ON_TEXTCMDFUNC(TextCmd_AroundKill, "aroundkill", "ak", "їшј¦", "їш", TCM_SERVER, AUTH_GAMEMASTER2, "Tuer les monstres alentour")
	ON_TEXTCMDFUNC(TextCmd_Level, "level", "lv", "·№є§", "·ѕ", TCM_SERVER, AUTH_GAMEMASTER2, "D\351finir le niveau")
	ON_TEXTCMDFUNC(TextCmd_BeginQuest, "BeginQuest", "bq", "ДщЅєЖ®ЅГАЫ", "ДщЅГ", TCM_SERVER, AUTH_GAMEMASTER2, "D\351marrer une qu\352te [ID]")
	ON_TEXTCMDFUNC(TextCmd_EndQuest, "EndQuest", "eq", "ДщЅєЖ®Бѕ·б", "ДщБѕ", TCM_SERVER, AUTH_GAMEMASTER2, "Terminer une qu\352te [ID]")
	ON_TEXTCMDFUNC(TextCmd_RemoveQuest, "RemoveQuest", "rq", "ДщЅєЖ®Б¦°Е", "ДщБ¦", TCM_SERVER, AUTH_GAMEMASTER2, "Supprimer une qu\352te [ID]")
	ON_TEXTCMDFUNC(TextCmd_RemoveAllQuest, "RemoveAllQuest", "raq", "ДщЅєЖ®АьГјБ¦°Е", "ДщАьБ¦", TCM_SERVER, AUTH_GAMEMASTER2, "Supprimer toutes les qu\352tes")
	ON_TEXTCMDFUNC(TextCmd_RemoveCompleteQuest, "RemoveCompleteQuest", "rcq", "ДщЅєЖ®їП·бБ¦°Е", "ДщїПБ¦", TCM_SERVER, AUTH_GAMEMASTER2, "Supprimer les qu\352tes termin\351es")
	ON_TEXTCMDFUNC(TextCmd_Freeze, "freeze", "fr", "Б¤Бц", "Б¤Бц", TCM_SERVER, AUTH_GAMEMASTER2, "Immobiliser un joueur")
	ON_TEXTCMDFUNC(TextCmd_NoFreeze, "nofreeze", "nofr", "Б¤БцЗШБ¦", "Б¤ЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Lib\351rer un joueur immobilis\351")
	ON_TEXTCMDFUNC(TextCmd_PartyLevel, "PartyLevel", "plv", "±ШґЬ·№є§", "±Ш·№", TCM_SERVER, AUTH_GAMEMASTER2, "D\351finir le niveau du groupe")
	ON_TEXTCMDFUNC(TextCmd_GuildStat, "GuildStat", "gstat", "±жµеЅєЕИ", "±жЅєЕИ", TCM_SERVER, AUTH_GAMEMASTER2, "Modifier les statistiques de guilde")
	ON_TEXTCMDFUNC(TextCmd_CreateGuild, "createguild", "cg", "±жµе»эјє", "±ж»э", TCM_SERVER, AUTH_GAMEMASTER2, "Cr\351er une guilde")
	ON_TEXTCMDFUNC(TextCmd_DestroyGuild, "destroyguild", "dg", "±жµеЗШГј", "±жЗШ", TCM_CLIENT, AUTH_GAMEMASTER2, "Dissoudre une guilde")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatIn, "GCIn", "gcin", "±жµеїцАФАе", "±жїцАФ", TCM_BOTH, AUTH_GAMEMASTER2, "Entrer dans la guerre de guilde")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatOpen, "GCOpen", "gcopen", "±жµеїцїАЗВ", "±жїцїА", TCM_BOTH, AUTH_GAMEMASTER2, "Ouvrir la guerre de guilde")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatClose, "GCClose", "gcclose", "±жµеїцґЭ±в", "±жїцґЭ", TCM_BOTH, AUTH_GAMEMASTER2, "Fermer la guerre de guilde")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatNext, "GCNext", "gcNext", "±жµеїцґЩАЅ", "±жїцґЩ", TCM_BOTH, AUTH_GAMEMASTER2, "\311tape suivante de la guerre de guilde")
	ON_TEXTCMDFUNC(TextCmd_indirect, "indirect", "id", "°ЈБў", "°ЈБў", TCM_BOTH, AUTH_GAMEMASTER2, "Faire parler un personnage")
	ON_TEXTCMDFUNC(TextCmd_CreateNPC, "createnpc", "cn", "їЈЗЗѕѕ»эјє", "їЈ»э", TCM_SERVER, AUTH_GAMEMASTER2, "Cr\351er un PNJ")
#else
	ON_TEXTCMDFUNC(TextCmd_Undying, "undying", "ud", "№«Аы", "№«", TCM_BOTH, AUTH_GAMEMASTER2, "№«Аы")
	ON_TEXTCMDFUNC(TextCmd_Undying2, "undying2", "ud2", "№Э№«Аы", "№Э№«", TCM_BOTH, AUTH_GAMEMASTER2, "№Э№«Аы")
	ON_TEXTCMDFUNC(TextCmd_NoUndying, "noundying", "noud", "№«АыЗШБ¦", "№«ЗШ", TCM_BOTH, AUTH_GAMEMASTER2, "№«Аы ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_Onekill, "onekill", "ok", "ГКЗК", "ГКЗК", TCM_BOTH, AUTH_GAMEMASTER2, "АыА» ЗС№жїЎ БЧАМ±в")
	ON_TEXTCMDFUNC(TextCmd_NoOnekill, "noonekill", "nook", "ГКЗКЗШБ¦", "ГКЗШ", TCM_BOTH, AUTH_GAMEMASTER2, "АыА» ЗС№жїЎ БЧАМ±в ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_AroundKill, "aroundkill", "ak", "їшј¦", "їш", TCM_SERVER, AUTH_GAMEMASTER2, "ѕо¶уїоµеїЎ АЦґВ ёуЅєЕН БЧАМ±в")
	ON_TEXTCMDFUNC(TextCmd_Level, "level", "lv", "·№є§", "·ѕ", TCM_SERVER, AUTH_GAMEMASTER2, "·№є§ јіБ¤ ЗП±в")
	ON_TEXTCMDFUNC(TextCmd_BeginQuest, "BeginQuest", "bq", "ДщЅєЖ®ЅГАЫ", "ДщЅГ", TCM_SERVER, AUTH_GAMEMASTER2, "ДщЅєЖ® ЅГАЫ [ID]")
	ON_TEXTCMDFUNC(TextCmd_EndQuest, "EndQuest", "eq", "ДщЅєЖ®Бѕ·б", "ДщБѕ", TCM_SERVER, AUTH_GAMEMASTER2, "ДщЅєЖ® Бѕ·б [ID]")
	ON_TEXTCMDFUNC(TextCmd_RemoveQuest, "RemoveQuest", "rq", "ДщЅєЖ®Б¦°Е", "ДщБ¦", TCM_SERVER, AUTH_GAMEMASTER2, "ДщЅєЖ® Б¦°Е [ID]")
	ON_TEXTCMDFUNC(TextCmd_RemoveAllQuest, "RemoveAllQuest", "raq", "ДщЅєЖ®АьГјБ¦°Е", "ДщАьБ¦", TCM_SERVER, AUTH_GAMEMASTER2, "ДщЅєЖ® АьГј Б¦°Е")
	ON_TEXTCMDFUNC(TextCmd_RemoveCompleteQuest, "RemoveCompleteQuest", "rcq", "ДщЅєЖ®їП·бБ¦°Е", "ДщїПБ¦", TCM_SERVER, AUTH_GAMEMASTER2, "ДщЅєЖ® їП·б Б¦°Е")
	ON_TEXTCMDFUNC(TextCmd_Freeze, "freeze", "fr", "Б¤Бц", "Б¤Бц", TCM_SERVER, AUTH_GAMEMASTER2, "їтБчАМБц ёшЗП°Ф ЗП±в")
	ON_TEXTCMDFUNC(TextCmd_NoFreeze, "nofreeze", "nofr", "Б¤БцЗШБ¦", "Б¤ЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "їтБчАМБц ёшЗП°Ф ЗП±в ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_PartyLevel, "PartyLevel", "plv", "±ШґЬ·№є§", "±Ш·№", TCM_SERVER, AUTH_GAMEMASTER2, "±ШґЬ·№є§ јіБ¤ ЗП±в")
	ON_TEXTCMDFUNC(TextCmd_GuildStat, "GuildStat", "gstat", "±жµеЅєЕИ", "±жЅєЕИ", TCM_SERVER, AUTH_GAMEMASTER2, "±жµе ЅєЕИєЇ°ж")
	ON_TEXTCMDFUNC(TextCmd_CreateGuild, "createguild", "cg", "±жµе»эјє", "±ж»э", TCM_SERVER, AUTH_GAMEMASTER2, "±жµе »эјє")
	ON_TEXTCMDFUNC(TextCmd_DestroyGuild, "destroyguild", "dg", "±жµеЗШГј", "±жЗШ", TCM_CLIENT, AUTH_GAMEMASTER2, "±жµе ЗШГј")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatIn, "GCIn", "gcin", "±жµеїцАФАе", "±жїцАФ", TCM_BOTH, AUTH_GAMEMASTER2, "±жµеґлАь АФАе")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatOpen, "GCOpen", "gcopen", "±жµеїцїАЗВ", "±жїцїА", TCM_BOTH, AUTH_GAMEMASTER2, "±жµеґлАь їАЗВ")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatClose, "GCClose", "gcclose", "±жµеїцґЭ±в", "±жїцґЭ", TCM_BOTH, AUTH_GAMEMASTER2, "±жµеґлАь ґЭ±в")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatNext, "GCNext", "gcNext", "±жµеїцґЩАЅ", "±жїцґЩ", TCM_BOTH, AUTH_GAMEMASTER2, "±жµеґлАь ґЩАЅ")
	ON_TEXTCMDFUNC(TextCmd_indirect, "indirect", "id", "°ЈБў", "°ЈБў", TCM_BOTH, AUTH_GAMEMASTER2, "»уґлїЎ°Ф °ЈБўАё·О ё»ЗП°Ф ЗП±в")
	ON_TEXTCMDFUNC(TextCmd_CreateNPC, "createnpc", "cn", "їЈЗЗѕѕ»эјє", "їЈ»э", TCM_SERVER, AUTH_GAMEMASTER2, "npc»эјє")
#endif // __ZCK_TRAD_FR
#if __VER >= 9 // __EVENTLUA
	ON_TEXTCMDFUNC(TextCmd_LuaEventList, "EVENTLIST", "eventlist", "АМєҐЖ®ёс·П", "АМєҐЖ®ёс·П", TCM_SERVER, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_LuaEventInfo, "EVENTINFO", "eventinfo", "АМєҐЖ®Б¤єё", "АМєҐЖ®Б¤єё", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif	// __EVENTLUA
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_GameSetting, "gamesetting", "gs", "°ФАУјіБ¤", "°Фјі", TCM_SERVER, AUTH_GAMEMASTER2, "Afficher les r\351glages du jeu")
	ON_TEXTCMDFUNC(TextCmd_RemoveNpc, "rmvnpc", "rn", "»иБ¦", "»и", TCM_SERVER, AUTH_GAMEMASTER2, "Supprimer un PNJ")

	// GM_LEVEL_4
	ON_TEXTCMDFUNC(TextCmd_Disguise, "disguise", "dis", "єЇЅЕ", "єЇ", TCM_SERVER, AUTH_GAMEMASTER2, "Se d\351guiser")
	ON_TEXTCMDFUNC(TextCmd_NoDisguise, "noDisguise", "nodis", "єЇЅЕЗШБ¦", "єЇЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Retirer le d\351guisement")
	ON_TEXTCMDFUNC(TextCmd_ResistItem, "ResistItem", "ritem", "јУјєѕЖАМЕЫ", "јУѕЖ", TCM_BOTH, AUTH_GAMEMASTER2, "Objet \351l\351mentaire")
	ON_TEXTCMDFUNC(TextCmd_JobName, "jobname", "jn", "БчѕчАМё§", "БчАМ", TCM_CLIENT, AUTH_GAMEMASTER2, "Afficher les noms de classes")
	ON_TEXTCMDFUNC(TextCmd_GetGold, "getgold", "gg", "µ·Ба", "µ·", TCM_SERVER, AUTH_GAMEMASTER2, "Obtenir des Penya")
	ON_TEXTCMDFUNC(TextCmd_CreateItem, "createitem", "ci", "ѕЖАМЕЫ»эјє", "ѕЖ»э", TCM_BOTH, AUTH_GAMEMASTER2, "Cr\351er un objet")
	ON_TEXTCMDFUNC(TextCmd_CreateItem2, "createitem2", "ci2", "ѕЖАМЕЫ»эјє2", "ѕЖ»э2", TCM_SERVER, AUTH_GAMEMASTER2, "Cr\351er un objet (2)")
	ON_TEXTCMDFUNC(TextCmd_QuestState, "QuestState", "qs", "ДщЅєЖ®»уЕВ", "Дщ»у", TCM_SERVER, AUTH_GAMEMASTER2, "D\351finir l'\351tat d'une qu\352te [ID] [\351tat]")
	ON_TEXTCMDFUNC(TextCmd_LoadScript, "loadscript", "loscr", "·ОµеЅєЕ©ёіЖ®", "·ОЅє", TCM_BOTH, AUTH_GAMEMASTER2, "Recharger les scripts")
	ON_TEXTCMDFUNC(TextCmd_ReloadConstant, "ReloadConstant", "rec", "ё®·ОµеДЬЅєЕєЖ®", "ё®ДЬ", TCM_SERVER, AUTH_GAMEMASTER2, "Recharger le fichier des constantes")
	ON_TEXTCMDFUNC(TextCmd_Piercing, "Piercing", "pier", "ЗЗѕоЅМ", "ЗЗЅМ", TCM_BOTH, AUTH_GAMEMASTER2, "Per\347age (emplacements)")
#else
	ON_TEXTCMDFUNC(TextCmd_GameSetting, "gamesetting", "gs", "°ФАУјіБ¤", "°Фјі", TCM_SERVER, AUTH_GAMEMASTER2, "°ФАУ јіБ¤ єё±в")
	ON_TEXTCMDFUNC(TextCmd_RemoveNpc, "rmvnpc", "rn", "»иБ¦", "»и", TCM_SERVER, AUTH_GAMEMASTER2, "NPC»иБ¦")

	// GM_LEVEL_4
	ON_TEXTCMDFUNC(TextCmd_Disguise, "disguise", "dis", "єЇЅЕ", "єЇ", TCM_SERVER, AUTH_GAMEMASTER2, "єЇЅЕ")
	ON_TEXTCMDFUNC(TextCmd_NoDisguise, "noDisguise", "nodis", "єЇЅЕЗШБ¦", "єЇЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "єЇЅЕ ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_ResistItem, "ResistItem", "ritem", "јУјєѕЖАМЕЫ", "јУѕЖ", TCM_BOTH, AUTH_GAMEMASTER2, "јУјєѕЖАМЕЫ")
	ON_TEXTCMDFUNC(TextCmd_JobName, "jobname", "jn", "БчѕчАМё§", "БчАМ", TCM_CLIENT, AUTH_GAMEMASTER2, "БчѕчАМё§ єё±в")
	ON_TEXTCMDFUNC(TextCmd_GetGold, "getgold", "gg", "µ·Ба", "µ·", TCM_SERVER, AUTH_GAMEMASTER2, "µ· ѕт±в")
	ON_TEXTCMDFUNC(TextCmd_CreateItem, "createitem", "ci", "ѕЖАМЕЫ»эјє", "ѕЖ»э", TCM_BOTH, AUTH_GAMEMASTER2, "ѕЖАМЕЫ»эјє")
	ON_TEXTCMDFUNC(TextCmd_CreateItem2, "createitem2", "ci2", "ѕЖАМЕЫ»эјє2", "ѕЖ»э2", TCM_SERVER, AUTH_GAMEMASTER2, "ѕЖАМЕЫ»эјє2")
	ON_TEXTCMDFUNC(TextCmd_QuestState, "QuestState", "qs", "ДщЅєЖ®»уЕВ", "Дщ»у", TCM_SERVER, AUTH_GAMEMASTER2, "ДщЅєЖ® јіБ¤ [ID] [State]")
	ON_TEXTCMDFUNC(TextCmd_LoadScript, "loadscript", "loscr", "·ОµеЅєЕ©ёіЖ®", "·ОЅє", TCM_BOTH, AUTH_GAMEMASTER2, "ЅєЕ©ёіЖ® ґЩЅГ АР±в")
	ON_TEXTCMDFUNC(TextCmd_ReloadConstant, "ReloadConstant", "rec", "ё®·ОµеДЬЅєЕєЖ®", "ё®ДЬ", TCM_SERVER, AUTH_GAMEMASTER2, "ё®·Оµе ДЬЅєЕєЖ®ЖДАП")
	ON_TEXTCMDFUNC(TextCmd_Piercing, "Piercing", "pier", "ЗЗѕоЅМ", "ЗЗЅМ", TCM_BOTH, AUTH_GAMEMASTER2, "ЗЗѕоЅМ(јТДП)")
#endif // __ZCK_TRAD_FR
#if __VER >= 9	// __PET_0410
	ON_TEXTCMDFUNC(TextCmd_PetLevel, "petlevel", "pl", "Жк·№є§", "Жк·№", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_PetExp, "petexp", "pe", "Жк°жЗиДЎ", "Жк°ж", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_MakePetFeed, "makepetfeed", "mpf", "ёФАМёёµй±в", "ёФАМ", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_Pet, "Pet", "pet", "Жк", "Жк", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif	// __PET_0410
#if __VER >= 9 // __EVENTLUA
	ON_TEXTCMDFUNC(TextCmd_Lua, "Lua", "lua", "·зѕЖ", "·зѕЖ", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif	// __EVENTLUA
#ifdef __PET_1024
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_SetPetName, "SetPetName", "setpetname", "ЖкАЫён", "ЖкАЫ", TCM_SERVER, AUTH_GAMEMASTER2, "Nommer le familier")
	ON_TEXTCMDFUNC(TextCmd_ClearPetName, "ClearPetName", "cpn", "ЖкАЫёнГлјТ", "ЖкАЫГл", TCM_CLIENT, AUTH_GAMEMASTER2, "Effacer le nom du familier")
#else
	ON_TEXTCMDFUNC(TextCmd_SetPetName, "SetPetName", "setpetname", "ЖкАЫён", "ЖкАЫ", TCM_SERVER, AUTH_GAMEMASTER2, "ЖкАЫён")
	ON_TEXTCMDFUNC(TextCmd_ClearPetName, "ClearPetName", "cpn", "ЖкАЫёнГлјТ", "ЖкАЫГл", TCM_CLIENT, AUTH_GAMEMASTER2, "ЖкАЫёнГлјТ")
#endif // __ZCK_TRAD_FR
#endif	// __PET_1024
#if __VER >= 13 // __COUPLE_1117
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_Propose, "Propose", "propose", "ЗБ·ЇЖчБо", "ЗБ·ЇЖчБо", TCM_SERVER, AUTH_GAMEMASTER2, "Proposer de former un couple")
	ON_TEXTCMDFUNC(TextCmd_Refuse, "Refuse", "refuse", "ЗБ·ЇЖчБо°ЕАэ", "ЗБ°Е", TCM_SERVER, AUTH_GAMEMASTER2, "Refuser une proposition de couple")
	ON_TEXTCMDFUNC(TextCmd_Couple, "Couple", "couple", "ДїЗГ", "ДїЗГ", TCM_SERVER, AUTH_GAMEMASTER2, "Accepter une proposition de couple")
	ON_TEXTCMDFUNC(TextCmd_Decouple, "Decouple", "decouple", "ДїЗГЗШБц", "ДїЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Rompre le couple")
	ON_TEXTCMDFUNC(TextCmd_ClearPropose, "ClearPropose", "clearpropose", "ЗБ·ЇЖчБоГК±вИ­", "ЗБГК", TCM_SERVER, AUTH_GAMEMASTER2, "R\351initialiser les propositions de couple")
#else
	ON_TEXTCMDFUNC(TextCmd_Propose, "Propose", "propose", "ЗБ·ЇЖчБо", "ЗБ·ЇЖчБо", TCM_SERVER, AUTH_GAMEMASTER2, "ЗБ·ЇЖчБо")
	ON_TEXTCMDFUNC(TextCmd_Refuse, "Refuse", "refuse", "ЗБ·ЇЖчБо°ЕАэ", "ЗБ°Е", TCM_SERVER, AUTH_GAMEMASTER2, "ЗБ·ЇЖчБо°ЕАэ")
	ON_TEXTCMDFUNC(TextCmd_Couple, "Couple", "couple", "ДїЗГ", "ДїЗГ", TCM_SERVER, AUTH_GAMEMASTER2, "ДїЗГ")
	ON_TEXTCMDFUNC(TextCmd_Decouple, "Decouple", "decouple", "ДїЗГЗШБц", "ДїЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "ДїЗГЗШБц")
	ON_TEXTCMDFUNC(TextCmd_ClearPropose, "ClearPropose", "clearpropose", "ЗБ·ЇЖчБоГК±вИ­", "ЗБГК", TCM_SERVER, AUTH_GAMEMASTER2, "ЗБ·ЇЖчБоГК±вИ­")
#endif // __ZCK_TRAD_FR

#if __VER >= 13 // __COUPLE_1202
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_NextCoupleLevel, "NextCoupleLevel", "ncl", "ДїЗГ·№є§ѕч", "Дї·№", TCM_SERVER, AUTH_GAMEMASTER2, "Niveau de couple suivant")
#else
	ON_TEXTCMDFUNC(TextCmd_NextCoupleLevel, "NextCoupleLevel", "ncl", "ДїЗГ·№є§ѕч", "Дї·№", TCM_SERVER, AUTH_GAMEMASTER2, "ДїЗГ·№є§ѕч")
#endif // __ZCK_TRAD_FR
#endif	// __COUPLE_1202
#endif	// __COUPLE_1117
#ifdef __NPC_BUFF
	ON_TEXTCMDFUNC(TextCmd_RemoveAllBuff, "RemoveBuff", "rb", "№цЗБЗШБ¦", "№цЗШ", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif // __NPC_BUFF
#if __VER >= 13
	ON_TEXTCMDFUNC(TextCmd_HonorTitleSet, "HonorTitleSet", "hts", "ґЮАОјјЖГ", "ґЮјј", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif

#ifdef __FL_EQUALIZED_MODE
	ON_TEXTCMDFUNC(TextCmd_SaveTemporalPreset, "SaveTemporal", "savetemporal", "savetmp", "st", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif

	ON_TEXTCMDFUNC(TextCmd_RefineAccessory, "RefineAccessory", "refineaccessory", "ra", "RA", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_RefineCollector, "RefineCollector", "refinecollector", "rc", "RC", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_GenRandomOption, "GenRandomOption", "gro", "Awake", "awake", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_InitializeRandomOption, "InitializeRandomOption", "initializerandomoption", "iro", "IRO", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_SetRandomOption, "SetRandomOption", "setrandomoption", "sro", "SRO", TCM_BOTH, AUTH_GAMEMASTER2, "")


	ON_TEXTCMDFUNC(TextCmd_Open, "open", "open", "ї­±в", "ї­±в", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_Close, "close", "close", "ґЭ±в", "ґЭ±в", TCM_CLIENT, AUTH_GAMEMASTER2, "")
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_Music, "music", "mu", "АЅѕЗ", "АЅѕЗ", TCM_SERVER, AUTH_GAMEMASTER2, "Musique de fond")
	ON_TEXTCMDFUNC(TextCmd_Sound, "sound", "so", "јТё®", "јТё®", TCM_SERVER, AUTH_GAMEMASTER2, "Effet sonore")
	ON_TEXTCMDFUNC(TextCmd_LocalEvent, "localevent", "le", "БцїЄАМєҐЖ®", "БцАМ", TCM_SERVER, AUTH_GAMEMASTER2, "\311v\351nement local")
	ON_TEXTCMDFUNC(TextCmd_QuerySetPlayerName, "SetPlayerName", "spn", "ЗГ·№АМѕоАМё§", "ЗГАМ", TCM_SERVER, AUTH_GAMEMASTER2, "Changer le nom d'un joueur")
	ON_TEXTCMDFUNC(TextCmd_QuerySetGuildName, "SetGuildName", "sgn", "±жµеАМё§", "±жАМ", TCM_SERVER, AUTH_GAMEMASTER2, "Changer le nom d'une guilde")
	ON_TEXTCMDFUNC(TextCmd_DeclWar, "DeclWar", "declwar", "±жµеАьЅЕГ»", "±жЅЕ", TCM_CLIENT, AUTH_GAMEMASTER2, "D\351clarer une guerre de guilde")
	ON_TEXTCMDFUNC(TextCmd_RemoveGuildMember, "rgm", "rgm", "±жµеГЯ№ж", "±жГЯ", TCM_CLIENT, AUTH_GAMEMASTER2, "Exclure de la guilde")
	ON_TEXTCMDFUNC(TextCmd_ItemMode, "gmitem", "gmitem", "ѕЖАМЕЫёрµе", "ѕЖёр", TCM_SERVER, AUTH_GAMEMASTER2, "Emp\352cher de ramasser ou de jeter des objets")
	ON_TEXTCMDFUNC(TextCmd_ItemNotMode, "gmnotitem", "gmnotitem", "ѕЖАМЕЫЗШБ¦", "ѕЖёрЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Fin du mode objets")
	ON_TEXTCMDFUNC(TextCmd_AttackMode, "gmattck", "gmattck", "°ш°Эёрµе", "°шёр", TCM_SERVER, AUTH_GAMEMASTER2, "Emp\352cher d'attaquer")
	ON_TEXTCMDFUNC(TextCmd_AttackNotMode, "gmnotattck", "gmnotattck", "°ш°ЭЗШБ¦", "°шёрЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Fin du mode attaque")
	ON_TEXTCMDFUNC(TextCmd_CommunityMode, "gmcommunity", "gmcommunity", "Дї№ВґПЖјёрµе", "Дїёр", TCM_SERVER, AUTH_GAMEMASTER2, "Bloquer guilde, groupe, amis, \351changes et boutique")
	ON_TEXTCMDFUNC(TextCmd_CommunityNotMode, "gmnotcommunity", "gmnotcommunity", "Дї№ВґПЖјЗШБ¦", "ДїёрЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Fin du mode communaut\351")
	ON_TEXTCMDFUNC(TextCmd_ObserveMode, "gmobserve", "gmobserve", "°ьАьёрµе", "°ьёр", TCM_SERVER, AUTH_GAMEMASTER2, "Mode observation (objets, communaut\351, parole et attaque bloqu\351s)")
	ON_TEXTCMDFUNC(TextCmd_ObserveNotMode, "gmnotobserve", "gmnotobserve", "°ьАьЗШБ¦", "°ьёрЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Fin du mode observation")
	ON_TEXTCMDFUNC(TextCmd_EscapeReset, "EscapeReset", "EscapeReset", "Е»ГвГК±вИ­", "Е»ГК", TCM_BOTH, AUTH_GAMEMASTER2, "R\351initialiser le d\351lai de retour en ville")
	ON_TEXTCMDFUNC(TextCmd_userlist, "userlist", "ul", "»зїлАЪё®ЅєЖ®", "»зїлАЪё®", TCM_SERVER, AUTH_GAMEMASTER2, "Liste des joueurs")
	ON_TEXTCMDFUNC(TextCmd_SetGuildQuest, "SetGuildQuest", "sgq", "±жµеДщЅєЖ®", "±жДщ", TCM_SERVER, AUTH_GAMEMASTER2, "Modifier l'\351tat d'une qu\352te de guilde")
	ON_TEXTCMDFUNC(TextCmd_SetSnoop, "Snoop", "snoop", "°ЁГ»", "°ЁГ»", TCM_SERVER, AUTH_GAMEMASTER2, "\311couter les conversations d'un joueur")

	ON_TEXTCMDFUNC(TextCmd_GuildCombatRequest, "GCRequest", "gcrquest", "±жµеїцЅЕГ»", "±жїцЅЕ", TCM_BOTH, AUTH_GAMEMASTER2, "S'inscrire \340 la guerre de guilde")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatCancel, "GCCancel", "gccancel", "±жµеїцЕ»Ер", "±жїцЕ»", TCM_BOTH, AUTH_GAMEMASTER2, "Se retirer de la guerre de guilde")
	ON_TEXTCMDFUNC(TextCmd_ExpUpStop, "ExpUpStop", "eus", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_GENERAL, "Bloquer le gain d'EXP par la chasse")
#else
	ON_TEXTCMDFUNC(TextCmd_Music, "music", "mu", "АЅѕЗ", "АЅѕЗ", TCM_SERVER, AUTH_GAMEMASTER2, "№и°жАЅѕЗ")
	ON_TEXTCMDFUNC(TextCmd_Sound, "sound", "so", "јТё®", "јТё®", TCM_SERVER, AUTH_GAMEMASTER2, "»зїоµе Иї°ъ")
	ON_TEXTCMDFUNC(TextCmd_LocalEvent, "localevent", "le", "БцїЄАМєҐЖ®", "БцАМ", TCM_SERVER, AUTH_GAMEMASTER2, "БцїЄАМєҐЖ®")
	ON_TEXTCMDFUNC(TextCmd_QuerySetPlayerName, "SetPlayerName", "spn", "ЗГ·№АМѕоАМё§", "ЗГАМ", TCM_SERVER, AUTH_GAMEMASTER2, "ЗГ·№АМѕо АМё§ єЇ°ж")
	ON_TEXTCMDFUNC(TextCmd_QuerySetGuildName, "SetGuildName", "sgn", "±жµеАМё§", "±жАМ", TCM_SERVER, AUTH_GAMEMASTER2, "±жµе АМё§ єЇ°ж")
	ON_TEXTCMDFUNC(TextCmd_DeclWar, "DeclWar", "declwar", "±жµеАьЅЕГ»", "±жЅЕ", TCM_CLIENT, AUTH_GAMEMASTER2, "±жµеАь ЅЕГ»")
	ON_TEXTCMDFUNC(TextCmd_RemoveGuildMember, "rgm", "rgm", "±жµеГЯ№ж", "±жГЯ", TCM_CLIENT, AUTH_GAMEMASTER2, "±жµе ГЯ№ж")
	ON_TEXTCMDFUNC(TextCmd_ItemMode, "gmitem", "gmitem", "ѕЖАМЕЫёрµе", "ѕЖёр", TCM_SERVER, AUTH_GAMEMASTER2, "ѕЖАМЕЫ ёшБэ°н ёш¶іѕоЖ®ё®°Ф ЗП±в")
	ON_TEXTCMDFUNC(TextCmd_ItemNotMode, "gmnotitem", "gmnotitem", "ѕЖАМЕЫЗШБ¦", "ѕЖёрЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "ѕЖАМЕЫ ёрµе ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_AttackMode, "gmattck", "gmattck", "°ш°Эёрµе", "°шёр", TCM_SERVER, AUTH_GAMEMASTER2, "°ш°Э ёшЗП°Ф ЗП±в")
	ON_TEXTCMDFUNC(TextCmd_AttackNotMode, "gmnotattck", "gmnotattck", "°ш°ЭЗШБ¦", "°шёрЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "°ш°Э ёрµе ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_CommunityMode, "gmcommunity", "gmcommunity", "Дї№ВґПЖјёрµе", "Дїёр", TCM_SERVER, AUTH_GAMEMASTER2, "±жµе, ЖДЖј, ДЈ±ё, °Е·Ў, »уБЎ ёшЗП°Ф ЗП±в")
	ON_TEXTCMDFUNC(TextCmd_CommunityNotMode, "gmnotcommunity", "gmnotcommunity", "Дї№ВґПЖјЗШБ¦", "ДїёрЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "Дї№ВґПЖј ёрµе ЗШГј")
	ON_TEXTCMDFUNC(TextCmd_ObserveMode, "gmobserve", "gmobserve", "°ьАьёрµе", "°ьёр", TCM_SERVER, AUTH_GAMEMASTER2, "ѕЖАМЕЫ, Дї№ВґПЖј, ё»ёшЗП°Ф, ѕоЕШ ёрµе ЗХЗС°Н")
	ON_TEXTCMDFUNC(TextCmd_ObserveNotMode, "gmnotobserve", "gmnotobserve", "°ьАьЗШБ¦", "°ьёрЗШ", TCM_SERVER, AUTH_GAMEMASTER2, "°ьАь ёрµе ЗШБ¦")
	ON_TEXTCMDFUNC(TextCmd_EscapeReset, "EscapeReset", "EscapeReset", "Е»ГвГК±вИ­", "Е»ГК", TCM_BOTH, AUTH_GAMEMASTER2, "Е»Гв(±НИЇј®) ЅГ°Ј ГК±вИ­")
	ON_TEXTCMDFUNC(TextCmd_userlist, "userlist", "ul", "»зїлАЪё®ЅєЖ®", "»зїлАЪё®", TCM_SERVER, AUTH_GAMEMASTER2, "»зїлАЪ ё®ЅєЖ®")
	ON_TEXTCMDFUNC(TextCmd_SetGuildQuest, "SetGuildQuest", "sgq", "±жµеДщЅєЖ®", "±жДщ", TCM_SERVER, AUTH_GAMEMASTER2, "±жµе ДщЅєЖ® »уЕВ єЇ°ж")
	ON_TEXTCMDFUNC(TextCmd_SetSnoop, "Snoop", "snoop", "°ЁГ»", "°ЁГ»", TCM_SERVER, AUTH_GAMEMASTER2, "°ЁГ»")

	ON_TEXTCMDFUNC(TextCmd_GuildCombatRequest, "GCRequest", "gcrquest", "±жµеїцЅЕГ»", "±жїцЅЕ", TCM_BOTH, AUTH_GAMEMASTER2, "±жµеґлАь ЅЕГ»")
	ON_TEXTCMDFUNC(TextCmd_GuildCombatCancel, "GCCancel", "gccancel", "±жµеїцЕ»Ер", "±жїцЕ»", TCM_BOTH, AUTH_GAMEMASTER2, "±жµеґлАь Е»Ер")
	ON_TEXTCMDFUNC(TextCmd_ExpUpStop, "ExpUpStop", "eus", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_GENERAL, "»зіЙАё·О їАёЈґВ °жЗиДЎ »уЅВА» ±ЭБц")
#endif // __ZCK_TRAD_FR

#ifdef __FL_UPDATE_READSTAFF
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_LoadServerStaff, "LoadServerStaff", "LSS", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_ADMINISTRATOR, "Recharger la liste du staff")
#else
	ON_TEXTCMDFUNC(TextCmd_LoadServerStaff, "LoadServerStaff", "LSS", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_ADMINISTRATOR, "»зіЙАё·О їАёЈґВ °жЗиДЎ »уЅВА» ±ЭБц")
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_FFA
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ReloadFFA, "ReloadFFA", "reloadffa", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_GAMEMASTER2, "Recharger la configuration du FFA")
#else
	ON_TEXTCMDFUNC(TextCmd_ReloadFFA, "ReloadFFA", "reloadffa", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_GAMEMASTER2, "»зіЙАё·О їАёЈґВ °жЗиДЎ »уЅВА» ±ЭБц")
#endif // __ZCK_TRAD_FR
#endif
#ifdef __FL_TDM
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ReloadTDM, "ReloadTDM", "reloadtdm", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_GAMEMASTER2, "Recharger la configuration du match \340 mort par \351quipe")
	ON_TEXTCMDFUNC(TextCmd_StartTDM, "StartTDM", "starttdm", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_GAMEMASTER2, "Lancer le match \340 mort par \351quipe")
#else
	ON_TEXTCMDFUNC(TextCmd_ReloadTDM, "ReloadTDM", "reloadtdm", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_GAMEMASTER2, "»зіЙАё·О їАёЈґВ °жЗиДЎ »уЅВА» ±ЭБц")
	ON_TEXTCMDFUNC(TextCmd_StartTDM, "StartTDM", "starttdm", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_SERVER, AUTH_GAMEMASTER2, "»зіЙАё·О їАёЈґВ °жЗиДЎ »уЅВА» ±ЭБц")
#endif // __ZCK_TRAD_FR
#endif

#ifdef __FL_WHEEL_OF_FORTUNE
	ON_TEXTCMDFUNC(TextCmd_WofInit, "wofinit", "initwof", "", "", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_WofFinish, "woffinish", "finishwof", "", "", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif

	ON_TEXTCMDFUNC(TextCmd_PushPower, "PushPower", "pushpower", "", "", TCM_BOTH, AUTH_GAMEMASTER2, "")

#ifdef __FL_VENDORS
	ON_TEXTCMDFUNC(TextCmd_DestroyAllVendors, "DestroyAllVendors", "destroyallvendors", "", "", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_DestroyVendor, "DestroyVendor", "destroyvendor", "", "", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif

#ifdef __FL_CATCH_THE_PET
	ON_TEXTCMDFUNC(TextCmd_CreateCatchedPet, "CreateCatchedPet", "createcatchedpet", "", "", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif
#ifdef __ZCK_ANTICHEAT
	ON_TEXTCMDFUNC(TextCmd_ZckAnticheat, "ZckAnticheat", "zckanticheat", "", "", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif
#ifdef __ZCK_FENETRE_CHAT_MJ
	ON_TEXTCMDFUNC(TextCmd_ZckChatMj, "ZckChatMj", "zckchatmj", "", "", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif
	ON_TEXTCMDFUNC(TextCmd_SetAllBinds, "SetAllBinds", "setallbinds", "", "", TCM_BOTH, AUTH_GAMEMASTER2, "")

#ifdef __S1108_BACK_END_SYSTEM
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_PropMonster, "monstersetting", "ms", "ёуЅєЕНјіБ¤", "ёујі", TCM_CLIENT, AUTH_GAMEMASTER2, "Afficher les r\351glages des monstres")
#else
	ON_TEXTCMDFUNC(TextCmd_PropMonster, "monstersetting", "ms", "ёуЅєЕНјіБ¤", "ёујі", TCM_CLIENT, AUTH_GAMEMASTER2, "ёуЅєЕН јіБ¤ єё±в")
#endif // __ZCK_TRAD_FR
#else
	ON_TEXTCMDFUNC(TextCmd_ChangeShopCost, "changeshopcost", "csc", "»уБЎ°Ў°ЭБ¶Б¤", "»у°ЎБ¶", TCM_SERVER, AUTH_GAMEMASTER2, "»уБЎ°Ў°ЭБ¶Б¤ Min(0.5) ~ Max(2.0)")
#endif // __S1108_BACK_END_SYSTEM

#if __VER >= 8 //__CSC_VER8_5
	ON_TEXTCMDFUNC(TextCmd_AngelExp, "AExp", "aexp", "aaaaaexp", "aaaexxp", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif // __CSC_VER8_5

#if __VER >= 10 // __REMOVE_ATTRIBUTE
	ON_TEXTCMDFUNC(TextCmd_RemoveAttribute, "RemAttr", "remattr", "јУјєБ¦°Е", "јУБ¦", TCM_CLIENT, AUTH_GAMEMASTER2, "")
#endif // __REMOVE_ATTRIBUTE

#if __VER >= 11 // __SYS_IDENTIFY
	ON_TEXTCMDFUNC(TextCmd_ItemLevel, "ItemLevel", "il", "ЗП¶ф", "ЗП¶ф", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif	// __SYS_IDENTIFY

#if __VER >= 12 // __SECRET_ROOM
	ON_TEXTCMDFUNC(TextCmd_SecretRoomOpen, "SROPEN", "sropen", "єс№РАЗ№жїАЗВ", "єсїА", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_SecretRoomNext, "SRNEXT", "srnext", "єс№РАЗ№жґЩАЅ", "єсґЩ", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_SecretRoomEntrance, "SRENTRANCE", "srentrance", "єс№РАЗ№жАФАе", "єсАФАе", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_SecretRoomTender, "SRTENDER", "srtender", "єс№РАЗ№жАФВы", "єсАФ", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_SecretRoomLineUp, "SRLINEUP", "srlineup", "єс№РАЗ№ж±ёјє", "єс±ё", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_SecretRoomClose, "SRCLOSE", "srclose", "єс№РАЗ№жґЭ±в", "єсґЭ", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_SecretRoomTenderView, "SRVIEW", "srview", "єс№РАЗ№жАФВыЗцИІ", "єсЗц", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_SecretRoomTenderCancelReturn, "SRCANCEL", "srcancel", "єс№РАЗ№жАФВыГлјТ", "єсГл", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif // __SECRET_ROOM

#if __VER >= 12 // __LORD
	ON_TEXTCMDFUNC(TextCmd_ElectionRequirement, "ElectionRequirement", "er", "±єБЦЕхЗҐЗцИІ", "±єЕхЗц", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	//#ifdef __INTERNALSERVER
	ON_TEXTCMDFUNC(TextCmd_ElectionAddDeposit, "ElectionAddDeposit", "ead", "±єБЦАФВы", "±єАФ", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_ElectionSetPledge, "ElectionSetPledge", "esp", "±єБЦ°шѕајіБ¤", "±є°ш", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_ElectionIncVote, "ElectionIncVote", "eiv", "±єБЦЕхЗҐ", "±єЕх", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_ElectionProcess, "ElectionProcess", "ep", "±єБЦЗБ·ОјјЅє", "±єЗБ", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_ElectionBeginCandidacy, "ElectionBeginCandidacy", "ebc", "±єБЦАФИДєёЅГАЫ", "±єАФЅГ", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_ElectionBeginVote, "ElectionBeginVote", "ebv", "±єБЦЕхЗҐЅГАЫ", "±єЕхЅГ", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_ElectionEndVote, "ElectionEndVote", "eev", "±єБЦЕхЗҐБѕ·б", "±єЕхБѕ", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_ElectionState, "ElectionState", "estate", "±єБЦЕхЗҐ»уЕВ", "±єЕх»у", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_LEventCreate, "LEventCreate", "lecreate", "±єБЦАМєҐЖ®ЅГАЫ", "±єАМЅГ", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_LEventInitialize, "LEventInitialize", "leinitialize", "±єБЦАМєҐЖ®ГК±вИ­", "±єАМГК", TCM_SERVER, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_LSkill, "LSkill", "lskill", "±єБЦЅєЕі", "±єЅє", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_RemoveTotalGold, "RemoveTotalGold", "rtg", "µ·»иБ¦", "µ·»и", TCM_SERVER, AUTH_GAMEMASTER2, "")
	//#endif	// __INTERNALSERVER
#endif	// __LORD

#if __VER >= 12 // __TAX
	ON_TEXTCMDFUNC(TextCmd_TaxApplyNow, "TaxApplyNow", "tan", "јјАІАыїл", "јјАы", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif // __TAX

#if __VER >= 12 // __HEAVEN_TOWER
	ON_TEXTCMDFUNC(TextCmd_HeavenTower, "HeavenTower", "HTower", "ЅЙї¬АЗЕѕ", "ЅЙЕѕ", TCM_BOTH, AUTH_GAMEMASTER2, "")
#endif //__HEAVEN_TOWER

	ON_TEXTCMDFUNC(TextCmd_PickupPetAwakeningCancel, "PickupPetAwakeningCancel", "ppac", "ЗИѕчЖк°ўјєГлјТ", "ЗИјТ", TCM_CLIENT, AUTH_GAMEMASTER2, "")

#ifdef __LAYER_1020
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_CreateLayer, "CreateLayer", "cl", "·№АМѕо»эјє", "·№»э", TCM_SERVER, AUTH_GAMEMASTER2, "Cr\351er une couche (layer)")
	ON_TEXTCMDFUNC(TextCmd_DeleteLayer, "DeleteLayer", "dl", "·№АМѕоЖД±«", "·№ЖД", TCM_SERVER, AUTH_GAMEMASTER2, "D\351truire une couche (layer)")
	ON_TEXTCMDFUNC(TextCmd_Layer, "Layer", "lay", "·№АМѕоАМµї", "·№АМ", TCM_SERVER, AUTH_GAMEMASTER2, "Changer de couche (layer)")
#else
	ON_TEXTCMDFUNC(TextCmd_CreateLayer, "CreateLayer", "cl", "·№АМѕо»эјє", "·№»э", TCM_SERVER, AUTH_GAMEMASTER2, "·№АМѕо»эјє")
	ON_TEXTCMDFUNC(TextCmd_DeleteLayer, "DeleteLayer", "dl", "·№АМѕоЖД±«", "·№ЖД", TCM_SERVER, AUTH_GAMEMASTER2, "·№АМѕоЖД±«")
	ON_TEXTCMDFUNC(TextCmd_Layer, "Layer", "lay", "·№АМѕоАМµї", "·№АМ", TCM_SERVER, AUTH_GAMEMASTER2, "·№АМѕоАМµї")
#endif // __ZCK_TRAD_FR
#endif	// __LAYER_1020

#if __VER >= 13 // __HOUSING
	ON_TEXTCMDFUNC(TextCmd_HousingVisitRoom, "HousingVisit", "hv", "№ж№®", "№ж№®", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_HousingGMRemoveAll, "HousingGMRemoveAll", "hgmra", "°Ў±ё»иБ¦", "°Ў»и", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif // __HOUSING

#if __VER >= 15 // __15_5TH_ELEMENTAL_SMELT_SAFETY
	ON_TEXTCMDFUNC(TextCmd_SmeltSafetyElement, "SmeltSafetyElement", "sse", "ѕИАьБ¦·ГјУјє", "ѕИБ¦јУ", TCM_CLIENT, AUTH_GAMEMASTER2, "")
#endif // __15_5TH_ELEMENTAL_SMELT_SAFETY

#if __VER >= 15 // __GUILD_HOUSE
	ON_TEXTCMDFUNC(TextCmd_BuyGuildHouse, "BuyGuildHouse", "bgh", "±жµеЗПїмЅє±ёАФ", "±жЗП±ё", TCM_CLIENT, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_GuildHouseUpkeep, "GuildHouseUpkeep", "ghu", "±жµеЗПїмЅєАЇБцєс", "±жЗПАЇ", TCM_CLIENT, AUTH_GAMEMASTER2, "")
#endif // __GUILD_HOUSE

	ON_TEXTCMDFUNC(TextCmd_InvenRemove, "InvenRemove", "irm", "АОєҐ»иБ¦", "АО»и", TCM_SERVER, AUTH_GAMEMASTER2, "")

#ifdef __AIO_ADMIN_THINGS
	ON_TEXTCMDFUNC(TextCmd_Duplicate, "Duplicate", "duplicate", "dupe", "DUPE", TCM_SERVER, AUTH_GAMEMASTER2, "")
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_Restart, "RESTART", "restart", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_CLIENT, AUTH_GAMEMASTER2, "Red\351marrer le client")
#else
	ON_TEXTCMDFUNC(TextCmd_Restart, "RESTART", "restart", "°жЗиДЎ±ЭБц", "°ж±Э", TCM_CLIENT, AUTH_GAMEMASTER2, "»зіЙАё·О їАёЈґВ °жЗиДЎ »уЅВА» ±ЭБц")
#endif // __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_SetRandomScroll, "SetRandomScroll", "setrandomscroll", "srs", "SRS", TCM_BOTH, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_KillPlayer, "Kill", "kill", "k", "K", TCM_SERVER, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_LevelPlayer, "LevelPlayer", "levelplayer", "lp", "LP", TCM_SERVER, AUTH_GAMEMASTER2, "")
	ON_TEXTCMDFUNC(TextCmd_OutAll, "OutAll", "outall", "KickAll", "kickall", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif

#ifdef __ZCK_UPGRADE
	ON_TEXTCMDFUNC(TextCmd_Upgrade, "Upgrade", "upgrade", "up", "UP", TCM_CLIENT, AUTH_GAMEMASTER2, "")
#endif

#ifdef __ZCK_RARE
	ON_TEXTCMDFUNC(TextCmd_ZckRare, "Rarete", "rarete", "rare", "RARE", TCM_CLIENT, AUTH_GENERAL, "")
	ON_TEXTCMDFUNC(TextCmd_SetZckRare, "SetWeaponRarity", "setweaponrarity", "swr", "SWR", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif

#ifdef __ZCK_JOB_FACTOR
	ON_TEXTCMDFUNC(TextCmd_ReloadZckJobFactor, "ReloadJobFactor", "reloadjobfactor", "zjf", "ZJF", TCM_SERVER, AUTH_ADMINISTRATOR, "Recharge ZckJobFactor.inc")
	ON_TEXTCMDFUNC(TextCmd_ZckJobFactorDps, "JobFactorDps", "jobfactordps", "zjfdps", "ZJFDPS", TCM_SERVER, AUTH_GAMEMASTER, "Mesure DPS : 1er appel demarre, 2e appel affiche")
#endif // __ZCK_JOB_FACTOR

#ifdef __ZCK_MONSTRE_FCT
	ON_TEXTCMDFUNC(TextCmd_ReloadZckMonstreFct, "ReloadMonstreFct", "reloadmonstrefct", "zmf", "ZMF", TCM_SERVER, AUTH_ADMINISTRATOR, "Recharge ZckMonstreFct.inc")
#endif // __ZCK_MONSTRE_FCT

#ifdef __ZCK_NIVEAU_ARME
    ON_TEXTCMDFUNC(TextCmd_SetZckArmeNiveau, "SetWeaponLevel", "setweaponlevel", "swl", "SWL", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif

#ifdef __ZCK_PRESTIGE
    ON_TEXTCMDFUNC(TextCmd_ResetPrestige, "ResetPrestige", "resetprestige", "rp", "RP", TCM_SERVER, AUTH_GAMEMASTER2, "")
    ON_TEXTCMDFUNC(TextCmd_SetPrestige, "SetPrestige", "setprestige", "sp", "SP", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif

#ifdef __ZCK_SYSTEME_EVEIL
    ON_TEXTCMDFUNC(TextCmd_ZckSystemeEveil, "Eveil", "eveil", "AwakeWindow", "awakewindow", TCM_CLIENT, AUTH_GENERAL, "")
    ON_TEXTCMDFUNC(TextCmd_ReloadZckAwakeMastery, "ReloadAwakeMastery", "reloadawakemastery", "ram", "RAM", TCM_SERVER, AUTH_GAMEMASTER2, "")
#endif

#ifdef __ZCK_WEATHER
	ON_TEXTCMDFUNC(TextCmd_TestRain, "TestRain", "train", "", "", TCM_CLIENT, AUTH_GAMEMASTER2, "Force la pluie pour test")
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_TestRainStop, "TestRainStop", "trainstop", "", "", TCM_CLIENT, AUTH_GAMEMASTER2, "Arr\352te la pluie de test")
#else
	ON_TEXTCMDFUNC(TextCmd_TestRainStop, "TestRainStop", "trainstop", "", "", TCM_CLIENT, AUTH_GAMEMASTER2, "Arrete la pluie de test")
#endif // __ZCK_TRAD_FR
#endif // __ZCK_WEATHER

#ifdef __ZCK_ANARCHY
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ZckAnarchy, "Anarchy", "anarchy", "ZckAnarchy", "zckanarchy", TCM_CLIENT, AUTH_GENERAL, "Ouvre la fen\352tre des buffs serveur")
#else
	ON_TEXTCMDFUNC(TextCmd_ZckAnarchy, "Anarchy", "anarchy", "ZckAnarchy", "zckanarchy", TCM_CLIENT, AUTH_GENERAL, "Ouvre la fenetre des buffs serveur")
#endif // __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ZckAnarchy, "AnarchyAdmin", "anarchyadmin", "za", "ZA", TCM_SERVER, AUTH_GAMEMASTER2, "Active, recharge ou inspecte les buffs serveur")
#endif // __ZCK_ANARCHY

#ifdef __ZCK_INVASION
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ZckInvasion, "createinvasion", "crein", "", "", TCM_SERVER, AUTH_ADMINISTRATOR, "D\351clenche le cr\351neau Schedule d'index donn\351 (ZckInvasion.inc)")
#else
	ON_TEXTCMDFUNC(TextCmd_ZckInvasion, "createinvasion", "crein", "", "", TCM_SERVER, AUTH_ADMINISTRATOR, "Declenche le creneau Schedule d'index donne (ZckInvasion.inc)")
#endif // __ZCK_TRAD_FR
#endif // __ZCK_INVASION

#ifdef __ZCK_MUTATEURS
	ON_TEXTCMDFUNC(TextCmd_ZckMutateurs, "zckmut", "zckmut", "", "", TCM_SERVER, AUTH_ADMINISTRATOR, "Mutateurs de donjon : /zckmut, /zckmut <n>, /zckmut force <id> [<id> ...]")
#endif // __ZCK_MUTATEURS
#ifdef __ZCK_IA_FARM
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ZckIaFarm, "iafarm", "iafarm", "", "", TCM_CLIENT, AUTH_GENERAL, "Auto Farm IA : /iafarm (fen\352tre), /iafarm start | stop | on | off, /iafarm offline on | off")
	ON_TEXTCMDFUNC(TextCmd_ZckIaFarmFantomes, "iafarmfantomes", "iafarmfantomes", "", "", TCM_SERVER, AUTH_GAMEMASTER, "Auto Farm IA hors ligne : /iafarmfantomes (liste), /iafarmfantomes <nom> (arr\352t)")
#else
	ON_TEXTCMDFUNC(TextCmd_ZckIaFarm, "iafarm", "iafarm", "", "", TCM_CLIENT, AUTH_GENERAL, "Auto Farm IA : /iafarm (fenetre), /iafarm start | stop | on | off, /iafarm offline on | off")
	ON_TEXTCMDFUNC(TextCmd_ZckIaFarmFantomes, "iafarmfantomes", "iafarmfantomes", "", "", TCM_SERVER, AUTH_GAMEMASTER, "Auto Farm IA hors ligne : /iafarmfantomes (liste), /iafarmfantomes <nom> (arret)")
#endif // __ZCK_TRAD_FR
#endif // __ZCK_IA_FARM
#ifdef __ZCK_MONDIAL_BUFF
	// Une seule entree : ParsingCommand s'arrete a la premiere entree de ce nom.
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ZckMondialBuff, "mondialbuff", "mondialbuff", "", "", TCM_BOTH, AUTH_GENERAL, "Buffs mondiaux : /mondialbuff (fen\352tre) ; MJ : <index|nom> <minutes>, stop <index|nom>, liste, palier <n> <minutes>, recharger")
#else
	ON_TEXTCMDFUNC(TextCmd_ZckMondialBuff, "mondialbuff", "mondialbuff", "", "", TCM_BOTH, AUTH_GENERAL, "Buffs mondiaux : /mondialbuff (fenetre) ; MJ : <index|nom> <minutes>, stop <index|nom>, liste, palier <n> <minutes>, recharger")
#endif // __ZCK_TRAD_FR
#endif // __ZCK_MONDIAL_BUFF

#ifdef __ZCK_PERIN_BUFF
	// Une seule entree : ParsingCommand s'arrete a la premiere entree de ce nom.
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ZckPerinBuff, "perinbuff", "perinbuff", "", "", TCM_BOTH, AUTH_GENERAL, "Buffs Perin : /perinbuff (fen\352tre) ; MJ : liste, ajouter <n>, retirer <n>, niveau <n>, vider, remplir, recharger")
#else
	ON_TEXTCMDFUNC(TextCmd_ZckPerinBuff, "perinbuff", "perinbuff", "", "", TCM_BOTH, AUTH_GENERAL, "Buffs Perin : /perinbuff (fenetre) ; MJ : liste, ajouter <n>, retirer <n>, niveau <n>, vider, remplir, recharger")
#endif // __ZCK_TRAD_FR
#endif // __ZCK_PERIN_BUFF

#ifdef __ZCK_COMBAT_MC
	ON_TEXTCMDFUNC(TextCmd_ZckCombatMCStart, "MCStart", "mcstart", "", "", TCM_SERVER, AUTH_ADMINISTRATOR, "Ouvre manuellement les inscriptions Monster Clash")
#endif // __ZCK_COMBAT_MC

#ifdef __ZCK_TOUR_INFINI
#ifdef __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ZckTourInfini, "tour", "tour", "", "", TCM_SERVER, AUTH_GENERAL, "Tour infinie : /tour quitter (sortie de mont\351e ou annulation d'inscription)")
	ON_TEXTCMDFUNC(TextCmd_ZckTourInfiniStop, "tourstop", "tourstop", "", "", TCM_SERVER, AUTH_ADMINISTRATOR, "Arr\352te une mont\351e de la Tour infinie : /tourstop <layer>")
#else
	ON_TEXTCMDFUNC(TextCmd_ZckTourInfini, "tour", "tour", "", "", TCM_SERVER, AUTH_GENERAL, "Tour infinie : /tour quitter (sortie de montee ou annulation d'inscription)")
	ON_TEXTCMDFUNC(TextCmd_ZckTourInfiniStop, "tourstop", "tourstop", "", "", TCM_SERVER, AUTH_ADMINISTRATOR, "Arrete une montee de la Tour infinie : /tourstop <layer>")
#endif // __ZCK_TRAD_FR
	ON_TEXTCMDFUNC(TextCmd_ZckTourInfiniStart, "tourstart", "tourstart", "", "", TCM_SERVER, AUTH_ADMINISTRATOR, "Ouvre les inscriptions de la Tour infinie : /tourstart")
#endif // __ZCK_TOUR_INFINI

#ifdef __ZCK_CLEAN_INVENTAIRE
	ON_TEXTCMDFUNC(TextCmd_ZckCleanInventaire, "cleaninventaire", "cleaninv", "", "", TCM_SERVER, AUTH_GAMEMASTER2, "Vide les cases du sac de l'inventaire du MJ (equipement porte et familier invoque conserves) : /cleaninventaire")
#endif // __ZCK_CLEAN_INVENTAIRE
#ifdef __ZCK_PLAGE_OBJET
	ON_TEXTCMDFUNC(TextCmd_ZckPlageObjet, "ciplage", "cip", "", "", TCM_SERVER, AUTH_GAMEMASTER2, "Cree un exemplaire de chaque objet d'une plage d'ID dans l'inventaire : /ciplage <debut> <fin>")
#endif // __ZCK_PLAGE_OBJET
#ifdef __ZCK_PLAGE
	ON_TEXTCMDFUNC(TextCmd_ZckPlage, "cnplage", "cnp", "", "", TCM_SERVER, AUTH_GAMEMASTER2, "Invoque chaque monstre d'une plage d'ID autour du MJ : /cnplage <debut> <fin> [0|1] (1 = agressif)")
#endif // __ZCK_PLAGE
#ifdef __ZCK_VOIR_INVENTAIRE_JOUEURS
	ON_TEXTCMDFUNC(TextCmd_ZckVoirInventaire, "voirinventaire", "voirinv", "viewinv", "vinv", TCM_CLIENT, AUTH_GAMEMASTER2, "Voir l'inventaire, l'\351quipement et le coffre d'un joueur connect\351 (lecture seule) : /voirinventaire <nom> [coffre]")
#endif // __ZCK_VOIR_INVENTAIRE_JOUEURS

#ifdef __ZCK_CRAFT_LOAD_TEX
	// Une seule entree : ParsingCommand s'arrete a la premiere entree de ce nom.
	ON_TEXTCMDFUNC(TextCmd_ZckCraft, "artisanat", "craft", "", "", TCM_BOTH, AUTH_GENERAL, "Artisanat : /artisanat (fen\352tre) ; administration : /artisanat recharger, /artisanat exp <n>")
#else
#line 6418 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX
#ifdef __ZCK_QUEST
	// Une seule entree : ParsingCommand s'arrete a la premiere entree de ce nom.
	ON_TEXTCMDFUNC(TextCmd_ZckQuest, "quete", "quetes", "quest", "", TCM_BOTH, AUTH_GENERAL, "Qu\352tes : /quete (journal), /quete suivi (suivi \340 l'\351cran) ; administration : /quete recharger, /quete reinitialiser")
#endif // __ZCK_QUEST
	END_TEXTCMDFUNC_MAP


int ParsingCommand(LPCTSTR lpszString, CMover* pMover, BOOL bItem)
{
	CScanner scanner;
	scanner.SetProg((LPTSTR)lpszString);
	scanner.dwValue = (DWORD)pMover;
	scanner.GetToken(); // skip /
	scanner.GetToken(); // get command

	if (scanner.Token.IsEmpty())
		return FALSE;

	int nCount = 0;
	while (m_textCmdFunc[nCount].m_pFunc)
	{
		TextCmdFunc* pTextCmdFunc = &m_textCmdFunc[nCount];
		if (scanner.Token.MakeLower() == CString(pTextCmdFunc->m_pCommand).MakeLower() || scanner.Token.MakeLower() == CString(pTextCmdFunc->m_pAbbreviation).MakeLower() ||
			scanner.Token.MakeLower() == CString(pTextCmdFunc->m_pKrCommand).MakeLower() || scanner.Token.MakeLower() == CString(pTextCmdFunc->m_pKrAbbreviation).MakeLower())
		{
#ifdef __ZCK_AUTH
			if (bItem == FALSE && !pMover->IsAuthHigher(pTextCmdFunc->m_dwAuthorization))
#else
			if (bItem == FALSE && pTextCmdFunc->m_dwAuthorization > pMover->m_dwAuthorization)
#endif // __ZCK_AUTH
				break;

#ifdef __CLIENT
			if (pTextCmdFunc->m_nServer == TCM_CLIENT || pTextCmdFunc->m_nServer == TCM_BOTH)
			{
				if ((*pTextCmdFunc->m_pFunc)(scanner))
					if (pTextCmdFunc->m_nServer == TCM_BOTH)
					{
						char szSendChat[MAX_PATH];
						sprintf(szSendChat, "%s", scanner.m_pBuf);
						g_DPlay.SendChat((LPCSTR)szSendChat);
					}
			}
			else
				g_DPlay.SendChat((LPCSTR)lpszString);
#else	// __CLIENT
#ifdef __ZCK_FENETRE_CHAT_MJ
			// Seules les commandes de niveau MJ sont capturees ici.
			// Sans ce filtre, /w /s /p /g seraient comptes deux fois :
			// une fois comme chat, une fois comme commande (cf. H3).
			if (pTextCmdFunc->m_dwAuthorization >= (DWORD)AUTH_GAMEMASTER
				&& IsValidObj(pMover) && pMover->IsPlayer())
			{
				CZckChatMjManager::GetInstance()->Capture(
					ZCK_CHATMJ_CAT_MJ, (CUser*)pMover, NULL, lpszString);
			}
#endif // __ZCK_FENETRE_CHAT_MJ
			if (pTextCmdFunc->m_nServer == TCM_SERVER || pTextCmdFunc->m_nServer == TCM_BOTH)
				(*pTextCmdFunc->m_pFunc)(scanner);
#endif	// __CLIENT
			return TRUE;
		}
		nCount++;
	}

#ifdef __CLIENT
	BOOL bSkip = FALSE;
	CString strTemp = lpszString;

	if (strTemp.Find("#", 0) >= 0)
		bSkip = TRUE;

	int nstrlen = strlen(lpszString);

	if (!bSkip)
	{
		TCHAR	szText[MAX_EMOTICON_STR];

		if (nstrlen < MAX_EMOTICON_STR)
			strcpy(szText, lpszString);
		else
		{
			strncpy(szText, lpszString, MAX_EMOTICON_STR);
			szText[MAX_EMOTICON_STR - 1] = NULL;
		}


		for (int j = 0; j < MAX_EMOTICON_NUM; j++)
		{
			if (stricmp(&(szText[1]), g_DialogMsg.m_EmiticonCmd[j].m_szCommand) == 0)
			{
				g_DPlay.SendChat((LPCSTR)lpszString);
				return TRUE;
			}
		}
	}
#endif	//__CLIENT

	return FALSE;
}

#ifdef __ZCK_LINK
// -----------------------------------------------------------------------------------------
// Lien d'objet dans le chat : fonctions communes au client et au WorldServer (format des
// codes et declarations dans FuncTextCmd.h).
// -----------------------------------------------------------------------------------------
int ZckLienJeton(LPCTSTR lpsz, int nReste)
{
	// Decoupage de ParsingEffect et de CEditString::ParsingString : #c + 8, #l + 4, #n + 1,
	// tout autre #X sur 2 caracteres, '\' suivi de 'n' sur 2, '#' final seul ; borne par nReste.
	int nJeton = 1;
	if (nReste <= 1)
		return 1;
	if (lpsz[0] == '#')
	{
		switch (lpsz[1])
		{
		case 'c':
			nJeton = 10;
			break;
		case 'l':
			nJeton = 6;
			break;
		case 'n':
			nJeton = 3;
			break;
		default:
			nJeton = 2;
			break;
		}
	}
	else if (lpsz[0] == '\\' && lpsz[1] == 'n')
		nJeton = 2;
	return (nJeton < nReste) ? nJeton : nReste;
}

static int ZckLienChiffre(TCHAR c)
{
	if (c >= '0' && c <= '9')
		return c - '0';
	if (c >= 'A' && c <= 'F')
		return c - 'A' + 10;
	return -1;
}

static DWORD ZckLienValeur(LPCTSTR lpsz, int nChiffres)
{
	// chiffres deja verifies par ZckLienLire
	DWORD dwValeur = 0;
	for (int i = 0; i < nChiffres; i++)
		dwValeur = (dwValeur << 4) | (DWORD)ZckLienChiffre(lpsz[i]);
	return dwValeur;
}

static void ZckLienChiffres(TCHAR* psz, DWORD dwValeur, int nChiffres)
{
	static const char s_szChiffres[] = "0123456789ABCDEF";
	for (int i = nChiffres - 1; i >= 0; i--)
	{
		psz[i] = s_szChiffres[dwValeur & 0x0F];
		dwValeur >>= 4;
	}
}

static int ZckLienBorne(int n, int nMin, int nMax)
{
	return (n < nMin) ? nMin : ((n > nMax) ? nMax : n);
}

int ZckLienLire(LPCTSTR lpsz, int nReste, ZCK_LIEN* pLien)
{
	if (nReste < ZCK_LIEN_TAILLE || lpsz[0] != '#' || (lpsz[1] != 'j' && lpsz[1] != 'k'))
		return 0;
	for (int i = 2; i < ZCK_LIEN_TAILLE; i++)
	{
		if (ZckLienChiffre(lpsz[i]) < 0)
			return 0;
	}
	ZCK_LIEN lien;
	memset(&lien, 0, sizeof(lien));
	if (lpsz[1] == 'j')
	{
		lien.nGenre = ZCK_LIEN_GENRE_CLIENT;
		lien.dwObjId = ZckLienValeur(lpsz + 2, 8);
		lien.dwItemId = ZckLienValeur(lpsz + 10, 8);
		lien.dwSerie = ZckLienValeur(lpsz + 18, 8);
		if (ZckLienValeur(lpsz + 26, 6) != 0)
			return 0;
	}
	else
	{
		lien.nGenre = ZCK_LIEN_GENRE_SERVEUR;
		lien.dwLienHaut = ZckLienValeur(lpsz + 2, 8);
		lien.dwLienBas = ZckLienValeur(lpsz + 10, 8);
		lien.dwItemId = ZckLienValeur(lpsz + 18, 8);
		lien.nOption = (int)ZckLienValeur(lpsz + 26, 2);
		lien.nRarete = (int)ZckLienValeur(lpsz + 28, 1);
		lien.dwDrapeaux = ZckLienValeur(lpsz + 29, 1);
		lien.nNiveau = (int)ZckLienValeur(lpsz + 30, 2);
		if (lien.nRarete > ZCK_LIEN_RARETE_MAX || (lien.dwDrapeaux & ~(DWORD)ZCK_LIEN_REBORN) != 0)
			return 0;
	}
	if (lien.dwItemId == 0)
		return 0;
	if (pLien)
		*pLien = lien;
	return ZCK_LIEN_TAILLE;
}

void ZckLienEcrire(const ZCK_LIEN* pLien, TCHAR* pszCode)
{
	pszCode[0] = '#';
	if (pLien->nGenre == ZCK_LIEN_GENRE_CLIENT)
	{
		pszCode[1] = 'j';
		ZckLienChiffres(pszCode + 2, pLien->dwObjId, 8);
		ZckLienChiffres(pszCode + 10, pLien->dwItemId, 8);
		ZckLienChiffres(pszCode + 18, pLien->dwSerie, 8);
		ZckLienChiffres(pszCode + 26, 0, 6);
	}
	else
	{
		pszCode[1] = 'k';
		ZckLienChiffres(pszCode + 2, pLien->dwLienHaut, 8);
		ZckLienChiffres(pszCode + 10, pLien->dwLienBas, 8);
		ZckLienChiffres(pszCode + 18, pLien->dwItemId, 8);
		ZckLienChiffres(pszCode + 26, (DWORD)ZckLienBorne(pLien->nOption, 0, 255), 2);
		ZckLienChiffres(pszCode + 28, (DWORD)ZckLienBorne(pLien->nRarete, 0, ZCK_LIEN_RARETE_MAX), 1);
		ZckLienChiffres(pszCode + 29, pLien->dwDrapeaux & ZCK_LIEN_REBORN, 1);
		ZckLienChiffres(pszCode + 30, (DWORD)ZckLienBorne(pLien->nNiveau, 0, 255), 2);
	}
	pszCode[ZCK_LIEN_TAILLE] = '\0';
}

BOOL ZckLienPresent(LPCTSTR lpsz)
{
	const int nLen = (int)_tcslen(lpsz);
	for (int i = 0; i < nLen; )
	{
		if (ZckLienLire(lpsz + i, nLen - i, NULL))
			return TRUE;
		i += ZckLienJeton(lpsz + i, nLen - i);
	}
	return FALSE;
}

void ZckLienDepuisObjet(CItemElem* pItemElem, ZCK_LIEN* pLien)
{
	memset(pLien, 0, sizeof(ZCK_LIEN));
	pLien->dwObjId = pItemElem->m_dwObjId;
	pLien->dwItemId = pItemElem->m_dwItemId;
	pLien->dwSerie = (DWORD)pItemElem->GetSerialNumber();
	pLien->nOption = ZckLienBorne(pItemElem->GetAbilityOption(), 0, 255);
#if defined(__ZCK_RARE) || defined(__ZCK_NIVEAU_ARME)
	ItemProp* pItemProp = pItemElem->GetProp();
#endif // __ZCK_RARE || __ZCK_NIVEAU_ARME
#ifdef __ZCK_RARE
	// rarete montree par l'infobulle : objets a rarete seulement
	if (pItemProp && IsZckRareItem(pItemProp->dwItemKind3))
		pLien->nRarete = ZckLienBorne(pItemElem->GetZckRareLevel(), 0, ZCK_LIEN_RARETE_MAX);
#endif // __ZCK_RARE
#ifdef __ZCK_ARME_REBORN
	if (pItemElem->IsZckReborn())
		pLien->dwDrapeaux |= ZCK_LIEN_REBORN;
#endif // __ZCK_ARME_REBORN
#ifdef __ZCK_NIVEAU_ARME
	// meme condition que le nom de l'infobulle (CWndMgr::PutItemName)
	if (pItemProp && prj.IsZckArmeNiveauEligible(pItemProp) && pItemElem->m_nZckArmeNiveau > 0)
		pLien->nNiveau = ZckLienBorne(pItemElem->m_nZckArmeNiveau, 0, 255);
#endif // __ZCK_NIVEAU_ARME
}

static void ZckLienAjouter(TCHAR* pszTexte, int nTaille, int* pnLen, LPCTSTR lpsz)
{
	while (*lpsz && *pnLen < nTaille - 1)
		pszTexte[(*pnLen)++] = *lpsz++;
	pszTexte[*pnLen] = '\0';
}

static void ZckLienAjouterNombre(TCHAR* pszTexte, int nTaille, int* pnLen, int nNombre)
{
	TCHAR szChiffres[12];
	int n = 11;
	unsigned int u = (nNombre > 0) ? (unsigned int)nNombre : 0;
	szChiffres[n] = '\0';
	do
	{
		szChiffres[--n] = (TCHAR)('0' + u % 10);
		u /= 10;
	} while (u && n > 0);
	ZckLienAjouter(pszTexte, nTaille, pnLen, szChiffres + n);
}

int ZckLienTexte(const ZCK_LIEN* pLien, TCHAR* pszTexte, int nTaille, int* pnPrefixe, int* pnNom)
{
	int nLen = 0;
	pszTexte[0] = '\0';
	if (pLien->dwDrapeaux & ZCK_LIEN_REBORN)
		ZckLienAjouter(pszTexte, nTaille, &nLen, "[Reborn] ");
	const int nPrefixe = nLen;
	ItemProp* pItemProp = (pLien->dwItemId < (DWORD)prj.m_aPropItem.GetSize()) ? prj.GetItemProp((int)pLien->dwItemId) : NULL;
	ZckLienAjouter(pszTexte, nTaille, &nLen, "<");
	ZckLienAjouter(pszTexte, nTaille, &nLen, pItemProp ? pItemProp->szName : "?");
	if (pLien->nOption > 0)
	{
		ZckLienAjouter(pszTexte, nTaille, &nLen, " +");
		ZckLienAjouterNombre(pszTexte, nTaille, &nLen, pLien->nOption);
	}
	ZckLienAjouter(pszTexte, nTaille, &nLen, ">");
	const int nNom = nLen - nPrefixe;
	if (pLien->nNiveau > 0)
	{
		ZckLienAjouter(pszTexte, nTaille, &nLen, " [Niv. ");
		ZckLienAjouterNombre(pszTexte, nTaille, &nLen, pLien->nNiveau);
		ZckLienAjouter(pszTexte, nTaille, &nLen, "]");
	}
	if (pnPrefixe)
		*pnPrefixe = nPrefixe;
	if (pnNom)
		*pnNom = nNom;
	return nLen;
}

void ZckLienTexteClair(LPCTSTR lpsz, TCHAR* pszSortie, int nTaille)
{
	const int nLen = (int)_tcslen(lpsz);
	int n = 0;
	pszSortie[0] = '\0';
	for (int i = 0; i < nLen; )
	{
		ZCK_LIEN lien;
		if (ZckLienLire(lpsz + i, nLen - i, &lien))
		{
			TCHAR szTexte[ZCK_LIEN_TEXTE_MAX];
			ZckLienTexte(&lien, szTexte, ZCK_LIEN_TEXTE_MAX, NULL, NULL);
			ZckLienAjouter(pszSortie, nTaille, &n, szTexte);
			i += ZCK_LIEN_TAILLE;
		}
		else
		{
			const int nJeton = ZckLienJeton(lpsz + i, nLen - i);
			for (int k = 0; k < nJeton && n < nTaille - 1; k++)
				pszSortie[n++] = lpsz[i + k];
			pszSortie[n] = '\0';
			i += nJeton;
		}
	}
}

int ZckLienCoupure(LPCTSTR lpsz, int nMax)
{
	// coupure de SetStrNull (vutil.cpp), caractere double octet compris
	const int nLen = (int)_tcslen(lpsz);
	const int nNull = (nMax > nLen) ? nLen : nMax;
	int i = 0;
	while (i < nNull)
		i += IsDBCSLeadByte((BYTE)lpsz[i]) ? 2 : 1;
	const int nCoupe = (i > nNull) ? i - 2 : i;
	// un code commence avant la coupure et finit apres : il part entier
	for (int j = 0; j < nCoupe; )
	{
		if (ZckLienLire(lpsz + j, nLen - j, NULL))
		{
			if (j + ZCK_LIEN_TAILLE > nCoupe)
				return j;
			j += ZCK_LIEN_TAILLE;
		}
		else
			j += ZckLienJeton(lpsz + j, nLen - j);
	}
	return nCoupe;
}

int ZckLienPreparerEnvoi(LPCTSTR lpsz, TCHAR* pszSortie, int nTaille)
{
	const int nLen = (int)_tcslen(lpsz);
	int n = 0;
	for (int i = 0; i < nLen; )
	{
		int nCopie = ZCK_LIEN_TAILLE;
		int nBlancs = 0;
		if (ZckLienLire(lpsz + i, nLen - i, NULL) == 0)
		{
			// sequence # qui avalerait le debut d'un code : completee par des espaces
			nCopie = ZckLienJeton(lpsz + i, nLen - i);
			for (int k = 1; k < nCopie; k++)
			{
				if (ZckLienLire(lpsz + i + k, nLen - i - k, NULL))
				{
					nBlancs = nCopie - k;
					nCopie = k;
					break;
				}
			}
		}
		for (int k = 0; k < nCopie && n < nTaille - 1; k++)
			pszSortie[n++] = lpsz[i + k];
		for (int k = 0; k < nBlancs && n < nTaille - 1; k++)
			pszSortie[n++] = ' ';
		i += nCopie;
	}
	pszSortie[n] = '\0';
	n = ZckLienCoupure(pszSortie, ZCK_LIEN_MESSAGE_MAX);
	pszSortie[n] = '\0';
	return n;
}

BOOL ZckLienCommandeDeChat(LPCTSTR lpsz)
{
	if (lpsz[0] != '/')
		return TRUE;
	// commande reconnue exactement comme ParsingCommand : premiere entree qui correspond
	CScanner scanner;
	scanner.SetProg((LPTSTR)lpsz);
	scanner.GetToken();
	scanner.GetToken();
	if (scanner.Token.IsEmpty())
		return FALSE;
	for (int nCount = 0; m_textCmdFunc[nCount].m_pFunc; nCount++)
	{
		TextCmdFunc* pTextCmdFunc = &m_textCmdFunc[nCount];
		if (scanner.Token.MakeLower() == CString(pTextCmdFunc->m_pCommand).MakeLower() || scanner.Token.MakeLower() == CString(pTextCmdFunc->m_pAbbreviation).MakeLower() ||
			scanner.Token.MakeLower() == CString(pTextCmdFunc->m_pKrCommand).MakeLower() || scanner.Token.MakeLower() == CString(pTextCmdFunc->m_pKrAbbreviation).MakeLower())
		{
			return (pTextCmdFunc->m_pFunc == TextCmd_whisper || pTextCmdFunc->m_pFunc == TextCmd_say || pTextCmdFunc->m_pFunc == TextCmd_shout
				|| pTextCmdFunc->m_pFunc == TextCmd_PartyChat || pTextCmdFunc->m_pFunc == TextCmd_GuildChat) ? TRUE : FALSE;
		}
	}
	return FALSE;
}

#ifdef __WORLDSERVER
void ZckLienAssainir(CUser* pUser, TCHAR* pszTexte)
{
	const int nLen = (int)_tcslen(pszTexte);
	int n = 0;
	for (int i = 0; i < nLen; )
	{
		ZCK_LIEN lien;
		if (ZckLienLire(pszTexte + i, nLen - i, &lien))
		{
			BOOL bGarde = FALSE;
			if (lien.nGenre == ZCK_LIEN_GENRE_SERVEUR && IsValidObj(pUser))
			{
				for (int k = 0; k < pUser->m_nZckLienMessage && k < ZCK_LIEN_PAR_MESSAGE; k++)
				{
					if (pUser->m_abZckLienPris[k] == FALSE && memcmp(pUser->m_aszZckLienMessage[k], pszTexte + i, ZCK_LIEN_TAILLE) == 0)
					{
						pUser->m_abZckLienPris[k] = TRUE;
						bGarde = TRUE;
						break;
					}
				}
			}
			if (bGarde)
			{
				memmove(pszTexte + n, pszTexte + i, ZCK_LIEN_TAILLE);
				n += ZCK_LIEN_TAILLE;
			}
			else if (n > 0 && i + ZCK_LIEN_TAILLE < nLen)
			{
				// code retire entre deux textes : un espace a sa place, sinon "#k" + code retire
				// + 30 chiffres formerait un nouveau code
				pszTexte[n++] = ' ';
			}
			i += ZCK_LIEN_TAILLE;
		}
		else
		{
			const int nJeton = ZckLienJeton(pszTexte + i, nLen - i);
			memmove(pszTexte + n, pszTexte + i, nJeton);
			n += nJeton;
			i += nJeton;
		}
	}
	pszTexte[n] = '\0';
}
#endif // __WORLDSERVER

#else
#line 6450
#endif // __ZCK_LINK
void RemoveCRLF(char* szString)
{
	CString str = szString;
	str.Replace("\\n", " ");
	lstrcpy(szString, (LPCSTR)str);
}

void Removeat(char* szString)
{
	CString str = szString;
	str.Replace("@", " ");
	str.Replace("@@", " ");
	lstrcpy(szString, (LPCSTR)str);
}

void ParsingEffect(TCHAR* pChar, int nLen)
{
	CString strTemp;

	for (int i = 0; i < nLen; i++)
	{
		if (pChar[i] == '#')
		{
			if (++i >= nLen)
				break;
			switch (pChar[i])
			{
			case 'c':
			{
				if (++i >= nLen)
					break;

				i += 7;
			}
			break;
			case 'u':
				break;
			case 'b':
				break;
			case 's':
				break;

			case 'l':
			{
				if (++i >= nLen)
					break;

				i += 3;
			}
			break;
			case 'n':
				if (++i >= nLen)
					break;

				{
					switch (pChar[i])
					{
					case 'c':
						break;
					case 'b':
						break;
					case 'u':
						break;
					case 's':
						break;
					case 'l':
						break;
					}
				}
				break;
			default:
			{

				strTemp += pChar[i - 1];
				strTemp += pChar[i];
			}
			break;
			}
		}
		else
		{
			if (pChar[i] == '\\' && pChar[i + 1] == 'n')
			{
				strTemp += '\n';
				i += 1;
			}
			else
			{
				strTemp += pChar[i];
				int nlength = strTemp.GetLength();
			}
		}
	}

	//	memcpy( pChar, strTemp, sizeof(TCHAR)*nLen );
	strcpy(pChar, strTemp);
}
