#include "stdafx.h"
#include "ZckQuest.h"

#ifdef __ZCK_QUEST

#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#ifdef __ZCK_PRESTIGE
#include "ZckPrestige.h"
#endif // __ZCK_PRESTIGE

#ifdef __WORLDSERVER
#include "worldmng.h"
#include "User.h"
#include "DPSrvr.h"
#include "DPDatabaseClient.h"
#include "party.h"
#ifdef __ZCK_MINIJEU_PVP
#include "ZckPvPMinigames.h"
#endif // __ZCK_MINIJEU_PVP
extern CWorldMng			g_WorldMng;
extern CUserMng				g_UserMng;
extern CDPSrvr				g_DPSrvr;
extern CDPDatabaseClient	g_dpDBClient;
extern CPartyMng			g_PartyMng;
#endif // __WORLDSERVER

//////////////////////////////////////////////////////////////////////
// Etat du personnage : Neuz, WorldServer et DatabaseServer
//////////////////////////////////////////////////////////////////////

CZckQuestState::CZckQuestState()
	: m_bBaseOk(FALSE)
{
	ResetRuntime();
}

CZckQuestState::CZckQuestState(const CZckQuestState& rhs)
	: m_mapEntrees(rhs.m_mapEntrees)
	, m_bBaseOk(rhs.m_bBaseOk)
{
	ResetRuntime();
}

CZckQuestState::~CZckQuestState()
{
	m_mapEntrees.clear();
}

CZckQuestState& CZckQuestState::operator=(const CZckQuestState& rhs)
{
	if (this != &rhs)
	{
		m_mapEntrees = rhs.m_mapEntrees;
		m_bBaseOk = rhs.m_bBaseOk;
		ResetRuntime();
	}
	return *this;
}

void CZckQuestState::ResetRuntime()
{
#ifdef __WORLDSERVER
	m_bAction = FALSE;
	m_dwDerniereAction = 0;
	m_bCatalogue = FALSE;
	m_dwDernierCatalogue = 0;
	m_bDemande = FALSE;
	m_dwDerniereDemande = 0;
#endif // __WORLDSERVER
}

// Etat vierge, colonne consideree comme non chargee : un personnage qui n'a
// pas ete lu en base n'ecrit jamais la colonne.
void CZckQuestState::Clear()
{
	m_mapEntrees.clear();
	m_bBaseOk = FALSE;
	ResetRuntime();
}

BOOL CZckQuestState::EntreeValide(int nId, const ZCK_QUEST_ENTREE& entree)
{
	if (nId <= 0 || nId > ZCK_QUEST_ID_MAX)
		return FALSE;
	if (entree.byEtat != ZCK_QUEST_ETAT_EN_COURS && entree.byEtat != ZCK_QUEST_ETAT_TERMINEE && entree.byEtat != ZCK_QUEST_ETAT_RECOMPENSEE)
		return FALSE;
	if (entree.nCycle < 0 || entree.nCycle > ZCK_QUEST_CYCLE_MAX)
		return FALSE;
	if (entree.n64Echeance < 0 || entree.n64Echeance > ZCK_QUEST_ECHEANCE_MAX)
		return FALSE;
	if (entree.nProgression < 0 || entree.nProgression > ZCK_QUEST_OBJECTIF_MAX)
		return FALSE;
	return TRUE;
}

// Bloc METHOD_NONE de CMover::Serialize : DatabaseServer <-> WorldServer et
// WorldServer -> proprietaire. Ecriture et lecture cote a cote, memes types.
void CZckQuestState::Serialize(CAr& ar)
{
	if (ar.IsStoring())
	{
		ar << (BYTE)(m_bBaseOk ? 1 : 0);
		ar << (DWORD)m_mapEntrees.size();
		for (std::map<int, ZCK_QUEST_ENTREE>::const_iterator it = m_mapEntrees.begin(); it != m_mapEntrees.end(); ++it)
		{
			ar << it->first;
			ar << it->second.byEtat;
			ar << it->second.nCycle;
			ar << it->second.n64Echeance;
			ar << it->second.nProgression;
		}
	}
	else
	{
		m_mapEntrees.clear();

		BYTE byBaseOk = 0;
		DWORD dwNombre = 0;
		ar >> byBaseOk;
		ar >> dwNombre;

		BOOL bValide = (byBaseOk <= 1 && dwNombre <= ZCK_QUEST_MAX);
		// Un nombre hors bornes ne vient que d'un flux corrompu : la lecture
		// s'arrete a ZCK_QUEST_MAX entrees, jamais une boucle sans fin.
		const DWORD dwLus = (dwNombre <= ZCK_QUEST_MAX) ? dwNombre : (DWORD)ZCK_QUEST_MAX;
		for (DWORD i = 0; i < dwLus; ++i)
		{
			int nId = 0;
			ZCK_QUEST_ENTREE entree;
			ar >> nId;
			ar >> entree.byEtat;
			ar >> entree.nCycle;
			ar >> entree.n64Echeance;
			ar >> entree.nProgression;

			if (!bValide)
				continue;
			if (!EntreeValide(nId, entree) || m_mapEntrees.find(nId) != m_mapEntrees.end())
			{
				bValide = FALSE;
				continue;
			}
			m_mapEntrees.insert(std::make_pair(nId, entree));
		}

		if (bValide)
			m_bBaseOk = (byBaseOk != 0) ? TRUE : FALSE;
		else
		{
			// Jamais d'ecriture en base d'un etat illisible : la colonne garde sa valeur.
			Error("CZckQuestState::Serialize : etat des quetes illisible (%u entrees), quetes coupees pour ce personnage", (unsigned int)dwNombre);
			m_mapEntrees.clear();
			m_bBaseOk = FALSE;
		}
		ResetRuntime();
	}
}

ZCK_QUEST_ENTREE* CZckQuestState::Find(int nId)
{
	std::map<int, ZCK_QUEST_ENTREE>::iterator it = m_mapEntrees.find(nId);
	return (it != m_mapEntrees.end()) ? &it->second : NULL;
}

const ZCK_QUEST_ENTREE* CZckQuestState::Find(int nId) const
{
	std::map<int, ZCK_QUEST_ENTREE>::const_iterator it = m_mapEntrees.find(nId);
	return (it != m_mapEntrees.end()) ? &it->second : NULL;
}

ZCK_QUEST_ENTREE* CZckQuestState::GetOrCreate(int nId)
{
	if (nId <= 0 || nId > ZCK_QUEST_ID_MAX)
		return NULL;
	std::map<int, ZCK_QUEST_ENTREE>::iterator it = m_mapEntrees.find(nId);
	if (it != m_mapEntrees.end())
		return &it->second;
	if (m_mapEntrees.size() >= ZCK_QUEST_MAX)
		return NULL;
	return &m_mapEntrees[nId];
}

void CZckQuestState::Remove(int nId)
{
	m_mapEntrees.erase(nId);
}

#ifdef __DBSERVER
// Texte de la colonne CHARACTER_TBL.m_szZckQuest : "id,etat,cycle,echeance,progression;" puis '$'.
// FALSE : rien d'ecrit (DbManagerSave lie alors NULL et la colonne garde sa valeur).
BOOL CZckQuestState::SerializeDbText(char* pszBuffer, size_t nBufferSize) const
{
	if (!pszBuffer || nBufferSize < 2)
		return FALSE;

	pszBuffer[0] = '\0';
	size_t nUtilise = 0;

	for (std::map<int, ZCK_QUEST_ENTREE>::const_iterator it = m_mapEntrees.begin(); it != m_mapEntrees.end(); ++it)
	{
		if (!EntreeValide(it->first, it->second))
		{
			Error("ZckQuest : SerializeDbText - entree %d hors bornes, colonne non ecrite", it->first);
			pszBuffer[0] = '\0';
			return FALSE;
		}

		char szEntree[64] = { 0, };
		const int nEcrit = sprintf_s(szEntree, sizeof(szEntree), "%d,%u,%d,%I64d,%d;",
			it->first,
			(unsigned int)it->second.byEtat,
			it->second.nCycle,
			it->second.n64Echeance,
			it->second.nProgression);
		if (nEcrit <= 0)
		{
			pszBuffer[0] = '\0';
			return FALSE;
		}

		if (nUtilise + (size_t)nEcrit + 2 > nBufferSize)
		{
			Error("ZckQuest : SerializeDbText - tampon sature (%u octets), colonne non ecrite", (unsigned int)nBufferSize);
			pszBuffer[0] = '\0';
			return FALSE;
		}

		memcpy(pszBuffer + nUtilise, szEntree, (size_t)nEcrit);
		nUtilise += (size_t)nEcrit;
	}

	pszBuffer[nUtilise++] = '$';
	pszBuffer[nUtilise] = '\0';
	return TRUE;
}

// Un nombre decimal dans [nMin, nMax], suivi d'un des separateurs de pszFins.
static BOOL ZckQuLireNombreDb(const char*& p, __int64 nMin, __int64 nMax, const char* pszFins, __int64& nValeur)
{
	char* pFin = NULL;
	errno = 0;
	const __int64 n = _strtoi64(p, &pFin, 10);
	if (errno == ERANGE || pFin == NULL || pFin == p || *pFin == '\0' || strchr(pszFins, *pFin) == NULL)
		return FALSE;
	if (n < nMin || n > nMax)
		return FALSE;
	nValeur = n;
	p = pFin;
	return TRUE;
}

BOOL CZckQuestState::DeserializeDbText(const char* pszBuffer)
{
	m_mapEntrees.clear();

	if (!pszBuffer || !pszBuffer[0] || strcmp(pszBuffer, "NULL") == 0)
		return TRUE;

	BOOL bOk = TRUE;
	const char* p = pszBuffer;
	while (*p != '\0' && *p != '$')
	{
		if (m_mapEntrees.size() >= ZCK_QUEST_MAX)
		{
			bOk = FALSE;
			break;
		}

		__int64 nId = 0, nEtat = 0, nCycle = 0, nEcheance = 0, nProgression = 0;
		if (!ZckQuLireNombreDb(p, 1, ZCK_QUEST_ID_MAX, ",", nId))
		{
			bOk = FALSE;
			break;
		}
		++p;
		if (!ZckQuLireNombreDb(p, ZCK_QUEST_ETAT_EN_COURS, ZCK_QUEST_ETAT_RECOMPENSEE, ",", nEtat))
		{
			bOk = FALSE;
			break;
		}
		++p;
		if (!ZckQuLireNombreDb(p, 0, ZCK_QUEST_CYCLE_MAX, ",", nCycle))
		{
			bOk = FALSE;
			break;
		}
		++p;
		if (!ZckQuLireNombreDb(p, 0, ZCK_QUEST_ECHEANCE_MAX, ",", nEcheance))
		{
			bOk = FALSE;
			break;
		}
		++p;
		if (!ZckQuLireNombreDb(p, 0, ZCK_QUEST_OBJECTIF_MAX, ";$", nProgression))
		{
			bOk = FALSE;
			break;
		}
		if (*p == ';')
			++p;

		const int nCle = (int)nId;
		if (m_mapEntrees.find(nCle) != m_mapEntrees.end())
		{
			bOk = FALSE;
			break;
		}

		ZCK_QUEST_ENTREE entree;
		entree.byEtat = (BYTE)nEtat;
		entree.nCycle = (int)nCycle;
		entree.n64Echeance = nEcheance;
		entree.nProgression = (int)nProgression;
		m_mapEntrees.insert(std::make_pair(nCle, entree));
	}

	if (bOk && (*p != '$' || p[1] != '\0'))
		bOk = FALSE;

	if (!bOk)
	{
		m_mapEntrees.clear();
		return FALSE;
	}
	return TRUE;
}
#endif // __DBSERVER

#if defined(__CLIENT) || defined(__WORLDSERVER)
//////////////////////////////////////////////////////////////////////
// Catalogue et calculs communs : Neuz et WorldServer
//////////////////////////////////////////////////////////////////////

CZckQuestManager::CZckQuestManager()
	: m_dwVersion(0)
	, m_nActivesMax(ZCK_QUEST_ACTIVES_DEFAUT)
#ifdef __WORLDSERVER
	, m_bActif(FALSE)
#endif // __WORLDSERVER
#ifdef __CLIENT
	, m_bCatalogue(FALSE)
	, m_bHorloge(FALSE)
	, m_n64HorlogeBase(0)
	, m_dwTickBase(0)
#endif // __CLIENT
{
}

CZckQuestManager::~CZckQuestManager()
{
	m_mapDefinitions.clear();
}

CZckQuestManager* CZckQuestManager::GetInstance()
{
	static CZckQuestManager s_manager;
	return &s_manager;
}

const ZCK_QUEST_DEFINITION* CZckQuestManager::GetDefinition(int nId) const
{
	std::map<int, ZCK_QUEST_DEFINITION>::const_iterator it = m_mapDefinitions.find(nId);
	return (it != m_mapDefinitions.end()) ? &it->second : NULL;
}

int CZckQuestManager::JourSemaine(__int64 n64Jour)
{
	// 01/01/1970 (jour 0) etait un jeudi : (jour + 4) % 7, 0 = dimanche.
	const __int64 n = (n64Jour + 4) % 7;
	return (int)((n < 0) ? n + 7 : n);
}

// Ouverture la plus recente commencee (8 jours en arriere au plus, un jour
// ouvert par semaine suffit) et prochaine ouverture (8 jours en avant).
void CZckQuestManager::CalculerFenetre(const ZCK_QUEST_DEFINITION& def, __int64 n64Maintenant, ZCK_QUEST_FENETRE& fen)
{
	fen = ZCK_QUEST_FENETRE();
	if (n64Maintenant <= 0 || def.nDebut < 0 || def.nDebut >= 1440 || def.nFin <= 0 || def.nFin > 1440 || def.nFin == def.nDebut)
		return;

	const __int64 n64Duree = (def.nFin > def.nDebut)
		? (__int64)(def.nFin - def.nDebut) * 60
		: (__int64)(1440 - def.nDebut + def.nFin) * 60;
	const __int64 n64Aujourdhui = n64Maintenant / ZCK_QUEST_JOUR_S;

	for (__int64 j = n64Aujourdhui; j >= n64Aujourdhui - 8; --j)
	{
		if ((def.byJours & (1 << JourSemaine(j))) == 0)
			continue;
		const __int64 n64Debut = j * ZCK_QUEST_JOUR_S + (__int64)def.nDebut * 60;
		if (n64Debut > n64Maintenant)
			continue;
		fen.bCycle = TRUE;
		fen.nCycle = (int)j;
		fen.n64Debut = n64Debut;
		fen.n64Fin = n64Debut + n64Duree;
		fen.bOuverte = (n64Maintenant < fen.n64Fin) ? TRUE : FALSE;
		break;
	}

	for (__int64 j = n64Aujourdhui; j <= n64Aujourdhui + 8; ++j)
	{
		if ((def.byJours & (1 << JourSemaine(j))) == 0)
			continue;
		const __int64 n64Debut = j * ZCK_QUEST_JOUR_S + (__int64)def.nDebut * 60;
		if (n64Debut <= n64Maintenant)
			continue;
		fen.n64Prochaine = n64Debut;
		break;
	}
}

BOOL CZckQuestManager::ConditionsRemplies(const ZCK_QUEST_DEFINITION& def, int nNiveau, int nPrestige)
{
	if (nNiveau < def.nNiveauMin || nNiveau > def.nNiveauMax)
		return FALSE;
	if (nPrestige < def.nPrestigeMin || nPrestige > def.nPrestigeMax)
		return FALSE;
	return TRUE;
}

int CZckQuestManager::CalculerStatut(const ZCK_QUEST_DEFINITION& def, const ZCK_QUEST_ENTREE* pEntree, __int64 n64Maintenant, int nNiveau, int nPrestige)
{
	ZCK_QUEST_FENETRE fen;
	CalculerFenetre(def, n64Maintenant, fen);

	if (pEntree)
	{
		switch (pEntree->byEtat)
		{
		case ZCK_QUEST_ETAT_TERMINEE:
			// La recompense ne se perd jamais, meme apres la fin de l'horaire.
			return ZCK_QUEST_STATUT_TERMINEE;
		case ZCK_QUEST_ETAT_RECOMPENSEE:
			if (fen.bCycle && pEntree->nCycle == fen.nCycle)
				return ZCK_QUEST_STATUT_ACCOMPLIE;
			break;
		case ZCK_QUEST_ETAT_EN_COURS:
			if (n64Maintenant < pEntree->n64Echeance)
				return ZCK_QUEST_STATUT_EN_COURS;
			if (fen.bCycle && pEntree->nCycle == fen.nCycle)
				return ZCK_QUEST_STATUT_ECHOUEE;
			break;
		default:
			break;
		}
	}

	if (!fen.bOuverte)
		return ZCK_QUEST_STATUT_FERMEE;
	if (!ConditionsRemplies(def, nNiveau, nPrestige))
		return ZCK_QUEST_STATUT_VERROUILLEE;
	return ZCK_QUEST_STATUT_DISPONIBLE;
}

BOOL CZckQuestManager::MondeValide(const ZCK_QUEST_DEFINITION& def, DWORD dwWorldId)
{
	if (def.vecMondes.empty())
		return TRUE;
	for (size_t i = 0; i < def.vecMondes.size(); ++i)
	{
		if (def.vecMondes[i] == dwWorldId)
			return TRUE;
	}
	return FALSE;
}

// EXP brute plus nExpPourcent % de l'EXP du niveau en cours (expTable.inc),
// bornee a ZCK_QUEST_EXP_MAX.
__int64 CZckQuestManager::ExpRecompense(const ZCK_QUEST_DEFINITION& def, int nNiveau)
{
	__int64 n64Exp = (def.n64Exp > 0) ? def.n64Exp : 0;
	if (def.nExpPourcent > 0 && nNiveau >= 1 && nNiveau + 1 < MAX_EXPCHARACTER)
	{
		const __int64 n64Niveau = (__int64)prj.m_aExpCharacter[nNiveau + 1].nExp1;
		if (n64Niveau > 0)
			n64Exp += n64Niveau / 100 * def.nExpPourcent + (n64Niveau % 100) * def.nExpPourcent / 100;
	}
	if (n64Exp > ZCK_QUEST_EXP_MAX)
		n64Exp = ZCK_QUEST_EXP_MAX;
	return n64Exp;
}

LPCTSTR CZckQuestManager::TexteCode(BYTE byCode)
{
	switch (byCode)
	{
	case ZCK_QUEST_OK:					return "Demande accept\351e.";
	case ZCK_QUEST_REFUS_DEMANDE:		return "Demande invalide.";
	case ZCK_QUEST_REFUS_INDISPONIBLE:	return "Le syst\350me de qu\352tes est indisponible (ZckQuetes.inc absent ou invalide sur le serveur).";
	case ZCK_QUEST_REFUS_BASE:			return "Qu\352tes indisponibles : la base de donn\351es n'est pas \340 jour (12.CHARACTER_TBL_ZCK_QUEST.sql et CHARACTER_STR).";
	case ZCK_QUEST_REFUS_CATALOGUE:		return "La liste des qu\352tes a chang\351 : elle vient d'\352tre recharg\351e.";
	case ZCK_QUEST_REFUS_INCONNUE:		return "Qu\352te inconnue.";
	case ZCK_QUEST_REFUS_FERMEE:		return "Cette qu\352te n'est pas disponible \340 cette heure.";
	case ZCK_QUEST_REFUS_NIVEAU:		return "Votre niveau ne permet pas cette qu\352te.";
	case ZCK_QUEST_REFUS_PRESTIGE:		return "Votre rang de prestige ne permet pas cette qu\352te.";
	case ZCK_QUEST_REFUS_DEJA:			return "Cette qu\352te est d\351j\340 en cours ou accomplie pour cette ouverture.";
	case ZCK_QUEST_REFUS_A_RECUPERER:	return "R\351cup\351rez d'abord la r\351compense de cette qu\352te.";
	case ZCK_QUEST_REFUS_ACTIVES:		return "Trop de qu\352tes en cours : terminez ou abandonnez-en une.";
	case ZCK_QUEST_REFUS_PAS_ACTIVE:	return "Cette qu\352te n'est pas en cours.";
	case ZCK_QUEST_REFUS_PAS_TERMINEE:	return "Cette qu\352te n'est pas termin\351e.";
	case ZCK_QUEST_REFUS_INVENTAIRE:	return "Inventaire insuffisant pour recevoir toutes les r\351compenses.";
	case ZCK_QUEST_REFUS_PENYA:			return "Votre montant de Penya est trop \351lev\351 pour cette r\351compense.";
	case ZCK_QUEST_REFUS_BUFF:			return "Un effet incompatible est d\351j\340 actif : r\351essayez quand il sera termin\351.";
	case ZCK_QUEST_REFUS_MODE_EGALISE:	return "Impossible pendant le mode \351galis\351.";
	case ZCK_QUEST_REFUS_MORT:			return "Impossible tant que votre personnage est mort.";
	case ZCK_QUEST_REFUS_TROP_TOT:		return "Patientez un instant avant une nouvelle demande.";
	case ZCK_QUEST_REFUS_STAFF:			return "Action interdite au staff : r\351compense de qu\352te.";
	case ZCK_QUEST_REFUS_OCCUPE:		return "Impossible maintenant : \351change, boutique personnelle, p\351trification ou mini-jeu PvP en cours.";
	default:							break;
	}
	return "R\351ponse inconnue du serveur.";
}

LPCTSTR CZckQuestManager::TexteStatut(int nStatut)
{
	switch (nStatut)
	{
	case ZCK_QUEST_STATUT_FERMEE:		return "Ferm\351e";
	case ZCK_QUEST_STATUT_DISPONIBLE:	return "Disponible";
	case ZCK_QUEST_STATUT_VERROUILLEE:	return "Verrouill\351e";
	case ZCK_QUEST_STATUT_EN_COURS:		return "En cours";
	case ZCK_QUEST_STATUT_ECHOUEE:		return "\311chou\351e";
	case ZCK_QUEST_STATUT_TERMINEE:		return "Termin\351e";
	case ZCK_QUEST_STATUT_ACCOMPLIE:	return "Accomplie";
	default:							break;
	}
	return "?";
}

int CZckQuestManager::CompterActives(const CZckQuestState& state, __int64 n64Maintenant) const
{
	int nActives = 0;
	const std::map<int, ZCK_QUEST_ENTREE>& entrees = state.GetEntrees();
	for (std::map<int, ZCK_QUEST_ENTREE>::const_iterator it = entrees.begin(); it != entrees.end(); ++it)
	{
		if (it->second.byEtat == ZCK_QUEST_ETAT_EN_COURS && n64Maintenant < it->second.n64Echeance && GetDefinition(it->first))
			++nActives;
	}
	return nActives;
}

BOOL CZckQuestManager::Normaliser(CZckQuestState& state, __int64 n64Maintenant) const
{
	BOOL bChange = FALSE;
	std::map<int, ZCK_QUEST_ENTREE>& entrees = state.GetEntrees();
	for (std::map<int, ZCK_QUEST_ENTREE>::iterator it = entrees.begin(); it != entrees.end(); )
	{
		const ZCK_QUEST_DEFINITION* pDef = GetDefinition(it->first);
		if (!pDef)
		{
			// Quete retiree de ZckQuetes.inc.
			it = entrees.erase(it);
			bChange = TRUE;
			continue;
		}

		ZCK_QUEST_ENTREE& entree = it->second;
		if (entree.nProgression < 0)
		{
			entree.nProgression = 0;
			bChange = TRUE;
		}
		if (entree.nProgression > pDef->nObjectif)
		{
			entree.nProgression = pDef->nObjectif;
			bChange = TRUE;
		}
		// Objectif abaisse par un rechargement : les monstres deja tues suffisent,
		// pour une tentative encore dans son temps seulement (jamais un echec).
		if (entree.byEtat == ZCK_QUEST_ETAT_EN_COURS && entree.nProgression >= pDef->nObjectif && n64Maintenant < entree.n64Echeance)
		{
			entree.byEtat = ZCK_QUEST_ETAT_TERMINEE;
			bChange = TRUE;
		}

		// Entree d'une ouverture passee : la quete redevient disponible.
		if (entree.byEtat != ZCK_QUEST_ETAT_TERMINEE)
		{
			const BOOL bEnCours = (entree.byEtat == ZCK_QUEST_ETAT_EN_COURS && n64Maintenant < entree.n64Echeance);
			if (!bEnCours)
			{
				ZCK_QUEST_FENETRE fen;
				CalculerFenetre(*pDef, n64Maintenant, fen);
				if (!fen.bCycle || entree.nCycle != fen.nCycle)
				{
					it = entrees.erase(it);
					bChange = TRUE;
					continue;
				}
			}
		}
		++it;
	}
	return bChange;
}

// Catalogue : ecrit par le WorldServer, relu par CZckQuestManager::LireCatalogue
// (Neuz), memes types, meme ordre.
void CZckQuestManager::EcrireCatalogue(CAr& ar) const
{
	ar << m_dwVersion;
	ar << m_nActivesMax;
	ar << (DWORD)m_mapDefinitions.size();
	for (std::map<int, ZCK_QUEST_DEFINITION>::const_iterator it = m_mapDefinitions.begin(); it != m_mapDefinitions.end(); ++it)
	{
		const ZCK_QUEST_DEFINITION& def = it->second;
		ar << def.nId;
		ar.WriteString((LPCTSTR)def.strNom);
		ar.WriteString((LPCTSTR)def.strDescription);
		ar.WriteString((LPCTSTR)def.strCategorie);
		ar.WriteString((LPCTSTR)def.strLieu);
		ar << def.nDebut;
		ar << def.nFin;
		ar << def.byJours;
		ar << def.nDuree;
		ar << def.nNiveauMin;
		ar << def.nNiveauMax;
		ar << def.nPrestigeMin;
		ar << def.nPrestigeMax;
		ar << def.nObjectif;
		ar << (BYTE)(def.bGroupe ? 1 : 0);

		ar << (BYTE)def.vecMondes.size();
		for (size_t i = 0; i < def.vecMondes.size(); ++i)
			ar << def.vecMondes[i];

		ar << (BYTE)def.vecMonstres.size();
		for (size_t i = 0; i < def.vecMonstres.size(); ++i)
			ar << def.vecMonstres[i];

		ar << (BYTE)def.vecObjets.size();
		for (size_t i = 0; i < def.vecObjets.size(); ++i)
		{
			ar << def.vecObjets[i].dwItemId;
			ar << def.vecObjets[i].nNombre;
			ar << (BYTE)(def.vecObjets[i].bLie ? 1 : 0);
		}

		ar << (BYTE)def.vecBuffs.size();
		for (size_t i = 0; i < def.vecBuffs.size(); ++i)
			ar << def.vecBuffs[i];

		ar << def.nPenya;
		ar << def.n64Exp;
		ar << def.nExpPourcent;
	}
	ar << (DWORD)ZCK_QUEST_FIN;
}
#endif // __CLIENT || __WORLDSERVER

#ifdef __WORLDSERVER
//////////////////////////////////////////////////////////////////////
// WorldServer : lecture de ZckQuetes.inc
//
// Chaque valeur est controlee des sa lecture ; la ligne du fichier est
// reprise dans le message (journal d'erreurs du WorldServer). Un fichier
// invalide n'est jamais applique, meme en partie : le catalogue en service
// reste celui d'avant (au demarrage : aucun, quetes refusees).
//////////////////////////////////////////////////////////////////////

static int ZckQuLigne(CScript& s)
{
	return s.GetLineNum() + 1;
}

// Entier : chiffres decimaux ou #define connu (MI_*, II_*, WI_*, ...).
// L'hexadecimal est refuse ; un signe '-' n'est admis que si nMin < 0.
static BOOL ZckQuLireEntier(CScript& s, __int64 nMin, __int64 nMax, __int64& nValeur, LPCTSTR lpszChamp, int nQuete)
{
	const int nLigne = ZckQuLigne(s);
	s.GetToken_NoDef();
	BOOL bNegatif = FALSE;
	if (s.tok != FINISHED && nMin < 0 && s.Token == _T("-"))
	{
		bNegatif = TRUE;
		s.GetToken_NoDef();
	}
	if (s.tok == FINISHED)
	{
		Error("ZckQuetes.inc(%d) : quete %d, %s : valeur attendue, fin du fichier atteinte", nLigne, nQuete, lpszChamp);
		return FALSE;
	}

	__int64 n = 0;
	if (s.tokenType == NUMBER)
	{
		const int nLongueur = s.Token.GetLength();
		if (nLongueur <= 0 || nLongueur > 18)
		{
			Error("ZckQuetes.inc(%d) : quete %d, %s : nombre invalide '%s'", ZckQuLigne(s), nQuete, lpszChamp, (LPCTSTR)s.Token);
			return FALSE;
		}
		for (int i = 0; i < nLongueur; ++i)
		{
			if (s.Token[i] < '0' || s.Token[i] > '9')
			{
				Error("ZckQuetes.inc(%d) : quete %d, %s : nombre decimal attendu, recu '%s'", ZckQuLigne(s), nQuete, lpszChamp, (LPCTSTR)s.Token);
				return FALSE;
			}
		}
		n = _atoi64(s.Token);
	}
	else if (s.tokenType == HEX)
	{
		Error("ZckQuetes.inc(%d) : quete %d, %s : nombre decimal attendu, recu '0x%s'", ZckQuLigne(s), nQuete, lpszChamp, (LPCTSTR)s.Token);
		return FALSE;
	}
	else if (s.tokenType == STRING || s.tokenType == BLOCK || s.tokenType == DELIMITER)
	{
		Error("ZckQuetes.inc(%d) : quete %d, %s : valeur attendue, recu '%s'", ZckQuLigne(s), nQuete, lpszChamp, (LPCTSTR)s.Token);
		return FALSE;
	}
	else
	{
		int nDefine = 0;
		if (!CScript::LookupDefine(s.Token, nDefine))
		{
			Error("ZckQuetes.inc(%d) : quete %d, %s : '%s' inconnu (#define absent des fichiers define*.h ?)", ZckQuLigne(s), nQuete, lpszChamp, (LPCTSTR)s.Token);
			return FALSE;
		}
		n = (__int64)nDefine;
	}

	if (bNegatif)
		n = -n;
	if (n < nMin || n > nMax)
	{
		Error("ZckQuetes.inc(%d) : quete %d, %s : %I64d hors bornes (%I64d a %I64d)", ZckQuLigne(s), nQuete, lpszChamp, n, nMin, nMax);
		return FALSE;
	}
	nValeur = n;
	return TRUE;
}

static BOOL ZckQuLireInt(CScript& s, int nMin, int nMax, int& nValeur, LPCTSTR lpszChamp, int nQuete)
{
	__int64 n = 0;
	if (!ZckQuLireEntier(s, nMin, nMax, n, lpszChamp, nQuete))
		return FALSE;
	nValeur = (int)n;
	return TRUE;
}

// Texte entre guillemets, nMax octets au plus, sans guillemet ni retour a la ligne.
static BOOL ZckQuLireTexte(CScript& s, int nMax, CString& str, LPCTSTR lpszChamp, int nQuete)
{
	s.GetToken_NoDef();
	if (s.tok == FINISHED || s.tokenType != STRING)
	{
		Error("ZckQuetes.inc(%d) : quete %d, %s : texte entre guillemets attendu, recu '%s'", ZckQuLigne(s), nQuete, lpszChamp, (LPCTSTR)s.Token);
		return FALSE;
	}
	if (s.Token.GetLength() > nMax)
	{
		Error("ZckQuetes.inc(%d) : quete %d, %s : %d octets au plus (%d recus)", ZckQuLigne(s), nQuete, lpszChamp, nMax, s.Token.GetLength());
		return FALSE;
	}
	str = s.Token;
	return TRUE;
}

// Heure "HH:MM" en minutes depuis minuit ; 24:00 accepte si b24.
static BOOL ZckQuLireHeure(CScript& s, BOOL b24, int& nMinutes, LPCTSTR lpszChamp, int nQuete)
{
	int nHeure = 0;
	int nMinute = 0;
	if (!ZckQuLireInt(s, 0, 24, nHeure, lpszChamp, nQuete))
		return FALSE;
	s.GetToken_NoDef();
	if (s.tok == FINISHED || s.Token != _T(":"))
	{
		Error("ZckQuetes.inc(%d) : quete %d, %s : horaire attendu au format HH:MM, ':' manquant (recu '%s')", ZckQuLigne(s), nQuete, lpszChamp, (LPCTSTR)s.Token);
		return FALSE;
	}
	if (!ZckQuLireInt(s, 0, 59, nMinute, lpszChamp, nQuete))
		return FALSE;
	if (nHeure == 24 && (!b24 || nMinute != 0))
	{
		Error("ZckQuetes.inc(%d) : quete %d, %s : %02d:%02d invalide (24:00 seulement pour HeureFin)", ZckQuLigne(s), nQuete, lpszChamp, nHeure, nMinute);
		return FALSE;
	}
	nMinutes = nHeure * 60 + nMinute;
	return TRUE;
}

static BOOL ZckQuOuvrir(CScript& s, LPCTSTR lpszBloc, int nQuete)
{
	s.GetToken_NoDef();
	if (s.tok == FINISHED || s.Token != _T("{"))
	{
		Error("ZckQuetes.inc(%d) : quete %d, '{' attendu apres %s, recu '%s'", ZckQuLigne(s), nQuete, lpszBloc, (LPCTSTR)s.Token);
		return FALSE;
	}
	return TRUE;
}

// Liste d'identifiants entre accolades : "{ A B C }".
static BOOL ZckQuLireListe(CScript& s, std::vector<DWORD>& vec, int nMax, LPCTSTR lpszBloc, int nQuete)
{
	if (!ZckQuOuvrir(s, lpszBloc, nQuete))
		return FALSE;
	for (;;)
	{
		s.GetToken_NoDef();
		if (s.tok == FINISHED)
		{
			Error("ZckQuetes.inc : quete %d, bloc %s non ferme", nQuete, lpszBloc);
			return FALSE;
		}
		if (s.Token == _T("}"))
			break;
		if ((int)vec.size() >= nMax)
		{
			Error("ZckQuetes.inc(%d) : quete %d, bloc %s limite a %d entrees", ZckQuLigne(s), nQuete, lpszBloc, nMax);
			return FALSE;
		}
		s.PutBack();
		__int64 n = 0;
		if (!ZckQuLireEntier(s, 1, 0xFFFFFFFELL, n, lpszBloc, nQuete))
			return FALSE;
		const DWORD dw = (DWORD)n;
		for (size_t i = 0; i < vec.size(); ++i)
		{
			if (vec[i] == dw)
			{
				Error("ZckQuetes.inc(%d) : quete %d, bloc %s : %u declare deux fois", ZckQuLigne(s), nQuete, lpszBloc, (unsigned int)dw);
				return FALSE;
			}
		}
		vec.push_back(dw);
	}
	return TRUE;
}

BOOL CZckQuestManager::LireReglages(CScript& s, int& nActivesMax)
{
	if (!ZckQuOuvrir(s, _T("Reglages"), 0))
		return FALSE;
	BOOL bActives = FALSE;
	for (;;)
	{
		s.GetToken_NoDef();
		if (s.tok == FINISHED)
		{
			Error("ZckQuetes.inc : bloc Reglages non ferme");
			return FALSE;
		}
		if (s.Token == _T("}"))
			break;
		if (s.Token == _T("QuetesActivesMax"))
		{
			if (bActives)
			{
				Error("ZckQuetes.inc(%d) : Reglages, QuetesActivesMax declare deux fois", ZckQuLigne(s));
				return FALSE;
			}
			if (!ZckQuLireInt(s, 1, ZCK_QUEST_ACTIVES_MAX, nActivesMax, _T("QuetesActivesMax"), 0))
				return FALSE;
			bActives = TRUE;
		}
		else
		{
			Error("ZckQuetes.inc(%d) : Reglages, cle inconnue '%s'", ZckQuLigne(s), (LPCTSTR)s.Token);
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CZckQuestManager::LireRecompenses(CScript& s, ZCK_QUEST_DEFINITION& def)
{
	const int nQuete = def.nId;
	if (!ZckQuOuvrir(s, _T("Recompenses"), nQuete))
		return FALSE;
	BOOL bPenya = FALSE;
	BOOL bExp = FALSE;
	BOOL bExpPourcent = FALSE;
	for (;;)
	{
		s.GetToken_NoDef();
		if (s.tok == FINISHED)
		{
			Error("ZckQuetes.inc : quete %d, bloc Recompenses non ferme", nQuete);
			return FALSE;
		}
		if (s.Token == _T("}"))
			break;

		if (s.Token == _T("Objet"))
		{
			if ((int)def.vecObjets.size() >= ZCK_QUEST_OBJETS_MAX)
			{
				Error("ZckQuetes.inc(%d) : quete %d, %d objets au plus en recompense", ZckQuLigne(s), nQuete, ZCK_QUEST_OBJETS_MAX);
				return FALSE;
			}
			ZCK_QUEST_OBJET objet;
			__int64 nItem = 0;
			int nLie = 0;
			if (!ZckQuLireEntier(s, 1, 0xFFFFFFFELL, nItem, _T("Objet (identifiant)"), nQuete))
				return FALSE;
			if (!ZckQuLireInt(s, 1, ZCK_QUEST_NOMBRE_MAX, objet.nNombre, _T("Objet (quantite)"), nQuete))
				return FALSE;
			if (!ZckQuLireInt(s, 0, 1, nLie, _T("Objet (lie 0 ou 1)"), nQuete))
				return FALSE;
			objet.dwItemId = (DWORD)nItem;
			objet.bLie = (nLie != 0) ? TRUE : FALSE;
			def.vecObjets.push_back(objet);
		}
		else if (s.Token == _T("Buff"))
		{
			if ((int)def.vecBuffs.size() >= ZCK_QUEST_BUFFS_MAX)
			{
				Error("ZckQuetes.inc(%d) : quete %d, %d buffs au plus en recompense", ZckQuLigne(s), nQuete, ZCK_QUEST_BUFFS_MAX);
				return FALSE;
			}
			__int64 nItem = 0;
			if (!ZckQuLireEntier(s, 1, 0xFFFFFFFELL, nItem, _T("Buff"), nQuete))
				return FALSE;
			for (size_t i = 0; i < def.vecBuffs.size(); ++i)
			{
				if (def.vecBuffs[i] == (DWORD)nItem)
				{
					Error("ZckQuetes.inc(%d) : quete %d, Buff %u declare deux fois", ZckQuLigne(s), nQuete, (unsigned int)nItem);
					return FALSE;
				}
			}
			def.vecBuffs.push_back((DWORD)nItem);
		}
		else if (s.Token == _T("Penya"))
		{
			if (bPenya)
			{
				Error("ZckQuetes.inc(%d) : quete %d, Penya declare deux fois", ZckQuLigne(s), nQuete);
				return FALSE;
			}
			if (!ZckQuLireInt(s, 0, INT_MAX, def.nPenya, _T("Penya"), nQuete))
				return FALSE;
			bPenya = TRUE;
		}
		else if (s.Token == _T("Exp"))
		{
			if (bExp)
			{
				Error("ZckQuetes.inc(%d) : quete %d, Exp declare deux fois", ZckQuLigne(s), nQuete);
				return FALSE;
			}
			if (!ZckQuLireEntier(s, 0, ZCK_QUEST_EXP_MAX, def.n64Exp, _T("Exp"), nQuete))
				return FALSE;
			bExp = TRUE;
		}
		else if (s.Token == _T("ExpPourcent"))
		{
			if (bExpPourcent)
			{
				Error("ZckQuetes.inc(%d) : quete %d, ExpPourcent declare deux fois", ZckQuLigne(s), nQuete);
				return FALSE;
			}
			if (!ZckQuLireInt(s, 0, ZCK_QUEST_EXP_POURCENT_MAX, def.nExpPourcent, _T("ExpPourcent"), nQuete))
				return FALSE;
			bExpPourcent = TRUE;
		}
		else
		{
			Error("ZckQuetes.inc(%d) : quete %d, Recompenses : cle inconnue '%s' (Objet, Buff, Penya, Exp, ExpPourcent)", ZckQuLigne(s), nQuete, (LPCTSTR)s.Token);
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CZckQuestManager::LireQuete(CScript& s, ZCK_QUEST_DEFINITION& def)
{
	if (!ZckQuLireInt(s, 1, ZCK_QUEST_ID_MAX, def.nId, _T("identifiant de Quete"), 0))
		return FALSE;
	const int nQuete = def.nId;
	if (!ZckQuOuvrir(s, _T("Quete"), nQuete))
		return FALSE;

	// Valeurs par defaut des cles facultatives ; -1 : cle obligatoire non lue.
	def.byJours = ZCK_QUEST_JOURS_TOUS;
	def.nDuree = 0;
	def.nNiveauMin = 1;
#ifdef __ZCK_4_CLASSES
	def.nNiveauMax = MAX_4TH_JOBS_LEVEL;
#else
	def.nNiveauMax = MAX_3RD_LEGEND_LEVEL;
#endif // __ZCK_4_CLASSES
	def.nPrestigeMin = 0;
#ifdef __ZCK_PRESTIGE
	def.nPrestigeMax = ZCK_PRESTIGE_STORAGE_MAX;
#else
	def.nPrestigeMax = 0;
#endif // __ZCK_PRESTIGE
	def.nObjectif = -1;
	def.bGroupe = FALSE;
	def.strCategorie = _T("Chasse");

	// Une seule declaration par cle : un doublon est presque toujours une erreur de copie.
	std::vector<CString> vecVues;
	for (;;)
	{
		s.GetToken_NoDef();
		if (s.tok == FINISHED)
		{
			Error("ZckQuetes.inc : quete %d non fermee ('}' manquant)", nQuete);
			return FALSE;
		}
		if (s.Token == _T("}"))
			break;

		const CString strCle = s.Token;
		// Monde se repete (une ligne par monde) ; toute autre cle une seule fois.
		if (strCle != _T("Monde"))
		{
			for (size_t i = 0; i < vecVues.size(); ++i)
			{
				if (vecVues[i] == strCle)
				{
					Error("ZckQuetes.inc(%d) : quete %d, %s declare deux fois", ZckQuLigne(s), nQuete, (LPCTSTR)strCle);
					return FALSE;
				}
			}
			vecVues.push_back(strCle);
		}

		if (strCle == _T("Nom"))
		{
			if (!ZckQuLireTexte(s, ZCK_QUEST_NOM_MAX, def.strNom, _T("Nom"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("Description"))
		{
			if (!ZckQuLireTexte(s, ZCK_QUEST_TEXTE_MAX, def.strDescription, _T("Description"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("Categorie"))
		{
			if (!ZckQuLireTexte(s, ZCK_QUEST_CATEGORIE_MAX, def.strCategorie, _T("Categorie"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("Lieu"))
		{
			if (!ZckQuLireTexte(s, ZCK_QUEST_LIEU_MAX, def.strLieu, _T("Lieu"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("Monde"))
		{
			if ((int)def.vecMondes.size() >= ZCK_QUEST_MONDES_MAX)
			{
				Error("ZckQuetes.inc(%d) : quete %d, %d lignes Monde au plus", ZckQuLigne(s), nQuete, ZCK_QUEST_MONDES_MAX);
				return FALSE;
			}
			__int64 nMonde = 0;
			if (!ZckQuLireEntier(s, 1, 0xFFFFFFFELL, nMonde, _T("Monde"), nQuete))
				return FALSE;
			for (size_t i = 0; i < def.vecMondes.size(); ++i)
			{
				if (def.vecMondes[i] == (DWORD)nMonde)
				{
					Error("ZckQuetes.inc(%d) : quete %d, Monde %u declare deux fois", ZckQuLigne(s), nQuete, (unsigned int)nMonde);
					return FALSE;
				}
			}
			def.vecMondes.push_back((DWORD)nMonde);
		}
		else if (strCle == _T("HeureDebut"))
		{
			if (!ZckQuLireHeure(s, FALSE, def.nDebut, _T("HeureDebut"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("HeureFin"))
		{
			if (!ZckQuLireHeure(s, TRUE, def.nFin, _T("HeureFin"), nQuete))
				return FALSE;
			// 00:00 en fin = minuit, comme 24:00.
			if (def.nFin == 0)
				def.nFin = 1440;
		}
		else if (strCle == _T("Jours"))
		{
			std::vector<DWORD> vecJours;
			if (!ZckQuLireListe(s, vecJours, 7, _T("Jours"), nQuete))
				return FALSE;
			if (vecJours.empty())
			{
				Error("ZckQuetes.inc(%d) : quete %d, Jours vide (retirer la cle pour tous les jours)", ZckQuLigne(s), nQuete);
				return FALSE;
			}
			def.byJours = 0;
			for (size_t i = 0; i < vecJours.size(); ++i)
			{
				if (vecJours[i] < 1 || vecJours[i] > 7)
				{
					Error("ZckQuetes.inc(%d) : quete %d, Jours : %u invalide, attendu 1 (dimanche) a 7 (samedi)", ZckQuLigne(s), nQuete, (unsigned int)vecJours[i]);
					return FALSE;
				}
				def.byJours |= (BYTE)(1 << (vecJours[i] - 1));
			}
		}
		else if (strCle == _T("Duree"))
		{
			if (!ZckQuLireInt(s, 0, ZCK_QUEST_DUREE_MAX, def.nDuree, _T("Duree"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("NiveauMin"))
		{
			if (!ZckQuLireInt(s, 1, 1000, def.nNiveauMin, _T("NiveauMin"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("NiveauMax"))
		{
			if (!ZckQuLireInt(s, 1, 1000, def.nNiveauMax, _T("NiveauMax"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("PrestigeMin"))
		{
			if (!ZckQuLireInt(s, 0, 1000, def.nPrestigeMin, _T("PrestigeMin"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("PrestigeMax"))
		{
			if (!ZckQuLireInt(s, 0, 1000, def.nPrestigeMax, _T("PrestigeMax"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("Objectif"))
		{
			if (!ZckQuLireInt(s, 1, ZCK_QUEST_OBJECTIF_MAX, def.nObjectif, _T("Objectif"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("Groupe"))
		{
			int nGroupe = 0;
			if (!ZckQuLireInt(s, 0, 1, nGroupe, _T("Groupe (0 ou 1)"), nQuete))
				return FALSE;
			def.bGroupe = (nGroupe != 0) ? TRUE : FALSE;
		}
		else if (strCle == _T("Monstres"))
		{
			if (!ZckQuLireListe(s, def.vecMonstres, ZCK_QUEST_MONSTRES_MAX, _T("Monstres"), nQuete))
				return FALSE;
		}
		else if (strCle == _T("Recompenses"))
		{
			if (!LireRecompenses(s, def))
				return FALSE;
		}
		else
		{
			Error("ZckQuetes.inc(%d) : quete %d, cle inconnue '%s'", ZckQuLigne(s), nQuete, (LPCTSTR)strCle);
			return FALSE;
		}
	}
	return TRUE;
}

static int ZckQuTailleTas(const ItemProp* pItemProp)
{
	if (!pItemProp)
		return 0;
	DWORD dwPackMax = pItemProp->dwPackMax;
	if (dwPackMax == 0)
		dwPackMax = 1;
	if (dwPackMax > SHRT_MAX)
		dwPackMax = SHRT_MAX;
	return (int)dwPackMax;
}

// Categories de buffs exclusives : un seul actif a la fois (meme liste que
// CMover::IsDoUseBuff, MoverSkill.cpp). Deux buffs de la meme categorie dans une
// recompense passeraient chacun le controle d'avant la remise et seraient poses
// ensemble : refuse au chargement.
static BOOL ZckQuIk3Exclusif(DWORD dwItemKind3)
{
	switch (dwItemKind3)
	{
	case IK3_POTION_BUFF_STR:
	case IK3_POTION_BUFF_DEX:
	case IK3_POTION_BUFF_INT:
	case IK3_POTION_BUFF_STA:
	case IK3_POTION_BUFF_DEFENSE:
	case IK3_ANGEL_BUFF:
	case IK3_DEFENSE_SCROLL:
	case IK3_BATTERY:
	case IK3_PARTY_EXP_BOOST:
	case IK3_PARTY_SKILL_BOOST:
	case IK3_FLOWERPOT:
	case IK3_POWERSCROLL:
#ifdef __FL_CATCH_THE_PET
	case IK3_CATCHED_PET_EXP_BOOST:
#endif // __FL_CATCH_THE_PET
#ifdef __FL_BATTLE_PASS
	case IK3_BATTLEPASS:
#endif // __FL_BATTLE_PASS
		return TRUE;
	default:
		break;
	}
	return FALSE;
}

// Regles qui demandent toute la quete lue (et les tables propItem, propMover, World.inc).
BOOL CZckQuestManager::ValiderQuete(const ZCK_QUEST_DEFINITION& def) const
{
	const int nQuete = def.nId;

	if (def.strNom.IsEmpty())
	{
		Error("ZckQuetes.inc : quete %d sans Nom", nQuete);
		return FALSE;
	}
	if (def.nDebut < 0 || def.nFin < 0)
	{
		Error("ZckQuetes.inc : quete %d : HeureDebut et HeureFin sont obligatoires", nQuete);
		return FALSE;
	}
	if (def.nDebut == def.nFin)
	{
		Error("ZckQuetes.inc : quete %d : HeureDebut et HeureFin identiques (00:00 a 24:00 pour toute la journee)", nQuete);
		return FALSE;
	}
	if (def.nObjectif <= 0)
	{
		Error("ZckQuetes.inc : quete %d sans Objectif", nQuete);
		return FALSE;
	}

#ifdef __ZCK_4_CLASSES
	const int nNiveauJeu = MAX_4TH_JOBS_LEVEL;
#else
	const int nNiveauJeu = MAX_3RD_LEGEND_LEVEL;
#endif // __ZCK_4_CLASSES
	if (def.nNiveauMin < 1 || def.nNiveauMax > nNiveauJeu || def.nNiveauMin > def.nNiveauMax)
	{
		Error("ZckQuetes.inc : quete %d : NiveauMin %d / NiveauMax %d invalides (1 a %d, min <= max)", nQuete, def.nNiveauMin, def.nNiveauMax, nNiveauJeu);
		return FALSE;
	}
#ifdef __ZCK_PRESTIGE
	const int nPrestigeJeu = ZCK_PRESTIGE_STORAGE_MAX;
#else
	const int nPrestigeJeu = 0;
#endif // __ZCK_PRESTIGE
	if (def.nPrestigeMin < 0 || def.nPrestigeMax > nPrestigeJeu || def.nPrestigeMin > def.nPrestigeMax)
	{
		Error("ZckQuetes.inc : quete %d : PrestigeMin %d / PrestigeMax %d invalides (0 a %d, min <= max)", nQuete, def.nPrestigeMin, def.nPrestigeMax, nPrestigeJeu);
		return FALSE;
	}

	for (size_t i = 0; i < def.vecMondes.size(); ++i)
	{
		LPWORLD lpWorld = g_WorldMng.GetWorldStruct((OBJID)def.vecMondes[i]);
		if (lpWorld == NULL || !lpWorld->IsValid())
		{
			Error("ZckQuetes.inc : quete %d : Monde %u absent de World.inc (identifiant WI_* inconnu ?)", nQuete, (unsigned int)def.vecMondes[i]);
			return FALSE;
		}
	}

	if (def.vecMonstres.empty())
	{
		Error("ZckQuetes.inc : quete %d sans Monstres", nQuete);
		return FALSE;
	}
	for (size_t i = 0; i < def.vecMonstres.size(); ++i)
	{
		// CProject::GetMoverProp rend une entree vide (dwID 0) pour un numero sans
		// ligne dans propMover : l'identifiant doit etre celui de l'entree.
		MoverProp* pMoverProp = prj.GetMoverProp(def.vecMonstres[i]);
		if (pMoverProp == NULL || pMoverProp->dwID != def.vecMonstres[i])
		{
			Error("ZckQuetes.inc : quete %d : monstre %u absent de propMover (identifiant MI_* inconnu ?)", nQuete, (unsigned int)def.vecMonstres[i]);
			return FALSE;
		}
	}

	int nTas = 0;
	for (size_t i = 0; i < def.vecObjets.size(); ++i)
	{
		const ZCK_QUEST_OBJET& objet = def.vecObjets[i];
		ItemProp* pItemProp = prj.GetItemProp(objet.dwItemId);
		if (pItemProp == NULL || pItemProp->dwID != objet.dwItemId)
		{
			Error("ZckQuetes.inc : quete %d : objet %u absent de propItem (identifiant II_* inconnu ?)", nQuete, (unsigned int)objet.dwItemId);
			return FALSE;
		}
		const int nTaille = ZckQuTailleTas(pItemProp);
		if (nTaille <= 0)
			return FALSE;
		nTas += (objet.nNombre + nTaille - 1) / nTaille;
		if (nTas > ZCK_QUEST_TAS_MAX)
		{
			Error("ZckQuetes.inc : quete %d : objets en recompense sur plus de %d tas d'inventaire", nQuete, ZCK_QUEST_TAS_MAX);
			return FALSE;
		}
	}

	for (size_t i = 0; i < def.vecBuffs.size(); ++i)
	{
		ItemProp* pItemProp = prj.GetItemProp(def.vecBuffs[i]);
		if (pItemProp == NULL || pItemProp->dwID != def.vecBuffs[i])
		{
			Error("ZckQuetes.inc : quete %d : Buff %u absent de propItem (identifiant II_* inconnu ?)", nQuete, (unsigned int)def.vecBuffs[i]);
			return FALSE;
		}
		// Meme pose que CMover::DoUseItem, case IK2_BUFF (MoverSkill.cpp) : DoApplySkill.
		BOOL bBuff = (pItemProp->dwItemKind2 == IK2_BUFF) ? TRUE : FALSE;
#ifdef __BUFF_TOGIFT
		if (pItemProp->dwItemKind2 == IK2_BUFF_TOGIFT)
			bBuff = TRUE;
#endif // __BUFF_TOGIFT
		if (!bBuff)
		{
			Error("ZckQuetes.inc : quete %d : Buff %s doit etre un objet IK2_BUFF (power-up utilisable) dans propItem", nQuete, pItemProp->szName);
			return FALSE;
		}
		if (pItemProp->dwItemKind3 == IK3_ANGEL_BUFF)
		{
			Error("ZckQuetes.inc : quete %d : Buff %s : IK3_ANGEL_BUFF refuse (regles d'ange propres)", nQuete, pItemProp->szName);
			return FALSE;
		}
		if (pItemProp->dwSkillTime == NULL_ID || pItemProp->dwSkillTime == 0)
		{
			Error("ZckQuetes.inc : quete %d : Buff %s : dwSkillTime doit etre numerique et non nul dans propItem", nQuete, pItemProp->szName);
			return FALSE;
		}
		// IBuffItemBase::Release (buff.cpp) execute szTextFileName comme une commande au retrait du buff.
		if (pItemProp->szTextFileName[0] != '\0')
		{
			Error("ZckQuetes.inc : quete %d : Buff %s : szTextFileName doit etre vide dans propItem", nQuete, pItemProp->szName);
			return FALSE;
		}
		if (ZckQuIk3Exclusif(pItemProp->dwItemKind3))
		{
			for (size_t k = 0; k < i; ++k)
			{
				ItemProp* pAutre = prj.GetItemProp(def.vecBuffs[k]);
				if (pAutre && pAutre->dwItemKind3 == pItemProp->dwItemKind3)
				{
					Error("ZckQuetes.inc : quete %d : Buff %s et Buff %s : meme categorie exclusive (IK3 %u), un seul actif a la fois",
						nQuete, pAutre->szName, pItemProp->szName, (unsigned int)pItemProp->dwItemKind3);
					return FALSE;
				}
			}
		}
	}

	if (def.vecObjets.empty() && def.vecBuffs.empty() && def.nPenya <= 0 && def.n64Exp <= 0 && def.nExpPourcent <= 0)
		Error("ZckQuetes.inc : quete %d sans recompense (acceptee, mais rien n'est donne)", nQuete);

	return TRUE;
}

static DWORD ZckQuFnv(DWORD dwHash, const void* pDonnees, size_t nTaille)
{
	const BYTE* p = (const BYTE*)pDonnees;
	for (size_t i = 0; i < nTaille; ++i)
	{
		dwHash ^= p[i];
		dwHash *= 16777619u;
	}
	return dwHash;
}

static DWORD ZckQuFnvTexte(DWORD dwHash, const CString& str)
{
	const int nLongueur = str.GetLength();
	dwHash = ZckQuFnv(dwHash, &nLongueur, sizeof(nLongueur));
	return ZckQuFnv(dwHash, (LPCTSTR)str, (size_t)nLongueur);
}

// Empreinte du catalogue : le client la renvoie avec chaque action, une
// difference fait renvoyer le catalogue. Jamais 0 (0 : aucun catalogue).
DWORD CZckQuestManager::CalculerVersion(const std::map<int, ZCK_QUEST_DEFINITION>& mapDefinitions, int nActivesMax)
{
	DWORD dwHash = 2166136261u;
	dwHash = ZckQuFnv(dwHash, &nActivesMax, sizeof(nActivesMax));
	for (std::map<int, ZCK_QUEST_DEFINITION>::const_iterator it = mapDefinitions.begin(); it != mapDefinitions.end(); ++it)
	{
		const ZCK_QUEST_DEFINITION& def = it->second;
		dwHash = ZckQuFnv(dwHash, &def.nId, sizeof(def.nId));
		dwHash = ZckQuFnvTexte(dwHash, def.strNom);
		dwHash = ZckQuFnvTexte(dwHash, def.strDescription);
		dwHash = ZckQuFnvTexte(dwHash, def.strCategorie);
		dwHash = ZckQuFnvTexte(dwHash, def.strLieu);
		const int anValeurs[] = { def.nDebut, def.nFin, (int)def.byJours, def.nDuree, def.nNiveauMin, def.nNiveauMax,
			def.nPrestigeMin, def.nPrestigeMax, def.nObjectif, def.bGroupe ? 1 : 0, def.nPenya, def.nExpPourcent };
		dwHash = ZckQuFnv(dwHash, anValeurs, sizeof(anValeurs));
		dwHash = ZckQuFnv(dwHash, &def.n64Exp, sizeof(def.n64Exp));
		for (size_t i = 0; i < def.vecMondes.size(); ++i)
			dwHash = ZckQuFnv(dwHash, &def.vecMondes[i], sizeof(DWORD));
		for (size_t i = 0; i < def.vecMonstres.size(); ++i)
			dwHash = ZckQuFnv(dwHash, &def.vecMonstres[i], sizeof(DWORD));
		for (size_t i = 0; i < def.vecObjets.size(); ++i)
		{
			const int anObjet[] = { (int)def.vecObjets[i].dwItemId, def.vecObjets[i].nNombre, def.vecObjets[i].bLie ? 1 : 0 };
			dwHash = ZckQuFnv(dwHash, anObjet, sizeof(anObjet));
		}
		for (size_t i = 0; i < def.vecBuffs.size(); ++i)
			dwHash = ZckQuFnv(dwHash, &def.vecBuffs[i], sizeof(DWORD));
	}
	return (dwHash != 0) ? dwHash : 1;
}

BOOL CZckQuestManager::Charger(LPCTSTR lpszFichier)
{
	CScript s;
	if (!s.Load(lpszFichier))
	{
		Error("ZckQuetes.inc : %s introuvable ou illisible (dossier Resource du WorldServer) : %s", lpszFichier,
			m_bActif ? "quetes precedentes gardees" : "quetes inactives");
		return FALSE;
	}

	std::map<int, ZCK_QUEST_DEFINITION> mapDefinitions;
	int nActivesMax = ZCK_QUEST_ACTIVES_DEFAUT;
	BOOL bReglages = FALSE;

	s.GetToken_NoDef();
	while (s.tok != FINISHED)
	{
		if (s.Token == _T("Reglages"))
		{
			if (bReglages)
			{
				Error("ZckQuetes.inc(%d) : bloc Reglages declare deux fois", ZckQuLigne(s));
				return FALSE;
			}
			if (!LireReglages(s, nActivesMax))
				return FALSE;
			bReglages = TRUE;
		}
		else if (s.Token == _T("Quete"))
		{
			if ((int)mapDefinitions.size() >= ZCK_QUEST_MAX)
			{
				Error("ZckQuetes.inc(%d) : %d quetes au plus", ZckQuLigne(s), ZCK_QUEST_MAX);
				return FALSE;
			}
			ZCK_QUEST_DEFINITION def;
			if (!LireQuete(s, def) || !ValiderQuete(def))
				return FALSE;
			if (mapDefinitions.find(def.nId) != mapDefinitions.end())
			{
				Error("ZckQuetes.inc : identifiant de quete %d declare deux fois", def.nId);
				return FALSE;
			}
			mapDefinitions.insert(std::make_pair(def.nId, def));
		}
		else
		{
			Error("ZckQuetes.inc(%d) : 'Reglages' ou 'Quete' attendu, recu '%s'", ZckQuLigne(s), (LPCTSTR)s.Token);
			return FALSE;
		}
		s.GetToken_NoDef();
	}

	if (mapDefinitions.empty())
	{
		Error("ZckQuetes.inc : aucune quete declaree : %s", m_bActif ? "quetes precedentes gardees" : "quetes inactives");
		return FALSE;
	}

	std::map<DWORD, std::vector<int> > mapMonstres;
	for (std::map<int, ZCK_QUEST_DEFINITION>::const_iterator it = mapDefinitions.begin(); it != mapDefinitions.end(); ++it)
	{
		for (size_t i = 0; i < it->second.vecMonstres.size(); ++i)
			mapMonstres[it->second.vecMonstres[i]].push_back(it->first);
	}

	m_mapDefinitions.swap(mapDefinitions);
	m_mapMonstres.swap(mapMonstres);
	m_nActivesMax = nActivesMax;
	m_dwVersion = CalculerVersion(m_mapDefinitions, m_nActivesMax);
	m_bActif = TRUE;

	WriteLog("ZckQuest : %s charge, %u quete(s), %d en cours au plus par personnage, version %08X",
		lpszFichier, (unsigned int)m_mapDefinitions.size(), m_nActivesMax, (unsigned int)m_dwVersion);
	return TRUE;
}

//////////////////////////////////////////////////////////////////////
// WorldServer : jeu
//////////////////////////////////////////////////////////////////////

// Secondes locales (heure murale du WorldServer) depuis 1970.
__int64 CZckQuestManager::Horloge()
{
	const time_t t = time(NULL);
	struct tm tmLocal;
	if (localtime_s(&tmLocal, &t) != 0)
		return (__int64)t;
	const __int64 n64Local = (__int64)_mkgmtime(&tmLocal);
	return (n64Local > 0) ? n64Local : (__int64)t;
}

static int ZckQuPrestige(CUser* pUser)
{
#ifdef __ZCK_PRESTIGE
	return (int)pUser->GetZckPrestige();
#else
	return 0;
#endif // __ZCK_PRESTIGE
}

void CZckQuestManager::EcrireEntree(CAr& ar, int nId, const ZCK_QUEST_ENTREE& entree) const
{
	ar << nId;
	ar << entree.byEtat;
	ar << entree.nCycle;
	ar << entree.n64Echeance;
	ar << entree.nProgression;
}

void CZckQuestManager::EnvoyerCatalogue(CUser* pUser)
{
	if (!IsValidObj(pUser) || pUser->IsDelete())
		return;
	pUser->m_Snapshot.cb++;
	pUser->m_Snapshot.ar << NULL_ID;
	pUser->m_Snapshot.ar << SNAPSHOTTYPE_ZCK_QUEST;
	pUser->m_Snapshot.ar << (BYTE)ZCK_QUEST_GENRE_CATALOGUE;
	EcrireCatalogue(pUser->m_Snapshot.ar);
}

// Etat complet : version du catalogue, heure du serveur, colonne chargee, entrees.
void CZckQuestManager::EnvoyerEtat(CUser* pUser)
{
	if (!IsValidObj(pUser) || pUser->IsDelete())
		return;
	const std::map<int, ZCK_QUEST_ENTREE>& entrees = pUser->m_ZckQuest.GetEntrees();
	pUser->m_Snapshot.cb++;
	pUser->m_Snapshot.ar << NULL_ID;
	pUser->m_Snapshot.ar << SNAPSHOTTYPE_ZCK_QUEST;
	pUser->m_Snapshot.ar << (BYTE)ZCK_QUEST_GENRE_ETAT;
	pUser->m_Snapshot.ar << m_dwVersion;
	pUser->m_Snapshot.ar << Horloge();
	pUser->m_Snapshot.ar << (BYTE)(pUser->m_ZckQuest.IsBaseOk() ? 1 : 0);
	pUser->m_Snapshot.ar << (DWORD)entrees.size();
	for (std::map<int, ZCK_QUEST_ENTREE>::const_iterator it = entrees.begin(); it != entrees.end(); ++it)
		EcrireEntree(pUser->m_Snapshot.ar, it->first, it->second);
	pUser->m_Snapshot.ar << (DWORD)ZCK_QUEST_FIN;
}

// Une quete : taille fixe (entree vide si la quete n'est plus suivie).
void CZckQuestManager::EnvoyerMaj(CUser* pUser, int nId)
{
	if (!IsValidObj(pUser) || pUser->IsDelete())
		return;
	const ZCK_QUEST_ENTREE* pEntree = pUser->m_ZckQuest.Find(nId);
	const ZCK_QUEST_ENTREE vide;
	pUser->m_Snapshot.cb++;
	pUser->m_Snapshot.ar << NULL_ID;
	pUser->m_Snapshot.ar << SNAPSHOTTYPE_ZCK_QUEST;
	pUser->m_Snapshot.ar << (BYTE)ZCK_QUEST_GENRE_MAJ;
	pUser->m_Snapshot.ar << Horloge();
	pUser->m_Snapshot.ar << (BYTE)(pEntree ? 1 : 0);
	EcrireEntree(pUser->m_Snapshot.ar, nId, pEntree ? *pEntree : vide);
	pUser->m_Snapshot.ar << (DWORD)ZCK_QUEST_FIN;
}

void CZckQuestManager::EnvoyerReponse(CUser* pUser, BYTE byAction, BYTE byCode, int nId)
{
	if (!IsValidObj(pUser) || pUser->IsDelete())
		return;
	pUser->m_Snapshot.cb++;
	pUser->m_Snapshot.ar << NULL_ID;
	pUser->m_Snapshot.ar << SNAPSHOTTYPE_ZCK_QUEST;
	pUser->m_Snapshot.ar << (BYTE)ZCK_QUEST_GENRE_REPONSE;
	pUser->m_Snapshot.ar << byAction;
	pUser->m_Snapshot.ar << byCode;
	pUser->m_Snapshot.ar << nId;
	pUser->m_Snapshot.ar << (DWORD)ZCK_QUEST_FIN;
}

// Un monstre tue (CMover::DoDie) : chaque quete qui le compte avance d'un.
void CZckQuestManager::OnMonsterKilled(CUser* pTueur, CMover* pMonstre)
{
	if (!m_bActif || !IsValidObj(pTueur) || pMonstre == NULL)
		return;
	MoverProp* pMoverProp = pMonstre->GetProp();
	if (pMoverProp == NULL)
		return;
	std::map<DWORD, std::vector<int> >::const_iterator it = m_mapMonstres.find(pMoverProp->dwID);
	if (it == m_mapMonstres.end())
		return;

	const __int64 n64Maintenant = Horloge();
	for (size_t i = 0; i < it->second.size(); ++i)
	{
		const ZCK_QUEST_DEFINITION* pDef = GetDefinition(it->second[i]);
		if (pDef == NULL)
			continue;

		CParty* pParty = pDef->bGroupe ? g_PartyMng.GetParty(pTueur->m_idparty) : NULL;
		if (pParty == NULL || !pParty->IsMember(pTueur->m_idPlayer))
		{
			Crediter(pTueur, *pDef, n64Maintenant);
			continue;
		}

		// Groupe 1 : le tueur et chaque membre proche du monstre, comme les
		// quetes de groupe d'origine (m_nBeginCondParty == 2, IsValidArea 64 m).
		for (int k = 0; k < pParty->GetSizeofMember(); ++k)
		{
			CMover* pMembre = prj.GetUserByID(pParty->GetPlayerId(k));
			if (!IsValidObj(pMembre) || !pMembre->IsPlayer())
				continue;
			if (pMembre != pTueur && !pMonstre->IsValidArea(pMembre, ZCK_QUEST_PORTEE_GROUPE))
				continue;
			Crediter((CUser*)pMembre, *pDef, n64Maintenant);
		}
	}
}

void CZckQuestManager::Crediter(CUser* pUser, const ZCK_QUEST_DEFINITION& def, __int64 n64Maintenant)
{
	if (!IsValidObj(pUser) || !pUser->m_ZckQuest.IsBaseOk())
		return;
	ZCK_QUEST_ENTREE* pEntree = pUser->m_ZckQuest.Find(def.nId);
	if (pEntree == NULL || pEntree->byEtat != ZCK_QUEST_ETAT_EN_COURS || n64Maintenant >= pEntree->n64Echeance)
		return;
	CWorld* pWorld = pUser->GetWorld();
	if (pWorld == NULL || !MondeValide(def, pWorld->GetID()))
		return;

	if (pEntree->nProgression < def.nObjectif)
		++pEntree->nProgression;
	if (pEntree->nProgression >= def.nObjectif)
	{
		pEntree->nProgression = def.nObjectif;
		pEntree->byEtat = ZCK_QUEST_ETAT_TERMINEE;
		CString str;
		str.Format("Qu\352te termin\351e : %s. R\351cup\351rez la r\351compense dans le journal des qu\352tes.", (LPCTSTR)def.strNom);
		pUser->AddText(str, 0xffffd040);
	}
	EnvoyerMaj(pUser, def.nId);
}

// Les objets tiennent-ils tous dans l'inventaire ? Simulation sur une copie,
// avec les memes tas que la remise (CZckAchievementManager::CanReceiveItemRewards).
BOOL CZckQuestManager::PeutRecevoirObjets(CUser* pUser, const ZCK_QUEST_DEFINITION& def) const
{
	if (def.vecObjets.empty())
		return TRUE;

	CItemContainer<CItemElem> inventaire;
	inventaire.SetItemContainer(ITYPE_ITEM, MAX_INVENTORY, MAX_HUMAN_PARTS);
	inventaire.Copy(pUser->m_Inventory);

	for (size_t i = 0; i < def.vecObjets.size(); ++i)
	{
		const ZCK_QUEST_OBJET& objet = def.vecObjets[i];
		ItemProp* pItemProp = prj.GetItemProp(objet.dwItemId);
		const int nTaille = ZckQuTailleTas(pItemProp);
		if (pItemProp == NULL || nTaille <= 0)
			return FALSE;

		int nReste = objet.nNombre;
		while (nReste > 0)
		{
			const int nTas = (nReste < nTaille) ? nReste : nTaille;
			CItemElem itemElem;
			itemElem.m_dwItemId = objet.dwItemId;
			itemElem.m_nItemNum = nTas;
			if (objet.bLie)
				itemElem.SetFlag(CItemElem::binds);
			itemElem.SetSerialNumber();
			if (!inventaire.Add(&itemElem))
				return FALSE;
			nReste -= nTas;
		}
	}
	return TRUE;
}

BYTE CZckQuestManager::Accepter(CUser* pUser, const ZCK_QUEST_DEFINITION& def, __int64 n64Maintenant)
{
#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
		return ZCK_QUEST_REFUS_MODE_EGALISE;
#endif // __FL_EQUALIZED_MODE

	CZckQuestState& state = pUser->m_ZckQuest;
	ZCK_QUEST_ENTREE* pEntree = state.Find(def.nId);
	const int nNiveau = (int)pUser->GetLevel();
	const int nPrestige = ZckQuPrestige(pUser);

	switch (CalculerStatut(def, pEntree, n64Maintenant, nNiveau, nPrestige))
	{
	case ZCK_QUEST_STATUT_TERMINEE:		return ZCK_QUEST_REFUS_A_RECUPERER;
	case ZCK_QUEST_STATUT_EN_COURS:		return ZCK_QUEST_REFUS_DEJA;
	case ZCK_QUEST_STATUT_ACCOMPLIE:	return ZCK_QUEST_REFUS_DEJA;
	case ZCK_QUEST_STATUT_FERMEE:		return ZCK_QUEST_REFUS_FERMEE;
	default:							break;	// disponible, verrouillee ou echouee : controles ci-dessous
	}

	ZCK_QUEST_FENETRE fen;
	CalculerFenetre(def, n64Maintenant, fen);
	if (!fen.bOuverte || n64Maintenant >= fen.n64Fin)
		return ZCK_QUEST_REFUS_FERMEE;
	if (nNiveau < def.nNiveauMin || nNiveau > def.nNiveauMax)
		return ZCK_QUEST_REFUS_NIVEAU;
	if (nPrestige < def.nPrestigeMin || nPrestige > def.nPrestigeMax)
		return ZCK_QUEST_REFUS_PRESTIGE;
	if (CompterActives(state, n64Maintenant) >= m_nActivesMax)
		return ZCK_QUEST_REFUS_ACTIVES;

	if (pEntree == NULL)
	{
		pEntree = state.GetOrCreate(def.nId);
		if (pEntree == NULL)
			return ZCK_QUEST_REFUS_ACTIVES;
	}

	// Echeance : Duree minutes, jamais apres la fin de l'ouverture.
	__int64 n64Echeance = fen.n64Fin;
	if (def.nDuree > 0 && n64Maintenant + (__int64)def.nDuree * 60 < n64Echeance)
		n64Echeance = n64Maintenant + (__int64)def.nDuree * 60;

	pEntree->byEtat = ZCK_QUEST_ETAT_EN_COURS;
	pEntree->nCycle = fen.nCycle;
	pEntree->n64Echeance = n64Echeance;
	pEntree->nProgression = 0;

	CString str;
	str.Format("Qu\352te accept\351e : %s (%d monstre%s).", (LPCTSTR)def.strNom, def.nObjectif, (def.nObjectif > 1) ? "s" : "");
	pUser->AddText(str, 0xff80e080);
	return ZCK_QUEST_OK;
}

BYTE CZckQuestManager::Abandonner(CUser* pUser, const ZCK_QUEST_DEFINITION& def, __int64 /*n64Maintenant*/)
{
	ZCK_QUEST_ENTREE* pEntree = pUser->m_ZckQuest.Find(def.nId);
	if (pEntree == NULL || pEntree->byEtat != ZCK_QUEST_ETAT_EN_COURS)
		return ZCK_QUEST_REFUS_PAS_ACTIVE;

	pUser->m_ZckQuest.Remove(def.nId);

	CString str;
	str.Format("Qu\352te abandonn\351e : %s.", (LPCTSTR)def.strNom);
	pUser->AddText(str, 0xffffa040);
	return ZCK_QUEST_OK;
}

BYTE CZckQuestManager::Recuperer(CUser* pUser, const ZCK_QUEST_DEFINITION& def, __int64 /*n64Maintenant*/)
{
#ifdef __FL_EQUALIZED_MODE
	if (pUser->bTmpMode)
		return ZCK_QUEST_REFUS_MODE_EGALISE;
#endif // __FL_EQUALIZED_MODE
	if (pUser->IsDie())
		return ZCK_QUEST_REFUS_MORT;
	// Memes interdits que CMover::DoUseItem (les buffs sont poses comme si
	// l'objet etait utilise) : echange, boutique, petrification, minijeu PvP.
	if (!pUser->IsPossibleUseItem())
		return ZCK_QUEST_REFUS_OCCUPE;
#ifdef __ZCK_MINIJEU_PVP
	if (CZckPvPMinigamesMng::GetInstance()->IsPlaying(pUser->m_idPlayer))
		return ZCK_QUEST_REFUS_OCCUPE;
#endif // __ZCK_MINIJEU_PVP

	ZCK_QUEST_ENTREE* pEntree = pUser->m_ZckQuest.Find(def.nId);
	if (pEntree == NULL || pEntree->byEtat != ZCK_QUEST_ETAT_TERMINEE)
		return ZCK_QUEST_REFUS_PAS_TERMINEE;

	// Controles AVANT toute remise : Penya, place, buffs.
	if (def.nPenya > 0 && (__int64)pUser->GetGold() + (__int64)def.nPenya > (__int64)INT_MAX)
		return ZCK_QUEST_REFUS_PENYA;
	if (!PeutRecevoirObjets(pUser, def))
		return ZCK_QUEST_REFUS_INVENTAIRE;
	for (size_t i = 0; i < def.vecBuffs.size(); ++i)
	{
		ItemProp* pItemProp = prj.GetItemProp(def.vecBuffs[i]);
		if (pItemProp == NULL || pUser->IsDoUseBuff(pItemProp) != 0)
			return ZCK_QUEST_REFUS_BUFF;
#ifdef __FL_STACKABLE_POWERUPS
		// Meme controle que CMover::DoUseItem, case IK2_BUFF.
		const DWORD dwCurr = g_tmCurrent;
		IBuff* pBuff = pUser->m_buffs.GetBuff(BUFF_ITEM, (WORD)(pItemProp->dwID));
		if (pBuff)
		{
			if (!pBuff->IsRemovable(pUser) || (static_cast<int>(pItemProp->dwSkillTime) > static_cast<int>(pItemProp->dwSkillTime + (pBuff->GetTotal() - (dwCurr - pBuff->GetInst())))))
				return ZCK_QUEST_REFUS_BUFF;
		}
#endif // __FL_STACKABLE_POWERUPS
	}

	// Point de non-retour : la quete est marquee recompensee AVANT la remise,
	// si bien qu'aucun chemin ne permet de la recuperer deux fois. La place
	// ayant ete verifiee, un echec de remise n'arrive pas ; il serait journalise.
	pEntree->byEtat = ZCK_QUEST_ETAT_RECOMPENSEE;

	for (size_t i = 0; i < def.vecObjets.size(); ++i)
	{
		const ZCK_QUEST_OBJET& objet = def.vecObjets[i];
		ItemProp* pItemProp = prj.GetItemProp(objet.dwItemId);
		const int nTaille = ZckQuTailleTas(pItemProp);
		if (pItemProp == NULL || nTaille <= 0)
			continue;

		int nReste = objet.nNombre;
		while (nReste > 0)
		{
			const int nTas = (nReste < nTaille) ? nReste : nTaille;
			CItemElem itemElem;
			itemElem.m_dwItemId = objet.dwItemId;
			itemElem.m_nItemNum = nTas;
			if (objet.bLie)
				itemElem.SetFlag(CItemElem::binds);
			itemElem.SetSerialNumber();
			if (pUser->CreateItem(&itemElem))
				g_DPSrvr.PutItemLog(pUser, "b", "ZCK_QUEST", &itemElem, nTas);
			else
				Error("ZckQuest : CreateItem refuse, joueur %07d, quete %d, objet %u x %d (a compenser)",
					(int)pUser->m_idPlayer, def.nId, (unsigned int)objet.dwItemId, nTas);
			nReste -= nTas;
		}
	}

	if (def.nPenya > 0 && !pUser->AddGold(def.nPenya))
		Error("ZckQuest : AddGold refuse, joueur %07d, quete %d, %d Penya (a compenser)", (int)pUser->m_idPlayer, def.nId, def.nPenya);

	// EXP : meme sequence que la fonction de dialogue AddExp (ScriptLib.cpp).
	const __int64 n64Exp = ExpRecompense(def, (int)pUser->GetLevel());
	if (n64Exp > 0)
	{
		if (pUser->AddExperience((EXPINTEGER)n64Exp, TRUE, FALSE))
		{
			pUser->AddSetExperience(pUser->GetExp1(), (WORD)pUser->m_nLevel);
			pUser->LevelUpSetting();
		}
		else
			pUser->AddSetExperience(pUser->GetExp1(), (WORD)pUser->m_nLevel);
	}

	// Buffs : meme pose que l'utilisation de l'objet (CMover::DoUseItem, case IK2_BUFF).
	for (size_t i = 0; i < def.vecBuffs.size(); ++i)
	{
		ItemProp* pItemProp = prj.GetItemProp(def.vecBuffs[i]);
		if (pItemProp)
			pUser->DoApplySkill(pUser, pItemProp, NULL);
	}

	// Sauvegarde immediate : la remise et l'etat recompense partent ensemble.
	if (pUser->GetWorld())
		g_dpDBClient.SavePlayer(pUser, pUser->GetWorld()->GetID(), pUser->GetPos(), pUser->GetLayer());

	CString str;
	str.Format("R\351compense re\347ue : %s.", (LPCTSTR)def.strNom);
	pUser->AddText(str, 0xffffd040);
	return ZCK_QUEST_OK;
}

// PACKETTYPE_ZCK_QUEST (CDPSrvr::OnZckQuest) : tout est revalide ici.
// bStaffBloque : regle ZckStaffBloque de __ZCK_CUSTOM_UI_CORRECTIF (DPSrvr.cpp),
// le staff bloque ne recoit aucune recompense, comme il ne fabrique ni n'echange.
void CZckQuestManager::Traiter(CUser* pUser, BYTE byAction, int nId, DWORD dwVersion, BOOL bStaffBloque)
{
	if (!IsValidObj(pUser))
		return;

	CZckQuestState& state = pUser->m_ZckQuest;
	const DWORD dwTick = GetTickCount();
	const __int64 n64Maintenant = Horloge();

	if (byAction == ZCK_QUEST_ACTION_CATALOGUE)
	{
		// Demande repetee a moins de ZCK_QUEST_DELAI_ACTION_MS : ignoree (la
		// precedente vient d'etre servie), comme toute action trop rapprochee.
		if (state.m_bDemande && dwTick - state.m_dwDerniereDemande < (DWORD)ZCK_QUEST_DELAI_ACTION_MS)
			return;
		state.m_bDemande = TRUE;
		state.m_dwDerniereDemande = dwTick;
		if (!m_bActif)
		{
			EnvoyerReponse(pUser, byAction, ZCK_QUEST_REFUS_INDISPONIBLE, 0);
			return;
		}
		Normaliser(state, n64Maintenant);
		// Catalogue au plus toutes les ZCK_QUEST_DELAI_CATALOGUE_MS ; l'etat, lui, part toujours.
		if (!state.m_bCatalogue || dwTick - state.m_dwDernierCatalogue >= (DWORD)ZCK_QUEST_DELAI_CATALOGUE_MS)
		{
			state.m_bCatalogue = TRUE;
			state.m_dwDernierCatalogue = dwTick;
			EnvoyerCatalogue(pUser);
		}
		EnvoyerEtat(pUser);
		return;
	}

	if (byAction != ZCK_QUEST_ACTION_ACCEPTER && byAction != ZCK_QUEST_ACTION_ABANDONNER && byAction != ZCK_QUEST_ACTION_RECUPERER)
	{
		EnvoyerReponse(pUser, byAction, ZCK_QUEST_REFUS_DEMANDE, nId);
		return;
	}

	if (state.m_bAction && dwTick - state.m_dwDerniereAction < (DWORD)ZCK_QUEST_DELAI_ACTION_MS)
	{
		EnvoyerReponse(pUser, byAction, ZCK_QUEST_REFUS_TROP_TOT, nId);
		return;
	}
	state.m_bAction = TRUE;
	state.m_dwDerniereAction = dwTick;

	if (!m_bActif)
	{
		EnvoyerReponse(pUser, byAction, ZCK_QUEST_REFUS_INDISPONIBLE, nId);
		return;
	}
	if (dwVersion != m_dwVersion)
	{
		Normaliser(state, n64Maintenant);
		state.m_bCatalogue = TRUE;
		state.m_dwDernierCatalogue = dwTick;
		EnvoyerCatalogue(pUser);
		EnvoyerEtat(pUser);
		EnvoyerReponse(pUser, byAction, ZCK_QUEST_REFUS_CATALOGUE, nId);
		return;
	}
	const ZCK_QUEST_DEFINITION* pDef = GetDefinition(nId);
	if (pDef == NULL)
	{
		EnvoyerReponse(pUser, byAction, ZCK_QUEST_REFUS_INCONNUE, nId);
		return;
	}
	if (!state.IsBaseOk())
	{
		EnvoyerReponse(pUser, byAction, ZCK_QUEST_REFUS_BASE, nId);
		return;
	}

	Normaliser(state, n64Maintenant);

	BYTE byCode = ZCK_QUEST_REFUS_DEMANDE;
	switch (byAction)
	{
	case ZCK_QUEST_ACTION_ACCEPTER:		byCode = Accepter(pUser, *pDef, n64Maintenant);		break;
	case ZCK_QUEST_ACTION_ABANDONNER:	byCode = Abandonner(pUser, *pDef, n64Maintenant);	break;
	case ZCK_QUEST_ACTION_RECUPERER:	byCode = bStaffBloque ? (BYTE)ZCK_QUEST_REFUS_STAFF : Recuperer(pUser, *pDef, n64Maintenant);	break;
	default:							break;
	}

	// La quete est toujours renvoyee : le client reste d'accord avec le serveur, refus compris.
	EnvoyerMaj(pUser, nId);
	EnvoyerReponse(pUser, byAction, byCode, nId);
}

// /quete <sous-commande> (FuncTextCmd.cpp, TCM_BOTH) : le client n'envoie que
// les sous-commandes ; les droits sont juges ici.
//   recharger      : relit Resource\ZckQuetes.inc et renvoie le catalogue a tous ;
//   reinitialiser  : efface les quetes de celui qui tape la commande (essais).
void CZckQuestManager::Commande(CUser* pUser, CScanner& s)
{
	if (!IsValidObj(pUser))
		return;
	if (!pUser->IsAuthHigher(AUTH_ADMINISTRATOR))
	{
		pUser->AddText("Qu\352tes : sous-commande r\351serv\351e \340 l'administration.", 0xffff0000);
		return;
	}

	s.GetToken();
	CString strSous = s.Token;
	strSous.MakeLower();

	if (strSous == "recharger")
	{
		const BOOL bCharge = Charger(ZCK_QUEST_FICHIER);
		CString str;
		if (bCharge)
			str.Format("Qu\352tes : %s recharg\351, %d qu\352te(s), version %08X.", ZCK_QUEST_FICHIER, (int)m_mapDefinitions.size(), (unsigned int)m_dwVersion);
		else
			str.Format("Qu\352tes : %s refus\351 (raison dans le journal d'erreurs du WorldServer), %s.", ZCK_QUEST_FICHIER,
				m_bActif ? "qu\352tes pr\351c\351dentes gard\351es" : "qu\352tes inactives");
		pUser->AddText(str, bCharge ? 0xff80e080 : 0xffff0000);

		if (bCharge)
		{
			// Aucun CUser* garde : la table est relue ici. Un fantome (objet
			// invalide) reste dans m_users : IsValidObj l'ecarte.
			const __int64 n64Maintenant = Horloge();
			for (std::unordered_map<DWORD, CUser*>::iterator it = g_UserMng.m_users.begin(); it != g_UserMng.m_users.end(); ++it)
			{
				CUser* pCible = it->second;
				if (!IsValidObj(pCible))
					continue;
				Normaliser(pCible->m_ZckQuest, n64Maintenant);
				pCible->m_ZckQuest.m_bCatalogue = TRUE;
				pCible->m_ZckQuest.m_dwDernierCatalogue = GetTickCount();
				EnvoyerCatalogue(pCible);
				EnvoyerEtat(pCible);
			}
		}
		return;
	}

	if (strSous == "reinitialiser")
	{
		if (!pUser->m_ZckQuest.IsBaseOk())
		{
			pUser->AddText(TexteCode(ZCK_QUEST_REFUS_BASE), 0xffff0000);
			return;
		}
		pUser->m_ZckQuest.GetEntrees().clear();
		EnvoyerEtat(pUser);
		pUser->AddText("Qu\352tes : vos qu\352tes ont \351t\351 effac\351es.", 0xff80e080);
		return;
	}

	pUser->AddText("Qu\352tes : /quete (journal) ; administration : /quete recharger, /quete reinitialiser.", 0xffffff00);
}
#endif // __WORLDSERVER

#ifdef __CLIENT
//////////////////////////////////////////////////////////////////////
// Neuz : catalogue et heure du serveur
//////////////////////////////////////////////////////////////////////

void CZckQuestManager::OublierClient()
{
	m_mapDefinitions.clear();
	m_dwVersion = 0;
	m_nActivesMax = ZCK_QUEST_ACTIVES_DEFAUT;
	m_bCatalogue = FALSE;
	m_bHorloge = FALSE;
	m_n64HorlogeBase = 0;
	m_dwTickBase = 0;
}

void CZckQuestManager::SetHorloge(__int64 n64Serveur)
{
	if (n64Serveur <= 0 || n64Serveur > ZCK_QUEST_ECHEANCE_MAX)
		return;
	m_n64HorlogeBase = n64Serveur;
	m_dwTickBase = GetTickCount();
	m_bHorloge = TRUE;
}

__int64 CZckQuestManager::HorlogeServeur() const
{
	if (!m_bHorloge)
		return 0;
	return m_n64HorlogeBase + (__int64)((DWORD)(GetTickCount() - m_dwTickBase) / 1000);
}

// Miroir exact de EcrireCatalogue. Tout ou rien : un catalogue incoherent
// laisse celui d'avant en place.
BOOL CZckQuestManager::LireCatalogue(CAr& ar)
{
	DWORD dwVersion = 0;
	int nActivesMax = 0;
	DWORD dwNombre = 0;
	ar >> dwVersion;
	ar >> nActivesMax;
	ar >> dwNombre;
	if (dwVersion == 0 || nActivesMax < 1 || nActivesMax > ZCK_QUEST_ACTIVES_MAX || dwNombre > ZCK_QUEST_MAX)
		return FALSE;

	std::map<int, ZCK_QUEST_DEFINITION> mapDefinitions;
	char szTexte[ZCK_QUEST_TEXTE_MAX + 1];

	for (DWORD n = 0; n < dwNombre; ++n)
	{
		ZCK_QUEST_DEFINITION def;
		ar >> def.nId;
		ar.ReadString(szTexte, ZCK_QUEST_NOM_MAX + 1);
		def.strNom = szTexte;
		ar.ReadString(szTexte, ZCK_QUEST_TEXTE_MAX + 1);
		def.strDescription = szTexte;
		ar.ReadString(szTexte, ZCK_QUEST_CATEGORIE_MAX + 1);
		def.strCategorie = szTexte;
		ar.ReadString(szTexte, ZCK_QUEST_LIEU_MAX + 1);
		def.strLieu = szTexte;
		ar >> def.nDebut;
		ar >> def.nFin;
		ar >> def.byJours;
		ar >> def.nDuree;
		ar >> def.nNiveauMin;
		ar >> def.nNiveauMax;
		ar >> def.nPrestigeMin;
		ar >> def.nPrestigeMax;
		ar >> def.nObjectif;
		BYTE byGroupe = 0;
		ar >> byGroupe;
		def.bGroupe = (byGroupe != 0) ? TRUE : FALSE;

		BYTE byNombre = 0;
		ar >> byNombre;
		if (byNombre > ZCK_QUEST_MONDES_MAX)
			return FALSE;
		for (BYTE i = 0; i < byNombre; ++i)
		{
			DWORD dw = 0;
			ar >> dw;
			def.vecMondes.push_back(dw);
		}

		ar >> byNombre;
		if (byNombre == 0 || byNombre > ZCK_QUEST_MONSTRES_MAX)
			return FALSE;
		for (BYTE i = 0; i < byNombre; ++i)
		{
			DWORD dw = 0;
			ar >> dw;
			def.vecMonstres.push_back(dw);
		}

		ar >> byNombre;
		if (byNombre > ZCK_QUEST_OBJETS_MAX)
			return FALSE;
		for (BYTE i = 0; i < byNombre; ++i)
		{
			ZCK_QUEST_OBJET objet;
			BYTE byLie = 0;
			ar >> objet.dwItemId;
			ar >> objet.nNombre;
			ar >> byLie;
			objet.bLie = (byLie != 0) ? TRUE : FALSE;
			if (objet.nNombre <= 0 || objet.nNombre > ZCK_QUEST_NOMBRE_MAX)
				return FALSE;
			def.vecObjets.push_back(objet);
		}

		ar >> byNombre;
		if (byNombre > ZCK_QUEST_BUFFS_MAX)
			return FALSE;
		for (BYTE i = 0; i < byNombre; ++i)
		{
			DWORD dw = 0;
			ar >> dw;
			def.vecBuffs.push_back(dw);
		}

		ar >> def.nPenya;
		ar >> def.n64Exp;
		ar >> def.nExpPourcent;

		if (def.nId <= 0 || def.nId > ZCK_QUEST_ID_MAX || def.strNom.IsEmpty()
			|| def.nDebut < 0 || def.nDebut >= 1440 || def.nFin <= 0 || def.nFin > 1440 || def.nFin == def.nDebut
			|| (def.byJours & ZCK_QUEST_JOURS_TOUS) == 0 || def.nDuree < 0 || def.nDuree > ZCK_QUEST_DUREE_MAX
			|| def.nNiveauMin > def.nNiveauMax || def.nPrestigeMin > def.nPrestigeMax
			|| def.nObjectif <= 0 || def.nObjectif > ZCK_QUEST_OBJECTIF_MAX
			|| def.nPenya < 0 || def.n64Exp < 0 || def.n64Exp > ZCK_QUEST_EXP_MAX
			|| def.nExpPourcent < 0 || def.nExpPourcent > ZCK_QUEST_EXP_POURCENT_MAX)
			return FALSE;
		if (mapDefinitions.find(def.nId) != mapDefinitions.end())
			return FALSE;
		mapDefinitions.insert(std::make_pair(def.nId, def));
	}

	DWORD dwFin = 0;
	ar >> dwFin;
	if (dwFin != ZCK_QUEST_FIN)
		return FALSE;

	m_mapDefinitions.swap(mapDefinitions);
	m_dwVersion = dwVersion;
	m_nActivesMax = nActivesMax;
	m_bCatalogue = TRUE;
	return TRUE;
}

// Miroir de EnvoyerEtat : remplace l'etat du personnage, tout ou rien.
BOOL CZckQuestManager::LireEtat(CAr& ar, CZckQuestState& state, DWORD& dwVersion)
{
	__int64 n64Horloge = 0;
	BYTE byBaseOk = 0;
	DWORD dwNombre = 0;
	ar >> dwVersion;
	ar >> n64Horloge;
	ar >> byBaseOk;
	ar >> dwNombre;

	BOOL bValide = (byBaseOk <= 1 && dwNombre <= ZCK_QUEST_MAX);
	std::map<int, ZCK_QUEST_ENTREE> mapEntrees;
	const DWORD dwLus = (dwNombre <= ZCK_QUEST_MAX) ? dwNombre : (DWORD)ZCK_QUEST_MAX;
	for (DWORD i = 0; i < dwLus; ++i)
	{
		int nId = 0;
		ZCK_QUEST_ENTREE entree;
		ar >> nId;
		ar >> entree.byEtat;
		ar >> entree.nCycle;
		ar >> entree.n64Echeance;
		ar >> entree.nProgression;
		if (!bValide)
			continue;
		if (!CZckQuestState::EntreeValide(nId, entree) || mapEntrees.find(nId) != mapEntrees.end())
		{
			bValide = FALSE;
			continue;
		}
		mapEntrees.insert(std::make_pair(nId, entree));
	}

	DWORD dwFin = 0;
	ar >> dwFin;
	if (!bValide || dwFin != ZCK_QUEST_FIN)
		return FALSE;

	SetHorloge(n64Horloge);
	state.GetEntrees().swap(mapEntrees);
	state.SetBaseOk(byBaseOk != 0);
	return TRUE;
}

// Miroir de EnvoyerMaj : une quete, taille fixe.
BOOL CZckQuestManager::LireMaj(CAr& ar, CZckQuestState& state, int& nId)
{
	__int64 n64Horloge = 0;
	BYTE byPresent = 0;
	ZCK_QUEST_ENTREE entree;
	DWORD dwFin = 0;
	nId = 0;
	ar >> n64Horloge;
	ar >> byPresent;
	ar >> nId;
	ar >> entree.byEtat;
	ar >> entree.nCycle;
	ar >> entree.n64Echeance;
	ar >> entree.nProgression;
	ar >> dwFin;
	if (dwFin != ZCK_QUEST_FIN || byPresent > 1 || nId <= 0 || nId > ZCK_QUEST_ID_MAX)
		return FALSE;

	if (byPresent)
	{
		if (!CZckQuestState::EntreeValide(nId, entree))
			return FALSE;
		ZCK_QUEST_ENTREE* pEntree = state.GetOrCreate(nId);
		if (pEntree == NULL)
			return FALSE;
		*pEntree = entree;
	}
	else
		state.Remove(nId);

	SetHorloge(n64Horloge);
	return TRUE;
}

// Miroir de EnvoyerReponse.
BOOL CZckQuestManager::LireReponse(CAr& ar, BYTE& byAction, BYTE& byCode, int& nId)
{
	DWORD dwFin = 0;
	ar >> byAction;
	ar >> byCode;
	ar >> nId;
	ar >> dwFin;
	return (dwFin == ZCK_QUEST_FIN) ? TRUE : FALSE;
}
#endif // __CLIENT

#endif // __ZCK_QUEST
