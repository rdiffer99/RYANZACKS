#include "stdafx.h"
#if defined(__ZCK_ANARCHY) && (defined(__WORLDSERVER) || defined(__CLIENT))
// Requis par les DEUX cibles : la reapplication des DestParam dans
// OnApplySM tourne aussi cote Neuz. Le limiter a __WORLDSERVER casserait
// la compilation du client.
#include "ZckAnarchy.h"
#endif
#if defined(__ZCK_ANARCHY) && defined(__WORLDSERVER)
// User.h n'existe que cote serveur : la resynchronisation sur le registre
// global est la seule partie strictement WorldServer.
#include "User.h"
#endif

#	if defined(__WORLDSERVER) || defined(__CLIENT)
#include "mover.h"
#include "defineItem.h"
#	else	// __WORLDSERVER, __CLIENT
#include "..\_network\objects\obj.h"
#	endif	// __WORLDSERVER, __CLIENT

#ifndef GETBLOCK
#define	GETBLOCK( ar, lpBuf, nBufSize )	\
										int nBufSize;	\
										LPBYTE lpBuf	= ar.GetBuffer( &nBufSize );
#endif	// __GETBLOCK

#include "honor.h"

#ifdef __ZCK_BADGE
#include "ZckBadge.h"

static void ZckBadgeWriteList(CAr& ar, const vector<int>& vecBadges)
{
	const DWORD dwCount = static_cast<DWORD>(vecBadges.size());
	ar << dwCount;

	if (dwCount > 0)
		ar.Write(&vecBadges[0], dwCount * sizeof(int));
}

static BOOL ZckBadgeReadList(CAr& ar, vector<int>& vecBadges)
{
	vecBadges.clear();

	DWORD dwCount = 0;
	ar >> dwCount;

	if (dwCount > (DWORD)ZCK_BADGE_MAX_OWNED)
		return FALSE;

	vector<int> vecRead;
	vecRead.resize(dwCount);

	if (dwCount > 0)
		ar.Read(&vecRead[0], dwCount * sizeof(int));

	ZckBadgeBuildSafeList(vecRead, vecBadges);
	return TRUE;
}
#endif // __ZCK_BADGE

void CObj::Serialize(CAr& ar)
{
	if (ar.IsStoring())
	{
		ar << (u_char)m_dwType;
		ar << m_dwIndex;
		ar << (u_short)(m_vScale.x * 100.0f);
		ar << m_vPos;
		ar << (short)(m_fAngle * 10.0f);
	}
	else
	{
		u_short u2;
		short i2;
		m_dwType = m_dwIndex = 0;

		ar >> (u_char&)m_dwType;
		ar >> m_dwIndex;
		ar >> u2;
		m_vScale.x = m_vScale.y = m_vScale.z = (float)u2 / 100.0f;
		ar >> m_vPos;
		ar >> i2;
		m_fAngle = (float)i2 / 10.0f;
#if defined(__WORLDSERVER) || defined(__CLIENT)
		SetAngle(m_fAngle);
#endif

#ifdef __WORLDSERVER
		m_vLink = m_vPos;
#endif	// __WORLDSERVER
	}
}

#if defined(__WORLDSERVER) || defined(__CLIENT)
void CMover::OnApplySM()
{
	ItemProp* aItemprop;
	int nAdjParamVal;

	if (m_dwSMTime[SM_MAX_HP] > 0)
	{
		aItemprop = prj.GetItemProp(II_CHR_FOO_COO_BULLHAMS);
		nAdjParamVal = aItemprop->nAdjParamVal2;
		SetDestParam(aItemprop->dwDestParam1, nAdjParamVal, NULL_CHGPARAM, 1);
	}

	if (m_dwSMTime[SM_MAX_HP50] > 0)
	{
		aItemprop = prj.GetItemProp(II_CHR_FOO_COO_GRILLEDEEL);
		nAdjParamVal = m_nPlusMaxHitPoint;
		SetDestParam(aItemprop->dwDestParam1, nAdjParamVal, NULL_CHGPARAM, 1);
	}

	if (m_dwSMTime[SM_VELOCIJUMP] > 0)
	{
		aItemprop = prj.GetItemProp(g_AddSMMode.dwSMItemID[SM_VELOCIJUMP]);
		if (aItemprop)
		{
			for (int i = 0; i < PROP_BONUSES; i++)
			{
				if (aItemprop->dwDestParam[i] != NULL_ID)
					SetDestParam(aItemprop->dwDestParam[i], aItemprop->nAdjParamVal[i], NULL_CHGPARAM);
			}
		}
	}

#ifdef __ZCK_ANARCHY
	// 1) Reapplication des DestParam des slots encore actifs dans la
	//    sauvegarde. Une seule boucle : l'ancien systeme ecrivait 16 blocs
	//    identiques a la main.
	for (int nSlot = 0; nSlot < ZCK_ANARCHY_COUNT; ++nSlot)
	{
		const int nSMMode = CZckAnarchyManager::GetSMModeBySlot(nSlot);

		if (nSMMode < 0 || nSMMode >= SM_MAX)
			continue;

		if (m_dwSMTime[nSMMode] == 0)
			continue;

		aItemprop = prj.GetItemProp(g_AddSMMode.dwSMItemID[nSMMode]);
		if (!aItemprop)
			continue;

		if (aItemprop->dwDestParam1 != -1)
			SetDestParam(aItemprop->dwDestParam1, aItemprop->nAdjParamVal1, NULL_CHGPARAM);

		if (aItemprop->dwDestParam2 != -1)
			SetDestParam(aItemprop->dwDestParam2, aItemprop->nAdjParamVal2, NULL_CHGPARAM);
	}

#ifdef __WORLDSERVER
	// 2) Resynchronisation sur le registre global du WorldServer.
	//    C'est le registre qui fait autorite, pas la sauvegarde : un buff
	//    present dans m_dwSMTime mais absent du registre est efface ici.
	if (IsPlayer())
		CZckAnarchyManager::GetInstance()->ApplyAllActiveToUser((CUser*)this);
#endif // __WORLDSERVER
#endif // __ZCK_ANARCHY
#ifdef __ZCK_VIP
	// __ZCK_VIP : DestParam du palier VIP.
	// Serveur : synchronisation suivie, aucune double application possible ;
	// un palier dont l'echeance est depassee n'est pas pose (SubSMMode le
	// purge au tick suivant).
	// Client : m_dwSMTime vient d'etre deserialise, les DestParam sont
	// reposes comme pour les autres modes SM de cette fonction.
#ifdef __WORLDSERVER
	ZckVipSynchroniserBonus();
#else // __WORLDSERVER
	ZckVipAppliquerBonus(GetZckVipSlot(), TRUE);
#endif // __WORLDSERVER
#endif // __ZCK_VIP
}
#ifdef __ZCK_VIP

// Pose (bAppliquer = TRUE) ou retire les DestParam de l'objet VIP du slot
// nSM, sur les PROP_BONUSES lignes : le donneur en posait six a
// l'activation mais n'en retirait que trois a l'expiration.
void CMover::ZckVipAppliquerBonus(int nSM, BOOL bAppliquer)
{
	if (nSM < SM_VIP1 || nSM > SM_VIP4)
		return;

	ItemProp* pItemProp = prj.GetItemProp(g_AddSMMode.dwSMItemID[nSM]);
	if (!pItemProp)
		return;

	for (int i = 0; i < PROP_BONUSES; i++)
	{
		if (pItemProp->dwDestParam[i] == NULL_ID)
			continue;

		if (bAppliquer)
			SetDestParam(pItemProp->dwDestParam[i], pItemProp->nAdjParamVal[i], NULL_CHGPARAM);
		else
			ResetDestParam(pItemProp->dwDestParam[i], pItemProp->nAdjParamVal[i]);
	}
}
#endif // __ZCK_VIP
#endif // __WORLDSERVER __CLIENT

void CMover::Serialize(CAr& ar)
{
	CCtrl::Serialize(ar);	//	25
	DWORD dwGold;

	if (ar.IsStoring())	// STORING
	{
		ar << (u_short)m_dwMotion;
		ar << (u_char)m_bPlayer;

#ifdef __DBSERVER
		ar << (DWORD)AII_NONE;
#else
		ar << m_dwAIInterface;
#endif

		ar << m_nHitPoint;
		ar << m_pActMover->GetState();
		ar << m_pActMover->GetStateFlag();
		ar << (u_char)m_dwBelligerence;
		ar << m_dwMoverSfxId;

#ifdef __ZCK_INVASION
		ar << bIsInvasionMonster;
#endif // __ZCK_INVASION

		if (m_bPlayer)	// PLAYER
		{
			ar.WriteString(m_szName);
			ar << GetSex();
			ar << (u_char)m_dwSkinSet;
			ar << (u_char)m_dwHairMesh;
			ar << m_dwHairColor;
			ar << (u_char)m_dwHeadMesh;
			ar << m_idPlayer;
			ar << (u_char)m_nJob;
			ar << (u_short)m_nStr;
			ar << (u_short)m_nSta;
			ar << (u_short)m_nDex;
			ar << (u_short)m_nInt;
			ar << (u_short)m_nLevel;
#ifdef __ZCK_PRESTIGE
			ar << GetZckPrestige();
#endif
			ar << m_nManaPoint;
			ar << m_nFatiguePoint;
			ar << m_nFuel;
			ar << m_tmAccFuel;
#ifdef __ZCK_BADGE
			ar << ZckBadgeSanitizeSelected(GetZckBadge(), GetZckOwnedBadges());
#endif // __ZCK_BADGE
#ifdef __ZCK_AURA_SYSTEM
			// Partie commune a toutes les methodes : DatabaseServer <-> WorldServer,
			// WorldServer -> proprietaire (join) et -> autres joueurs (apparition).
			// DWORD depuis la refonte RGB : les trois executables se redeploient
			// ensemble (voir l'ordre d'application).
			ar << GetZckAura();
			// Geometrie de l'aura (WORD), meme rang, memes destinataires.
			ar << GetZckAuraGeo();
			// Style de l'aura (BYTE), meme rang, memes destinataires.
			ar << GetZckAuraStyle();
#endif // __ZCK_AURA_SYSTEM
#ifdef __ZCK_TRAILS
			// Trail du personnage : deux DWORD (code, reglages), meme rang que
			// l'aura, memes destinataires (DatabaseServer <-> WorldServer,
			// WorldServer -> proprietaire et -> autres joueurs). Les trois
			// executables se redeploient ensemble.
			ar << GetZckTrails();
			ar << GetZckTrailsParam();
#endif // __ZCK_TRAILS
#ifdef __ZCK_ELEMENT_RGB
			// Element RGB : deux DWORD (couleur des SFX d'element de la main
			// droite, puis de la main gauche), meme rang que l'aura et les
			// trails, memes destinataires (DatabaseServer <-> WorldServer,
			// WorldServer -> proprietaire et -> autres joueurs). Les trois
			// executables se redeploient ensemble.
			ar << GetZckElementRgb(ZCK_ELEMENT_RGB_HAND_RIGHT);
			ar << GetZckElementRgb(ZCK_ELEMENT_RGB_HAND_LEFT);
#endif // __ZCK_ELEMENT_RGB
#ifdef __ZCK_BURNOUT
			// Burnout : jauge (Virtuos : m_nBurnoutExp, partie commune des joueurs). Toutes les methodes :
			// DatabaseServer <-> WorldServer, WorldServer -> proprietaire et -> autres joueurs. Les trois
			// executables se redeploient ensemble. Jamais ecrite en base (comme Virtuos).
			ar << m_nBurnoutExp;
#endif // __ZCK_BURNOUT
			if (m_idGuild > 0)
			{
				ar << (u_char)1;
				ar << m_idGuild;
			}
			else
			{
				ar << (u_char)0;
			}

			if (m_idparty > 0)
			{
				ar << (u_char)1;
				ar << m_idparty;
			}
			else
			{
				ar << (u_char)0;
			}

			ar << (char)m_dwAuthorization;
			ar << m_dwMode;
			ar << m_dwStateMode;
#ifdef __WORLDSERVER
			CItemElem* pItemElem = m_Inventory.GetAtId(m_dwUseItemId);
			if (pItemElem)
				ar << pItemElem->GetProp()->dwID;
			else
				ar << (OBJID)0;
#else // __WORLDSERVER
			ar << m_dwUseItemId;
#endif // __WORLDSERVER

			if (m_dwPKTime > 0)
#ifdef __WORLDSERVER
				ar << (m_dwPKTime - GetTickCount());
#else // __WORLDSERVER
				ar << m_dwPKTime;
#endif // __WORLDSERVER
			else
				ar << m_dwPKTime;
			ar << m_nPKValue;
			ar << m_dwPKPropensity;
			ar << m_dwPKExp;
			ar << m_nFame;
			ar << m_nHonor;

			for (int i = 0; i < MAX_HUMAN_PARTS; i++)
			{
				ar << m_aEquipInfo[i].nOption;
			}

			ar << m_nGuildCombatState;
#ifdef __FL_BATTLE_PASS
			ar << m_nBattlePassLevel;
			ar << m_nBattlePassExp;
#endif
			for (int z = 0; z < hft_MAX_HIDEFASHION_TYPES; z++)
				ar << m_bHideFashion[z];

			for (int j = 0; j < SM_MAX; ++j)
				ar << m_dwSMTime[j];

			if (CObj::GetMethod() == METHOD_NONE)
			{
				ar << m_nFxp;

				dwGold = GetGold();
				ar << dwGold;
				ar << m_nExp1;
#ifdef __ZCK_PRESTIGE
				ar << (BYTE)(IsZckPrestigePending() ? 1 : 0);
				ar << GetZckPrestigePending();
#endif
#ifdef __ZCK_SYSTEME_EVEIL
				for (int iZckAwake = 0; iZckAwake < ZCK_AWAKE_CATEGORY_MAX; ++iZckAwake)
				{
				ar << m_ZckAwakeMastery.aCategory[iZckAwake].wMastery;
				ar << m_ZckAwakeMastery.aCategory[iZckAwake].byFlags;
				ar << m_ZckAwakeMastery.aCategory[iZckAwake].byAffinity;
				ar << m_ZckAwakeMastery.aCategory[iZckAwake].bySelectedDst;
				ar << m_ZckAwakeMastery.aCategory[iZckAwake].dwProtectedSerial;
				}
#endif
				DWORD dwJobLv[MAX_JOB] = { 0, };
				ar.Write((void*)dwJobLv, sizeof(DWORD) * MAX_JOB);
				ar << m_idMarkingWorld;
				ar << m_vMarkingPos;
				ar << m_nQuestSize;
				ar.Write(m_aQuest, sizeof(QUEST) * m_nQuestSize);
				ar << m_nCompleteQuestSize;
				ar.Write(m_aCompleteQuest, sizeof(WORD) * m_nCompleteQuestSize);

				ar << m_nCheckedQuestSize;
				ar.Write(m_aCheckedQuest, sizeof(WORD) * m_nCheckedQuestSize);

				ar << m_idMurderer;
				ar << (short)m_nRemainGP;
				ar << (short)0;
				{
					for (int i = 0; i < MAX_HUMAN_PARTS; i++)
					{
						ar << m_aEquipInfo[i].dwId;
					}
				}
				ar.Write((void*)m_aJobSkill, sizeof(SKILL) * (MAX_SKILL_JOB));

				ar << (BYTE)m_nCheerPoint << m_dwTickCheer - GetTickCount();

				ar << m_nSlot;
				for (int k = 0; k < 3; ++k)
					ar << m_dwGoldBank[k];
				for (int k = 0; k < 3; ++k)
					ar << m_idPlayerBank[k];
				ar << m_nPlusMaxHitPoint;
				ar << m_nAngelExp;
				ar << m_nAngelLevel;
#ifdef __ZCK_CRAFT_LOAD_TEX
				// Experience d'artisanat : DatabaseServer <-> WorldServer et WorldServer ->
				// proprietaire (bloc METHOD_NONE), jamais aux autres joueurs. Meme rang a la
				// lecture. Neuz, WorldServer et DatabaseServer se redeploient ensemble.
				ar << m_nZckCraftExp;
#else
#line 404 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX

				m_Inventory.Serialize(ar);
				for (int k = 0; k < 3; ++k)
					m_Bank[k].Serialize(ar);

				ar << GetPetId();
#ifdef __FL_CONSUMABLES_STORAGE
				m_Chest.Serialize(ar);
#endif
#ifdef __FL_SWITCH_EQ
				m_Switches.Serialize(ar);
#endif
#ifdef __FL_MONSTER_ALBUM
				m_MonsterAlbum.Serialize(ar);
#endif
#ifdef __ZCK_ACHIEVEMENT
				m_ZckAchievement.Serialize(ar);
#endif
#ifdef __ZCK_CLASSEMENT
				m_ZckClassement.Serialize(ar);
#endif
#ifdef __ZCK_QUEST
				// Quetes : DatabaseServer <-> WorldServer et WorldServer -> proprietaire
				// (bloc METHOD_NONE), meme rang a l'ecriture et a la lecture.
				m_ZckQuest.Serialize(ar);
#endif // __ZCK_QUEST
#ifdef __FL_SEASON_PASS
				m_SeasonPass.Serialize(ar);
#endif
#ifdef __FL_WARDROBE
				m_Wardrobe.Serialize(ar, true);
#endif
#ifdef __JEFF_9_20
				ar << m_dwMute;
#endif
#ifdef __FL_PET_FILTER
				ar << m_setPetfilterBlackList.size();
				for (auto& it : m_setPetfilterBlackList)
					ar << it;
				ar << m_setPetfilterWhiteList.size();
				for (auto& it : m_setPetfilterWhiteList)
					ar << it;
#endif
#ifdef __FL_AUTO_STAT
				ar << m_nAutoStat;
#endif

				for (int i = 0; i < MAX_HONOR_TITLE; ++i)
				{
					ar << m_aHonorTitle[i];

				}
#ifdef __ZCK_BADGE
				{
					vector<int> vecZckSafeBadges;
					ZckBadgeBuildSafeList(GetZckOwnedBadges(), vecZckSafeBadges);
					ZckBadgeWriteList(ar, vecZckSafeBadges);
				}
#endif // __ZCK_BADGE
#ifdef __ZCK_PET_GLOW
				// Couleur enregistree du personnage : DatabaseServer <-> WorldServer et
				// WorldServer -> proprietaire. Jamais envoyee aux autres joueurs.
				ar << GetZckPetGlow();
				// Geometrie de glow enregistree (WORD), memes destinataires.
				ar << GetZckPetGlowGeo();
#ifdef __ZCK_PET_GLOW_STYLES
				// Style de glow enregistre (BYTE), memes destinataires, juste apres.
				ar << GetZckPetGlowStyle();
#endif // __ZCK_PET_GLOW_STYLES
#ifdef __ZCK_PET_SELECTION
				// Familier a montrer a l'ecran de selection (DWORD), memes destinataires.
				ar << GetZckPetSelection();
#endif // __ZCK_PET_SELECTION
#endif // __ZCK_PET_GLOW

			}
			else if (CObj::GetMethod() == METHOD_EXCLUDE_ITEM)
			{
#ifdef __FL_WARDROBE
				m_Wardrobe.Serialize(ar, false);
#endif
#	if defined (__WORLDSERVER) || defined(__CLIENT)
				ar.WriteString(m_vtInfo.GetTitle());
#	endif
				u_char uSize = 0;
				u_long uOffset = ar.GetOffset();
				ar << uSize;
				for (u_char uParts = 0; uParts < MAX_HUMAN_PARTS; uParts++)
				{
					CItemElem* pItemElem = m_Inventory.GetEquip(uParts);
					if (pItemElem)
					{
						uSize++;
						ar << uParts;
						ar << (u_short)pItemElem->m_dwItemId;
						ar << pItemElem->m_byFlag;
					}
				}
				GETBLOCK(ar, pBlock, nBlockSize);
				*(UNALIGNED u_char*)(pBlock + uOffset) = uSize;

				DWORD dwPetId = NULL_ID;
#ifdef __PET_1024
				char* pszPetName = "";
				CItemElem* pItemElem = GetPetItem();
				if (pItemElem)
				{
					dwPetId = MAKELONG((WORD)pItemElem->m_pPet->GetIndex(), (WORD)pItemElem->m_pPet->GetLevel());
#ifdef __PET_1024
					pszPetName = const_cast<char*>(pItemElem->m_pPet->GetName());
#endif	// __PET_1024
				}
				ar << dwPetId;
#ifdef __PET_1024
				ar.WriteString(pszPetName);
#endif	// __PET_1024
#endif	// __PET_0410
			}
		}
		else	// NPC
		{
#if defined (__FL_PLAYER_STATUE) || defined (__FL_VENDORS)
			SerializeAbnormalNpc(ar);
#endif
			ar << (u_char)m_dwHairMesh << m_dwHairColor << (u_char)m_dwHeadMesh;
			ar.WriteString(m_szCharacterKey);
#if defined(__ZCK_DIFFICULTY) && (defined(__WORLDSERVER) || defined(__CLIENT))
			ar << m_fDungeonHpFactor;
#endif

			u_char uSize = 0;
			u_long uOffset = ar.GetOffset();
			ar << uSize;
			if (IsEquipableNPC())
			{
				CItemElem* pItemElem;
				for (u_char uParts = 0; uParts < MAX_HUMAN_PARTS; uParts++)
				{
					pItemElem = m_Inventory.GetEquip(uParts);
					if (pItemElem)
					{
						uSize++;
						ar << uParts;
						ar << (u_short)pItemElem->m_dwItemId;
					}
				}
			}
			GETBLOCK(ar, pBlock, nBlockSize);
			*(UNALIGNED u_char*)(pBlock + uOffset) = uSize;


			ar << (u_char)m_bActiveAttack;
			ar << (u_char)m_nMovePattern;
			ar << (u_char)m_nMoveEvent;
			ar << m_nMoveEventCnt;
			ar << m_fSpeedFactor;
#if defined(__ZCK_PET_GLOW) && (defined(__WORLDSERVER) || defined(__CLIENT))
			// Familier : couleur affichee, pour les nouveaux observateurs. Ecrite et
			// lue sous la meme condition (interface d'IA, deja serialisee plus haut).
			if (m_dwAIInterface == AII_PET)
			{
				ar << GetZckPetGlow();
				ar << GetZckPetGlowGeo();
#ifdef __ZCK_PET_GLOW_STYLES
				// Style affiche (BYTE), juste apres, memes observateurs.
				ar << GetZckPetGlowStyle();
#endif // __ZCK_PET_GLOW_STYLES
			}
#endif // __ZCK_PET_GLOW
#ifdef __FL_WORLDBOSS
			ar << m_bWorldBoss;

			if (m_bWorldBoss)
			{
				ar << m_mapAttackersDamage.size();
				for (auto& it : m_mapAttackersDamage)
				{
					ar << it.first;
					ar << it.second;
				}
			}
#endif
		}

		m_buffs.Serialize(ar);
	}
	else	// LOADING
	{
		m_dwMotion = 0;

		u_short nMotion;
		ar >> nMotion;

#if defined(__WORLDSERVER) || defined(__CLIENT)
		m_dwMotion = (DWORD)nMotion;
#else
		m_dwMotion = (DWORD)nMotion;
#endif

		m_bPlayer =
			m_dwBelligerence =
			m_idGuild =
			m_idparty = 0;

		ClearEquipInfo();

		ar >> (u_char&)m_bPlayer;

#ifdef __DBSERVER
		SKILL	aJobSkill[MAX_SKILL_JOB];
		memcpy(aJobSkill, m_aJobSkill, sizeof(aJobSkill));
#endif

		DWORD dwAIInterface;
		ar >> dwAIInterface;

#ifdef __CLIENT
		m_dwAIInterface = dwAIInterface;
#endif

		InitProp();

		m_nHitPoint = 0;

		ar >> m_nHitPoint;

		DWORD dw1, dw2;
		ar >> dw1;
		ar >> dw2;
		m_pActMover->ClearStateFlag();
		m_pActMover->AddStateFlag(dw2);
		m_pActMover->__ForceSetState(dw1);
		ar >> (u_char&)m_dwBelligerence;
		ar >> m_dwMoverSfxId;

#ifdef __ZCK_INVASION
		ar >> bIsInvasionMonster;
#endif // __ZCK_INVASION

		if (m_bPlayer)	// PLAYER
		{
			m_dwSkinSet =
				m_dwHairMesh =
				m_dwHeadMesh =
				m_idPlayer =
				m_nJob =
				m_nStr =
				m_nSta =
				m_nDex =
				m_nInt =
				m_nLevel =
				m_nManaPoint =
				m_nFatiguePoint =
				m_dwAuthorization =
				0;

			BYTE bySex;
			ar.ReadString(m_szName, 32);
			ar >> bySex;
			SetSex(bySex);
			ar >> (u_char&)m_dwSkinSet;
			ar >> (u_char&)m_dwHairMesh;
			ar >> m_dwHairColor;
			ar >> (u_char&)m_dwHeadMesh;
#	if defined (__WORLDSERVER) || defined(__CLIENT)
			SetHairColor(m_dwHairColor);
#	endif	// __WORLDSERVER	//__CLIENT
			ar >> m_idPlayer;
			ar >> (u_char&)m_nJob;
			ar >> (u_short&)m_nStr;
			ar >> (u_short&)m_nSta;
			ar >> (u_short&)m_nDex;
			ar >> (u_short&)m_nInt;
			ar >> (u_short&)m_nLevel;
#ifdef __ZCK_PRESTIGE
			BYTE byZckPrestige = 0;
			ar >> byZckPrestige;
			SetZckPrestige(byZckPrestige);
#endif
			ar >> m_nManaPoint;
			ar >> m_nFatiguePoint;
			ar >> m_nFuel;
			ar >> m_tmAccFuel;
#ifdef __ZCK_BADGE
			{
				int nZckBadge = ZCK_BADGE_ID_NONE;
				ar >> nZckBadge;
				if (nZckBadge < ZCK_BADGE_ID_NONE)
					nZckBadge = ZCK_BADGE_ID_NONE;
				SetZckBadge(nZckBadge);
			}
#endif // __ZCK_BADGE
#ifdef __ZCK_AURA_SYSTEM
			{
				// Miroir exact de l'ecriture : un DWORD, au meme rang.
				DWORD dwZckAura = ZCK_AURA_NONE;
				ar >> dwZckAura;
				SetZckAura(dwZckAura);
				// Puis un WORD : la geometrie de l'aura.
				WORD wZckAuraGeo = ZCK_SFX_GEO_NEUTRAL;
				ar >> wZckAuraGeo;
				SetZckAuraGeo(ZckSfxGeoSanitize(wZckAuraGeo));
				// Puis un BYTE : le style de l'aura (SetZckAuraStyle assainit).
				BYTE byZckAuraStyle = (BYTE)ZCK_AURA_STYLE_DEFAULT;
				ar >> byZckAuraStyle;
				SetZckAuraStyle(byZckAuraStyle);
			}
#endif // __ZCK_AURA_SYSTEM
#ifdef __ZCK_TRAILS
			{
				// Miroir exact de l'ecriture : deux DWORD, au meme rang, lus en
				// entier avant tout test ; SetZckTrails / SetZckTrailsParam assainissent.
				DWORD dwZckTrails = ZCK_TRAILS_NONE;
				DWORD dwZckTrailsParam = ZCK_TRAILS_PARAM_DEFAULT;
				ar >> dwZckTrails;
				ar >> dwZckTrailsParam;
				SetZckTrails(dwZckTrails);
				SetZckTrailsParam(dwZckTrailsParam);
			}
#endif // __ZCK_TRAILS
#ifdef __ZCK_ELEMENT_RGB
			{
				// Miroir exact de l'ecriture : deux DWORD, droite puis gauche, au
				// meme rang, lus en entier avant tout test ; SetZckElementRgb
				// assainit.
				DWORD dwZckElementRgbRight = ZCK_ELEMENT_RGB_NONE;
				DWORD dwZckElementRgbLeft = ZCK_ELEMENT_RGB_NONE;
				ar >> dwZckElementRgbRight;
				ar >> dwZckElementRgbLeft;
				SetZckElementRgb(ZCK_ELEMENT_RGB_HAND_RIGHT, dwZckElementRgbRight);
				SetZckElementRgb(ZCK_ELEMENT_RGB_HAND_LEFT, dwZckElementRgbLeft);
			}
#endif // __ZCK_ELEMENT_RGB
#ifdef __ZCK_BURNOUT
			// Miroir exact de l'ecriture : un int, au meme rang.
			ar >> m_nBurnoutExp;
#endif // __ZCK_BURNOUT

			u_char u1;
			ar >> u1;
			if (u1 == 1)
			{
				ar >> m_idGuild;
			}

			ar >> u1;
			if (u1 == 1)
			{
				ar >> m_idparty;
			}

			ar >> (char&)m_dwAuthorization;
			ar >> m_dwMode;
			ar >> m_dwStateMode;
#ifdef __WORLDSERVER
			OBJID dwItemTem;
			ar >> dwItemTem;
#else // __WORLDSERVER
			ar >> m_dwUseItemId;
#endif // __WORLDSERVER

			ar >> m_dwPKTime;
#ifdef __WORLDSERVER
			if (m_dwPKTime > 0)
				m_dwPKTime = GetTickCount() + m_dwPKTime;
#endif // __WORLDSERVER
			ar >> m_nPKValue;
			ar >> m_dwPKPropensity;
			ar >> m_dwPKExp;
			ar >> m_nFame;

			int nTemp = -1;
			ar >> nTemp;
#ifdef __CLIENT
			if (m_nHonor != nTemp)
			{
				m_nHonor = nTemp;
				SetTitle(CTitleManager::Instance()->GetTitle(m_nHonor));
			}
#else	// __CLIENT
			m_nHonor = nTemp;
#endif	// __CLIENT

			for (int i = 0; i < MAX_HUMAN_PARTS; i++)
			{
				ar >> m_aEquipInfo[i].nOption;
			}

			ar >> m_nGuildCombatState;
#ifdef __FL_BATTLE_PASS
			ar >> m_nBattlePassLevel;
			ar >> m_nBattlePassExp;
#endif
			for (int z = 0; z < hft_MAX_HIDEFASHION_TYPES; z++)
				ar >> m_bHideFashion[z];

			for (int j = 0; j < SM_MAX; ++j)
				ar >> m_dwSMTime[j];

			if (CObj::GetMethod() == METHOD_NONE)
			{
				m_nRemainGP = 0;
				ar >> m_nFxp;

				ar >> dwGold;
				SetGold(dwGold);

				ar >> m_nExp1;
#ifdef __ZCK_PRESTIGE
				BYTE byPendingCommit = 0;
				BYTE byPendingPrestige = 0;
				ar >> byPendingCommit;
				ar >> byPendingPrestige;
				SetZckPrestigePending(byPendingCommit ? TRUE : FALSE, byPendingPrestige);
#endif
#ifdef __ZCK_SYSTEME_EVEIL
				for (int iZckAwake = 0; iZckAwake < ZCK_AWAKE_CATEGORY_MAX; ++iZckAwake)
				{
				ar >> m_ZckAwakeMastery.aCategory[iZckAwake].wMastery;
				ar >> m_ZckAwakeMastery.aCategory[iZckAwake].byFlags;
				ar >> m_ZckAwakeMastery.aCategory[iZckAwake].byAffinity;
				ar >> m_ZckAwakeMastery.aCategory[iZckAwake].bySelectedDst;
				ar >> m_ZckAwakeMastery.aCategory[iZckAwake].dwProtectedSerial;
				}
					m_ZckAwakeMastery.Normalize(ZCK_AWAKE_MASTERY_STORAGE_MAX);
#endif
				DWORD dwJobLv[MAX_JOB];
				ar.Read((void*)dwJobLv, sizeof(DWORD) * MAX_JOB);
				ar >> m_idMarkingWorld;
				ar >> m_vMarkingPos;
				ar >> m_nQuestSize;
				ar.Read(m_aQuest, sizeof(QUEST) * m_nQuestSize);
				ar >> m_nCompleteQuestSize;
				ar.Read(m_aCompleteQuest, sizeof(WORD) * m_nCompleteQuestSize);

				ar >> m_nCheckedQuestSize;
				ar.Read(m_aCheckedQuest, sizeof(WORD) * m_nCheckedQuestSize);

				ar >> m_idMurderer;

				short n1, n2;
				ar >> n1 >> n2;
				m_nRemainGP = n1;
				{
					for (int i = 0; i < MAX_HUMAN_PARTS; i++)
					{
						ar >> m_aEquipInfo[i].dwId;
					}
				}
#ifdef __DBSERVER
				ar.Read((void*)m_aJobSkill, sizeof(SKILL) * (MAX_SKILL_JOB));
				for (int i = 0; i < MAX_SKILL_JOB; i++)
					m_abUpdateSkill[i] = (BOOL)(memcmp(&m_aJobSkill[i], &aJobSkill[i], sizeof(SKILL)) != 0);
#else
				ar.Read((void*)m_aJobSkill, sizeof(SKILL) * (MAX_SKILL_JOB));
#endif

				m_nCheerPoint = 0;
				ar >> (BYTE&)m_nCheerPoint >> m_dwTickCheer;
				m_dwTickCheer += GetTickCount();
				ar >> m_nSlot;
				for (int k = 0; k < 3; ++k)
					ar >> m_dwGoldBank[k];
				for (int k = 0; k < 3; ++k)
					ar >> m_idPlayerBank[k];

				ar >> m_nPlusMaxHitPoint;
				ar >> m_nAngelExp;
				ar >> m_nAngelLevel;
#ifdef __ZCK_CRAFT_LOAD_TEX
				// Miroir exact de l'ecriture. Hors bornes : non chargee (artisanat refuse,
				// rien n'est sauvegarde).
				ar >> m_nZckCraftExp;
				if (m_nZckCraftExp < 0 || m_nZckCraftExp > ZCK_CRAFT_EXP_NIVEAU_MAX)
					m_nZckCraftExp = ZCK_CRAFT_EXP_INCONNUE;
#else
#line 868 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX

				m_Inventory.Serialize(ar);
				for (int k = 0; k < 3; ++k)
					m_Bank[k].Serialize(ar);

				DWORD dwPetId;
				ar >> dwPetId;
				SetPetId(dwPetId);
#ifdef __PET_1024
#ifdef __CLIENT
				CPet* pPet = GetPet();
				if (pPet)
					m_pet.SetName(const_cast<char*>(pPet->GetName()));
#endif	// __CLIENT
#endif	// __PET_1024

#ifdef __FL_CONSUMABLES_STORAGE
				m_Chest.Serialize(ar);
#endif
#ifdef __FL_SWITCH_EQ
				m_Switches.Serialize(ar);
#endif
#ifdef __FL_MONSTER_ALBUM
				m_MonsterAlbum.Serialize(ar);
#endif
#ifdef __ZCK_ACHIEVEMENT
				m_ZckAchievement.Serialize(ar);
#endif
#ifdef __ZCK_CLASSEMENT
				m_ZckClassement.Serialize(ar);
#endif
#ifdef __ZCK_QUEST
				// Quetes : DatabaseServer <-> WorldServer et WorldServer -> proprietaire
				// (bloc METHOD_NONE), meme rang a l'ecriture et a la lecture.
				m_ZckQuest.Serialize(ar);
#endif // __ZCK_QUEST
#ifdef __FL_SEASON_PASS
				m_SeasonPass.Serialize(ar);
#endif
#ifdef __FL_WARDROBE
				m_Wardrobe.Serialize(ar, true);
#endif
#ifdef __JEFF_9_20
				ar >> m_dwMute;
#endif
#ifdef __FL_PET_FILTER
				m_setPetfilterBlackList.clear();

				size_t nBlackListSize;
				ar >> nBlackListSize;

				for (size_t i = 0; i < nBlackListSize; i++)
				{
					DWORD dwItemID;
					ar >> dwItemID;
					m_setPetfilterBlackList.insert(dwItemID);
				}

				m_setPetfilterWhiteList.clear();

				size_t nWhiteListSize;
				ar >> nWhiteListSize;

				for (size_t i = 0; i < nWhiteListSize; i++)
				{
					DWORD dwItemID;
					ar >> dwItemID;
					m_setPetfilterWhiteList.insert(dwItemID);
				}
#endif
#ifdef __FL_AUTO_STAT
				ar >> m_nAutoStat;
#endif

#ifdef __CLIENT
				CTitleManager::Instance()->InitEarned();
#endif	// __CLIENT
				for (int l = 0; l < MAX_HONOR_TITLE; ++l)
				{
					ar >> m_aHonorTitle[l];
#ifdef __CLIENT
					int nNeed = CTitleManager::Instance()->GetNeedCount(l, -1);
					if (m_aHonorTitle[l] >= nNeed && nNeed > 0)
					{
						CTitleManager::Instance()->AddEarned(l);
					}
					else
					{

						if (CTitleManager::Instance()->IsEarned(l))
						{
							CTitleManager::Instance()->RemoveEarned(l);
						}
					}
#endif	// __CLIENT
				}
#ifdef __ZCK_BADGE
				{
					vector<int> vecZckSafeBadges;
					if (!ZckBadgeReadList(ar, vecZckSafeBadges))
					{
						// Flux incoherent : la liste est videe et la lecture
						// continue. Sortir ici laisserait tout ce qui suit
						// non lu.
						vecZckSafeBadges.clear();
					}

					GetZckOwnedBadges() = vecZckSafeBadges;
					SetZckBadge(ZckBadgeSanitizeSelected(GetZckBadge(), vecZckSafeBadges));
				}
#endif // __ZCK_BADGE
#ifdef __ZCK_PET_GLOW
				{
					// Miroir exact de l'ecriture : un DWORD, en fin de bloc METHOD_NONE.
					DWORD dwZckPetGlow = ZCK_PET_GLOW_NONE;
					ar >> dwZckPetGlow;
					SetZckPetGlow(dwZckPetGlow);
					// Puis un WORD : la geometrie de glow enregistree.
					WORD wZckPetGlowGeo = ZCK_SFX_GEO_NEUTRAL;
					ar >> wZckPetGlowGeo;
					SetZckPetGlowGeo(ZckSfxGeoSanitize(wZckPetGlowGeo));
#ifdef __ZCK_PET_GLOW_STYLES
					// Puis un BYTE : le style de glow enregistre (SetZckPetGlowStyle assainit).
					BYTE byZckPetGlowStyle = (BYTE)ZCK_AURA_STYLE_DEFAULT;
					ar >> byZckPetGlowStyle;
					SetZckPetGlowStyle(byZckPetGlowStyle);
#endif // __ZCK_PET_GLOW_STYLES
#ifdef __ZCK_PET_SELECTION
					// Puis un DWORD : le familier de l'ecran de selection (SetZckPetSelection assainit).
					DWORD dwZckPetSelection = ZCK_PET_SELECTION_NONE;
					ar >> dwZckPetSelection;
					SetZckPetSelection(dwZckPetSelection);
#endif // __ZCK_PET_SELECTION
				}
#endif // __ZCK_PET_GLOW
			}
			else if (CObj::GetMethod() == METHOD_EXCLUDE_ITEM)
			{
#ifdef __FL_WARDROBE
				m_Wardrobe.Serialize(ar, false);
#endif
#if defined (__WORLDSERVER) || defined(__CLIENT)
				char szPVendor[MAX_VENDORNAME] = { 0, };
				ar.ReadString(szPVendor, MAX_VENDORNAME);
				m_vtInfo.SetTitle(szPVendor);
#endif
				for (int i = 0; i < MAX_HUMAN_PARTS; i++)
					m_aEquipInfo[i].dwId = NULL_ID;

				u_char uSize;
				ar >> uSize;
				u_char uParts;
				u_short	u2;
				for (u_char uCount = 0; uCount < uSize; uCount++)
				{
					ar >> uParts;
					ar >> u2;
					m_aEquipInfo[uParts].dwId = (DWORD)u2;
					ar >> m_aEquipInfo[uParts].byFlag;
				}

				DWORD dwPetId;
				ar >> dwPetId;
				SetPetId(dwPetId);
#ifdef __PET_1024
				char szPetName[MAX_PET_NAME] = { 0, };
				ar.ReadString(szPetName, MAX_PET_NAME);
#ifdef __CLIENT
				m_pet.SetName(szPetName);
#endif	// __CLIENT
#endif	// __PET_1024
			}

#if defined(__WORLDSERVER) || defined(__CLIENT)
			OnApplySM();
#endif	// __WORLDSERVER	// __CLIENT

		}
		else	// NPC
		{
#if defined (__FL_PLAYER_STATUE) || defined (__FL_VENDORS)
			SerializeAbnormalNpc(ar);
#endif

			ar >> (u_char&)m_dwHairMesh >> m_dwHairColor >> (u_char&)m_dwHeadMesh;
			ar.ReadString(m_szCharacterKey, 32);
#if defined(__ZCK_DIFFICULTY) && (defined(__WORLDSERVER) || defined(__CLIENT))
			ar >> m_fDungeonHpFactor;
#endif
#if defined (__WORLDSERVER) || defined(__CLIENT)
			SetHairColor(m_dwHairColor);
#endif	// __WORLDSERVER	//__CLIENT

#if !defined (__FL_PLAYER_STATUE) && !defined (__FL_VENDORS)
			for (int i = 0; i < MAX_HUMAN_PARTS; i++)
				m_aEquipInfo[i].dwId = NULL_ID;
#endif
			u_char uSize;
			ar >> uSize;
			if (IsEquipableNPC())
			{
				u_char uParts;
				u_short	u2;
				for (u_char uCount = 0; uCount < uSize; uCount++)
				{
					ar >> uParts;
					ar >> u2;
					m_aEquipInfo[uParts].dwId = (DWORD)u2;
				}
			}

			m_bActiveAttack =
				m_nMovePattern =
				m_nMoveEvent =
				0;

			ar >> (u_char&)m_bActiveAttack;
			ar >> (u_char&)m_nMovePattern;
			ar >> (u_char&)m_nMoveEvent;
			ar >> m_nMoveEventCnt;
#ifdef __CLIENT
			if (*m_szCharacterKey)
			{
				LPCHARACTER pCharacter = prj.GetCharacter(m_szCharacterKey);
				if (pCharacter)
				{
					_tcscpy(m_szName, pCharacter->m_strName);
					AllocShopInventory(pCharacter);
				}
			}
#endif	// __CLIENT
			ar >> m_fSpeedFactor;
#if defined(__ZCK_PET_GLOW) && (defined(__WORLDSERVER) || defined(__CLIENT))
			// Miroir exact de l'ecriture : un DWORD puis un WORD, pour AII_PET
			// seulement (dwAIInterface : valeur lue en tete de ce Serialize).
			if (dwAIInterface == AII_PET)
			{
				DWORD dwZckPetGlow = ZCK_PET_GLOW_NONE;
				ar >> dwZckPetGlow;
				SetZckPetGlow(dwZckPetGlow);
				WORD wZckPetGlowGeo = ZCK_SFX_GEO_NEUTRAL;
				ar >> wZckPetGlowGeo;
				SetZckPetGlowGeo(ZckSfxGeoSanitize(wZckPetGlowGeo));
#ifdef __ZCK_PET_GLOW_STYLES
				// Puis un BYTE : le style affiche (SetZckPetGlowStyle assainit).
				BYTE byZckPetGlowStyle = (BYTE)ZCK_AURA_STYLE_DEFAULT;
				ar >> byZckPetGlowStyle;
				SetZckPetGlowStyle(byZckPetGlowStyle);
#endif // __ZCK_PET_GLOW_STYLES
			}
#endif // __ZCK_PET_GLOW
#ifdef __FL_WORLDBOSS
			ar >> m_bWorldBoss;

			if (m_bWorldBoss)
			{
				m_mapAttackersDamage.clear();

				size_t nSize;
				ar >> nSize;

				for (size_t i = 0; i < nSize; i++)
				{
					u_long idPlayer;
					__int64 n64Damage;

					ar >> idPlayer;
					ar >> n64Damage;

					m_mapAttackersDamage[idPlayer] = n64Damage;
				}
			}
#endif
		}

		m_buffs.Serialize(ar);

#ifdef __CLIENT
		AutoSynchronizer()->Initialize();
#endif

	} // LOADING

#ifdef __CLIENT
	m_fDestScale = GetScale().x;
	if (m_fDestScale > 10.0f)
		Error("SerializeOpt:%f %s", m_fDestScale, GetName());
#endif
}

#if defined (__FL_PLAYER_STATUE) || defined (__FL_VENDORS)
void CMover::SerializeAbnormalNpc(CAr& ar)
{
	if (ar.IsStoring())	// STORING
	{
#if defined (__WORLDSERVER) || defined(__CLIENT)
		int nNpcType = GetNpcType();
		u_long idNpcOwner = GetNpcOwner();

		ar << nNpcType;
		ar << idNpcOwner;

		if (nNpcType != NPC_TYPE_NORMAL)
			ar.WriteString(m_szName);

		if (nNpcType == NPC_TYPE_PLAYERSTATUE || nNpcType == NPC_TYPE_VENDOR_HUMAN)
		{
			ar << (u_char)m_nJob;
			ar << (u_short)m_nLevel;
			if (m_idGuild > 0)
			{
				ar << (u_char)1;
				ar << m_idGuild;
			}
			else
			{
				ar << (u_char)0;
			}

			for (int i = 0; i < MAX_HUMAN_PARTS; i++)
			{
				ar << m_aEquipInfo[i].dwId;
				ar << m_aEquipInfo[i].nOption;
			}

#ifdef __FL_WARDROBE
			m_Wardrobe.Serialize(ar, false);
#endif

#ifdef __FL_PLAYER_STATUE
			if (nNpcType == NPC_TYPE_PLAYERSTATUE)
#ifdef __ZCK_AURA_STATUE
			{
				ar << m_nPlayerStatueType;
				// Aura du personnage represente : DWORD code, WORD geometrie, BYTE
				// style, juste apres le type de statue, pour tout client qui recoit
				// la statue (ADD_OBJ). Lecture symetrique ci-dessous. Le rendu du
				// set (+3 a +10) du client lit ces valeurs comme pour un joueur
				// (CMover::CreateAbilityOption_SetItemSFX, CSfxPartsLinkShoulder).
				ar << GetZckAura();
				ar << GetZckAuraGeo();
				ar << GetZckAuraStyle();
#ifdef __ZCK_ELEMENT_RGB
				// Element RGB du personnage represente (deux DWORD, droite puis
				// gauche), juste apres son aura. Lecture symetrique ci-dessous.
				ar << GetZckElementRgb(ZCK_ELEMENT_RGB_HAND_RIGHT);
				ar << GetZckElementRgb(ZCK_ELEMENT_RGB_HAND_LEFT);
#endif // __ZCK_ELEMENT_RGB
			}
#else // __ZCK_AURA_STATUE
				ar << m_nPlayerStatueType;
#endif // __ZCK_AURA_STATUE
#endif
		}

		if (nNpcType == NPC_TYPE_VENDOR_HUMAN || nNpcType == NPC_TYPE_VENDOR_NPC)
		{
			std::string title(m_vtInfo.GetTitle());
			title.resize(MAX_VENDORNAME);
			ar.WriteString(title.c_str());
		}
#endif
	}
	else
	{
#if defined (__WORLDSERVER) || defined(__CLIENT)
		int nNpcType = NPC_TYPE_NORMAL;
		u_long idNpcOwner = NULL_ID;

		ar >> nNpcType;
		ar >> idNpcOwner;

		SetNpcType(nNpcType);
		SetNpcOwner(idNpcOwner);

		if (nNpcType != NPC_TYPE_NORMAL)
			ar.ReadString(m_szName, 64);

		if (nNpcType == NPC_TYPE_PLAYERSTATUE || nNpcType == NPC_TYPE_VENDOR_HUMAN)
		{
			m_nJob = m_nLevel = 0;
			ar >> (u_char&)m_nJob;
			ar >> (u_short&)m_nLevel;

			u_char u1;
			ar >> u1;
			if (u1 == 1)
			{
				ar >> m_idGuild;
			}

			for (int i = 0; i < MAX_HUMAN_PARTS; i++)
			{
				ar >> m_aEquipInfo[i].dwId;
				ar >> m_aEquipInfo[i].nOption;
			}

#ifdef __FL_WARDROBE
			m_Wardrobe.Serialize(ar, false);
#endif
#ifdef __FL_PLAYER_STATUE
			if (nNpcType == NPC_TYPE_PLAYERSTATUE)
#ifdef __ZCK_AURA_STATUE
			{
				ar >> m_nPlayerStatueType;
				// Miroir exact de l'ecriture : un DWORD, un WORD, un BYTE.
				DWORD dwZckAura = ZCK_AURA_NONE;
				ar >> dwZckAura;
				SetZckAura(dwZckAura);
				WORD wZckAuraGeo = ZCK_SFX_GEO_NEUTRAL;
				ar >> wZckAuraGeo;
				SetZckAuraGeo(ZckSfxGeoSanitize(wZckAuraGeo));
				BYTE byZckAuraStyle = (BYTE)ZCK_AURA_STYLE_DEFAULT;
				ar >> byZckAuraStyle;
				SetZckAuraStyle(byZckAuraStyle);
#ifdef __ZCK_ELEMENT_RGB
				// Miroir exact de l'ecriture : deux DWORD, droite puis gauche ;
				// SetZckElementRgb assainit.
				DWORD dwZckElementRgbRight = ZCK_ELEMENT_RGB_NONE;
				DWORD dwZckElementRgbLeft = ZCK_ELEMENT_RGB_NONE;
				ar >> dwZckElementRgbRight;
				ar >> dwZckElementRgbLeft;
				SetZckElementRgb(ZCK_ELEMENT_RGB_HAND_RIGHT, dwZckElementRgbRight);
				SetZckElementRgb(ZCK_ELEMENT_RGB_HAND_LEFT, dwZckElementRgbLeft);
#endif // __ZCK_ELEMENT_RGB
			}
#else // __ZCK_AURA_STATUE
				ar >> m_nPlayerStatueType;
#endif // __ZCK_AURA_STATUE
#endif
		}
		else
		{
			for (int i = 0; i < MAX_HUMAN_PARTS; i++)
				m_aEquipInfo[i].dwId = NULL_ID;
		}

		if (nNpcType == NPC_TYPE_VENDOR_HUMAN || nNpcType == NPC_TYPE_VENDOR_NPC)
		{
			char szPVendor[MAX_VENDORNAME] = { 0, };
			ar.ReadString(szPVendor, MAX_VENDORNAME);
			m_vtInfo.SetTitle(szPVendor);
		}
#else
		for (int i = 0; i < MAX_HUMAN_PARTS; i++)
			m_aEquipInfo[i].dwId = NULL_ID;
#endif
	}
}
#endif
