// Config
#define	__VER 18							        //| "Version"
#define __ZCK_LANG_FR								// Langue francaise V18 + clavier AZERTY et taskbar
#define __LOCAL_TESTS TRUE					        //| TRUE = Local | FALSE = Live 
#define __NEUZ_IPSET __LOCAL_TESTS == TRUE ? "127.0.0.1" : "185.246.87.54"		 
#define	__NEUZ_MSGVR "f12538dg1h26z"				//| Patch Version
#define	__NEUZ_TITLE "FlyFF"				        //| Neuz Wnd Title
#define __NEUZ_PHASH "kikugalanet"			        //| Password hash
#define	__NEUZ_BOOTS __LOCAL_TESTS == TRUE ? "" : "sunkist"		
#define	__MAX_SPEED	 500					        //| Max speed 

// Zacks système.

#define __ZCK_WEATHER             // Ajustements météo visuels V21 adaptés pour v18
#define __ZCK_SFX        	      // Ajustements SFX V21 réellement utiles adaptés pour v18
#define __ZCK_INTERFACE_GLOBAL    // Centre global des systemes custom V18
#define __ZCK_INTERFACE_V19       // Interface graphique V21
#define __ZCK_TOOLTIP             // Alignement et rendu fiable des tooltips V19
#define __ZCK_DIFFICULTY          // Difficulté sécurisée des donjons instanciés
#define __ZCK_PROGRESSION         // Progression temps reel des donjons instancies
#define __ZCK_CLASSEMENT          // Classement de donjons : Livre des Records / Hall of Fame
#define __ZCK_SCORE_ARENE         // Classement PvP de l'arene : rang, joueur, guilde, classe, kills, morts et ratio
#define __ZCK_SFX_VIEWPORTS       // Synchronisation SFX upgrade et effets armes/elements dans les viewports
#define __ZCK_AILES_SFX           // Ailes visuelles basees sur un effet SFX, portees sur PARTS_MASK / IK3_AILES_SFX
#define __ZCK_CARTE_MARCHE        // Carte V19 : WdMarket (WI_WORLD_MARKET) affiche sa propre carte (CASHAREA_MARKET)
#define __ZCK_RARE                // Systeme de rarete des armes et des armures (IK3_SUIT uniquement)
#define __ZCK_NIVEAU_ARME         // Niveau d'arme configurable via ZckArmeNiveau.inc
#ifdef __ZCK_RARE
#define ZCK_RARE_MAX_LEVEL       10
#define ZCK_RARE_SCROLL_ITEM_ID  7031
#endif
#define __ZCK_ARME_REBORN         // Arme Reborn : passage d'une arme de rarete maximale en Reborn au PNJ Bobochan, +7 % sur les bonus de rarete, 10 emplacements de pierres Reborn (propItem), icone Reborn (aucun SQL)
#ifdef __ZCK_ARME_REBORN
#ifndef __ZCK_RARE
#error __ZCK_ARME_REBORN requiert __ZCK_RARE
#endif // __ZCK_RARE
#define ZCK_ARME_REBORN_SLOTS    10   // emplacements de pierres Reborn d'une arme Reborn (grille 5 x 2, 5 par rangee)
#endif // __ZCK_ARME_REBORN
#define __ZCK_JOB_FACTOR          // Equilibrage des classes : multiplicateur de degats final par job, PvE / PvP (ZckJobFactor.inc, /zjf, /zjfdps)
#define __ZCK_MONSTRE_FCT         // Degats des boss choisis a la main : fourchette + gros coup cyclique par MI (ZckMonstreFct.inc, /zmf)
#define __ZCK_UPGRADE             // Fenetre d'amelioration administrateur securisee
#define __ZCK_HP_AUCUNE_LIMITE    // HP / MaxHP monstres et boss en 64 bits, sans modifier les stats classiques
#define __ZCK_ACHIEVEMENT         // Achievements configurables : kills, rewards, progression et bonus permanents
#define __ZCK_PRESTIGE            // Prestige personnage configurable
#define __ZCK_LOGIN_VIDEO         // Preview 3D de Madrigal sur login / selection de personnage
#define __ZCK_SYSTEME_EVEIL       // Fenêtre d'éveil.
#define __ZCK_LOADPNG             // Lecture des fichiers PNG
#define __ZCK_ANTICHEAT           // Couche d'integrite serveur : cadence d'attaque, vitesse, filtrage du classement
#define __ZCK_FENETRE_CHAT_MJ     // Supervision MJ des communications et des echanges (AUTH_ADMINISTRATOR)
#define __ZCK_CHAPEAU_ANIMER      // Chapeaux animes : modele O3D anime rendu sur l'os de tete (PARTS_HAT / IK3_CHAPEAU_ANIMER)
#define __ZCK_ANARCHY             // Buffs serveur globaux achetables : ZckAnarchy.inc /za 0
#define __ZCK_AUTH                // Roles Guide / Animateur / Mappeur, autorisations, titres et affichage
#define __ZCK_NPC_TAG             // Tag colore au-dessus des PNJ : TAG( "libelle", 0xAARRGGBB ) dans character.inc
#define __ZCK_INVASION            // Invasions automatiques : ZckInvasion.inc /createinvasion
#define __ZCK_COMBAT_MC            // Monster Clash inter-guildes : ZckCombatMC.inc
#define __ZCK_TOUR_INFINI          // Tour infinie : instance a etages solo/groupe, ZckTourInfini.inc, classement fichier ZckTourInfini.sav
#define __ZCK_COLOSSEUM            // Colisee : arene de groupe par etapes (donneur __COLOSSEUM), Colosseum.lua + LuaFunc/ColosseumFunc.lua
#define __ZCK_WIKI_MONSTRES       // Wikipedia (monstres) : liste filtrable + invocation MJ, ZckWikiMonstres.inc
#define __ZCK_SHOP                // Cash shop : cash et votepoint portes par le personnage
#define __ZCK_CORRECTIF           // Stabilite : link map purgee avant destruction des objets, IA jamais sollicitee par un CMover a demi detruit
#define __ZCK_BADGE               // Badges cosmetiques au-dessus du nom : ZckBadge.txt, onglet Badge de la fenetre personnage
#define __ZCK_APNG                // Textures animees APNG : cache client, repli sur la texture statique, champ Animated de ZckBadge.txt
#define __ZCK_POSITION_H      	  // Fenetre personnage en deux colonnes, positions et libelles dans ZckPositionH.txt
#define __ZCK_SURBRILLANCE_LISTES // Geometrie unique des lignes de liste : surbrillance et trait de separation cales sur la meme bande
#ifdef __ZCK_SURBRILLANCE_LISTES
#define ZCK_LISTE_MARGE_H 2       // Retrait horizontal, en pixels, entre le bord du rectangle client et la bande d'une ligne. 0 = bande collee au cadre.
#endif // __ZCK_SURBRILLANCE_LISTES
#define __ZCK_BUFF_CLASSE         // Buffs accordes selon la classe du personnage : ZckBuffClasse.inc, NPC MMI_NPC_BUFF
#define __ZCK_CUBE                // Drop de cube en donjon instancie, par donjon et par difficulte : ZckCube.inc
#define __ZCK_BUFF_GROUPE         // Propagation des buffs de ZckBuffClasse.inc au groupe : lignee Acolyte, Madrigal hors instance
//#define ZCK_BUFF_GROUPE_LANCEUR_CIBLE_UNIQUE  // Optionnel : supprime AUSSI la diffusion en zone pour le joueur qui clique le PANG. Voir PV4.
//#define ZCK_BUFF_GROUPE_DEBUG                 // TEMPORAIRE : trace de diagnostic en jeu. A recommenter une fois le probleme identifie.
#if defined(__ZCK_BUFF_GROUPE) && !defined(__ZCK_BUFF_CLASSE)
#error "__ZCK_BUFF_GROUPE exige __ZCK_BUFF_CLASSE : il ne distribue aucune liste propre."
#endif // __ZCK_BUFF_GROUPE && !__ZCK_BUFF_CLASSE
#define __ZCK_IMGUI              // Dear ImGui Win32 + DirectX9 : Developer Tools F10
#define __ZCK_LISTE_JOUEURS       // Liste des joueurs connectes : filtres, actions et masquage individuel
#define __ZCK_SPD_LOG             // Journalisation centralisee spdlog : Program\LogsZck
#define __ZCK_TRACY               // Profiling CPU Tracy 0.13.1 : Neuz + WorldServer, active uniquement sous ce define
#define __ZCK_AURA_SYSTEM         // Aura RGB du personnage : couleur libre 0-255 par canal, CHARACTER_TBL.m_nZckAura
#define __ZCK_TRAILS              // Trails du personnage : particules BMP qui suivent le joueur, CHARACTER_TBL.m_nZckTrails / m_nZckTrailsParam
#define __ZCK_PET_GLOW            // Glow RGB du familier buff pet teinte 0-255 par canal, CHARACTER_TBL.m_nZckPetGlow
#define __ZCK_AURA_FENETRE        // Aura du personnage rendue dans les fenetres a modele (inventaire, garde-robe, switch equipement, livre des records) ; retire = SFX de set d'origine dans les fenetres, aura du monde intacte
#define __ZCK_INVENTAIRE_PET      // Familiers (buff pet, familier eleve) affiches dans l'inventaire a cote du personnage, glow du buff pet compris
#define __ZCK_PARTY_INFO          // Fenetre de groupe : carte des membres hors de vue, portee par sPlayerData (aucun SQL, aucun nouveau paquet)
#define __ZCK_MUTATEURS           // Mutateurs de donjon hebdomadaires : ZckMutateurs.inc, /zckmut (aucun SQL, aucune ressource)
#define __ZCK_RENDU              // Chaine de post-traitement DX9 SM3.0 : bloom, FXAA, grading, vignette, nettete, grain ; L2 : SSAO, brouillard, DoF (profondeur INTZ / RESZ) ; L3 : filtrage trilineaire, mipmaps complets, SMAA 1x, rayons de soleil, ombres dynamiques, eau ps_2_0 ; reglages ZckRendu.ini
#define __ZCK_CRYPT_CLIENT       // Contenu du client range dans des archives Zck\*.zck chiffrees (XChaCha20) et signees (EdDSA), lues par CResFile ; outil ZckCryptClientOutil, jeton ZckCryptClient.dev
#define __ZCK_PERIN_BUFF         // Buffs Perin : reserve commune de Perins, 4 paliers (25/50/75/100 Perins = 1 a 4 buffs pour tout le serveur), ZckPerinBuff.inc, ZckPerinBuff.sav, fenetre APP_ZCK_PERIN_BUFF, icone a gauche des buffs mondiaux, /perinbuff (aucun SQL)

//#define __ZCK_IA_FARM            // Auto Farm IA (portage de __FARM_BOT) : module Neuz/ZckIaFarm, fenetre APP_BOTSYSTEMZCK, onglet ImGui "IA Farm", ZckIaFarm.ini, /iafarm // FINI MAIS INUTILE
#define __ZCK_MONDIAL_BUFF       // Buffs mondiaux lies a la population du serveur : ZckMondialBuff.inc, ZckMondialBuff.sav, fenetre APP_ZCK_MONDIAL_BUFF, onglet ImGui "Buff mondial", /mondialbuff (aucun SQL)
#define __ZCK_TRAD_FR            // Textes du jeu en francais : corrections et traductions sous define, accents en octal (encodage historique), TextClient non modifie
#ifdef __ZCK_TRAD_FR
#pragma warning(disable : 4566)  // C4566 : alias coreens corrompus de la table ON_TEXTCMDFUNC (FuncTextCmd.cpp), deja inutilisables, cles non modifiables
#endif // __ZCK_TRAD_FR
#define __ZCK_VIP                // Systeme VIP : parchemins 1/7/14/30 jours portes par les slots SM_VIP1..4 de m_dwSMTime (aucun SQL, aucun paquet)
#ifdef __ZCK_VIP
#define ZCK_VIP_DELAI_AMELIORATION      150             // ms d'attente d'un VIP avant l'envoi d'une amelioration (hors VIP : 4 s inventaire, 1 s amelioration securisee)
#define ZCK_VIP_COUPLE_EXP_PAR_MEMBRE   7               // exp de couple ajoutee par membre VIP a chaque tick de couple (base FlyFF : 1)
#define ZCK_VIP_DUREE_MAX               (366 * 86400)   // borne de securite du dwCircleTime d'un parchemin VIP, en secondes
#define ZCK_VIP_COULEUR_NOM             0xFFE4FF00      // nom d'un joueur VIP au-dessus du personnage (hors MJ, chaotique et PK rose)
#define ZCK_VIP_PREFIXE_NOM             "[VIP] "        // prefixe du nom au-dessus du personnage
#define ZCK_VIP_LIBELLE_FENETRE         "VIP"           // libelle de la ligne ajoutee d'office dans la fenetre personnage (ZckPositionH)
#define ZCK_VIP_COULEUR_ACTIF           0xFF00F000      // fenetre personnage : statut actif
#define ZCK_VIP_COULEUR_INACTIF         0xFFFF0000      // fenetre personnage : statut inactif
#define ZCK_VIP_COULEUR_TITRE           0xFFFF0000      // infobulle de l'icone VIP : titre des avantages
#define ZCK_VIP_COULEUR_TEXTE           0xFF82A8F4      // infobulle de l'icone VIP : liste des avantages
#endif // __ZCK_VIP
#define __ZCK_AJOUT_STAT         // 27 DST en % (95 a 127) : FOR/DEX/INT/END, drop, penyas, soins, degats boss / etats / elements, reductions PvE et PvP (aucun SQL, aucune ressource)
#ifdef __ZCK_AJOUT_STAT
#define ZCK_AJOUT_STAT_POURCENT_MIN     (-90)           // borne basse d'un bonus en % (stats, drop, penyas, soins, degats infliges) : jamais de facteur nul
#define ZCK_AJOUT_STAT_POURCENT_MAX     1000            // borne haute d'un bonus en % : x11 au plus, aucun debordement d'int
#define ZCK_AJOUT_STAT_REDUCTION_MIN    (-100)          // reduction de degats subis la plus basse (vulnerabilite) : degats x2 au plus
#define ZCK_AJOUT_STAT_REDUCTION_MAX    75              // reduction de degats subis la plus haute : jamais d'invulnerabilite, 25 % des degats passent toujours
#endif // __ZCK_AJOUT_STAT
#define __ZCK_AMELIORATION_TICKET // Tickets de monde payant : tickets multi-mondes, changement de canal, carte des joueurs d'un canal, joueurs presents par canal (PaidWorldSet.txt, PaidWorldTicket.txt, layer.inc ; aucun SQL, aucune ressource)
#ifdef __ZCK_AMELIORATION_TICKET
#define ZCK_TICKET_CANAUX_MAX           9               // canaux en plus par monde acceptes dans layer.inc (0 = un seul canal) ; au-dela, la ligne est refusee et le monde garde un seul canal
#define ZCK_TICKET_CARTE_MAX            100             // positions envoyees au plus par carte des joueurs d'un canal (1 a 255)
#define ZCK_TICKET_DELAI_CANAL_MS       10000           // ms minimum entre deux deplacements par ticket d'un meme joueur (anti saut de canal)
#define ZCK_TICKET_DELAI_CARTE_MS       3000            // ms minimum entre deux cartes des joueurs demandees par un meme joueur
#define ZCK_TICKET_ENCADRE_X            5               // encadre "Monde [Canal N]" : coin haut gauche a l'ecran, en pixels (donneur : 5, 120)
#define ZCK_TICKET_ENCADRE_Y            120             // encadre "Monde [Canal N]" : ordonnee du coin haut gauche, en pixels
#define ZCK_TICKET_ENCADRE_ECART        4               // encadre "Monde [Canal N]" : ecart en pixels sous les boutons roulette / boutique (CAdvMgr)
#if defined(__CLIENT) || defined(__WORLDSERVER)
#if !defined(__SYS_TICKET) || !defined(__AZRIA_1023)
#error "__ZCK_AMELIORATION_TICKET exige __SYS_TICKET et __AZRIA_1023 (VersionCommon.h de Neuz et du WorldServer)."
#endif
#endif // __CLIENT || __WORLDSERVER
#endif // __ZCK_AMELIORATION_TICKET
#define __ZCK_200 										// MAX_EXPCHARACTER Mis a 210 pour évité un débordement.
#define __ZCK_4_CLASSES          // 4emes classes (portage du donneur __NEWCLASS) : jobs 40-47, 32 skills, onglet 5 de l'arbre de skills, niveau 300
#define __ZCK_SKILLS_VIRTUOS      // Skills Virtuos (35 skills de 4eme classe, 4 Burnout, 2 skills de test) : plafond de skills ULTIMATE par job porte de 4 a 10 (ZCK_MAX_LEGEND_HERO_SKILL_ULTIMATE, MAX_SKILL_JOB 55 -> 61), cases de l'onglet 5 ; donnees propSkill.csv / propSkillAdd.csv / propSkill.txt.txt / defineSkill.h / defineAttribute.h ; exige __ZCK_4_CLASSES
#if defined(__ZCK_SKILLS_VIRTUOS) && !defined(__ZCK_4_CLASSES)
#undef __ZCK_SKILLS_VIRTUOS       // sans les 4emes classes (jobs ULTIMATE, onglet 5), rien a porter : compilation et comportement d'origine
#endif // __ZCK_SKILLS_VIRTUOS sans __ZCK_4_CLASSES
#define __ZCK_BURNOUT             // Burnout (portage Virtuos __BURNOUT_SYSTEM + DST __VIRTUOS_KNOCKBACK / KNOCKBACKDMG / CRITICALRESIS / UNBLOCK) : jauge, bouton et 4 stats dans APP_STATUS1, buff aleatoire de 12 min ; exige __ZCK_SKILLS_VIRTUOS
#if defined(__ZCK_BURNOUT) && !defined(__ZCK_SKILLS_VIRTUOS)
#undef __ZCK_BURNOUT              // sans les skills Virtuos (SI_CHEER_BURNOUT*, SA_BURNOUT*_LV1, DST 129 a 132), rien a porter : compilation et comportement d'origine
#endif // __ZCK_BURNOUT sans __ZCK_SKILLS_VIRTUOS
#define __ZCK_PET_GLOW_STYLES     // Styles d'aura sur le glow du familier ramasseur (Flamme, Foudre, Impulsion, Soleils, Elfes, Simen) : fenetre APP_ZCK_AURA_PET, rendu, reseau, persistance (bits 5..3 de m_nRemainLP, partages avec le style de l'aura), inventaire ; exige __ZCK_PET_GLOW et __ZCK_AURA_SYSTEM
#if defined(__ZCK_PET_GLOW_STYLES) && (!defined(__ZCK_PET_GLOW) || !defined(__ZCK_AURA_SYSTEM))
#undef __ZCK_PET_GLOW_STYLES      // sans le glow ou sans l'aura (table des styles, colonne partagee), les styles du familier se retirent d'eux-memes : compilation et comportement d'origine
#endif // __ZCK_PET_GLOW_STYLES sans __ZCK_PET_GLOW ou __ZCK_AURA_SYSTEM
#define __ZCK_PET_SELECTION       // Familier ramasseur (modele, glow, geometrie et style) a cote du personnage a l'ecran de selection : colonne morte m_dwRideItemIdx reutilisee, champs ajoutes en fin d'enregistrement de PACKETTYPE_PLAYER_LIST ; exige __ZCK_PET_GLOW et __ZCK_INVENTAIRE_PET
#if defined(__ZCK_PET_SELECTION) && (!defined(__ZCK_PET_GLOW) || !defined(__ZCK_INVENTAIRE_PET))
#undef __ZCK_PET_SELECTION        // sans le glow (identite du familier) ou sans la vitrine de l'inventaire (placement et rendu), l'ecran de selection reste celui d'origine
#endif // __ZCK_PET_SELECTION sans __ZCK_PET_GLOW ou __ZCK_INVENTAIRE_PET
#define __ZCK_PET_GLOW_HUD        // Fenetre du glow du familier (APP_ZCK_AURA_PET) en HUD comme l'aura HUD : grille dessinee par le code, deux viewports 3D (glow actuel / apercu) sur un modele du familier propre a la fenetre et un SFX de glow par vue, textes TID_ZCK_PET_GLOW_HUD_* ; retire = fenetre d'origine ; exige __ZCK_PET_GLOW (styles __ZCK_PET_GLOW_STYLES facultatifs)
#if defined(__ZCK_PET_GLOW_HUD) && !defined(__ZCK_PET_GLOW)
#error "__ZCK_PET_GLOW_HUD exige __ZCK_PET_GLOW : la fenetre remplace CWndZckPetGlow et rend le glow par les services de CZckPetGlow (CreateSfxModel, ResolveAnchor, GetAnchor, BeginRenderTint)."
#endif // __ZCK_PET_GLOW_HUD sans __ZCK_PET_GLOW
#define __ZCK_PLAGE               // Commande MJ /cnplage : invoque d'un coup chaque monstre d'une plage d'ID autour du MJ (test des monstres importes) /cnplage 1817 1957 1
#ifdef __ZCK_PLAGE
// Utilisation (droits AUTH_GAMEMASTER2, comme /cn) : /cnplage <ID debut> <ID fin> [0|1]   (alias /cnp)
//   /cnplage 1817 1957     -> chaque monstre de 1817 a 1957, une fois chacun, PAS agressifs
//   /cnplage 1817 1957 0   -> pareil : 0 = pas agressif (il ne se bat que si on l'attaque)
//   /cnplage 1817 1957 1   -> 1 = agressif (il attaque de lui-meme les joueurs proches, comme un monstre agressif du respawn)
// Les monstres sont poses en grille centree sur le MJ (meme monde, meme couche, au sol comme le respawn officiel) ;
// aucun n'apparait sur le MJ. Les ID sans monstre et les PNJ sont ignores. Un bilan s'affiche dans le chat :
// monstres invoques, ID absents du propMover du serveur, PNJ ignores, cases hors carte, echecs de creation.
// Monstres de test : ils ne reapparaissent pas une fois tues. Code : FuncTextCmd.cpp (TextCmd_ZckPlage
// + ligne de la table des commandes) ; recompiler Neuz ET WorldServer (le client doit connaitre la commande).
#define ZCK_PLAGE_MAX                   200             // nombre maximal d'ID par commande
#define ZCK_PLAGE_ECART                 5.0f            // ecart en metres entre deux monstres de la grille
#endif // __ZCK_PLAGE
#define __ZCK_PLAGE_OBJET         // Commande MJ /ciplage : cree d'un coup un exemplaire de chaque objet d'une plage d'ID dans l'inventaire du MJ /ciplage 8530 8594
#ifdef __ZCK_PLAGE_OBJET
// Utilisation (droits AUTH_GAMEMASTER2, comme /ci) : /ciplage <ID debut> <ID fin>   (alias /cip)
//   /ciplage 5500 5650     -> un exemplaire de chaque objet de 5500 a 5650 (ID de defineItem.h), dans l'inventaire du MJ
// /ci reste inchange : /ci <ID> <quantite> cree toujours un seul objet (son 2e nombre est une quantite, pas une fin de plage).
// Au plus ZCK_PLAGE_OBJET_MAX objets crees par commande (inventaire de 168 places). Si la limite est atteinte ou si
// l'inventaire est plein, la commande s'arrete proprement et donne la commande exacte pour reprendre a l'ID suivant.
// Memes objets que /ci : objets virtuels et oeufs autres que II_PET_EGG refuses ; ID sans objet ignores (aucune erreur
// "range_error" : la borne du tableau des objets est verifiee avant chaque lecture). Bilan dans le chat.
// Code : FuncTextCmd.cpp (TextCmd_ZckPlageObjet + ligne de la table des commandes) ; recompiler Neuz ET WorldServer.
#define ZCK_PLAGE_OBJET_MAX             150             // nombre maximal d'objets crees par commande
#define ZCK_PLAGE_OBJET_PLAGE_MAX       1000            // nombre maximal d'ID parcourus par commande (securite contre une faute de frappe)
#endif // __ZCK_PLAGE_OBJET
#define __ZCK_BOITES_FASHION      // Boites des costumes importes (ZckBoitesFashion) : MAX_PACKITEM (Project.h) porte de 1024 a 4096
#ifdef __ZCK_BOITES_FASHION
// CPackItem (Project.h) charge au plus MAX_PACKITEM - 1 boites PackItem (propPackItem.inc) : 1023 avec la valeur
// d'origine 1024. V18.2 en avait deja 499 et les boites des costumes importes en ajoutent 713 : au-dela de la
// limite, LoadPackItem s'arrete sans message et les boites suivantes ne s'ouvrent plus (ni leur apercu au survol).
// Le tableau statique CPackItem::m_packitem passe de 1024 a 4096 elements de 396 octets (1,6 Mo).
// Recompiler WorldServer ET Neuz (les deux chargent propPackItem.inc).
#define ZCK_BOITES_FASHION_MAX          4096            // nouvelle valeur de MAX_PACKITEM (Project.h)
#endif // __ZCK_BOITES_FASHION
#define __ZCK_CLEAN_INVENTAIRE    // Commande MJ /cleaninventaire : vide d'un coup les cases du sac du MJ (tests), equipement porte conserve
#ifdef __ZCK_CLEAN_INVENTAIRE
// Utilisation (droits AUTH_GAMEMASTER2, comme /ci et /irm) : /cleaninventaire   (alias /cleaninv), sans argument.
// Vide les cases du sac (MAX_INVENTORY, 168 avec __INVENTORY_168_SLOTS) de l'inventaire du MJ qui tape la commande.
// Sont conserves : l'equipement porte ; le familier invoque et les objets en cours d'utilisation (CMover::IsUsing) ;
// les objets poses dans un echange ou dans la boutique personnelle (GetExtra). Penyas et banque ne sont pas touches.
// Meme regle de suppression que /irm (TextCmd_InvenRemove, inchange), avec un bilan dans le chat.
// Code : FuncTextCmd.cpp (TextCmd_ZckCleanInventaire + ligne de la table des commandes) ; recompiler Neuz ET WorldServer.
#endif // __ZCK_CLEAN_INVENTAIRE
#define __ZCK_FRAMEOS             // Pieces animees (ex. feu de item_WeaBowFire.o3d) : animation propre jouee en boucle sur sa longueur au lieu d'etre coupee par le mouvement du personnage, plus de lecture hors limites ; message LoadElement 4 lisible (client)
#define __ZCK_MOUNTURE_VOLANTE    // Montures volantes : vol des montures Titanium porte sans son bug (rafales de vitesse quand on tourne la camera en vol) ; clic droit sur la monture equipee dans l'inventaire -> Voler / Atterrir ; Mount.inc : SetMount( __MOUNT_WALK_FLY ) + SetFlightSpeed( v ) ; exige __SYS_MOUNT ; recompiler Neuz ET WorldServer
#define __ZCK_BOITE_3D            // Visionneuse de modeles (__MODEL_VIEW, client seul) : mains corrigees comme dans Reborn Final (__ZACKS_FIX_MODELVIEWER : arme a deux mains ou arc et bouclier jamais ensemble) ; Ctrl gauche + clic dans la boutique du PNJ (APP_SHOP_) et l'inventaire = apercu + infobulle de l'objet ; boite de tenue (PackItem) essayee en entier ; monture (IK3_MOUNT, __SYS_MOUNT) montree seule ; aucun SQL, aucune ressource ; recompiler Neuz seul
#define __ZCK_CHANGEMENT_TOUCHE   // Touches configurables (portage Titanium __CHANGE_HOT_KEY + __AEGON_HOTKEY_F_KEYS + __AEGON_FOLLOW_HOTKEY) : onglet Touches de la fenetre Options, F11 a F24 pour les fenetres, touche Suivre = suivre le joueur cible, touches enregistrees par compte (ZckTouches\compte_<nom>.ini, une touche = une action) ; client seul : aucun SQL, aucune ressource, aucun paquet ; recompiler Neuz seul
#define __ZCK_VOIR_INVENTAIRE_JOUEURS // Voir l'inventaire d'un joueur connecte (portage Titanium __AEGON_VIEW_INV, en lecture seule) : clic droit sur un joueur > Voir l'inventaire / Voir le coffre, ou /voirinventaire <nom> [coffre] ; MJ seulement (AUTH_GAMEMASTER2), le WorldServer juge tout, aucune commande d'objet ; fenetre APP_QUERYINVENTORY sur la mise en page de APP_INVENTORY ; aucun SQL, aucune ressource ; recompiler Neuz ET WorldServer
#define __ZCK_CHANGE_DST_NIVEAU   // Changement de la caracteristique du niveau d'arme (portage recode de __WEAPON_DST_CHANGE, RebornMMO FINAL) : Parchemin de changement de stats d'arme II_CHR_SYS_SCR_CHANGEDST (7438), fenetre APP_ZCK_CHANGE_DST_NIVEAU ; FOR / END / DEX / INT de ZckArmeNiveau.inc, le WorldServer juge tout, le bonus garde sa valeur ; champ deja sauvegarde m_dwZckArmeNiveauStat : aucun SQL ; exige __ZCK_NIVEAU_ARME ; recompiler Neuz ET WorldServer
#if defined(__ZCK_CHANGE_DST_NIVEAU) && !defined(__ZCK_NIVEAU_ARME)
#undef __ZCK_CHANGE_DST_NIVEAU    // sans le niveau d'arme, aucune caracteristique a changer : compilation et comportement d'origine
#endif // __ZCK_CHANGE_DST_NIVEAU sans __ZCK_NIVEAU_ARME
#define __ZCK_LOG_DROP            // Journal des drops a gauche de l'ecran (portage recode de Titanium __DROP_LOG) : objets et penyas ramasses ou remis par un monstre, le WorldServer decide de chaque entree (SNAPSHOTTYPE_ZCK_LOG_DROP 0x897D) ; icones PNG animees par ZckApng comme les badges ; remplace la ligne de chat "Vous avez recu" de ces seuls objets et penyas ; aucun SQL, aucune ressource ; recompiler Neuz ET WorldServer
#define __ZCK_MASQUERADE          // Pack de textures Masquerade (portage recode de Sakura __MASQUERADE, client seul) : case "Textures Masquerade" de l'onglet video des Options (neuz.ini Masquerade 0/1), appliquee en jeu des le clic, sans relancer le client ; textures des modeles lues dans Model\Masquerade, du terrain dans World\Masquerade, fichiers .sfx et leurs textures dans SFX_M et SFX_M\Texture, fichier par fichier, avec repli sur le dossier d'origine si le fichier y manque ; aucun SQL, aucun paquet, serveurs non concernes
//#define __ZCK_MINIJEU_PVP       // Minijeux PvP : Tic-Tac-Toe, Connect Four et Fluno [DEV] PROCHAINE VER
#define __ZCK_LINK                // Lien d'objet dans le chat (portage recode de __ITEMLINK, RebornMMO FINAL) : Alt + clic gauche ou glisser-deposer d'un objet de l'inventaire dans la saisie du chat ; le WorldServer valide, reecrit et garde une copie 15 min, relayee aux autres canaux par le CoreServer (paquets 0x8810035E / 0x8810035F, snapshot 0x897E) ; couleurs de rarete, rendu Reborn et niveau d'arme calcules par chaque client ; fenetre APP_TOOLTIP_LINKEDITEM deja declaree ; aucun SQL, aucune ressource ; recompiler Neuz, WorldServer ET CoreServer
#define __ZCK_INTERFACE_CONNEXION // Fenetres de connexion refaites : interrupteur general, chacune garde son propre define juste en dessous (pour l'instant __ZCK_SELECTION_REBORN) ; retire = fenetres d'origine
#define __ZCK_SELECTION_REBORN    // Fenetre de selection du personnage refaite : theme noir, titre REBORN, HUD
#if defined(__ZCK_SELECTION_REBORN) && !defined(__ZCK_INTERFACE_CONNEXION)
#undef __ZCK_SELECTION_REBORN     // sans __ZCK_INTERFACE_CONNEXION, la fenetre de selection reste celle d'origine
#endif // __ZCK_SELECTION_REBORN sans __ZCK_INTERFACE_CONNEXION


// New DEFINED content.
#define __ZCK_FISH_AND_QOL        // Peche et familiers (portage recode de Sakura : MAX_FISH_BY_IP, __COLLECT_EXTRA, NEW_PET, __PET_AUTO_LEVEL_UP, __PET_EXP, __NO_PET_LIFE, __HIDEPETS ; __PET_COLLISION et __EATPET_STATS deja natifs) : (1) peche = collecteur : la canne a peche de Sakura (modeles et icone, ressources), au bord de l'eau seulement (eau a ZCK_FAQ_DISTANCE_EAU m au plus, pas en vol ; la zone de collecte n'est plus exigee), les 6 poissons ajoutes au bloc Collecting_Item de collecting.inc (0,25 % chacun), tirage sans biais par le WorldServer seul, au plus ZCK_FAQ_MAX_PECHEURS_PAR_IP pecheurs par IP et par canal ; (2) 7 familiers ultimes, types 7 a 13 (Phenix, Renard legendaire, Licorne enchantee, Oriantus, Chocobo, Gryphona, Poisson venimeux : bloc ZckAvailDestParam de pet.inc) et leurs 7 parchemins, a utiliser sur un oeuf invoque ; (3) familiers D a A montes de niveau des 100 % d'experience ; (4) experience de familier gagnee en tuant des monstres, nourriture refusee ; (5) familiers sans vies : aucune perte a la mort du maitre, objets de vie refuses sans etre consommes ; (6) onglet Jeu des options : Masquer les familiers (modele, nom, ombre, glow, aura, effets) et Familiers non ciblables (neuz.ini) ; aucun SQL, aucun paquet ; recompiler Neuz, WorldServer ET DatabaseServer ; avant de retirer ce define, aucun familier de type 7 a 13 ne doit rester en jeu
#ifdef __ZCK_FISH_AND_QOL
#define ZCK_FAQ_MAX_PECHEURS_PAR_IP        5           // MAX_FISH_BY_IP : personnages qui collectent en meme temps depuis une meme IP, sur un meme canal (chaque WorldServer compte ses joueurs)
#define ZCK_FAQ_DISTANCE_EAU               8           // peche : eau a 8 metres au plus du personnage, au sol (points tous les 2 m : nombre pair)
#define ZCK_FAQ_PROFONDEUR_EAU_MAX         1.5f        // peche : au plus 1,5 metre d'eau au-dessus des pieds du personnage (au bord ou dans l'eau peu profonde)
#define ZCK_FAQ_HAUTEUR_EAU_MAX            8.0f        // peche : pieds au plus 8 metres au-dessus de la surface de cette eau (haut d'une falaise, pont trop haut)
#define ZCK_FAQ_EXP_OEUF_PAR_MONSTRE       1500        // __PET_EXP : experience d'un oeuf par monstre tue (MAX_PET_EGG_EXP 50000 : oeuf pret a eclore)
#define ZCK_FAQ_EXP_FAMILIER_PAR_MONSTRE   1500        // __PET_EXP : experience d'un familier D a A par monstre tue, divisee par son niveau (MAX_PET_EXP 100000 = 100 %)
#define ZCK_FAQ_ECART_NIVEAU_MONSTRE       5           // __PET_EXP : le monstre compte s'il a au moins le niveau du joueur moins 5
#define ZCK_FAQ_DIVISEUR_DST_EXP_FAMILIER  125         // __PET_EXP : DST_PET_EXPERIENCE multiplie l'experience par (1 + valeur / 125), comme chez Sakura
#define ZCK_FAQ_COULEUR_REFUS              0xFFFF6060  // messages de refus : peche (limite par IP, bord de l'eau), nourriture, objets de vie, parchemins
#else
#line 215 // __ZCK_FISH_AND_QOL
#endif // __ZCK_FISH_AND_QOL
#define __FL_BUYBACK
#define __FL_DPS_UI
#define __FL_CATCH_THE_PET
#define __FL_MONSTER_TOTEMS
#define __FL_WIKI_HONORS
#define __FL_SEASON_PASS
#define __FL_WARDROBE
#define __FL_ANI_WINGS
#define __EXTRA_TASKBARS
#define __FL_NEW_PET
#define __FL_ITEM_RUNE
#define __FL_TASKBAR_ONLINE_COUNTER
#define __connection_limitation 8
#define __post_collect_delete
#define __FL_STARTER_ITEMS
#define __FL_AUTO_POWERUPS
#define __FL_STACKABLE_POWERUPS
#define __FL_QUICK_SELL
#define __FL_WIKI_UPGRADE
#define __FL_WIKI_AWAKENING
#define __FL_GUARANTEED_UPGRADE
#define __FL_WORLDBOSS
#define __SYS_MOUNT
#define __SYS_MOUNT_SFX
#if defined(__ZCK_MOUNTURE_VOLANTE) && !defined(__SYS_MOUNT)
#undef __ZCK_MOUNTURE_VOLANTE     // sans les montures __SYS_MOUNT, rien a faire voler : compilation et comportement d'origine
#endif // __ZCK_MOUNTURE_VOLANTE && !__SYS_MOUNT
#define __exchanges_ui
#define __FL_AUTO_STAT
#define __FL_PLAYER_STATUE
#define __FL_SET_SFX_VIEWPORT
#if defined(__ZCK_SFX_VIEWPORTS) && !defined(__FL_SET_SFX_VIEWPORT)
#define __FL_SET_SFX_VIEWPORT
#endif // __ZCK_SFX_VIEWPORTS && !__FL_SET_SFX_VIEWPORT
#if defined(__ZCK_AURA_SYSTEM) && !defined(__FL_SET_SFX_VIEWPORT)
#error "__ZCK_AURA_SYSTEM exige __FL_SET_SFX_VIEWPORT : l'aura se greffe sur CreateAbilityOption_SetItemSFX(nAbilityOption, bManageWorld)."
#endif // __ZCK_AURA_SYSTEM && !__FL_SET_SFX_VIEWPORT
#define __ZCK_AURA_STATUE         // Aura du personnage (couleur RGB, contraste, intensite, geometrie, style) portee par sa statue de joueur (__FL_PLAYER_STATUE : MVP et chef de la guerre de guilde, livre des records) : DatabaseServer -> WorldServer -> Neuz, aucun SQL, aucune ressource ; exige __ZCK_AURA_SYSTEM et __FL_PLAYER_STATUE
#if defined(__ZCK_AURA_STATUE) && (!defined(__ZCK_AURA_SYSTEM) || !defined(__FL_PLAYER_STATUE))
#undef __ZCK_AURA_STATUE          // sans l'aura ou sans les statues de joueur, rien a porter : compilation et comportement d'origine
#endif // __ZCK_AURA_STATUE sans __ZCK_AURA_SYSTEM ou __FL_PLAYER_STATUE
#define __ZCK_AURA_HUD            // Fenetre de l'aura (APP_ZCK_AURA) en HUD comme l'achievement : grille dessinee par le code, deux viewports 3D (aura actuelle / apercu) sur des copies du personnage, textes TID_ZCK_AURA_HUD_* ; retire = fenetre d'origine ; exige __ZCK_AURA_SYSTEM, __ZCK_AURA_FENETRE et __FL_SET_SFX_VIEWPORT
#if defined(__ZCK_AURA_HUD) && (!defined(__ZCK_AURA_SYSTEM) || !defined(__ZCK_AURA_FENETRE) || !defined(__FL_SET_SFX_VIEWPORT))
#error "__ZCK_AURA_HUD exige __ZCK_AURA_SYSTEM, __ZCK_AURA_FENETRE et __FL_SET_SFX_VIEWPORT : les viewports montrent l'aura par les SFX geres (CMover::CreateManagedSFX) d'une copie du personnage."
#endif // __ZCK_AURA_HUD sans __ZCK_AURA_SYSTEM, __ZCK_AURA_FENETRE ou __FL_SET_SFX_VIEWPORT
#define __FL_FLARIS_LIGHT
#define __FL_NAVIGATOR_TIME
#define __FL_GEAR_SCORE
#define __FL_PANG_HELPER
#define __ZCK_CUSTOM_UI_CORRECTIF // Portage recode de 9 systemes Titanium. Ajoute : (1) jeux de curseurs (__NEWCUR) et (2) petites icones de bonus (__RENDER_SMALL_POWERUPS), choisis dans l'onglet Jeu des options et gardes dans neuz.ini ; (3) Ctrl + double-clic sur un buff benefique de la fenetre des buffs = retrait demande au WorldServer, qui decide (__REMOVE_SKILL_BUFF, paquet 0x88100360) ; (4) noms du staff en gras (__LEESE_STAFF_BOLD) ; (5) connexion d'un membre du staff annoncee au staff du canal (__LEESE_STAFF_CONNECT) ; (6) echange, banque, courrier, boutique, guilde et deliaison interdits au staff sauf Developpeur (__BLOCK_STAFF_ACTIONS) ; (7) infobulles [Non echangeable] et [Expire] (__TITANIUM_TOOLTIP_OPT) ; correction en plus : boutons a texture (liste deroulante, aide, reduire, agrandir, boussole, points de caracteristiques) sans leur lettre tracee en noir par-dessus. Deja natifs en V18.2, rien d'ajoute : (8) SFX orphelins retires (__FIX_REMOVESFX), (9) infobulle des cartes de percage (__PIERCE_CARD_TOOLTIPS). Aucun SQL ; recompiler Neuz ET WorldServer
#define __ZCK_NOUVEAUX_CORRECTIF  // Interface V19 : boutons V19 de resdata.inc (ButtNormal00/01/02/05.tga) a la place des anciennes textures (ButtOk.tga, ButtCancel.tga, ButtYes.tga, ButtNo.tga, ButOk2.bmp, ButtStart.bmp, ButtStop.bmp, ButtBreakUp.bmp, en-tetes .bmp de la messagerie et des membres de guilde), libelles francais, titre "BTN" retire des icones du logement, texte des cartes de percage en noir et ajuste a la largeur des lignes, compteur des onglets de l'Eveil sans le maximum, fenetre des mini-jeux PvP agrandie de 20 px (boutons de 24 px)
#if defined(__ZCK_NOUVEAUX_CORRECTIF) && !defined(__ZCK_INTERFACE_V19)
#undef __ZCK_NOUVEAUX_CORRECTIF   // sans l'interface V19, aucun bouton V19 a utiliser : compilation et comportement d'origine
#endif // __ZCK_NOUVEAUX_CORRECTIF && !__ZCK_INTERFACE_V19

// Systems & Features
#define __FL_TDM									//| Team vs Team pvp mode
#define __FL_MONSTER_ALBUM							//| Monster Album System
#define __FL_RECORD_BOOK							//| Recordbook
#define __FL_WHEEL_OF_FORTUNE						//| Wheel of fortune
#define __FL_PACKED_ITEMS							//| Ability to pack items into items 
#define __FL_FARM_DISPLAY							//| Remade old farm counter system
#define __FL_GUILD_FINDER							//| Guild Finder
#define __FL_SWITCH_EQ								//| Self made switch equipment system
#define __FL_CASH_SHOP								//| Donate/Vote Shop
#define __FL_PENYA_CONVERTER						//| "Smart" and manual penya -> perins converter
#define __FL_NEW_BOXES								//| Boxes with ability to select item
#define __FL_VENDORS 1								//| Offline Vendors v3
#define __FL_PARTY_FINDER							//| Party Finder
#define __FL_SOLO_DUNGEONS					        //| Solo dungeons
#define __FL_RECYCLE II_SYS_SYS_EVE_TICKECT01       //| System for convert items to specific currency
#define __FL_TELEPORT						        //| Teleporter System
#define __FL_FFA							        //| FFA system
#define __FL_DAILY_REWARDS 					        //| [TODO: Notify Online Players] Daily Rewards
#define __FL_PET_FILTER						        //| New petfilter with more filters + possibility to loot items in bag + presets
#define __FL_SHOP_SEARCH					        //| Shop Search System
#define __FL_SAVE_MESSAGES					        //| Save all private messages while client is active
#define __FL_CONSUMABLES_STORAGE			        //| New item container for power-ups/consumables
#define __FL_DUNGEON_TREASURE				        //| Dungeon treasure system
#define __FL_BATTLE_PASS					        //| Battle Pass System
#define __FL_BOXES_V2						        //| Box Preview & Bulk Opening
#define __FL_PARTY_SORT						        //| Party Sorting
#define __FL_FAST_ELEMENT II_SYS_SYS_SCR_SOKCHANG	//| Fast Element Changer
#define __ZCK_ELEMENT_RGB         // Element RGB : couleur RGB libre des SFX d'element, une par main (arme de droite ; arme de gauche ou bouclier), memes SFX, element inchange, Pierre d'element RGB II_PIERRE_AURA_ELEMENT dans la fenetre du Fast Element Changer, CHARACTER_TBL.m_nZckElementRgb (droite) et m_SkillPoint (gauche, colonne reutilisee) ; exige __FL_FAST_ELEMENT et __ZCK_AURA_SYSTEM
#if defined(__ZCK_ELEMENT_RGB) && (!defined(__FL_FAST_ELEMENT) || !defined(__ZCK_AURA_SYSTEM))
#undef __ZCK_ELEMENT_RGB          // sans la fenetre du Fast Element Changer ou sans la teinte des SFX (ZckSfxTint, partagee avec l'aura), rien a colorer : compilation et comportement d'origine
#endif // __ZCK_ELEMENT_RGB sans __FL_FAST_ELEMENT ou __ZCK_AURA_SYSTEM
#define __FL_EQUALIZED_MODE					        //| [TODO: rework for optimising memory] Equalized System
#define __MODEL_VIEW						        //| Public model viewer
#if defined(__ZCK_BOITE_3D) && !defined(__MODEL_VIEW)
#undef __ZCK_BOITE_3D             // sans la visionneuse de modeles, rien a corriger ni a montrer : compilation et comportement d'origine
#endif // __ZCK_BOITE_3D && !__MODEL_VIEW
#define __CONTAINER_RCLICKS					        //| Right clicks transfer items between inventory <--> containers
#define __CONTAINER_SORTING							//| TODO: recode this system to avoid packets-spam + make it universal for all containers. v21 version - exploitable
#define __INVENTORY_168_SLOTS				        //| 168 Slots in inventory
#define __INVENTORY_RESIZE					        //| Inventory Resize
#define __WIKI_ITEMS_V2						        //| Based on public wiki, but re-written with more filters etc
#define __JOB_CHANGE						        //| Public job changer with some edits, dont use other job-changers if you dont know what you do
#if defined(__ZCK_4_CLASSES) && !defined(__JOB_CHANGE)
#error "__ZCK_4_CLASSES exige __JOB_CHANGE : la montee en 4eme classe passe par APP_CHANGE_JOB_03 et PACKETTYPE_SEND_JOB_CHANGE."
#endif // __ZCK_4_CLASSES && !__JOB_CHANGE
#define __ZCK_CRAFT_LOAD_TEX // Portage recode de 2 systemes Titanium. Ajoute : (1) textures a leur taille reelle (__AEGON_TEX_LOAD) : D3DX_DEFAULT_NONPOW2 quand l'appelant laisse D3DX choisir la taille, repli sur la taille d'origine si la creation echoue, neuz.ini ZckTextureNative (1 par defaut, 0 = comportement d'origine) ; (2) artisanat (__AEGON_CRAFTING_SYSTEM recode sans ses dupes) : fenetre APP_ZCK_CRAFT (/artisanat, menu de la barre des taches, touche configurable), recettes ZckCraft.inc (dossier Resource) lues par le WorldServer seul, paquet 0x88100361 et snapshot 0x897F, le client nomme une recette et jamais un objet, ingredients choisis et retires par le serveur avant la creation avec retour arriere complet, inventaire plein refuse avant tout, anti-spam et anti-rejeu, deconnexion sans perte ni dupe, experience d'artisanat en base (ZCK_CRAFT_TBL, script 11.ZCK_ CRAFT_TBL.sql ; sans lui l'artisanat est refuse, rien n'est ecrit) ; recompiler Neuz, WorldServer ET DatabaseServer
#define __ZCK_QUEST              // Quetes de chasse a horaires (etape 04) : Resource\ZckQuetes.inc lu par le WorldServer seul (catalogue envoye au client, /quete recharger a chaud), heure de debut, heure de fin et duree, jours, mondes (WI_*), niveau et prestige min / max, plusieurs MI par quete, groupe ; recompenses objets, buffs (DwID IK2_BUFF), Penya, EXP ; journal APP_ZCK_QUEST (HUD dessine, redimensionnable, viewport 3D et fiche du monstre) et suivi a l'ecran APP_ZCK_QUEST_SUIVI (masquable, neuz.ini ZckQueteSuivi) ; /quete, menu de la barre des taches, touche configurable ; paquet 0x88100362, snapshot 0x8980 ; colonne CHARACTER_TBL.m_szZckQuest : executer 12.CHARACTER_TBL_ZCK_QUEST.sql puis CHARACTER_STR a jour AVANT de lancer les nouveaux executables (avec l'ancienne procedure le DatabaseServer ne peut plus sauvegarder aucun personnage) ; recompiler Neuz, WorldServer ET DatabaseServer

// Fixes & Addons
#define __ATTR_HIT_FIX								//| Experimental fix from old source to not skip attack in case if animation speed is too big + increased range attacks speed
#define __FL_DST_ATKPOWER_RATE_MAGIC				//| DST_ATKPOWER_RATE_MAGIC first and experimental dst which mostly added to balance psykeepers/mentalists
#define __FL_FIX_LINKMAP_LEVEL						//| Experimental fix
#define __FL_FIX_USELESS_LOGS						//| Disable useless logs
#define __FL_FIX_SHORTCUTCRASH						//| Fix related to unknown itemelem in globalshortcut data
#define __FL_FIX_PLAYERDATA							//| Several fixes for playerdata
#define __FL_FIX_IK2BUFF2					        //| Now possible to add stats on IK2_BUFF2 items
#define __FL_FIX_PROPER_GUILD_COOLDOWN		        //| Proper guild cooldown removal
#define __FL_FIX_IDCHANGE_EXPLOIT			        //| Defined fixes for exploit which allow to change ID of character and be invited to any messenger/guild/party without invite
#define __FL_FIX_MEMORY_LEAKS				        //| Some code to prevent possible client memory leaks
#define __FL_FIX_MAILVALUES					        //| Added missing values (+ MAIL_STR/TBL)
#define __FL_UPDATE_TASKBAR					        //| Static taskbar at centre + switch F1-F9 keys + click effects etc
#define __FL_UPDATE_REAGGRO					        //| Re-aggro by any kind of damage + other updates
#define __FL_UPDATE_CHATTING				        //| CD on worldserver side + possibility to use DOWN button to see next message in history
#define __FL_UPDATE_LORDEVENT				        //| Penya event in lord system
#define __FL_UPDATE_READSTAFF				        //| Improved reading admin/gm characters from file.
#define __FL_UPDATE_PROJECTILES				        //| Increase most projectiles speed
#define __FL_UPDATE_GROUNDITEMS				        //| Name rendering for ground items with some additional updates
#define __AIO										//| Random snippets for quick access
#define __AIO_NEUZAPP						        //| Random snippets for quick access (Neuz)
#define __AIO_PETS							        //| Random snippets for quick access (Pets)
#define __AIO_ADMIN_THINGS					        //| Random snippets for quick access (Staff)
#define __AIO_POSI_RELATED					        //| All test modifications which somehow related to movement/position/casting/etc
#define __FIX_SQL_INJECTS					        //| Protections against broken text which can cause sql inject or just sql related problems
#define __FIX_STUNBUG								//| [Main code only] Defined fixes against stun-bug
#define __NPC_ADDMENU2						        //| AddMenu2 for NPC
#define __TEST_ANISOTROPIC					        //| Some random Anisotropy
#define __TEST_ANTIALIASING					        //| Some random Antialiasing
#define __TEST_PACKET_CRYPT					        //| Some random Packet Cryptage

// Classic Content & Other
#define __V21_CLOSE_EXISTING_CONNECTION				//| Actually should fix rare problem when you cant disconnect your own account
#define __MINIDUMP									//| .dmp generator (neuz/world)
#define __SIZED_SNAPSHOTS_V2						//| https://gist.github.com/SPSquonK/4b0ae08d924b55cc0ccd03b85071ead4
//#define __BUGSPLAT								//| Bugsplat
//#define __DISCORD							        //| Discord RPC (credits to kotori for base)
//#define __VALID_CONNECTION_CONFORMATION			//| From Lykan src
//#define __AI_SYSTEM								//| For testing purposes ONLY