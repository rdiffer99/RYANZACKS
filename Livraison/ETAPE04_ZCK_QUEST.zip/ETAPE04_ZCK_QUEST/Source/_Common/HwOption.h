#ifndef __HWOPTION_H__
#define	__HWOPTION_H__

class COption
{
public:
	TCHAR	m_szFileName[MAX_PATH];
	int		m_nResWidth;
	int		m_nResHeight;

	BOOL	m_bStartFullScreen;
	int		m_nTextureQuality;
	int		m_nObjectDetail;
	int     m_nObjectDistant;
	int     m_nShadow;
	BOOL    m_bOperator;
	DWORD   m_dwChatFilter[5];
	DWORD   m_dwChatFilterEtc;
	int		m_nMonName;
	int		m_nPlayerName;
	int		m_nOtherPlayerName;
	int		m_nToolTipTexture;

	BOOL	m_nWeatherEffect;
	float	m_fEffectVolume;
	float	m_fBGMVolume;
	int     m_nWindowAlpha; // 0 ~ 255
	int     m_nWindowEffect;
	int     m_nInstantHelp;


	BOOL	m_bSay;
	BOOL	m_bTrade;
	BOOL	m_bParty;
	BOOL	m_bMessengerJoin;
	BOOL	m_bMessenger;
#if __VER >= 15 // __IMPROVE_SYSTEM_VER15
	BOOL	m_bBattleBGM;
#endif // __IMPROVE_SYSTEM_VER15

	int		m_nSer;
	int		m_nMSer;

	BOOL    m_bSaveAccount;
	TCHAR   m_szAccount[ 64 ];
	BOOL    m_bNotice;
	int		m_nCurFold;
#ifdef __ZCK_CUSTOM_UI_CORRECTIF
	BOOL	m_bZckPetitsPowerUps;		// petites icones de bonus en haut de l'ecran (neuz.ini SmallPowerUps, onglet Jeu)
	int		m_nZckJeuCurseurs;		// jeu de curseurs choisi, 0 a 7 (neuz.ini ZckCurseurs) ; -1 : celui de nCurFold
#else
#line 47 // __ZCK_CUSTOM_UI_CORRECTIF
#endif // __ZCK_CUSTOM_UI_CORRECTIF
#ifdef __FL_UPDATE_TASKBAR
	BOOL m_bRekeyTask;
#endif
#ifdef __FL_PET_FILTER
	int		m_nLootType;
	BYTE	m_nLootPlace;
#endif
	BOOL m_bNightMode;
#ifdef __ZCK_FISH_AND_QOL
	BOOL	m_bZckFaqMasquerFamiliers;		// familiers caches : modele, nom, ombre, glow, aura, effets (neuz.ini ZckMasquerFamiliers)
	BOOL	m_bZckFaqFamiliersNonCiblables;	// familiers ignores par le clic (neuz.ini ZckFamiliersNonCiblables)
#else
#line 61 // __ZCK_FISH_AND_QOL
#endif // __ZCK_FISH_AND_QOL
#ifdef __AIO_PETS
	BOOL m_bHideWindowLooter;
	BOOL m_bHideWindowPet;
#endif
#ifdef __FL_SAVE_MESSAGES
	BOOL m_bBigMessenger;
#endif
#ifdef __EXTRA_TASKBARS 
	bool m_bVerticalBar;
	bool m_bHorizontalBar;
#endif

	BOOL	m_bDamageRender;
	BOOL	m_bSFXItemRenderOff;
	BOOL	m_bSFXRenderOff;
	BOOL	m_bCameraLock;
	BOOL	m_bAutoAttack;
#ifdef __ZCK_CRAFT_LOAD_TEX
	BOOL	m_bZckTextureNative;	// textures a leur taille reelle (neuz.ini ZckTextureNative), portage de __AEGON_TEX_LOAD
#else
#line 78 // __ZCK_CRAFT_LOAD_TEX
#endif // __ZCK_CRAFT_LOAD_TEX

	int m_BuffStatusMode;
	BOOL	m_bZoomLimit;
#ifdef __ZCK_MASQUERADE
	BOOL	m_bZckMasquerade;			// choix enregistre (neuz.ini "Masquerade") et case de l'onglet video
	BOOL	m_bZckMasqueradeActif;		// choix applique aux fichiers charges : lu dans neuz.ini au lancement, puis change en jeu par la case
#endif // __ZCK_MASQUERADE
#ifdef __ZCK_QUEST
	BOOL	m_bZckQueteSuivi;			// suivi des quetes affiche quand une quete est en cours (neuz.ini ZckQueteSuivi)
	BOOL	m_bZckQueteSuiviReduit;		// suivi des quetes reduit a sa barre de titre (neuz.ini ZckQueteSuiviReduit)
#endif // __ZCK_QUEST
	COption();
	~COption();

	void Init();
	int Load( LPCTSTR szFileName );
	int Save( LPCTSTR szFileName );
	void CheckResolution();
};

extern COption		g_Option;

#endif
