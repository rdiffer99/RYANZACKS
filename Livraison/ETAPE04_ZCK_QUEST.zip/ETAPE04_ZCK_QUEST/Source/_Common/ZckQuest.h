#ifndef __ZCK_QUEST_H__
#define __ZCK_QUEST_H__

#ifdef __ZCK_QUEST

//////////////////////////////////////////////////////////////////////
// __ZCK_QUEST : quetes de chasse a horaires (etape 04).
//
// Configuration : Resource\ZckQuetes.inc, lu par le WorldServer SEUL
// (CProject::OpenProject). Le client ne lit aucun fichier : le WorldServer
// lui envoie le catalogue (SNAPSHOTTYPE_ZCK_QUEST, genre CATALOGUE) a sa
// demande, a l'entree en jeu (CDPClient::OnJoin) et apres /quete recharger.
// Une quete changee dans ZckQuetes.inc n'exige donc aucun patch du client.
//
// Une quete :
//   - s'ouvre chaque jour choisi (Jours) de HeureDebut a HeureFin, heure
//     LOCALE du WorldServer (une fenetre qui finit avant de commencer passe
//     minuit et appartient au jour de son debut) ;
//   - s'accepte dans cette fenetre, si le niveau et le prestige du
//     personnage sont dans les bornes ;
//   - se termine en tuant Objectif monstres parmi Monstres (plusieurs MI
//     comptent pour la meme quete), dans un des Mondes (aucun = tous), avant
//     son echeance : Duree minutes apres l'acceptation, jamais apres la fin
//     de la fenetre (Duree 0 = jusqu'a la fin de la fenetre) ;
//   - se recupere ensuite (objets, buffs, Penya, EXP), une seule fois par
//     ouverture de la fenetre (cycle). Une quete echouee (temps ecoule) se
//     recommence tant que la fenetre est ouverte.
//
// Le WorldServer juge tout : le client nomme une action et une quete, jamais
// une recompense. Paquet PACKETTYPE_ZCK_QUEST (client -> WorldServer) :
//   BYTE action, int quete, DWORD version du catalogue, DWORD ZCK_QUEST_FIN.
// Snapshot SNAPSHOTTYPE_ZCK_QUEST (WorldServer -> joueur seul) : BYTE genre,
// puis le contenu ecrit et relu cote a cote dans ZckQuest.cpp, puis
// ZCK_QUEST_FIN. Un contenu incoherent est refuse en entier.
//
// Persistance : colonne CHARACTER_TBL.m_szZckQuest (12.CHARACTER_TBL_ZCK_QUEST.sql,
// CHARACTER_STR a jour : dernier parametre @im_szZckQuest, branches S8, U1, I1).
// ORDRE OBLIGATOIRE : 12.CHARACTER_TBL_ZCK_QUEST.sql, puis CHARACTER_STR, puis
// les executables. CDbManager::SavePlayer envoie toujours @im_szZckQuest (comme
// les autres colonnes Zck) : avec l'ancienne procedure, la branche U1 echoue
// (trop d'arguments) et plus aucun personnage n'est sauvegarde.
// Texte "id,etat,cycle,echeance,progression;...$". Etat non charge (colonne
// absente de la branche S8, ou texte illisible en base) : quetes refusees pour
// ce personnage et la colonne n'est jamais ecrasee (parametre NULL, ISNULL de la
// branche U1). Elle voyage avec le
// personnage (bloc METHOD_NONE de CMover::Serialize) : DatabaseServer <->
// WorldServer et WorldServer -> proprietaire. La recompense et l'etat
// "recompensee" partent dans le meme appel de CHARACTER_STR (sauvegarde
// immediate) : ni perte ni double recompense apres un plantage.
//
// Heure : secondes locales du WorldServer depuis 1970 (heure murale, pas UTC).
// Jour = secondes / 86400, jour de la semaine = (jour + 4) % 7 (0 = dimanche).
// Le client recoit l'heure du serveur avec chaque etat et la fait avancer
// avec GetTickCount : son horloge a lui n'intervient jamais.
//////////////////////////////////////////////////////////////////////

#include <map>
#include <vector>

// Le catalogue est de taille variable : un catalogue refuse par le client est
// saute en entier grace a la taille de chaque snapshot (CDPClient::OnSnapshot).
#ifndef __SIZED_SNAPSHOTS_V2
#error "__ZCK_QUEST exige __SIZED_SNAPSHOTS_V2 (CustomCommon.h)"
#endif // __SIZED_SNAPSHOTS_V2

class CAr;
class CMover;
#ifdef __WORLDSERVER
class CUser;
class CScanner;
class CScript;
#endif // __WORLDSERVER

//------------------------------------------------------------------------
// Bornes : elles bornent ce que le fichier peut demander, elles ne sont pas
// des reglages de jeu (ceux-ci vivent dans ZckQuetes.inc).
//------------------------------------------------------------------------
#define ZCK_QUEST_FICHIER				"ZckQuetes.inc"	// dossier Resource du WorldServer
#define ZCK_QUEST_FIN					0x5453515A		// marqueur de fin ("ZQST"), paquet et snapshot
#define ZCK_QUEST_MAX					128				// quetes au plus
#define ZCK_QUEST_ID_MAX				99999			// identifiant de quete le plus haut (1 a ZCK_QUEST_ID_MAX)
#define ZCK_QUEST_MONSTRES_MAX			32				// monstres comptes par quete
#define ZCK_QUEST_MONDES_MAX			16				// mondes par quete (aucun = tous les mondes)
#define ZCK_QUEST_OBJETS_MAX			8				// objets en recompense par quete
#define ZCK_QUEST_BUFFS_MAX				8				// buffs en recompense par quete
#define ZCK_QUEST_TAS_MAX				64				// tas d'inventaire au plus pour les objets d'une quete
#define ZCK_QUEST_NOM_MAX				64				// octets d'un nom
#define ZCK_QUEST_TEXTE_MAX				480				// octets d'une description
#define ZCK_QUEST_CATEGORIE_MAX			32				// octets d'une categorie
#define ZCK_QUEST_LIEU_MAX				64				// octets d'un lieu
#define ZCK_QUEST_OBJECTIF_MAX			100000			// monstres a tuer au plus
#define ZCK_QUEST_DUREE_MAX				1440			// minutes
#define ZCK_QUEST_NOMBRE_MAX			9999			// quantite d'un objet en recompense
#define ZCK_QUEST_EXP_MAX				1000000000000000LL	// EXP brute en recompense (int64)
#define ZCK_QUEST_EXP_POURCENT_MAX		100				// EXP en % du niveau courant
#define ZCK_QUEST_ACTIVES_DEFAUT		5				// quetes en cours en meme temps, sans Reglages
#define ZCK_QUEST_ACTIVES_MAX			16
#define ZCK_QUEST_JOURS_TOUS			0x7F			// bit 0 = dimanche ... bit 6 = samedi
#define ZCK_QUEST_JOUR_S				86400
#define ZCK_QUEST_CYCLE_MAX				10000000		// jour le plus haut accepte en base
#define ZCK_QUEST_ECHEANCE_MAX			100000000000LL	// seconde la plus haute acceptee en base
#define ZCK_QUEST_DB_ENTREE_MAX			40				// "id,etat,cycle,echeance,progression;" au plus : 5+1+8+12+6+5 = 37
#define ZCK_QUEST_DB_COLONNE			(ZCK_QUEST_MAX * ZCK_QUEST_DB_ENTREE_MAX + 2)	// '$' final et zero compris
#define ZCK_QUEST_DELAI_ACTION_MS		300				// WorldServer : ms minimum entre deux actions d'un joueur
#define ZCK_QUEST_DELAI_CATALOGUE_MS	2000			// WorldServer : ms minimum entre deux catalogues au meme joueur
#define ZCK_QUEST_PORTEE_GROUPE			64.0f			// Groupe 1 : distance au monstre des membres credites (comme les quetes de groupe d'origine)

// Actions du paquet (client -> WorldServer).
#define ZCK_QUEST_ACTION_CATALOGUE		1				// catalogue et etat demandes
#define ZCK_QUEST_ACTION_ACCEPTER		2
#define ZCK_QUEST_ACTION_ABANDONNER		3
#define ZCK_QUEST_ACTION_RECUPERER		4

// Genres du snapshot (WorldServer -> client).
#define ZCK_QUEST_GENRE_CATALOGUE		1
#define ZCK_QUEST_GENRE_ETAT			2				// etat complet du personnage
#define ZCK_QUEST_GENRE_MAJ				3				// une quete du personnage
#define ZCK_QUEST_GENRE_REPONSE			4				// reponse a une action

// Codes de la reponse : un par cause, pour un message exact cote client.
#define ZCK_QUEST_OK					0
#define ZCK_QUEST_REFUS_DEMANDE			1				// demande incoherente
#define ZCK_QUEST_REFUS_INDISPONIBLE	2				// ZckQuetes.inc absent ou invalide
#define ZCK_QUEST_REFUS_BASE			3				// colonne m_szZckQuest absente de CHARACTER_STR
#define ZCK_QUEST_REFUS_CATALOGUE		4				// catalogue change : renvoye avec la reponse
#define ZCK_QUEST_REFUS_INCONNUE		5				// quete inconnue
#define ZCK_QUEST_REFUS_FERMEE			6				// hors horaire
#define ZCK_QUEST_REFUS_NIVEAU			7
#define ZCK_QUEST_REFUS_PRESTIGE		8
#define ZCK_QUEST_REFUS_DEJA			9				// deja en cours ou accomplie pour ce cycle
#define ZCK_QUEST_REFUS_A_RECUPERER		10				// terminee, recompense a recuperer d'abord
#define ZCK_QUEST_REFUS_ACTIVES			11				// trop de quetes en cours
#define ZCK_QUEST_REFUS_PAS_ACTIVE		12				// abandon d'une quete qui n'est pas en cours
#define ZCK_QUEST_REFUS_PAS_TERMINEE	13				// recuperation d'une quete qui n'est pas terminee
#define ZCK_QUEST_REFUS_INVENTAIRE		14
#define ZCK_QUEST_REFUS_PENYA			15
#define ZCK_QUEST_REFUS_BUFF			16				// un buff de la recompense ne peut pas etre pose
#define ZCK_QUEST_REFUS_MODE_EGALISE	17				// __FL_EQUALIZED_MODE : inventaire temporaire
#define ZCK_QUEST_REFUS_MORT			18
#define ZCK_QUEST_REFUS_TROP_TOT		19				// anti-spam
#define ZCK_QUEST_REFUS_STAFF			20				// staff bloque (__ZCK_CUSTOM_UI_CORRECTIF), sauf administrateur
#define ZCK_QUEST_REFUS_OCCUPE			21				// objets inutilisables : echange, boutique, petrification, minijeu PvP
#define ZCK_QUEST_NB_CODES				22

// Etats enregistres d'une quete du personnage.
#define ZCK_QUEST_ETAT_EN_COURS			1				// acceptee, n64Echeance = fin du temps imparti
#define ZCK_QUEST_ETAT_TERMINEE			2				// objectif atteint, recompense a recuperer (jamais perdue)
#define ZCK_QUEST_ETAT_RECOMPENSEE		3				// recompense recuperee pour le cycle nCycle

// Statut affiche, deduit de l'etat, de l'heure et du personnage.
enum EZckQuestStatut
{
	ZCK_QUEST_STATUT_FERMEE = 0,	// hors horaire, rien en cours
	ZCK_QUEST_STATUT_DISPONIBLE,	// horaire ouvert, conditions remplies
	ZCK_QUEST_STATUT_VERROUILLEE,	// horaire ouvert, niveau ou prestige hors bornes
	ZCK_QUEST_STATUT_EN_COURS,
	ZCK_QUEST_STATUT_ECHOUEE,		// temps ecoule (nouvel essai tant que l'horaire est ouvert)
	ZCK_QUEST_STATUT_TERMINEE,		// objectif atteint, recompense a recuperer
	ZCK_QUEST_STATUT_ACCOMPLIE,		// recompense recuperee pour ce cycle
	ZCK_QUEST_NB_STATUTS
};

//------------------------------------------------------------------------
// Etat du personnage (CMover::m_ZckQuest) : Neuz, WorldServer, DatabaseServer.
//------------------------------------------------------------------------
struct ZCK_QUEST_ENTREE
{
	BYTE	byEtat;			// ZCK_QUEST_ETAT_*
	int		nCycle;			// jour du debut de l'ouverture dans laquelle la quete a ete acceptee
	__int64	n64Echeance;	// fin du temps imparti (secondes locales du WorldServer)
	int		nProgression;	// monstres tues, 0 a l'objectif

	ZCK_QUEST_ENTREE()
		: byEtat(0), nCycle(0), n64Echeance(0), nProgression(0)
	{
	}
};

class CZckQuestState
{
public:
	CZckQuestState();
	CZckQuestState(const CZckQuestState& rhs);
	~CZckQuestState();

	CZckQuestState& operator=(const CZckQuestState& rhs);

	void	Clear();
	// Bloc METHOD_NONE de CMover::Serialize (meme rang a l'ecriture et a la lecture).
	void	Serialize(CAr& ar);

	// FALSE : colonne absente de CHARACTER_STR (ou etat jamais charge) ; le
	// WorldServer refuse les quetes et le DatabaseServer n'ecrit pas la colonne.
	BOOL	IsBaseOk() const { return m_bBaseOk; }
	void	SetBaseOk(BOOL bBaseOk) { m_bBaseOk = bBaseOk ? TRUE : FALSE; }

	ZCK_QUEST_ENTREE*		Find(int nId);
	const ZCK_QUEST_ENTREE*	Find(int nId) const;
	ZCK_QUEST_ENTREE*		GetOrCreate(int nId);
	void					Remove(int nId);

	std::map<int, ZCK_QUEST_ENTREE>&		GetEntrees() { return m_mapEntrees; }
	const std::map<int, ZCK_QUEST_ENTREE>&	GetEntrees() const { return m_mapEntrees; }

	// Bornes d'une entree (base, reseau) : la definition n'est pas consultee.
	static BOOL	EntreeValide(int nId, const ZCK_QUEST_ENTREE& entree);

#ifdef __DBSERVER
	BOOL	SerializeDbText(char* pszBuffer, size_t nBufferSize) const;
	BOOL	DeserializeDbText(const char* pszBuffer);
#endif // __DBSERVER

#ifdef __WORLDSERVER
	// Runtime pur : jamais sauvegarde, jamais envoye, remis a zero par chaque copie.
	BOOL	m_bAction;				// une action a deja ete traitee
	DWORD	m_dwDerniereAction;		// GetTickCount() de la derniere action traitee
	BOOL	m_bCatalogue;			// un catalogue a deja ete envoye
	DWORD	m_dwDernierCatalogue;	// GetTickCount() du dernier catalogue envoye
	BOOL	m_bDemande;				// une demande de catalogue a deja ete traitee
	DWORD	m_dwDerniereDemande;	// GetTickCount() de la derniere demande de catalogue traitee
#endif // __WORLDSERVER

private:
	void	ResetRuntime();

	std::map<int, ZCK_QUEST_ENTREE>	m_mapEntrees;
	BOOL							m_bBaseOk;
};

#if defined(__CLIENT) || defined(__WORLDSERVER)
//------------------------------------------------------------------------
// Catalogue : Neuz et WorldServer.
//------------------------------------------------------------------------
struct ZCK_QUEST_OBJET
{
	DWORD	dwItemId;		// propItem
	int		nNombre;		// 1 a ZCK_QUEST_NOMBRE_MAX
	BOOL	bLie;			// objet lie au personnage (CItemElem::binds)

	ZCK_QUEST_OBJET()
		: dwItemId(NULL_ID), nNombre(0), bLie(FALSE)
	{
	}
};

struct ZCK_QUEST_DEFINITION
{
	int		nId;
	CString	strNom;
	CString	strDescription;
	CString	strCategorie;
	CString	strLieu;					// texte libre ; vide : titres des mondes (World.inc)
	std::vector<DWORD>	vecMondes;		// WI_* ; vide : tous les mondes
	int		nDebut;						// minutes depuis minuit, 0 a 1439
	int		nFin;						// minutes depuis minuit, 1 a 1440, different de nDebut
	BYTE	byJours;					// bit 0 = dimanche ... bit 6 = samedi
	int		nDuree;						// minutes, 0 = jusqu'a la fin de la fenetre
	int		nNiveauMin;
	int		nNiveauMax;
	int		nPrestigeMin;
	int		nPrestigeMax;
	int		nObjectif;					// monstres a tuer
	BOOL	bGroupe;					// les membres du groupe proches sont credites aussi
	std::vector<DWORD>	vecMonstres;	// MI_* qui comptent
	std::vector<ZCK_QUEST_OBJET>	vecObjets;
	std::vector<DWORD>	vecBuffs;		// II_* IK2_BUFF poses comme si l'objet etait utilise
	int		nPenya;
	__int64	n64Exp;
	int		nExpPourcent;				// % de l'EXP du niveau courant

	ZCK_QUEST_DEFINITION()
		: nId(0), nDebut(-1), nFin(-1), byJours(ZCK_QUEST_JOURS_TOUS), nDuree(0)
		, nNiveauMin(0), nNiveauMax(0), nPrestigeMin(0), nPrestigeMax(0), nObjectif(0), bGroupe(FALSE)
		, nPenya(0), n64Exp(0), nExpPourcent(0)
	{
	}
};

// Ouverture d'une quete a un instant donne (CalculerFenetre).
struct ZCK_QUEST_FENETRE
{
	BOOL	bCycle;			// une ouverture a commence dans les 8 derniers jours
	int		nCycle;			// son jour de debut (la plus recente)
	BOOL	bOuverte;		// cette ouverture n'est pas finie
	__int64	n64Debut;		// debut de cette ouverture
	__int64	n64Fin;			// fin de cette ouverture
	__int64	n64Prochaine;	// debut de la prochaine ouverture (0 : aucune dans les 8 jours)

	ZCK_QUEST_FENETRE()
		: bCycle(FALSE), nCycle(0), bOuverte(FALSE), n64Debut(0), n64Fin(0), n64Prochaine(0)
	{
	}
};

class CZckQuestManager
{
public:
	static CZckQuestManager* GetInstance();

	const ZCK_QUEST_DEFINITION*						GetDefinition(int nId) const;
	const std::map<int, ZCK_QUEST_DEFINITION>&		GetDefinitions() const { return m_mapDefinitions; }
	DWORD	GetVersion() const { return m_dwVersion; }
	int		GetActivesMax() const { return m_nActivesMax; }

	// Calculs communs, identiques sur Neuz et le WorldServer.
	static int		JourSemaine(__int64 n64Jour);	// jour depuis 1970 -> 0 = dimanche ... 6 = samedi
	static void		CalculerFenetre(const ZCK_QUEST_DEFINITION& def, __int64 n64Maintenant, ZCK_QUEST_FENETRE& fen);
	static BOOL		ConditionsRemplies(const ZCK_QUEST_DEFINITION& def, int nNiveau, int nPrestige);
	static int		CalculerStatut(const ZCK_QUEST_DEFINITION& def, const ZCK_QUEST_ENTREE* pEntree, __int64 n64Maintenant, int nNiveau, int nPrestige);
	static BOOL		MondeValide(const ZCK_QUEST_DEFINITION& def, DWORD dwWorldId);
	static __int64	ExpRecompense(const ZCK_QUEST_DEFINITION& def, int nNiveau);
	static LPCTSTR	TexteCode(BYTE byCode);
	static LPCTSTR	TexteStatut(int nStatut);
	int		CompterActives(const CZckQuestState& state, __int64 n64Maintenant) const;
	// Retire les quetes inconnues et les entrees perimees (cycle passe), borne les progressions.
	BOOL	Normaliser(CZckQuestState& state, __int64 n64Maintenant) const;

	void	EcrireCatalogue(CAr& ar) const;

#ifdef __WORLDSERVER
	BOOL	Charger(LPCTSTR lpszFichier);		// remplace le catalogue en service seulement si tout le fichier est valide
	BOOL	EstActif() const { return m_bActif; }
	static __int64	Horloge();					// secondes locales du WorldServer depuis 1970

	void	OnMonsterKilled(CUser* pTueur, CMover* pMonstre);
	void	Traiter(CUser* pUser, BYTE byAction, int nId, DWORD dwVersion, BOOL bStaffBloque);
	void	Commande(CUser* pUser, CScanner& s);	// /quete <sous-commande> (administration)

	void	EnvoyerCatalogue(CUser* pUser);
	void	EnvoyerEtat(CUser* pUser);
	void	EnvoyerMaj(CUser* pUser, int nId);
	void	EnvoyerReponse(CUser* pUser, BYTE byAction, BYTE byCode, int nId);
#endif // __WORLDSERVER

#ifdef __CLIENT
	BOOL	EstActif() const { return m_bCatalogue; }
	void	OublierClient();					// nouvelle entree en jeu : rien de la session precedente
	BOOL	LireCatalogue(CAr& ar);				// tout ou rien
	void	SetHorloge(__int64 n64Serveur);
	BOOL	HorlogeConnue() const { return m_bHorloge; }
	__int64	HorlogeServeur() const;				// heure du WorldServer estimee maintenant
	// Miroirs de EnvoyerEtat, EnvoyerMaj et EnvoyerReponse. Tout ou rien.
	BOOL	LireEtat(CAr& ar, CZckQuestState& state, DWORD& dwVersion);
	BOOL	LireMaj(CAr& ar, CZckQuestState& state, int& nId);
	static BOOL	LireReponse(CAr& ar, BYTE& byAction, BYTE& byCode, int& nId);
#endif // __CLIENT

private:
	CZckQuestManager();
	~CZckQuestManager();

#ifdef __WORLDSERVER
	BOOL	LireReglages(CScript& s, int& nActivesMax);
	BOOL	LireQuete(CScript& s, ZCK_QUEST_DEFINITION& def);
	BOOL	LireRecompenses(CScript& s, ZCK_QUEST_DEFINITION& def);
	BOOL	ValiderQuete(const ZCK_QUEST_DEFINITION& def) const;
	static DWORD	CalculerVersion(const std::map<int, ZCK_QUEST_DEFINITION>& mapDefinitions, int nActivesMax);

	BOOL	PeutRecevoirObjets(CUser* pUser, const ZCK_QUEST_DEFINITION& def) const;
	BYTE	Accepter(CUser* pUser, const ZCK_QUEST_DEFINITION& def, __int64 n64Maintenant);
	BYTE	Abandonner(CUser* pUser, const ZCK_QUEST_DEFINITION& def, __int64 n64Maintenant);
	BYTE	Recuperer(CUser* pUser, const ZCK_QUEST_DEFINITION& def, __int64 n64Maintenant);
	void	Crediter(CUser* pUser, const ZCK_QUEST_DEFINITION& def, __int64 n64Maintenant);
	void	EcrireEntree(CAr& ar, int nId, const ZCK_QUEST_ENTREE& entree) const;
#endif // __WORLDSERVER

	std::map<int, ZCK_QUEST_DEFINITION>	m_mapDefinitions;
	DWORD	m_dwVersion;					// 0 : aucun catalogue
	int		m_nActivesMax;

#ifdef __WORLDSERVER
	std::map<DWORD, std::vector<int> >	m_mapMonstres;	// MI -> quetes qui le comptent
	BOOL	m_bActif;
#endif // __WORLDSERVER

#ifdef __CLIENT
	BOOL	m_bCatalogue;
	BOOL	m_bHorloge;
	__int64	m_n64HorlogeBase;				// heure du WorldServer recue
	DWORD	m_dwTickBase;					// GetTickCount() a la reception
#endif // __CLIENT
};
#endif // __CLIENT || __WORLDSERVER

#endif // __ZCK_QUEST

#endif // __ZCK_QUEST_H__
