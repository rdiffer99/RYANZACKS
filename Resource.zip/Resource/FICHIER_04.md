﻿# FICHIER — volume 04 / 04

Contenu intégral des fichiers de `C:\Users\rdiff\Desktop\FICHIER`, recopié tel quel (aucune troncature, aucun résumé).

| Champ | Valeur |
|---|---|
| Source | `C:\Users\rdiff\Desktop\FICHIER` |
| Généré le | 2026-10-11 10:16:24 |
| Script | fichiers_vers_md.py v1.0.0 |
| Fichiers texte | 177 |
| Fichiers binaires | 64 |
| Erreurs de lecture | 0 |
| Octets lus | 317 252 785 |
| Volumes | 4 |

## Sommaire du volume

- [230 — ZckJobFactor.inc](#f230)
- [231 — ZckMondialBuff.inc](#f231)
- [232 — ZckMondialBuff.sav](#f232)
- [233 — ZckMonstreFct.inc](#f233)
- [234 — ZckMutateurs.inc](#f234)
- [235 — ZckPerinBuff.inc](#f235)
- [236 — ZckPerinBuff.sav](#f236)
- [237 — ZckPositionH.txt](#f237)
- [238 — ZckPrestige.inc](#f238)
- [239 — ZckTourInfini.inc](#f239)
- [240 — ZckTourInfini.sav](#f240)
- [241 — ZckWikiMonstres.inc](#f241)

---

<a id="f230"></a>
### 230 — `ZckJobFactor.inc`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckJobFactor.inc` |
| Taille source | 5 362 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 70 |
| SHA-256 source | `5e0791fab6131b1ef3fba1ff82ed4842af23a0942676d0296ce68645fb4120ca` |
| Caractères décodés | 2 680 |
| Caractères écrits | 2 680 |
| Saut de ligne final d'origine | oui |

<!-- ZCKMD v=1 idx=230 mode=texte enc=utf-16-le bom=1 nlajoute=0 cloture=3 octets=5362 sha256=5e0791fab6131b1ef3fba1ff82ed4842af23a0942676d0296ce68645fb4120ca chemin64=WmNrSm9iRmFjdG9yLmluYw== -->
```text
// ZckJobFactor.inc - __ZCK_JOB_FACTOR
// Multiplicateur de degats FINAL par classe, applique apres stuff, rarete, critique et defense.
// C'est un pourcentage : l'ecart de stuff entre deux joueurs d'une meme classe est conserve.
//
// Format : JOB_xxx   PvE   PvP        (point decimal, entre 0.10 et 5.00)
// Un job absent du fichier reste a 1.00.
// Rechargement a chaud : /zjf
// Mesure              : /zjfdps, frapper la cible ~60 s, /zjfdps
//                       nouveau facteur = facteur actuel x (DPS cible / DPS mesure)

// Job                        PvE     PvP

// Vagabond
JOB_VAGRANT                  1.00    1.00

// 1ere classe
JOB_MERCENARY                1.00    1.00
JOB_ACROBAT                  1.00    1.00
JOB_ASSIST                   1.00    1.00
JOB_MAGICIAN                 1.00    1.00

// 2e classe
JOB_KNIGHT                   1.00    1.00
JOB_BLADE                    1.00    1.00
JOB_JESTER                   1.00    1.00
JOB_RANGER                   1.00    1.00
JOB_RINGMASTER               1.00    1.00
JOB_BILLPOSTER               1.00    1.00
JOB_PSYCHIKEEPER             1.00    1.00
JOB_ELEMENTOR                1.00    1.00

// Master
JOB_KNIGHT_MASTER            1.00    1.00
JOB_BLADE_MASTER             1.00    1.00
JOB_JESTER_MASTER            1.00    1.00
JOB_RANGER_MASTER            1.00    1.00
JOB_RINGMASTER_MASTER        1.00    1.00
JOB_BILLPOSTER_MASTER        1.00    1.00
JOB_PSYCHIKEEPER_MASTER      1.00    1.00
JOB_ELEMENTOR_MASTER         1.00    1.00

// Hero
JOB_KNIGHT_HERO              1.00    1.00
JOB_BLADE_HERO               1.00    1.00
JOB_JESTER_HERO              1.00    1.00
JOB_RANGER_HERO              1.00    1.00
JOB_RINGMASTER_HERO          1.00    1.00
JOB_BILLPOSTER_HERO          1.00    1.00
JOB_PSYCHIKEEPER_HERO        1.00    1.00
JOB_ELEMENTOR_HERO           1.00    1.00

// 3e classe (Legend Hero)
JOB_LORDTEMPLER_HERO         1.00    1.00
JOB_STORMBLADE_HERO          1.00    1.00
JOB_WINDLURKER_HERO          1.00    1.00
JOB_CRACKSHOOTER_HERO        1.00    1.00
JOB_FLORIST_HERO             1.00    1.00
JOB_FORCEMASTER_HERO         1.00    1.00
JOB_MENTALIST_HERO           1.00    1.00
JOB_ELEMENTORLORD_HERO       1.00    1.00

// 4e classe
JOB_LORDTEMPLER_HERO_ULTIMATE     1.00    1.00
JOB_STORMBLADE_HERO_ULTIMATE      1.00    1.00
JOB_WINDLURKER_HERO_ULTIMATE      1.00    1.00
JOB_CRACKSHOOTER_HERO_ULTIMATE    1.00    1.00
JOB_FLORIST_HERO_ULTIMATE         1.00    1.00
JOB_FORCEMASTER_HERO_ULTIMATE     1.00    1.00
JOB_MENTALIST_HERO_ULTIMATE       1.00    1.00
JOB_ELEMENTORLORD_HERO_ULTIMATE   1.00    1.00
```
<!-- ZCKMD:FIN idx=230 -->

<a id="f231"></a>
### 231 — `ZckMondialBuff.inc`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckMondialBuff.inc` |
| Taille source | 9 156 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 67 |
| SHA-256 source | `803f05a3c8cab6590d59248dd3f24d6961be263156ba784731548f66033829b6` |
| Caractères décodés | 4 577 |
| Caractères écrits | 4 578 |
| Saut de ligne final d'origine | non |

<!-- ZCKMD v=1 idx=231 mode=texte enc=utf-16-le bom=1 nlajoute=1 cloture=3 octets=9156 sha256=803f05a3c8cab6590d59248dd3f24d6961be263156ba784731548f66033829b6 chemin64=WmNrTW9uZGlhbEJ1ZmYuaW5j -->
```text
// ZckMondialBuff.inc - buffs mondiaux lies a la population (__ZCK_MONDIAL_BUFF).
// UTF-16 LE avec BOM, fins de ligne CRLF : CScanner saute un commentaire
// jusqu'au retour chariot puis avance de 2, un fichier LF casse la lecture.
// Le meme fichier sert au client (affichage) et au WorldServer (autorite).
// Aucun accent : CScanner convertit le fichier en 8 bits (g_codePage).
//
// Config : une cle absente prend la valeur entre parentheses.
//   GraceMinutes           1..240   (10)   un palier survit ce temps sous son seuil
//   OffrandeJoueurMinutes  0..1440  (60)   delai entre deux offrandes d'un meme joueur
//   OffrandeBuffMinutes    0..1440  (30)   delai entre deux offrandes d'un meme buff
//   DureeMaxMinutes        1..1440  (180)  plafond : une offrande doit tenir en entier dessous
//   Annonces               0 / 1    (1)    annonces (grand texte + ligne systeme) a tout le serveur
//   CompterFantomes        0 / 1    (1)    0 : les personnages en farm hors ligne ne comptent pas
//   IconeNeutre            ItemProp (0)    icone HUD quand aucun palier n'est atteint
//   BonusPenya             <ItemProp buff> <1..100>   % de penya ramasse en plus sous ce buff
//
// Buffs   : <ItemProp buff> <Offrable 0/1> <ItemProp cout> <qte> <DureeMinutes>
//           Non offrable : cout, quantite et duree sont ignores ('=' ou 0).
//           ItemProp buff, szTextFileName vide, l'un des deux gabarits :
//             IK1_SYSTEM / IK2_BUFF2 / IK3_ANARCHY ou IK3_SCROLL (comme l'Anarchy) :
//               pose en BUFF_ITEM2 ; dwSkillTime numerique pour l'icone de la barre ;
//             IK1_SYSTEM / IK2_SYSTEM / IK3_SCROLL (parchemin) : pose en BUFF_ITEM,
//               dwSkillTime numerique.
//           La duree vient du registre du serveur, jamais de dwSkillTime ni de dwAbilityMin.
// Paliers : <Joueurs> "<Nom>" <ItemProp embleme> <ItemProp buff> ...
//           Seuils strictement croissants ; un palier inclut les buffs des
//           paliers inferieurs ; buffs ecrits en symbolique (II_*) : la liste
//           s'arrete au nombre suivant ; le bloc Buffs precede le bloc Paliers.

Config
{
	GraceMinutes            10
	OffrandeJoueurMinutes   60
	OffrandeBuffMinutes     30
	DureeMaxMinutes         180
	Annonces                1
	CompterFantomes         1
	IconeNeutre             II_SYS_SYS_SCR_HOLY
	BonusPenya              II_BUFF_ZCK_MONDIAUX3   10
}

Buffs
{
	// <ItemProp du buff>       <Offrable>  <ItemProp du cout>      <qte>   <DureeMinutes>
	II_BUFF_ZCK_MONDIAUX        1           II_SYS_SYS_SCR_PERIN    1       60      // Vigueur     PV max +10 %
	II_BUFF_ZCK_MONDIAUX2       1           II_SYS_SYS_SCR_PERIN    1       60      // Celerite    vitesse +10 %
	II_BUFF_ZCK_MONDIAUX1       1           II_SYS_SYS_SCR_PERIN    2       60      // Sagesse     experience +10 %
	II_BUFF_ZCK_MONDIAUX8       1           II_SYS_SYS_SCR_PERIN    1       60      // Endurance   PM et PF max +10 %
	II_BUFF_ZCK_MONDIAUX3       1           II_SYS_SYS_SCR_PERIN    2       60      // Fortune     penya +10 % (BonusPenya)
	II_BUFF_ZCK_MONDIAUX4       1           II_SYS_SYS_SCR_PERIN    1       30      // Precision   toucher +5 %
	II_BUFF_ZCK_MONDIAUX5       1           II_SYS_SYS_SCR_PERIN    2       30      // Ferveur     attaque +5 %
	II_BUFF_ZCK_MONDIAUX6       1           II_SYS_SYS_SCR_PERIN    2       30      // Rempart     defense +5 %
	II_BUFF_ZCK_MONDIAUX10      1           II_SYS_SYS_SCR_PERIN    2       30      // Chance      critique +5 %
	II_BUFF_ZCK_MONDIAUX9       1           II_SYS_SYS_SCR_PERIN    2       30      // Ardeur      vitesse d'attaque +5 %
	II_BUFF_ZCK_MONDIAUX11      1           II_SYS_SYS_SCR_PERIN    3       30      // Acuite      degats critiques +10 %
	II_BUFF_ZCK_MONDIAUX7       0           =                       0       0       // Harmonie    FOR/END/DEX/INT +5, palier Diamant seulement
}

Paliers
{
	// <Joueurs>  <Nom>         <ItemProp embleme>        <buffs du palier...>
	1             "Bronze"      II_BUFF_ZCK_MONDIAUX      II_BUFF_ZCK_MONDIAUX   II_BUFF_ZCK_MONDIAUX2
	5            "Argent"      II_BUFF_ZCK_MONDIAUX1     II_BUFF_ZCK_MONDIAUX1  II_BUFF_ZCK_MONDIAUX8
	20            "Or"          II_BUFF_ZCK_MONDIAUX3     II_BUFF_ZCK_MONDIAUX3  II_BUFF_ZCK_MONDIAUX4  II_BUFF_ZCK_MONDIAUX5
	50            "Platine"     II_BUFF_ZCK_MONDIAUX6     II_BUFF_ZCK_MONDIAUX6  II_BUFF_ZCK_MONDIAUX10 II_BUFF_ZCK_MONDIAUX9
	100            "Diamant"     II_BUFF_ZCK_MONDIAUX7     II_BUFF_ZCK_MONDIAUX7  II_BUFF_ZCK_MONDIAUX11
}
```
<!-- ZCKMD:FIN idx=231 -->

<a id="f232"></a>
### 232 — `ZckMondialBuff.sav`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckMondialBuff.sav` |
| Taille source | 294 octets |
| Encodage détecté | utf-8 |
| BOM d'origine | non |
| Fin de ligne | CRLF |
| Lignes | 13 |
| SHA-256 source | `14f0e396dc48404e6aaa45436760bc1b69ae7459b1ea7d10db8983085fc2553c` |
| Caractères décodés | 294 |
| Caractères écrits | 294 |
| Saut de ligne final d'origine | oui |

<!-- ZCKMD v=1 idx=232 mode=texte enc=utf-8 bom=0 nlajoute=0 cloture=3 octets=294 sha256=14f0e396dc48404e6aaa45436760bc1b69ae7459b1ea7d10db8983085fc2553c chemin64=WmNrTW9uZGlhbEJ1ZmYuc2F2 -->
```text
ZCKMONDIALBUFF 1
CONNU	7443	1790694753
CONNU	7444	1790694753
CONNU	7445	1790694753
CONNU	7446	1790694753
CONNU	7447	1790694753
CONNU	7448	1790694753
CONNU	7449	1790694753
CONNU	7450	1790694753
CONNU	7451	1790694753
CONNU	7452	1790694753
CONNU	7453	1790694753
CONNU	7454	1790694753
```
<!-- ZCKMD:FIN idx=232 -->

<a id="f233"></a>
### 233 — `ZckMonstreFct.inc`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckMonstreFct.inc` |
| Taille source | 5 994 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 56 |
| SHA-256 source | `4fd104959629619f4694aeff13bd14089f63813c54fe771a86415e514a845bcd` |
| Caractères décodés | 2 996 |
| Caractères écrits | 2 996 |
| Saut de ligne final d'origine | oui |

<!-- ZCKMD v=1 idx=233 mode=texte enc=utf-16-le bom=1 nlajoute=0 cloture=3 octets=5994 sha256=4fd104959629619f4694aeff13bd14089f63813c54fe771a86415e514a845bcd chemin64=WmNrTW9uc3RyZUZjdC5pbmM= -->
```text

// Exemple : coups de 22000 a 29000, et toutes les 30 s un gros coup de 400000 a 425000
//   MI_BEHEMOTH               22000     29000     30      400000    425000
//
// Boss = ID_BOSS et ID_MIDBOSS a true dans DungeonParty.lua. Les ID_MIDBOSS a false (portes de
// Rustia, pierres de Dreadful Cave, statues de Behamah, steles et oeufs de Kalgas) ont ATK 1 dans
// propMover : ce sont des objets a detruire, ils ne tapent pas. Ils ne sont pas listes.
//
// Pour activer un boss : enlever les // en debut de ligne et remplacer les 0.

// MI                          CoupMin   CoupMax   Cycle   GrosMin   GrosMax

// WI_INSTANCE_RUSTIA (entree Nv 60)
//MI_BESIBIGFOOT01             0         0         30      0         0         // boss Nv 80

// WI_INSTANCE_RUSTIA_1 (entree Nv 60)
//MI_BESIBIGFOOT02             0         0         30      0         0         // boss Nv 80

// WI_INSTANCE_UPRESIA (entree Nv 75)
//MI_DREAMQEEN01               0         0         30      0         0         // boss Nv 85

// WI_INSTANCE_UPRESIA_1 (entree Nv 75)
//MI_DREAMQEEN01_1             0         0         30      0         0         // boss Nv 85

// WI_INSTANCE_HERNEOS (entree Nv 90)
//MI_HERNSIREN01               0         0         30      0         0         // mid-boss Nv 96
//MI_HERNKRAKEN01              0         0         30      0         0         // boss Nv 101

// WI_INSTANCE_HERNEOS_1 (entree Nv 90)
//MI_HERNSIREN01_1             0         0         30      0         0         // mid-boss Nv 96
//MI_HERNKRAKEN01_1            0         0         30      0         0         // boss Nv 101

// WI_INSTANCE_SANPRES (entree Nv 105)
//MI_SHIPHIPPOGRIPH            0         0         30      0         0         // mid-boss Nv 111
//MI_SHIPHARPINEES             0         0         30      0         0         // boss Nv 116

// WI_INSTANCE_SANPRES_1 (entree Nv 105)
//MI_SHIPHIPPOGRIPH_1          0         0         30      0         0         // mid-boss Nv 111
//MI_SHIPHARPINEES_1           0         0         30      0         0         // boss Nv 116

// WI_INSTANCE_OMINOUS (entree Nv 80)
//MI_LYCANOS01                 0         0         30      0         0         // mid-boss Nv 120
//MI_VEMPAIN01                 0         0         30      0         0         // boss Nv 121

// WI_INSTANCE_OMINOUS_1 (entree Nv 80)
//MI_LYCANOS01_1               0         0         30      0         0         // mid-boss Nv 120
//MI_VEMPAIN01_1               0         0         30      0         0         // boss Nv 121

// WI_INSTANCE_DREADFULCAVE (entree Nv 121)
//MI_SKELDEVIL                 0         0         30      0         0         // boss Nv 135

// WI_INSTANCE_BEHAMAH (entree Nv 130)
//MI_BEHEMOTH                  0         0         30      0         0         // boss Nv 143

// WI_INSTANCE_KALGAS (entree Nv 135)
//MI_KALGASBOSS                0         0         30      0         0         // boss Nv 152
```
<!-- ZCKMD:FIN idx=233 -->

<a id="f234"></a>
### 234 — `ZckMutateurs.inc`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckMutateurs.inc` |
| Taille source | 22 688 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 317 |
| SHA-256 source | `acf67edc8c6240d74be0695b5825339c7fb5d7570c77d02be9c30c11b5c1e393` |
| Caractères décodés | 11 343 |
| Caractères écrits | 11 344 |
| Saut de ligne final d'origine | non |

<!-- ZCKMD v=1 idx=234 mode=texte enc=utf-16-le bom=1 nlajoute=1 cloture=3 octets=22688 sha256=acf67edc8c6240d74be0695b5825339c7fb5d7570c77d02be9c30c11b5c1e393 chemin64=WmNrTXV0YXRldXJzLmluYw== -->
```text
// ====================================================================
//  ZckMutateurs.inc - mutateurs de donjon hebdomadaires (__ZCK_MUTATEURS)
// ====================================================================
//
//  Un seul fichier, identique cote WorldServer et cote Neuz. Tout reglage
//  du systeme vit ici : le C++ ne contient aucune valeur de jeu. Une
//  valeur invalide rend le systeme INACTIF (raison dans le journal et dans
//  /zckmut), jamais un defaut silencieux, jamais un refus de demarrer.
//
//  Grammaire : mots-cles, symboles WI_* / SI_* / XI_* resolus par les
//  defines pre-charges (PreLoadDefine.inc), couleurs en 0xAARRGGBB avec
//  "0x" en minuscules, textes ASCII sans accent. Commentaires // et /* */.
//
//  Bloc Config
//    AncreReset      annee mois jour heure minute : instant de reference,
//                    en heure murale du serveur. Semaine = (T - ancre) / 7 j,
//                    bascule a la meme heure murale ete comme hiver.
//    NbParDifficulte { NONE EASY NORMAL HARD } : nombre de malus actifs par
//                    palier, croissant, NONE = 0, HARD <= 3. Une instance
//                    NORMAL recoit les 2 premiers malus tires, HARD les 3 :
//                    c'est l'emboitement.
//    BonusChancePct  probabilite (0-100) qu'un BONUS accompagne la semaine.
//    MaxInstances    instances mutees simultanees (1-4096) ; au-dela, une
//                    instance tourne sans mutateur (WARNING).
//    Donjons         { WI_* ... } : donjons instancies concernes.
//    CouleurTitre / CouleurLigne / CouleurBonus : annonce dans le chat.
//
//  Bloc Mutateur <SYMBOLE> (les 12 symboles sont obligatoires, une fois)
//    Id              1-255, stable : transporte sur le reseau, journalise.
//    Nom             libelle court ("Volatile").
//    Genitif         complement du nom de semaine ("de la Poudre" ->
//                    "Semaine de la Poudre et du Sang").
//    Desc            une ligne pour le chat.
//    Categorie       MALUS (tire par position) ou BONUS (flux separe).
//    Poids           0-100000, 0 = jamais tire (dormant, /zckmut force
//                    le teste quand meme).
//    DiffMin         EASY, NORMAL ou HARD : premier palier ou le mutateur
//                    peut sortir. Un BONUS est toujours EASY.
//    ScoreCoef       pour-mille applique au score de la course (1000 = x1).
//    CubeCoef        pour-mille applique au taux de drop des cubes.
//    Exclut          { SYMBOLES } jamais tires avec celui-ci (symetrise).
//    Param           { ... } valeurs propres au mutateur, ordre fixe :
//
//    MUT_VOLATILE    { PctPvMax Rayon10 SfxId }
//                    PctPvMax  1-500  : degat de l'explosion, en pour-mille
//                                       des PV max de chaque joueur touche
//                    Rayon10   5-200  : rayon en dixiemes d'unite monde
//                    SfxId     XI_*   : effet joue a la mort du monstre
//    MUT_TYRANNIQUE  { PctPv PctAtk }   boss : PV et ATK en pour-mille (1000-3000)
//    MUT_ROBUSTE     { PctPv PctAtk }   non-boss : idem
//    MUT_NERVEUX     { SkillId Niveau SkillId2 Niveau2 DureeSec }
//                    buffs SI_* poses a l'apparition (SkillId2 = 0 : aucun),
//                    niveaux verifies dans propSkillAdd, duree 1-86400 s
//    MUT_VAMPIRIQUE  { PctVol CapPctPvMax }
//                    PctVol      1-1000 : part du degat inflige rendue en PV
//                    CapPctPvMax 1-500  : plafond par coup, pour-mille des
//                                         PV max du monstre
//    MUT_RONCES      { PctRenvoi CapPctPvMax }
//                    PctRenvoi   1-1000 : part du degat de melee renvoyee
//                    CapPctPvMax 1-500  : plafond par coup, pour-mille des
//                                         PV max du joueur
//    MUT_PACTE       { PctSoin Rayon10 BossInclus }
//                    PctSoin   1-500 : soin des voisins a la mort, pour-mille
//                                      de leurs PV max
//                    Rayon10   5-200, BossInclus 0/1
//    MUT_SABLIER     { SeuilPct CoefTard }
//                    clear <= TimeRefMs x SeuilPct / 100 : ScoreCoef,
//                    sinon CoefTard (pour-mille, 100-10000)
//    MUT_ESSAIM      { PctDup }         chance (pour-mille) qu'un monstre
//                                       non-boss apparaisse en double
//    MUT_CHASSEUR    { IntervalSec MaxSimultanes ExpireSec PctPv PctAtk }
//                    un monstre de l'instance apparait pres d'un joueur
//                    toutes les IntervalSec (15-3600), au plus MaxSimultanes
//                    (1-4) vivants, disparait apres ExpireSec (30-3600),
//                    renfort PV / ATK en pour-mille (1000-3000)
//    MUT_AUBAINE     { }                bonus : CubeCoef seulement
//    MUT_PRIME       { }                bonus : ScoreCoef seulement
//
//  L'ordre des blocs Mutateur fait partie du tirage : reordonner ce fichier
//  change les semaines futures, jamais une instance en cours.
// ====================================================================

Config
{
	AncreReset			2026 09 21 06 00			// lundi 21 septembre 2026, 06:00 heure murale
	NbParDifficulte		{ 0 1 2 3 }					// NONE EASY NORMAL HARD
	BonusChancePct		30
	MaxInstances		64							// nMaxInstanceDungeon vaut 40 : marge
	Donjons
	{
		WI_INSTANCE_RUSTIA			WI_INSTANCE_RUSTIA_1
		WI_INSTANCE_UPRESIA			WI_INSTANCE_UPRESIA_1
		WI_INSTANCE_HERNEOS			WI_INSTANCE_HERNEOS_1
		WI_INSTANCE_SANPRES			WI_INSTANCE_SANPRES_1
		WI_INSTANCE_OMINOUS			WI_INSTANCE_OMINOUS_1
		WI_INSTANCE_DREADFULCAVE
		WI_INSTANCE_BEHAMAH
		WI_INSTANCE_KALGAS
	}
	CouleurTitre		0xffffcc66					// titre de l'annonce et nom de semaine
	CouleurLigne		0xffe8e8e8					// lignes de description
	CouleurBonus		0xff9be39b					// ligne du bonus
}

// --------------------------------------------------------------------
//  Malus
// --------------------------------------------------------------------

Mutateur MUT_VOLATILE
{
	Id			1
	Nom			"Volatile"
	Genitif		"de la Poudre"
	Desc		"Les monstres explosent a leur mort et blessent les joueurs proches."
	Categorie	MALUS
	Poids		100
	DiffMin		EASY
	ScoreCoef	1150
	CubeCoef	1000
	Exclut		{ MUT_PACTE MUT_ESSAIM }
	Param		{ 200 40 XI_SKILL_ELE_MULTI_METEOSHOWER02 }
	// PctPvMax 200 = 20 % des PV max du joueur par explosion
	// Rayon10 40 = 4.0 unites, la portee de Burst Crack (propSkillAdd dwSkillRange 4 ;
	//   Earthquake 6, Meteo Shower 8)
	// SfxId : impact (colonne dwSfxObj3 de propSkill.csv) de Meteo Shower ;
	//   alternatives : XI_SKILL_ASS_KNU_BURSTCRACK01, XI_SKILL_ELE_EARTH_EARTHQUAKE02
}

Mutateur MUT_TYRANNIQUE
{
	Id			2
	Nom			"Tyrannique"
	Genitif		"du Tyran"
	Desc		"Les boss et mi-boss ont plus de vie et frappent plus fort."
	Categorie	MALUS
	Poids		100
	DiffMin		NORMAL
	ScoreCoef	1200
	CubeCoef	1000
	Exclut		{ MUT_CHASSEUR }
	Param		{ 1300 1150 }
	// PctPv 1300 = PV des boss x1.30, PctAtk 1150 = ATK x1.15,
	//   composes avec le facteur de difficulte (HARD 2.0 -> 2.6 et 2.3)
}

Mutateur MUT_ROBUSTE
{
	Id			3
	Nom			"Robuste"
	Genitif		"du Roc"
	Desc		"Les monstres ordinaires ont plus de vie et frappent plus fort."
	Categorie	MALUS
	Poids		100
	DiffMin		EASY
	ScoreCoef	1150
	CubeCoef	1000
	Exclut		{ }
	Param		{ 1250 1100 }
	// PctPv 1250 = PV des non-boss x1.25, PctAtk 1100 = ATK x1.10
}

Mutateur MUT_NERVEUX
{
	Id			4
	Nom			"Nerveux"
	Genitif		"de la Foudre"
	Desc		"Les monstres attaquent et se deplacent plus vite."
	Categorie	MALUS
	Poids		100
	DiffMin		EASY
	ScoreCoef	1150
	CubeCoef	1000
	Exclut		{ }
	Param		{ SI_ASS_CHEER_HASTE 20 SI_ASS_CHEER_QUICKSTEP 20 7200 }
	// Haste 20 : DST_ATTACKSPEED +500 (propSkillAdd SA_HASTE_LV20), soit +50 %
	// Quick Step 20 : DST_SPEED +30 (propSkillAdd SA_QUICKSTEP_L20), soit +30 %
	// DureeSec 7200 : plus long que toute instance, le buff meurt avec le monstre
}

Mutateur MUT_VAMPIRIQUE
{
	Id			5
	Nom			"Vampirique"
	Genitif		"du Sang"
	Desc		"Les monstres se soignent d'une part des degats qu'ils infligent."
	Categorie	MALUS
	Poids		100
	DiffMin		NORMAL
	ScoreCoef	1150
	CubeCoef	1000
	Exclut		{ }
	Param		{ 300 50 }
	// PctVol 300 = 30 % du degat inflige rendu en PV
	// CapPctPvMax 50 = au plus 5 % des PV max du monstre par coup
}

Mutateur MUT_RONCES
{
	Id			6
	Nom			"Ronces"
	Genitif		"des Ronces"
	Desc		"Frapper un monstre au corps a corps renvoie une part des degats."
	Categorie	MALUS
	Poids		100
	DiffMin		NORMAL
	ScoreCoef	1150
	CubeCoef	1000
	Exclut		{ }
	Param		{ 100 50 }
	// PctRenvoi 100 = 10 % du degat de melee renvoye a l'attaquant
	// CapPctPvMax 50 = au plus 5 % des PV max du joueur par coup, jamais mortel
}

Mutateur MUT_PACTE
{
	Id			7
	Nom			"Pacte"
	Genitif		"du Serment"
	Desc		"Quand un monstre meurt, ses voisins se soignent."
	Categorie	MALUS
	Poids		100
	DiffMin		NORMAL
	ScoreCoef	1150
	CubeCoef	1000
	Exclut		{ MUT_VOLATILE }
	Param		{ 300 60 0 }
	// PctSoin 300 = 30 % des PV max de chaque voisin
	// Rayon10 60 = 6.0 unites (Earthquake), BossInclus 0 : le boss ne se soigne pas
}

Mutateur MUT_SABLIER
{
	Id			8
	Nom			"Sablier"
	Genitif		"du Sablier"
	Desc		"Le score est bonifie si le donjon est fini dans le temps de reference."
	Categorie	MALUS
	Poids		100
	DiffMin		HARD
	ScoreCoef	1300
	CubeCoef	1000
	Exclut		{ }
	Param		{ 100 1000 }
	// SeuilPct 100 = clear en moins de 100 % du TimeRefMs du classement : ScoreCoef 1300
	// CoefTard 1000 = au-dela, coefficient neutre
}

Mutateur MUT_ESSAIM
{
	Id			9
	Nom			"Essaim"
	Genitif		"de l'Essaim"
	Desc		"Certains monstres apparaissent en double."
	Categorie	MALUS
	Poids		0
	DiffMin		HARD
	ScoreCoef	1200
	CubeCoef	1000
	Exclut		{ MUT_VOLATILE }
	Param		{ 350 }
	// Poids 0 : dormant (etape C), testable par /zckmut force 9
	// PctDup 350 = 35 % des monstres non-boss recoivent un jumeau au tick suivant
}

Mutateur MUT_CHASSEUR
{
	Id			10
	Nom			"Chasseur"
	Genitif		"de la Traque"
	Desc		"Un traqueur apparait regulierement pres d'un joueur."
	Categorie	MALUS
	Poids		0
	DiffMin		HARD
	ScoreCoef	1200
	CubeCoef	1000
	Exclut		{ MUT_TYRANNIQUE }
	Param		{ 90 2 120 1500 1200 }
	// Poids 0 : dormant (etape C), testable par /zckmut force 10
	// IntervalSec 90, MaxSimultanes 2, ExpireSec 120
	// PctPv 1500 = PV x1.5, PctAtk 1200 = ATK x1.2 en plus du renfort du palier
}

// --------------------------------------------------------------------
//  Bonus (flux separe, BonusChancePct)
// --------------------------------------------------------------------

Mutateur MUT_AUBAINE
{
	Id			11
	Nom			"Aubaine"
	Genitif		"de la Fortune"
	Desc		"Les cubes tombent deux fois plus souvent."
	Categorie	BONUS
	Poids		100
	DiffMin		EASY
	ScoreCoef	1000
	CubeCoef	2000
	Exclut		{ }
	Param		{ }
	// CubeCoef 2000 = taux de drop x2, borne par ZCK_CUBE_RATE_UNIT
}

Mutateur MUT_PRIME
{
	Id			12
	Nom			"Prime"
	Genitif		"de la Gloire"
	Desc		"Le score des courses est majore."
	Categorie	BONUS
	Poids		100
	DiffMin		EASY
	ScoreCoef	1250
	CubeCoef	1000
	Exclut		{ }
	Param		{ }
	// ScoreCoef 1250 = score de la course x1.25
}
```
<!-- ZCKMD:FIN idx=234 -->

<a id="f235"></a>
### 235 — `ZckPerinBuff.inc`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckPerinBuff.inc` |
| Taille source | 6 026 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 54 |
| SHA-256 source | `ff05cc4b60acb06c4a2f4020373a2391425f39c72880b27d260174939d907d02` |
| Caractères décodés | 3 012 |
| Caractères écrits | 3 012 |
| Saut de ligne final d'origine | oui |

<!-- ZCKMD v=1 idx=235 mode=texte enc=utf-16-le bom=1 nlajoute=0 cloture=3 octets=6026 sha256=ff05cc4b60acb06c4a2f4020373a2391425f39c72880b27d260174939d907d02 chemin64=WmNrUGVyaW5CdWZmLmluYw== -->
```text
// ZckPerinBuff.inc - buffs Perin : reserve commune de Perins (__ZCK_PERIN_BUFF).
// UTF-16 LE avec BOM, fins de ligne CRLF : CScanner saute un commentaire
// jusqu'au retour chariot puis avance de 2, un fichier LF casse la lecture.
// Le meme fichier sert au client (affichage) et au WorldServer (autorite) :
// il doit etre identique des deux cotes (empreinte verifiee a chaque
// investissement). Aucun accent : CScanner convertit le fichier en 8 bits.
//
// Principe : les joueurs investissent des Perins dans une reserve commune.
// Chaque palier atteint active son buff pour TOUS les joueurs connectes, tant
// que la reserve reste au-dessus de son seuil : barre pas assez remplie = pas
// de buff. Un palier inclut les buffs des paliers inferieurs :
//   25 Perins = 1 buff, 50 = 2 buffs, 75 = 3 buffs, 100 = 4 buffs.
// La reserve perd 1 Perin toutes les PerteMinutes : il faut la nourrir.
// Chaque Perin investi prolonge donc de PerteMinutes tous les paliers atteints.
//
// Config : une cle absente prend la valeur entre parentheses.
//   PerteMinutes   0..1440   (30)   1 Perin perdu toutes les N minutes, 0 = jamais
//   InvestMax      1..9999   (100)  Perins au plus par investissement
//   Annonces       0 / 1     (1)    paliers atteints ou eteints annonces a tout le serveur
//   AnnonceInvest  0 / 1     (1)    une ligne dans le chat a chaque investissement
//   Monnaie        ItemProp  (obligatoire) objet investi
//   IconeHud       ItemProp  (0 = Monnaie) icone a gauche de l'icone des buffs mondiaux
//
// Paliers : <Perins> "<Nom>" <ItemProp buff>        (1 a 4 paliers)
//   Seuils strictement croissants ; le dernier seuil est la capacite de la
//   reserve. Nom : ASCII sans accent, 31 caracteres au plus. ItemProp buff,
//   szTextFileName vide, l'un des deux gabarits (comme les buffs mondiaux) :
//     IK1_SYSTEM / IK2_SYSTEM / IK3_SCROLL (parchemin) : pose en BUFF_ITEM,
//       dwSkillTime numerique (icone de la barre de buffs) ;
//     IK1_SYSTEM / IK2_BUFF2 / IK3_ANARCHY ou IK3_SCROLL : pose en BUFF_ITEM2.
//   La duree vient de la reserve, jamais de dwSkillTime ni de dwAbilityMin.
//
// Commandes : /perinbuff (fenetre, tout joueur) ; MJ : /perinbuff liste |
// ajouter <n> | retirer <n> | niveau <n> | vider | remplir ; administrateur :
// /perinbuff recharger.

Config
{
	PerteMinutes    30
	InvestMax       100
	Annonces        1
	AnnonceInvest   1
	Monnaie         II_SYS_SYS_SCR_PERIN
	IconeHud        II_SYS_SYS_SCR_PERIN
}

Paliers
{
	// <Perins>  <Nom>           <ItemProp buff>
	25          "Palier I"       II_BUFF_ZCK_PERIN1      // Perin de Sagesse     experience +15 %
	50          "Palier II"      II_BUFF_ZCK_PERIN2      // Perin de Vigueur     PV max +10 %, defense +5 %
	75          "Palier III"     II_BUFF_ZCK_PERIN3      // Perin de Puissance   attaque +8 %, degats critiques +10 %
	100         "Palier IV"      II_BUFF_ZCK_PERIN4      // Perin de Fortune     degats monstres +10 %, penya +20 %
}
```
<!-- ZCKMD:FIN idx=235 -->

<a id="f236"></a>
### 236 — `ZckPerinBuff.sav`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckPerinBuff.sav` |
| Taille source | 282 octets |
| Encodage détecté | utf-8 |
| BOM d'origine | non |
| Fin de ligne | CRLF |
| Lignes | 12 |
| SHA-256 source | `3c4ad7a3ad8d39fd491fe96b5eb0f765d50cb448b2b78dea051a266b2160d35f` |
| Caractères décodés | 282 |
| Caractères écrits | 282 |
| Saut de ligne final d'origine | oui |

<!-- ZCKMD v=1 idx=236 mode=texte enc=utf-8 bom=0 nlajoute=0 cloture=3 octets=282 sha256=3c4ad7a3ad8d39fd491fe96b5eb0f765d50cb448b2b78dea051a266b2160d35f chemin64=WmNrUGVyaW5CdWZmLnNhdg== -->
```text
ZCKPERINBUFF 1
RESERVE	73	900
JOUEUR	1	102
CONTRIB	1790691127	2	Zacks
CONTRIB	1790631800	11	Zacks
CONTRIB	1790631798	25	Zacks
CONTRIB	1790631797	25	Zacks
CONTRIB	1790631792	25	Zacks
CONNU	8512	1791706269
CONNU	8513	1791706269
CONNU	8514	1791706269
CONNU	8515	1791706269
```
<!-- ZCKMD:FIN idx=236 -->

<a id="f237"></a>
### 237 — `ZckPositionH.txt`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckPositionH.txt` |
| Taille source | 10 798 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 171 |
| SHA-256 source | `85805d5dec6a155030d88f2500ab6c35987d114c3fd04aa3a3572cc0f72a4d4d` |
| Caractères décodés | 5 398 |
| Caractères écrits | 5 399 |
| Saut de ligne final d'origine | non |

<!-- ZCKMD v=1 idx=237 mode=texte enc=utf-16-le bom=1 nlajoute=1 cloture=3 octets=10798 sha256=85805d5dec6a155030d88f2500ab6c35987d114c3fd04aa3a3572cc0f72a4d4d chemin64=WmNrUG9zaXRpb25ILnR4dA== -->
```text
//------------------------------------------------------------------------
// ZckPositionH.txt - positions, couleurs et lignes de la fenetre personnage.
// Toute modification est prise en compte au redemarrage du client, sans
// recompilation.
//
// Repere : (0,0) = coin haut gauche de la zone de dessin de l'onglet
// Informations. Surface utile mesuree sur capture : 382 x 429.
//
// STRUCTURE DU SKIN, relevee au pixel sur WndNewCharacterBlack.tga :
//   trait vertical a x=221  -> la colonne droite commence a 226, jamais avant
//   panneau gauche decoupe par des traits horizontaux a y = 5, 25, 104, 127,
//   229 et 316. Les blocs doivent tenir DANS ces bandes :
//      5..25    bandeau du titre 'Info Personnage'
//      25..104  les 5 lignes Nom / Cla. / Niveau / Serveur / Canal
//    104..127   bandeau du titre 'Stats du perso'
//    127..229   bloc detail : ATK, DEF, Vit.atq, Critique
//    229..316   stats de base : FOR, END, DEX, INT
//    316..429   Points de stats, puis les boutons Ok et Annuler
//   panneau droit : aucun trait horizontal, libre de 30 a 429.
//------------------------------------------------------------------------

Zck_PositionH_Layout
{
	// Garde-fou : si le client reel est plus petit, un message est journalise
	// une seule fois au premier affichage.
	nClientWidthMin			380
	nClientHeightMin		420

	// Titres des quatre colonnes.
	nTitleInfoY				10
	nTitleInfoLeftX			9
	nTitleInfoRightX		226
	nTitleStatsY			109
	nTitleStatsLeftX		9
	nTitleStatsRightX		226

	// Colonne haut gauche : Nom, Classe, Niveau, Serveur, Canal.
	nInfoLabelX				10
	nInfoValueX				80
	nInfoRowY				31
	nInfoRowStep			15

	// Colonne haut droite : bloc Zck_PositionH_Info.
	nInfoRightLabelX		226
	nInfoRightValueX		284
	nInfoRightRowY			31
	nInfoRightRowStep		15

	// Icone Maitre / Heros, posee a droite du niveau.
	nIconLevelX				97
	nIconLevelHighX			103
	nIconOffsetX			3

	// Bloc detail : deux colonnes de deux lignes.
	nDetailLabelLeftX		10
	nDetailValueLeftX		48
	nDetailLabelRightX		102
	nDetailValueRightX		165
	nDetailRowY				156
	nDetailRowStep			30

	// Statistiques de base et leurs controles.
	// ATTENTION : les quatre emplacements arrondis sont DESSINES DANS LA
	// TEXTURE WndNewCharacterBlack.tga, aux coordonnees x 95..125,
	// y 234..248 / 250..263 / 265..278 / 280..293, soit un pas de 15.
	// Les valeurs ci-dessous calent les vrais champs de saisie dessus.
	// Si tu changes nStatRowY ou nStatRowStep, les champs quitteront les
	// emplacements peints et l'ecran redeviendra incoherent.
	nStatLabelX				10
	nStatValueX				50
	nStatRowY				237
	nStatRowStep			15
	nStatGpValueX			132
	nStatEditX				96
	nStatEditWidth			30
	nStatEditHeight			16
	nStatEditOffsetY		2
	nStatButtonX			130
	nStatButtonWidth		16
	nStatButtonGap			2
	nStatButtonHeight		14
	nAutoStatX				168
	nAutoStatWidth			14
	nAutoStatHeight			14

	// Colonne droite defilante : bloc Zck_PositionH_Stats.
	// nOtherRightLimit borne l'ecriture : une valeur trop large est decalee
	// vers la gauche au lieu de deborder.
	nOtherNameX				226
	nOtherValueX			304
	nOtherRowY				156
	nOtherRowStep			20
	nOtherVisible			8
	nOtherRightLimit		348

	nScrollLeft				350
	nScrollTop				150
	nScrollRight			366
	nScrollBottom			313

	// Boutons Ok et Annuler, positionnes par leur centre.
	nButtonOkCenterX		60
	nButtonCancelCenterX	150
	nButtonY				355
	nButtonWidth			75
	nButtonHeight			25

	// Seuils de couleur du ping, en millisecondes.
	nPingGoodMax			70
	nPingWarnMax			100
}

Zck_PositionH_Colors
{
	dwTitle			0xFFFFFFFF
	dwLabel			0xFFF6CC4D
	dwValue			0xFFFFFFFF
	dwValueUp		0xFF4A7BC5
	dwValueDown		0xFFFF0000
	dwFlash			0xFFFF0000
	dwPingGood		0xFF33CC33
	dwPingWarn		0xFFFFA500
	dwPingBad		0xFFFF0000
}

// Exactement quatre titres, dans cet ordre :
// haut gauche, haut droite, detail gauche, detail droite.
Zck_PositionH_Titles
{
	Titre	"Info Personnage"
	Titre	"Autre Infos"
	Titre	"Stats du perso"
	Titre	"Autre Stats"
}

// Colonne haut droite. Sources autorisees : PRESTIGE, WORLD, PING, BADGE.
// Au maximum 8 lignes.
Zck_PositionH_Info
{
	Ligne	"Prestige"		PRESTIGE
	Ligne	"Position"		WORLD
	Ligne	"Ping"			PING
	Ligne	"Badge"			BADGE
}

// Colonne droite defilante.
// Format : Stat <libelle> <source> [param] <pourcentage>
//   <libelle>       chaine entre guillemets, ou identifiant TID_* connu
//   <source>        SPEED_RUN, SPELL_SPEED, CRITICAL_RATE, DODGE_RATE,
//                   HIT_RATE, BLOCK_MELEE, BLOCK_RANGE, PVP_DAMAGE,
//                   ou PARAM
//   [param]         uniquement si la source vaut PARAM : identifiant DST_*
//                   ou sa valeur numerique
//   <pourcentage>   1 = suffixe '%', 0 = valeur brute
//
// Exemple d'ajout d'une statistique brute :
//   Stat	"Bonus d'exp"	PARAM	DST_EXPERIENCE	1
// Si le moteur de script ne connait pas le symbole DST_EXPERIENCE, le
// chargement echoue en le nommant : remplace-le alors par sa valeur
// numerique, prise dans defineJob.h.
Zck_PositionH_Stats
{
	Stat	TID_CRT_RATE	CRITICAL_RATE	1
	Stat	TID_DODGE		DODGE_RATE		1
	Stat	TID_HIT_RATE	HIT_RATE		1
	Stat	TID_M_BLOCK		BLOCK_MELEE		1
	Stat	TID_R_BLOCK		BLOCK_RANGE		1
	Stat	TID_SPD_RUN		SPEED_RUN		1
	Stat	TID_SPL_SPEED	SPELL_SPEED		1
	Stat	TID_PVP_DAMAGE	PVP_DAMAGE		1
}
```
<!-- ZCKMD:FIN idx=237 -->

<a id="f238"></a>
### 238 — `ZckPrestige.inc`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckPrestige.inc` |
| Taille source | 580 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 16 |
| SHA-256 source | `e82b321c1595dacf0b6c555e578975aeac0c18a98787a524d1e921dac8e69a73` |
| Caractères décodés | 289 |
| Caractères écrits | 290 |
| Saut de ligne final d'origine | non |

<!-- ZCKMD v=1 idx=238 mode=texte enc=utf-16-le bom=1 nlajoute=1 cloture=3 octets=580 sha256=e82b321c1595dacf0b6c555e578975aeac0c18a98787a524d1e921dac8e69a73 chemin64=WmNrUHJlc3RpZ2UuaW5j -->
```text
Zck_Prestige_Config
{
    nRequiredLevel = 200;
    nResetLevel = 60;
    nMaxPrestige = 10;

    nBonusStr = 10;
    nBonusSta = 10;
    nBonusDex = 10;
    nBonusInt = 10;

    fExpDivisor = 1.2;

    dwRequiredItemId = II_PIERRE_DE_PRESTIGE;
    nRequiredItemCount = 1;
}
```
<!-- ZCKMD:FIN idx=238 -->

<a id="f239"></a>
### 239 — `ZckTourInfini.inc`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckTourInfini.inc` |
| Taille source | 5 028 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 71 |
| SHA-256 source | `834dbae17906eda91c4c0d28e40631bcb5fd55579983d5f3ab7eb36172da0322` |
| Caractères décodés | 2 513 |
| Caractères écrits | 2 514 |
| Saut de ligne final d'origine | non |

<!-- ZCKMD v=1 idx=239 mode=texte enc=utf-16-le bom=1 nlajoute=1 cloture=3 octets=5028 sha256=834dbae17906eda91c4c0d28e40631bcb5fd55579983d5f3ab7eb36172da0322 chemin64=WmNrVG91ckluZmluaS5pbmM= -->
```text
// Reborn-MMO - Tour infinie (__ZCK_TOUR_INFINI)
// Fichier lu par CZckTourInfiniMng::ReadScript au demarrage du WorldServer.
// Une montee = une layer de SetTowerMapId. Cette map doit etre differente de
// SetClashMapId (ZckCombatMC.inc) et ne pas etre un donjon instancie.

// Map de la Tour, point d'arrivee dans la layer, sortie (map, x, z).
// CWorld::CreateLayer copie dans chaque layer les PNJ et objets de la map (.dyo) ;
// ses monstres natifs ne sont plus crees dans la Tour. Map conseillee : petite,
// sans PNJ, chargee par ce WorldServer, differente de SetClashMapId.
SetTowerMapId      = WI_DUNGEON_ABYSSEVENT
SetStartPos(282.0, 284.0)
SetReturnPort(WI_WORLD_MADRIGAL, 6975.6, 3331.5)

// Session quotidienne (comme le Monster Clash) : a chaque horaire AddTourTime,
// les inscriptions s'ouvrent au PNJ pendant SetRegisterMinutes, puis toutes les
// equipes inscrites partent ensemble. Aucune entree en dehors des sessions.
// AddTourTime(jour, HH:MM) : jour 0 = tous les jours, 1 = dimanche a 7 = samedi.
// Plusieurs lignes possibles. Ouverture manuelle : /tourstart (administrateur).
// SetMaxTeams : equipes par session (0 = sans limite). Toutes partent dans le
// meme tick avec une layer chacune : garder une limite basse sur une grande map
// (Madrigal), 0 ou une valeur haute sur une petite map.
SetRegisterMinutes = 5
SetMaxTeams        = 10
AddTourTime(0, 20:00)

// Entree

// Entree
SetMaxPlayers      = 4
SetEntryRange      = 30
SetMinLevel        = 60
SetEntryCost       = 1000000
SetCooldownMinutes = 30

// Deroulement
SetReadySeconds    = 10
SetBreakSeconds    = 10
SetFloorSeconds    = 600
SetMaxRunMinutes   = 60
SetLives           = 3
SetMaxFloor        = 0
SetCycleFrom       = 3

// Mise a l'echelle par etage (pourcents par etage) et drop (constant, > 0)
SetScalingHp       = 12
SetScalingAtk      = 6
SetScalingDef      = 4
SetDropFactor      = 1.0
SetRankingSize     = 20

// Recompenses : etage exact / tous les k etages
AddReward(5, II_SYS_SYS_SCR_PERIN, 1)
AddRewardEvery(10, II_SYS_SYS_SCR_PERIN, 2)

// Etages 1..N : au-dela de N, boucle sur SetCycleFrom..N
AddFloor 1
{
	AddMonster(MI_AIBATT1, 100.0, 100.0, 1)
	AddMonster(MI_AIBATT1, 105.0, 100.0, 1)
}
AddFloor 2
{
	AddMonster(MI_MUSHPANG1, 100.0, 100.0, 1)
	AddMonster(MI_MUSHPANG1, 105.0, 105.0, 1)
}
AddFloor 3
{
	AddMonster(MI_BURUDENG1, 100.0, 100.0, 1)
	AddMonster(MI_BURUDENG1, 105.0, 100.0, 1)
	AddMonster(MI_BURUDENG1, 100.0, 105.0, 1)
}
```
<!-- ZCKMD:FIN idx=239 -->

<a id="f240"></a>
### 240 — `ZckTourInfini.sav`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckTourInfini.sav` |
| Taille source | 37 octets |
| Encodage détecté | utf-8 |
| BOM d'origine | non |
| Fin de ligne | CRLF |
| Lignes | 2 |
| SHA-256 source | `721bc55e5bfd3658f2e237da3a15d66a8bc45fd52a145109a65cd1683a0be269` |
| Caractères décodés | 37 |
| Caractères écrits | 37 |
| Saut de ligne final d'origine | oui |

<!-- ZCKMD v=1 idx=240 mode=texte enc=utf-8 bom=0 nlajoute=0 cloture=3 octets=37 sha256=721bc55e5bfd3658f2e237da3a15d66a8bc45fd52a145109a65cd1683a0be269 chemin64=WmNrVG91ckluZmluaS5zYXY= -->
```text
ZCKTOUR 1
2	0	8	123	20260919	Zacks
```
<!-- ZCKMD:FIN idx=240 -->

<a id="f241"></a>
### 241 — `ZckWikiMonstres.inc`

| Champ | Valeur |
|---|---|
| Chemin relatif | `ZckWikiMonstres.inc` |
| Taille source | 1 266 octets |
| Encodage détecté | utf-16-le |
| BOM d'origine | oui |
| Fin de ligne | CRLF |
| Lignes | 19 |
| SHA-256 source | `3c3f71fdf00c78bdcc3dd619c5ffa5c361e060e9e320f9718e397665c5620918` |
| Caractères décodés | 632 |
| Caractères écrits | 633 |
| Saut de ligne final d'origine | non |

<!-- ZCKMD v=1 idx=241 mode=texte enc=utf-16-le bom=1 nlajoute=1 cloture=3 octets=1266 sha256=3c3f71fdf00c78bdcc3dd619c5ffa5c361e060e9e320f9718e397665c5620918 chemin64=WmNrV2lraU1vbnN0cmVzLmluYw== -->
```text
// ZckWikiMonstres.inc
// Types d'IA acceptes dans la fenetre Wikipedia - Monstres.
// Un MoverProp dont le dwAI n'est pas liste ici n'apparait pas dans la liste.
//
// Les six valeurs ci-dessous sont exactement celles que la commande /cn
// accepte (TextCmd_CreateNPC) : tout monstre affiche est donc invocable.
// Les identifiants disponibles sont ceux de la table du parser :
// AII_NONE, AII_MONSTER, AII_PET, AII_EGG, AII_CLOCKWORKS, AII_BIGMUSCLE,
// AII_KRRR, AII_BEAR, AII_METEONYKER, AII_VER2_TYPE0.

Ia
{
    AII_MONSTER
    AII_CLOCKWORKS
    AII_BIGMUSCLE
    AII_KRRR
    AII_BEAR
    AII_METEONYKER
}
```
<!-- ZCKMD:FIN idx=241 -->

---

## Annexe — fichiers binaires

Ces fichiers ne sont pas du texte : leur contenu n'est pas recopié dans ce document (mode `--binaires appendice`). Relancer avec `--binaires base64` pour les inclure intégralement.

| # | Chemin relatif | Taille source | Type détecté | SHA-256 source |
|---|---|---|---|---|
| 3 | `assimp-vc140-mt.dll` | 3 270 144 octets | EXE/DLL (PE) | `41e7fde288f5ad7ee33c572ae822f1d074cd35b2127e17958140ea85e4a71a49` |
| 4 | `assimp-vc141-mt.dll` | 3 343 360 octets | EXE/DLL (PE) | `4abb3cda0a256ec938ffbe2c306be19ea1e37550131aa6d42bc970e994aad082` |
| 6 | `AtoolsX_Licensing.dll` | 423 892 octets | EXE/DLL (PE) | `1a04edbc4cd83416ca7a1b571a95b696661dcb35abc0eca4ba7c1a287edcc9ca` |
| 7 | `AToolsXInstaller.exe` | 11 242 496 octets | EXE/DLL (PE) | `b921548bcc115b44d3a695dfc190d639e6baea7dfeffd7dbfa8c54b5c56bc70b` |
| 22 | `D3DCompiler_43.dll` | 2 106 216 octets | EXE/DLL (PE) | `2f23182ec6f4889397ac4bf03d62536136c5bdba825c7d2c4ef08c827f3a8a1c` |
| 23 | `d3dx9_43.dll` | 1 998 168 octets | EXE/DLL (PE) | `0b28546be22c71834501f7d7185ede5d79742457331c7ee09efc14490dd64f5f` |
| 25 | `dbghelp.dll` | 163 088 octets | EXE/DLL (PE) | `5af2fc15bcf4f6d7fddd7285dbe9934b660ca4a6b5a7f909e83f8ab99bd1a531` |
| 42 | `defineText.h.bak` | 163 213 octets | binaire (extension .bak) | `62e2c2283ef3bcb630e04bb14423999f8f70b850feb4eb7dee17f4486691f59f` |
| 44 | `DevIL.dll` | 1 482 240 octets | EXE/DLL (PE) | `63cc8eacf8c415b00aa57f235c58040fdd437c6afa0c936ad9c87f33feeab2ca` |
| 46 | `DSETUP.dll` | 60 416 octets | EXE/DLL (PE) | `794c2af407df2c63694a1f8c66258296aac780508d94be47a5c5807eeac5a8e4` |
| 59 | `ffmpeg.exe` | 87 429 632 octets | EXE/DLL (PE) | `b90225987bdd042cca09a1efb5e34e9848f2d1dbf5fbcd388753a44145522997` |
| 60 | `FloatToString.dll` | 31 744 octets | EXE/DLL (PE) | `5522fb6586aea0968d032f3e044345d3718571628d9f8b1527e9d8e743d29664` |
| 61 | `fmod.dll` | 162 816 octets | EXE/DLL (PE) | `1e08da161cf78746304a834973971ee47a24817ee4e28df74e3f37dbbb383b22` |
| 62 | `fmod64.dll` | 413 184 octets | EXE/DLL (PE) | `24b8aa4a795f4df3c603812a61ed3324923f6a69abe73683539368a45cb440ec` |
| 67 | `icudt53.dll` | 21 529 088 octets | EXE/DLL (PE) | `24d7d65ed8d0ae74f99fecc99a279bae611b526d4dc7486a022c78a24de42701` |
| 68 | `icuin53.dll` | 1 982 976 octets | EXE/DLL (PE) | `c689290376c1b01ddc4d0776921c182df463cf375f87f595be10468b4312f4e9` |
| 69 | `icuuc53.dll` | 1 355 264 octets | EXE/DLL (PE) | `f44c0ea71506c6cf0fad935ceb858ced7a3e0a12e1399c4c147e41659ac7f0bb` |
| 70 | `ILU.dll` | 100 352 octets | EXE/DLL (PE) | `b7ed4d93e8e3aa7f80e64ea3466b049f7841b7631f57c584c113d92fb4af9ade` |
| 71 | `ILUT.dll` | 29 696 octets | EXE/DLL (PE) | `eb4dcaedf8f8573a323dc23a790155312bb897275cd9d65d54dc17f39fdde605` |
| 78 | `libEGL.dll` | 13 312 octets | EXE/DLL (PE) | `17ef455fee86234a451e8ee3631954a9c9cb12ded863ab31b4dadd21d18e8f8e` |
| 79 | `libGLESV2.dll` | 1 950 720 octets | EXE/DLL (PE) | `d7c492b123b166073dc41d5d6b580e45983b650d43b18e5f7c6521ccbc521b83` |
| 91 | `mss32.dll` | 449 024 octets | EXE/DLL (PE) | `d7a73a1b0e005d0f4ce1437c13196b9967c801d5cbc0c8ebcde8977d265f55fd` |
| 92 | `mssmp3.asi` | 137 216 octets | EXE/DLL (PE) | `93b4322c8266ed4c05e5abbfcdba81537e557072ad6c752d899178952bcf5c29` |
| 93 | `mssogg.asi` | 41 472 octets | EXE/DLL (PE) | `ad874b9c432f14fe3409f393c72ca2f74f92af98dc5f0d045b7f701b5b7e1def` |
| 94 | `msvcp120.dll` | 455 328 octets | EXE/DLL (PE) | `87c42ca155473e4e71857d03497c8cbc28fa8ff7f2c8d72e8a1f39b71078f608` |
| 95 | `msvcr120.dll` | 970 912 octets | EXE/DLL (PE) | `86e39b5995af0e042fcdaa85fe2aefd7c9ddc7ad65e6327bd5e7058bc3ab615f` |
| 96 | `NeuzD.dll` | 32 828 octets | EXE/DLL (PE) | `21a15106da01feb043d549c852b64471f3a6ea26c98e0fe52a4cdd21f3c7daea` |
| 98 | `opengl32sw.dll` | 15 995 904 octets | EXE/DLL (PE) | `25ae7577e066fa80519a8f1c314b15cdd22e4a8d3ecd2a36eccc79e40714a91d` |
| 114 | `propItem.csv.bak` | 4 659 417 octets | binaire (extension .bak) | `6a309c5699390bc9c96b122f09611c89735d208ce617448f369b37844251034e` |
| 148 | `Qt5Core.dll` | 4 873 216 octets | EXE/DLL (PE) | `96a9f2b283262615be3077af5bfc45b6476a14baa5de1b71ba68959e41786b64` |
| 149 | `Qt5Cored.dll` | 10 422 784 octets | EXE/DLL (PE) | `f366c0931d757fb8aa601663be4e231102a035c3cd4a79cec9019b9ce6764d1d` |
| 150 | `Qt5Gui.dll` | 5 195 776 octets | EXE/DLL (PE) | `438c2952f60fc45f6c5ede2aa71cf0ed8139767af544137b45f88c467f6cb444` |
| 151 | `Qt5Guid.dll` | 11 149 312 octets | EXE/DLL (PE) | `10ecfbb2945f3afe0e9dfc648d516d25bdfbd46129f59fb99cf8e7f071a02092` |
| 152 | `Qt5Multimedia.dll` | 581 632 octets | EXE/DLL (PE) | `6e1a827af9552e36d4d7e7b6257d6c424ca1dbc8607f28f9f95606a0a79769f7` |
| 153 | `Qt5Multimediad.dll` | 1 426 944 octets | EXE/DLL (PE) | `9d7696eeb8990f42ce5f593c92cc8b7c88d912c4233a7cb8ad1c72d1803cc87b` |
| 154 | `Qt5MultimediaQuick.dll` | 91 136 octets | EXE/DLL (PE) | `5d1cf4ab2f71b7315261603352244a9304ab2fb53f2fdff888e9b383d5ad2307` |
| 155 | `Qt5MultimediaQuickd.dll` | 209 408 octets | EXE/DLL (PE) | `110f79b03d17f1bec66d21bff1b980bef4821d91177da51147fb21de7f45caab` |
| 156 | `Qt5MultimediaWidgets.dll` | 83 456 octets | EXE/DLL (PE) | `e8dab41a3601399f8264022d6bb9933fc38d21686659d578bb4fff639612f7e6` |
| 157 | `Qt5MultimediaWidgetsd.dll` | 190 464 octets | EXE/DLL (PE) | `ac57c5b5325e6786db87c0b6133c124a8b6600550b88beccb62f18732b5e2cf7` |
| 158 | `Qt5Network.dll` | 983 552 octets | EXE/DLL (PE) | `1c5d96e8f608c30d696c8c0d4c9b62667fe43f81b99c36d4ed48e6026adfc133` |
| 159 | `Qt5NetworkAuth.dll` | 124 928 octets | EXE/DLL (PE) | `aaa2b9a9c7a52bfdd1cc656f86442644167628ae8b470b397df2fc4495286b2a` |
| 160 | `Qt5NetworkAuthd.dll` | 276 480 octets | EXE/DLL (PE) | `c81ac451068af1d6944915c55b7c7a8de3bdb66006af9002a508db2b2c75922a` |
| 161 | `Qt5Networkd.dll` | 2 873 344 octets | EXE/DLL (PE) | `188cf6d0b90a219882aab02809dfbae8973c6555d99ca4cc145040d1ef49fad4` |
| 162 | `Qt5Svg.dll` | 265 216 octets | EXE/DLL (PE) | `de58cfb6f356b5aa3349a05e5ed02b22eb78e49f083321141644abeda6df0aee` |
| 163 | `Qt5Widgets.dll` | 4 428 800 octets | EXE/DLL (PE) | `a5f842520a10173d6165b8652fd0ffddd6270b38de13e9c02acc6a8b775778b2` |
| 164 | `Qt5Widgetsd.dll` | 8 823 296 octets | EXE/DLL (PE) | `777503b4b12fe6fd716a693739da61cc3a5cc69a8226f386c71cc0cd25522625` |
| 165 | `Qt5Xml.dll` | 150 016 octets | EXE/DLL (PE) | `0bce28800c3964f907c6583833dbd5ac2d4d3622e1097f73a97e2a2827d8ce74` |
| 166 | `Qt5Xmld.dll` | 312 832 octets | EXE/DLL (PE) | `1b961aad1b740d80430a73e7de0b109ac051d6d84b51dfe6a4f1db51ab302ae2` |
| 167 | `qtaudio_wasapi.dll` | 87 672 octets | EXE/DLL (PE) | `75ee05fcec3d14ad17acb6a80c0fdca6dd933a67f9bc117fd1c0c8625ff886f9` |
| 168 | `qtaudio_wasapid.dll` | 972 408 octets | EXE/DLL (PE) | `ba0f1daa7d2a6990297e077d1797f072c4dee04b7ba5bb85d1e803ce0c65dbb3` |
| 169 | `qtaudio_windows.dll` | 53 368 octets | EXE/DLL (PE) | `237d7ff677df368329d0b0c969f9c7b69179395a2f2f6f61f567e367b727a114` |
| 170 | `qtaudio_windowsd.dll` | 187 000 octets | EXE/DLL (PE) | `c6fb18c049b0c778583d5cc90d7c9499b44a20fcda936cac99323d5cd795fe3a` |
| 171 | `qtmedia_audioengine.dll` | 55 416 octets | EXE/DLL (PE) | `2269b681d12a85d20158b479079831b63791613436829e1df7f1cdedb31d0dff` |
| 172 | `qtmedia_audioengined.dll` | 213 624 octets | EXE/DLL (PE) | `2f6a2db59330a9530cdf26a4ca13ab71e252acb316d2a21097cd78786bc92982` |
| 173 | `qtmultimedia_m3u.dll` | 20 992 octets | EXE/DLL (PE) | `6b9aef63c45f147d0a4c6c8313c09adafd9c979c17b25e1424b99ccc62c1dd67` |
| 176 | `qwindows.dll` | 1 221 752 octets | EXE/DLL (PE) | `2565fe1111bf0ba6b98683030b8da92f77da877d0a981f712184e4ce5018b723` |
| 177 | `qwindowsvistastyle.dll` | 128 632 octets | EXE/DLL (PE) | `424ba260332cf1d7b45813032ecba9150f59fb5c5f966eae63675e376e3d0ed1` |
| 178 | `qwindowsvistastyled.dll` | 328 312 octets | EXE/DLL (PE) | `7ce5509633d200a446ccce92e19a3b1e345aa6d274767f1c4e2fad465d4b5272` |
| 179 | `qxdgdesktopportal.dll` | 49 784 octets | EXE/DLL (PE) | `6a902e7948cf408dd36cac2c59e2e279eac1583dc38cbe121f50b4b127a1e66e` |
| 180 | `qxdgdesktopportald.dll` | 157 304 octets | EXE/DLL (PE) | `f92a37d612d81d3d0a3e4400845f52277d0bd9b17969a4f990de5661bd715dce` |
| 201 | `textClient.txt.txt.bak` | 211 986 octets | binaire (extension .bak) | `0217df5b86eb2dbc8f61d4880ba2bebfca595122d344e89b36704dbc43f51299` |
| 206 | `updater.exe` | 1 136 128 octets | EXE/DLL (PE) | `4409fe074a6cfd697d47edb8de47f4959eae43d798362889cb9a33763e7ab4df` |
| 212 | `WorldDialog.dll` | 843 776 octets | EXE/DLL (PE) | `77a34aaa91774d06643749ca9761bfeb4e6ee623a56c50842d0d1770bf299c64` |
| 214 | `ZacksEditeur.exe` | 66 537 955 octets | EXE/DLL (PE) | `1d2ffa1f5269aaf1dcfb248aa262575b30b008a0d83fc680d89a49eb2932988e` |

